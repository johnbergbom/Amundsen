#ifndef _DISPLAY_
#define _DISPLAY_

#include "bitboards.h"

char getPieceLetter(int piece);

void showboard(struct board *board);

#ifndef AM_DEBUG
void showsettings(int *white, int *black, int *vemstur, int *started);
#else
void showsettings(int *white, int *black, int *vemstur, int *started, int gamelog);
#endif

void showhelp(int);

#endif      //_DISPLAY_
