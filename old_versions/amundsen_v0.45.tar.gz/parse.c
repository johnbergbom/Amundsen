#include "parse.h"
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include "alfabeta.h"
#include "iterdeep.h"
#include "moves.h"
#include "genmoves.h"
#include "display.h"
#include "timectrl.h"
#include "eval.h"
#include "hash.h"
#include "misc.h"
#include "slump.h"

//int xboard_mode = 0;
int mode = NORMAL_MODE;
struct move **historik;
int histpos = 0;
int hlistsize = 100;
int book;
int white = HUMAN;     //by default white is a human
int black = COMPUTER;  //by default the engine is black

#ifdef AM_DEBUG
int gamelog = 0;
#endif

extern int zugswang;
extern int endgame;
extern int probes;
extern int sc_hits;
extern int m_hits;
extern int b_hits;
extern int misses;
int tot_probes = 0, tot_hits = 0; //, tot_misses = 0;
extern int visited_nodes;
extern int node_count_at_last_check;
extern int quiescence_nodes;
extern int pawn_probes;
extern int pawn_hits;
extern int pawn_misses;
extern int presearch_pieceval[2];
extern int presearch_pawnval[2];
extern struct killers **killers;
extern int cutoffs;
extern int cutoffs_first;
extern int searches;
extern int search_depth;
extern int latte0;
extern struct board *board;
extern struct refutation_entry *ref_table;
extern struct transposition_entry *transp_table;
extern struct pawn_entry *pawn_table;
extern bitboard square[64];
extern int own_time;
extern int opp_time;
extern int timectrl;
extern int moves_per_timecontrol;
extern int base;
extern int increment;
extern int post;
extern int64 vain_thinking;
extern int abort_search;
extern int total_time_aborts;
extern int early_time_aborts;
extern int late_time_aborts;
extern int early_level_completed_time_aborts;
extern int late_level_completed_time_aborts;

extern int ending_search1;
extern int ending_search2;
extern int ending_search3;
extern int ending_search4;
extern int ending_search5;
extern int ending_search6;
extern int ending_search7;
extern int ending_search8;
extern int ending_search9;
extern int ending_search10;



/* This function reallocates the size of a list in the memory. */
int change_list_size(struct move **list, int new_size) {
  struct move *new_list;

  if((new_list = (struct move *) realloc(*list,(new_size + 1)*sizeof(struct move))) == NULL) {
    perror("Realloc failed");
    exit(1);
  } else
    *list = new_list;
  
  return new_size;
}

void move2history(struct move *move) {
  (*historik)[histpos++] = *move;

  if (histpos > hlistsize - 50) {
    infolog("Increasing size of game history.\n");
    hlistsize = change_list_size(historik,hlistsize + 100);
  }
}

/* This function returns 0 if game is not ended, 1 if stalemate,
   2 if check mate, 3 if draw by the 50 move rule, 4 if
   insufficient material, and 5 if draw by repetition */
int game_ended(struct board *brd, int color_to_move) {
  struct moves moves[16];
  int movables, piece_nbr;
  bitboard target;
  struct move move;
  struct board newpos;
  int color = color_to_move;

  /* If there is no pawns on the board, it could be insufficient material
     left to win the game. */
  if ((brd->piece[WHITE][PAWN] == 0) && (brd->piece[BLACK][PAWN] == 0)) {
    /* If there is no queens or rooks left on the board, it's possibly
       insufficient material left. */
    if ((brd->piece[WHITE][QUEEN] == 0) && (brd->piece[WHITE][ROOK] == 0)
	&& (brd->piece[BLACK][QUEEN] == 0) && (brd->piece[BLACK][ROOK] == 0)) {
      /* If neither player has at least 2 bishops, it could be a draw. */
      if ((bitcount(brd->piece[WHITE][BISHOP]) < 2)
	  && (bitcount(brd->piece[BLACK][BISHOP]) < 2)) {
	/* If neither player has at least a bishop and a knight, then
	   it's a draw. */
	if (((brd->piece[WHITE][BISHOP] == 0)
	     || (brd->piece[WHITE][KNIGHT] == 0))
	    && ((brd->piece[BLACK][BISHOP] == 0)
		|| (brd->piece[BLACK][KNIGHT] == 0))) {
	  return 4;
	}
      }
    }
  }


  /* Basically what we do in this function, is this:
     if (can make move which doesn't place him in check)
       return game is not over;
     else {
       if (in check now)
         return game is lost;
       else
         return stalemate;
     }
  */

  if (generate_moves(brd,color,moves,&movables) != 0) {
    /* If we get here, it means that the last move by the opponent
       left him in check, which is illegal. */
    infolog("ERROR! ILLEGAL POSITION!");
    printf("ERROR! ILLEGAL POSITION!\n");
    exit(1);
  }

  /* Try to make all the moves, and see if the player is still in check. */
  piece_nbr = 0;
  while (piece_nbr < movables) {
    while (moves[piece_nbr].targets != 0) {
      target = getlsb(moves[piece_nbr].targets);
      move.fsquare = moves[piece_nbr].source;
      move.tsquare = target;
      move.piece = moves[piece_nbr].piece;
      move.type = get_movetype(brd,color,
			       get_first_bitpos(moves[piece_nbr].source),
			       moves[piece_nbr].piece,target);
      makemove(brd,&newpos,color,move,0);
      if (!in_check(&newpos,color)) {
	/* The player has a move that will not place him in check.
	   So the game is not over, unless the 50 move rule or
	   draw by repetition rule apply. */
	if (brd->moves_left_to_draw <= 0)
	  return 3;
	else if (get_repetitions(brd) > 2)
	  return 5;
	else
	  return 0;
      }
      moves[piece_nbr].targets = moves[piece_nbr].targets & ~target;
    }
    piece_nbr++;
  }
  /* Every move places him in check. The game is over. */
  if (in_check(brd,color))
    return 2;     //the game is lost
  else
    return 1;     //stalemate
}

void preanalysis(struct board *brd, int color, struct move **movelist, int *mcount) {
  int movables = 0, piece_nbr = 0, nbr_moves = 0, i;
  struct moves moves[16];
  bitboard typetargets, target;
  int pieces[2];
  int pawns[2];

  sc_hits = 0;
  m_hits = 0;
  b_hits = 0;
  misses = 0;
  probes = 0;
  /* Make sure node_count_at_last_check is zeroed at the
     same time as visited_nodes. */
  visited_nodes = node_count_at_last_check = 0;
  quiescence_nodes = 0;
  pawn_probes = 0;
  pawn_hits = 0;
  pawn_misses = 0;

  for (i = 0; i < 2; i++) {
    pawns[i] = bitcount(brd->piece[i][PAWN]);
    pieces[i] = bitcount(brd->piece[i][KNIGHT])
      + bitcount(brd->piece[i][BISHOP])
      + bitcount(brd->piece[i][ROOK])
      + bitcount(brd->piece[i][QUEEN]);
  }

  /* Check the material values. */
  for (i = 0; i < 2; i++) {
    presearch_pawnval[i] = bitcount(brd->piece[i][PAWN])*VAL_PAWN;
    presearch_pieceval[i] = bitcount(brd->piece[i][KNIGHT])*VAL_KNIGHT
      + bitcount(brd->piece[i][BISHOP])*VAL_BISHOP
      + bitcount(brd->piece[i][ROOK])*VAL_ROOK
      + bitcount(brd->piece[i][QUEEN])*VAL_QUEEN
      + bitcount(brd->piece[i][KING])*VAL_KING;
  }

  /* See if we are in a position which could possibly contain zugswang
     issues. If so, then we shouldn't use null-move pruning. */
  if (pieces[WHITE] < 2 || pieces[BLACK] < 2)
    zugswang = 1;
  else
    zugswang = 0;

  /* See if we are in some type of particular endgame which we know how
     to handle. */
  if ((pieces[WHITE] == 0 && pieces[BLACK] == 1 && brd->piece[BLACK][ROOK])
      || (pieces[BLACK] == 0 && pieces[WHITE] == 1
	  && brd->piece[WHITE][ROOK]))
    endgame = KRK;
  else if ((pieces[WHITE] == 0 && pieces[BLACK] == 1
	    && brd->piece[BLACK][QUEEN])
	   || (pieces[BLACK] == 0 && pieces[WHITE] == 1
	       && brd->piece[WHITE][QUEEN]))
    endgame = KQK;
  else if (((brd->material_pieces[WHITE] + brd->material_pieces[BLACK])
	    <= (VAL_KING*2 + VAL_QUEEN*2))
	   || (brd->material_pieces[WHITE] <= VAL_KING + VAL_ROOK)
	   || (brd->material_pieces[BLACK] <= VAL_KING + VAL_ROOK))
    endgame = UNKNOWN_ENDGAME;
  else
    endgame = 0;

  if (endgame == KQK)
    printf("KQK-endgame\n");
  else if (endgame == KRK)
    printf("KRK-endgame\n");
  else if (endgame == UNKNOWN_ENDGAME)
    printf("UNKNOWN_ENDGAME\n");

  /* A board position should be in a legal state upon calling this
     function, so we should never be able to take the opponents king. */
  if (generate_moves(brd,color,moves,&movables) != 0) {
    infolog("ERROR!!! ILLEGAL MOVES SHOULD NOT BE FOUND HERE!");
    printf("ERROR!!! ILLEGAL MOVES SHOULD NOT BE FOUND HERE!\n");
    exit(1);
  }

  /* Count the number of possible moves, so we know how to initialize
     the movelist. */
  for (i = 0; i < movables; i++)
    nbr_moves += bitcount(moves[i].targets);
  *movelist = (struct move *) malloc(nbr_moves*sizeof(struct move));

  /* Go through all movable pieces and add them to the movelist. */
  for (piece_nbr = 0; piece_nbr < movables; piece_nbr++) {
      typetargets = moves[piece_nbr].targets;
      /* Go through the targets one at a time. */
      while (typetargets != 0) {
        target = getlsb(typetargets);
        (*movelist)[*mcount].fsquare = moves[piece_nbr].source;
        (*movelist)[*mcount].tsquare = target;
        (*movelist)[*mcount].piece = moves[piece_nbr].piece;
        (*movelist)[*mcount].type = get_movetype(brd,color,get_first_bitpos(moves[piece_nbr].source),moves[piece_nbr].piece,target);
	(*movelist)[*mcount].value = 0; //so we can check if != KINGTAKEN
        (*mcount)++;
        typetargets = typetargets & ~target;
      }
  }

  return;
}

void postanalysis(struct board *brd, struct move **movelist, int mcount,
		  int color, struct move *returnmove) {
  struct move *validmoves;
  struct move *goodmoves;
  struct move *bestmoves;
  int i, j, b, bestvalue;
  struct board newpos;
  char *str;

  str = (char *) malloc(500*sizeof(char));
  printf("\n");
  printf("Visited nodes tot = %d\n",visited_nodes);
  printf("Hash tot: probes = %d, sc_hits = %d, m_hits = %d, b_hits = %d, ",probes,sc_hits,m_hits,b_hits);
  printf("misses = %d, rate = %f\n",misses,(double)(sc_hits+m_hits+b_hits)/(probes));
  tot_probes += probes;
  tot_hits += sc_hits + m_hits + b_hits;
  printf("Total hashrate = %f\n",(double) tot_hits/tot_probes);
  printf("Visited nodes quies = %d\n",quiescence_nodes);
  printf("Pawn hash: probes = %d, hits = %d, misses = %d, rate = %f\n",pawn_probes,pawn_hits,pawn_misses,(double)(((double)pawn_hits)/((double)pawn_probes)));
  printf("Cutoff rate: %f (%d/%d)\n",(double)cutoffs_first/cutoffs,cutoffs_first,cutoffs);
  sprintf(str,"Percentage early level completed time aborts %f",(double)(((double)early_level_completed_time_aborts)/((double)early_time_aborts)));
  infolog(str);
  sprintf(str,"Percentage late level completed time aborts %f",(double)(((double)late_level_completed_time_aborts)/((double)late_time_aborts)));
  infolog(str);
  sprintf(str,"Percentage total level completed time aborts %f",(double)(((double)(early_level_completed_time_aborts + late_level_completed_time_aborts))/((double)total_time_aborts)));
  infolog(str);
  printf("Avg. depth: %f\n",(double)search_depth/searches);
  printf("Vain thinking (sec): %f\n",(double)vain_thinking/1000);
  sprintf(str,"t1 = %d, t2 = %d, t3 = %d, t4 = %d, t5 = %d, t6 = %d, t7 = %d, t8 = %d, t9 = %d, t10 = %d",ending_search1,ending_search2,ending_search3,ending_search4,ending_search5,ending_search6,ending_search7,ending_search8,ending_search9,ending_search10);
  infolog(str);
  //printf("node_count_at_last_check = %d\n",node_count_at_last_check);

  /* Remove all invalid moves from the list. (The invalid ones have
     value == KINGTAKEN, those are the moves that checks one's own king) */
  validmoves = (struct move *) malloc(mcount * sizeof(struct move));
  j = 0;
  for (i = 0; i < mcount; i++)
    if ((*movelist)[i].value != KINGTAKEN)
      validmoves[j++] = (*movelist)[i];

  mcount = j;

  turn_off_hash();
  //set_fixed_thinking_time(1000);   //give it at most 1 second of search time.
  if (mcount > 0) {
    /* Put the best moves in the array goodmoves, and chose a random best move.
       (Provided there are several moves which are equally good.) */
    goodmoves = (struct move *) malloc(mcount * sizeof(struct move));
    bestvalue = validmoves[0].value;
    b = 0;
    for (i = 0; i < mcount; i++) {
      if (validmoves[i].value >= bestvalue) {
	if (validmoves[i].value > bestvalue)
	  b = 0;
	bestvalue = validmoves[i].value;
	goodmoves[b++] = validmoves[i];
      }
    }
    /* Now we have an array of good moves. If there are two or more moves
       in the goodmoves-array, we will take the one that gives the maximum
       "profit" after two moves. */
    if (b > 1) {
      killers = (struct killers **) calloc(2,sizeof(struct killers *));
      for (i = 0; i < 2; i++)
	killers[i] = (struct killers *) calloc(NBR_KILLERS,sizeof(struct killers));
      abort_search = 0;
      for (i = 0; i < b; i++) {
	makemove(brd,&newpos,color,goodmoves[i],2);
	goodmoves[i].value = alphabeta(&newpos,color,color,MINNODE,-INFTY,INFTY,1,2,1);
      }
      for (i = 0; i < 2; i++)
	free(killers[i]);
      free(killers);
      bestvalue = goodmoves[0].value;
      mcount = b;
      b = 0;
      bestmoves = (struct move *) malloc(mcount * sizeof(struct move));
      for (i = 0; i < mcount; i++) {
	if (goodmoves[i].value >= bestvalue) {
	  if (goodmoves[i].value > bestvalue)
	    b = 0;
	  bestvalue = goodmoves[i].value;
	  bestmoves[b++] = goodmoves[i];
	}
      }
      *returnmove = bestmoves[get_random_number(b-1)];
      free(bestmoves);
    } else
      *returnmove = goodmoves[0];
    free(goodmoves);
  } else {
    printf("ERROR, NO LEGAL MOVE FOUND!\n");
    infolog("ERROR, NO LEGAL MOVE FOUND!\n");
    exit(1);
  }
  free(validmoves);
  free(*movelist);
  free(str);
  //unset_fixed_thinking_time();
  turn_on_hash();

  printf("Value = %d\n",(*returnmove).value);
}

int bookmove(int l_histpos, int *in_book, struct board *l_board,
	     int color, struct move *move) {
  int movenbr, which_row = 0;
  int possible_rows[BOOKSIZE];
  int i, j;
  FILE *fp;
  const char *filename = "openings.bok";
  char *line;
  char *movestr;
  char *themove;

  movenbr = l_histpos;
  printf("l_histpos = %d\n",l_histpos);
  fp = fopen(filename,"r");
  if (fp == NULL) {
    infolog("Could not open book file.");
    fprintf(stderr,"Could not open book file.\n");
    *in_book = 0;
  } else {
    line = (char *) calloc(200,sizeof(char));
    movestr = (char *) malloc(20*sizeof(char));
    for (i = 0; i < BOOKSIZE; i++) {
      fscanf(fp,"%s\n",line);
      possible_rows[i] = 1;
      for (j = 0; j < l_histpos; j++) {
	move2str(j%2,(*historik)[j],movestr);
	if (!(strlen(line) > l_histpos*4 && movestr[0] == line[j*4 + 0]
	      && movestr[1] == line[j*4 + 1] && movestr[2] == line[j*4 + 2]
	      && movestr[3] == line[j*4 + 3])) {
	  possible_rows[i] = 0;
	  break;
	}
      }
    }
    free(movestr);
    fclose(fp);

    /* Count how many possible rows we had, and then pick one of them
       by random. */
    j = 0;
    for (i = 0; i < BOOKSIZE; i++)
      if (possible_rows[i] == 1)
	j++;
    printf("possible moves = %d\n",j);
    if (j == 0) {
      *in_book = 0;
    } else {
      j = get_random_number(j-1);
      for (i = 0; i < BOOKSIZE; i++) {
	if (possible_rows[i] == 1) {
	  if (j == 0) {
	    which_row = i;
	    break;
	  }
	  j--;
	}
      }
      fp = fopen(filename,"r");
      for (i = 0; i <= which_row; i++)
	fscanf(fp,"%s\n",line);
      fclose(fp);
      //printf("line:\n%s\n",line);
      themove = (char *) malloc(5*sizeof(char));
      themove[0] = line[l_histpos*4 + 0];
      themove[1] = line[l_histpos*4 + 1];
      themove[2] = line[l_histpos*4 + 2];
      themove[3] = line[l_histpos*4 + 3];
      themove[4] = '\0';
      printf("themove = %s\n",themove);
      str2move(themove,l_board,color,move);
      free(themove);
    }
    free(line);
  }
  return *in_book;
}

void computer_make_move(struct board **l_board, int *color, int *started) {
  struct move move;
  struct board tempboard;
  char *str;
  char *str2;
  int status;
  struct move *movelist;
  //struct move *tempmovelist;
  int mcount = 0;
  //int tempi, tempj;

  str2 = (char *) malloc(100*sizeof(char));
  str = (char *) malloc(100*sizeof(char));
  if (!(book && bookmove(histpos,&book,*l_board,*color,&move))) {
    preanalysis(*l_board,*color,&movelist,&mcount);
    iterative_deepening_aspiration_search(*l_board,*color,movelist,mcount,histpos);
    postanalysis(*l_board,&movelist,mcount,*color,&move);
  }

  move2history(&move);
  makemove(*l_board,&tempboard,*color,move,0);
  **l_board = tempboard;
  if (!(move.type & NORMAL_MOVE) || move.piece == PAWN)
    non_reversible_move();
  new_position_on_board(*l_board);

  move2str(*color,move,str);
  if (mode != XBOARD_MODE) {
    showboard(*l_board);
    showtime(*color);
  } else {
    printf("move %s\n",str);
    sprintf(str2,"engine's move: move %s",str);
    infolog(str2);
  }
#ifdef AM_DEBUG
  if (gamelog) {
    sprintf(str,"Engine move: %s",input);
    debuglog(str);
  }
#endif

  if (*color == WHITE)
    *color = BLACK;
  else
    *color = WHITE;

  /* Check if game is over. */
  if ((status = game_ended(*l_board,*color))) {
    /* If we are in xboard mode, we won't quit playing until xboard tells us
       that the game is over. */
    if (mode != XBOARD_MODE)
      *started = 0;
    if (status == 2) {
      if (*color == WHITE)
	sprintf(str,"0-1 {Black mates}");
      else
	sprintf(str,"1-0 {White mates}");
      printf("%s\n",str);
      if (mode == XBOARD_MODE) {
	sprintf(str2,"output sent = %s",str);
	infolog(str2);
      }
    } else if (status == 1) {
      sprintf(str,"1/2-1/2 {Stalemate}");
      printf("%s\n",str);
      if (mode == XBOARD_MODE) {
	sprintf(str2,"output sent = %s",str);
	infolog(str2);
	infolog("Stalemate");
      }
    } else if (status == 3) {
      sprintf(str,"1/2-1/2 {50 move rule}");
      printf("%s\n",str);
      infolog("Draw according to the 50 move rule claimed");
    } else if (status == 5) {
      sprintf(str,"1/2-1/2 {Draw by repetition}");
      printf("%s\n",str);
      infolog("Draw according to the draw by repetition rule claimed");
    } else {
      sprintf(str,"1/2-1/2 {Insufficient material}");
      printf("%s\n",str);
      infolog("Draw because of insufficient material.");
    }
#ifdef AM_DEBUG
    if (gamelog) {
      sprintf(str2,"Game result: %s",str);
      debuglog(str);
    }
#endif
    resultlog(status,*color,white,black);
  }
  free(str);
  free(str2);
  return;
}

/* Returns false(=0) on error, and true(=1) if no error. */
int parsemove(char *input, struct board **l_board, int *color, int *started) {
  struct move move;
  struct board tempboard;
  char *str;
  char *str2;
  int returnval = 0;
  int status;

  str2 = (char *) malloc(100*sizeof(char));
  str = (char *) malloc(100*sizeof(char));
  str2move(input,*l_board,*color,&move);
  if (move.value != -99) {
    if (!(*started) && mode != XBOARD_MODE)
      printf("Illegal move (No game started): %s\n",input);
    else {
      sprintf(str,"xboard's move: %s",input);
      infolog(str);
      /* If we are in xboard mode, we check if the move is legal,
         otherwise we accept illegal moves. */
      if (mode == XBOARD_MODE && !legal_move(move,*l_board,*color)) {
	sprintf(str,"Illegal move: %s",input);
	printf("%s\n",str);
	infolog(str);
      } else {
	move2history(&move);
#ifdef AM_DEBUG
	if (gamelog) {
	  sprintf(str,"Opponent move: %s",input);
	  debuglog(str);
	}
#endif
	makemove(*l_board,&tempboard,*color,move,0);
	**l_board = tempboard;
	if (!(move.type & NORMAL_MOVE) || move.piece == PAWN)
	  non_reversible_move();
	new_position_on_board(*l_board);
	if (*color == WHITE)
	  *color = BLACK;
	else
	  *color = WHITE;
	if (mode != XBOARD_MODE) {
	  showboard(*l_board);
	  showtime(*color);
	}

	/* Check if game is over. If draw by repetition is reached, then a
	   draw will not be claimed unless draw_score() >= eval(board) */
	if ((status = game_ended(*l_board,*color))) {
	  if (!(status == 5 && draw_score() < eval(color,board))) {
	    *started = 0;
	    returnval = 0;
	    if (status == 2) {
	      if (*color == WHITE)
		sprintf(str,"0-1 {Black mates}");
	      else
		sprintf(str,"1-0 {White mates}");
	      printf("%s\n",str);
	      if (mode == XBOARD_MODE) {
		sprintf(str2,"output sent = %s",str);
		infolog(str2);
	      }
	    } else if (status == 1) {
	      sprintf(str,"1/2-1/2 {Stalemate}");
	      printf("%s\n",str);
	      if (mode == XBOARD_MODE) {
		sprintf(str2,"output sent = %s",str);
		infolog(str2);
		infolog("Stalemate");
	      }
	    } else if (status == 3) {  //draw by the 50 move rule
	      sprintf(str,"1/2-1/2 {50 move rule}");
	      printf("%s\n",str);
	      infolog("Draw according to the 50 move rule claimed");
	    } else if (status == 5) {
	      sprintf(str,"1/2-1/2 {Draw by repetition}");
	      printf("%s\n",str);
	      infolog("Draw according to the draw by repetition rule claimed");
	    } else {
	      sprintf(str,"1/2-1/2 {Insufficient material}");
	      printf("%s\n",str);
	      infolog("Draw because of insufficient material.");
	    }
#ifdef AM_DEBUG
	    if (gamelog) {
	      sprintf(str2,"Game result: %s",str);
	      debuglog(str);
	    }
#endif
	    resultlog(status,*color,white,black);
	  }
	}
	
	/* If xboard mode is on and *started = 0, then we will make the
	   move, but not start thinking until xboard sends a go. This
	   is done by returning a 0.*/
	if (*started)
	  returnval = 1;
      }
    }
  } else {
    if (mode != XBOARD_MODE)
      printf("Command could not be interpreted. Press '?' for help.\n");
    else {
      printf("Error (unknown command): %s\n",input);
      sprintf(str,"unknown input received = \"%s\"",input);
      infolog(str);
    }
  }
  free(str);
  free(str2);
  return returnval;
}

void parse() {
  int color = WHITE;     //white always starts
  int started = 0;       //is zero before a game is started
  char *input;
  int run = 1, i;
  char *str;
  char *str2;
  char *str3;
  int temp;

  historik = (struct move **) malloc(sizeof(struct move *));
  *historik = (struct move *) malloc(hlistsize*sizeof(struct move));
  input = (char *) malloc(100*sizeof(char));
  str = (char *) malloc(100*sizeof(char));
  str2 = (char *) malloc(100*sizeof(char));
  str3 = (char *) malloc(100*sizeof(char));

  new_position_on_board(board);

  while (run) {
#ifdef AM_DEBUG
    if (mode == DEBUG_MODE)
      printf("debug");
#endif
    if (mode != XBOARD_MODE)
      fprintf(stderr,">");
    fgets(input,100,stdin);   //reads a whole line
    input[strlen(input)-1] = '\0';   //remove trailing newline

    if (mode == XBOARD_MODE) {
      infolog(input);
      if (strcmp(input,"new") == 0) {
	set_board(board);
	new_position_on_board(board);
	color = WHITE;
	white = HUMAN;
	black = COMPUTER;
	started = 1;
	book = 1;
	histpos = 0;   //zero the move history
	non_reversible_move();   //zero the repetition counters
	stop_own_clock();
	stop_opp_clock();
	own_time = 300000;    //5 minutes;
	opp_time = 300000;    //5 minutes;
      } else if (strcmp(input,"random") == 0) {
	//do nothing, we always use random evaluation
      } else if (strcmp(input,"force") == 0) {
	started = 0;
	stop_own_clock();
	stop_opp_clock();
      } else if (strncmp(input,"level",5) == 0) {
	sscanf(input,"level %d %d %d",&moves_per_timecontrol,&base,&increment);
	base = base*60*1000; //since xboard gives the time in minutes
	increment = increment*1000;  //since xboard gives the time in seconds
	if (moves_per_timecontrol > 0)
	  timectrl = TIMECTRL_NEWTIME;
	else if (increment > 0)
	  timectrl = TIMECTRL_INC;
	else
	  timectrl = TIMECTRL_NOINC;
	sprintf(str,"timectrl = %d",timectrl);
	infolog(str);
      } else if (strcmp(input,"protover 2") == 0) {
	printf("feature ping=1 variants=\"normal\" analyze=0 myname=\"%s\" colors=1 done=1\n",MYSELF);
      } else if (strncmp(input,"accepted",8) == 0) {
	//do nothing
      } else if (strncmp(input,"rejected",8) == 0) {
	//do nothing
      } else if (strncmp(input,"ping",4) == 0) {
	sscanf(input,"ping %d",&temp);
	printf("pong %d\n",temp);
      } else if (strcmp(input,"computer") == 0) {
	infolog("Opponent is a computer.");
      } else if (strncmp(input,"name",4) == 0) {
	sscanf(input,"name %s",str);
	sprintf(str2,"Opponent's name: %s",str);
	infolog(str2);
      } else if (strncmp(input,"rating",6) == 0) {
	sscanf(input,"rating %s %s",str,str2);
	sprintf(str3,"Own rating: %s",str);
	infolog(str3);
	sprintf(str3,"Opponent rating: %s",str2);
	infolog(str3);
      } else if (strncmp(input,"time",4) == 0) {
	sscanf(input,"time %d",&own_time);
	/* Internally the engine works with milliseconds, and xboard gives
	   us the time in centiseconds, so we have to multiply by 10 here.*/
	own_time *= 10;
      } else if (strncmp(input,"otim",4) == 0) {
	sscanf(input,"otim %d",&opp_time);
	/* Internally the engine works with milliseconds, and xboard gives
	   us the time in centiseconds, so we have to multiply by 10 here.*/
	opp_time *= 10;
      } else if (strncmp(input,"result",6) == 0) {
	started = 0;
	sprintf(str3,"Result from xboard (%s = %s): %s",MYSELF,
		(white == COMPUTER ? "white" : "black"),input);
	infolog(str3);
      } else if (strcmp(input,"hard") == 0) {
	//do nothing, the engine doesn't support pondering
      } else if (strcmp(input,"post") == 0) {
	post = 1;
      } else if (strcmp(input,"nopost") == 0) {
	post = 0;
      } else if (strcmp(input,"draw") == 0) {
	if (white == COMPUTER)
	  temp = WHITE;
	else
	  temp = BLACK;
	if (eval(&temp,board) > 0) {
	  //decline the offer when you have a better position
	  infolog("draw declined");
	} else {
	  /* If the positions are equal or you are worse off than
	     your opponent, then accept a draw. However, we shouldn't
	     quit playing until xboard tells us that the game is over.
	     That's because when playing on ICS, it's possible that the
	     draw offer has been withdrawn by the time we accept it. */
	  printf("offer draw\n");
	  infolog("draw accepted");
	}
      } else if (strcmp(input,"dumpa") == 0) {
	//Used for debugging purposes
	showboard(board);
      } else if (strcmp(input,"quit") == 0) {
	started = 0;
	run = 0;
      } else if (strcmp(input,"white") == 0) {
	color = WHITE;
	white = HUMAN;
	black = COMPUTER;
	stop_own_clock();
	stop_opp_clock();
      } else if (strcmp(input,"black") == 0) {
	color = BLACK;
	white = COMPUTER;
	black = HUMAN;
	stop_own_clock();
	stop_opp_clock();
      } else if (strcmp(input,"go") == 0) {
	started = 1;
	book = 1;
	if (color == WHITE) {
	  white = COMPUTER;
	  black = HUMAN;
	} else {
	  black = COMPUTER;
	  white = HUMAN;
	}
	if (color == BLACK && histpos == 0) {
	  color = WHITE;
	  start_opp_clock();
	} else {
	  start_own_clock();
	  computer_make_move(&board,&color,&started);
	  stop_own_clock();
	  start_opp_clock();
	}
      } else {
	if (parsemove(input,&board,&color,&started)) {
	  stop_opp_clock();
	  start_own_clock();
	  computer_make_move(&board,&color,&started);
	  stop_own_clock();
	  start_opp_clock();
	}
      }
    }



#ifdef AM_DEBUG
    else if (mode == DEBUG_MODE) {
      if (strcmp(input,"debexit") == 0) {
	mode = NORMAL_MODE;
      } else if ((strcmp(input,"help") == 0) || (strcmp(input,"?") == 0))
	showhelp(mode);
      else if (strcmp(input,"show") == 0) {
	showboard(board);
      } else if (strcmp(input,"set") == 0)
	showsettings(&white,&black,&color,&started,gamelog);
      else if (strcmp(input,"gamelog") == 0)
	gamelog = 1;
      else if (strcmp(input,"nogamelog") == 0)
	gamelog = 0;
      else
	printf("Error (unknown command): %s - Press '?' for help.\n",input);
    }
#endif    //AM_DEBUG




    else {   //NORMAL_MODE
      if (strcmp(input,"xboard") == 0) {
	//xboard_mode = 1;
	mode = XBOARD_MODE;
	printf("\n");   //xboard wants a newline here
	signal(SIGINT,SIG_IGN);  //ignore SIGINT to work okay with xboard
	infolog("xboard");
      }
#ifdef AM_DEBUG
      else if (strcmp(input,"debug") == 0) {
	mode = DEBUG_MODE;
      }
#endif    //AM_DEBUG
      else if (strcmp(input,"hist") == 0) {
	//showhistory();
      } else if (strcmp(input,"quit") == 0)
	run = 0;
      else if ((strcmp(input,"help") == 0) || (strcmp(input,"?") == 0))
	showhelp(mode);
      else if (strcmp(input,"show") == 0) {
	showboard(board);
      } else if (strcmp(input,"enginewhite") == 0) {
	white = COMPUTER;
	black = HUMAN;
      } else if (strcmp(input,"humanwhite") == 0) {
	white = HUMAN;
	black = COMPUTER;
      } else if (strcmp(input,"dumpa") == 0) {
	//Used for debugging purposes
	for (i = 0; i < 64; i++) {
	  if ((board->rotNW_pieces[WHITE] | board->rotNW_pieces[BLACK]) & square[i])
	    printf("1");
	  else
	    printf("0");
	  if (i == 55 || i == 47 || i == 39 || i == 31
	      || i == 23 || i == 15 || i == 7)
	    printf("\n");
	}
	printf("\n\n");
      } else if (strcmp(input,"engineblack") == 0) {
	black = COMPUTER;
	white = HUMAN;
      } else if (strcmp(input,"humanblack") == 0) {
	black = HUMAN;
	white = COMPUTER;
	color = BLACK;
      } else if (strcmp(input,"start") == 0) {
	if (started != 1) {
	  //set_board(board);
	  non_reversible_move();   //zero the repetition counters
	  stop_own_clock();
	  stop_opp_clock();
	  own_time = 300000;    //5 minutes
	  opp_time = 300000;    //5 minutes
	  base = 300000;        //5 minutes
	  increment = 0;
	  moves_per_timecontrol = 0;
	  timectrl = TIMECTRL_NOINC;
	  started = 1;
	  book = 1;
	  histpos = 0;   //clear move history
	  if ((white == COMPUTER && color == WHITE) || (black == COMPUTER && color == BLACK)) {
	    start_own_clock();
	    computer_make_move(&board,&color,&started);
	    stop_own_clock();
	  }
	  start_opp_clock();
	}
      } else if (strcmp(input,"set") == 0)
	showsettings(&white,&black,&color,&started);
      else if (input[0] != '\0') {
	if (parsemove(input,&board,&color,&started)) {
	  stop_opp_clock();
	  start_own_clock();
	  computer_make_move(&board,&color,&started);
	  stop_own_clock();
	  start_opp_clock();
	}
      }
    }
  }
  free(pawn_table);
  free(ref_table);
  free(transp_table);
  free(input);
  free(str3);
  free(str2);
  free(str);
  free(*historik);
  free(historik);
  free(board);
}
