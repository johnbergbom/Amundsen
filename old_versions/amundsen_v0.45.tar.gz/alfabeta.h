#ifndef _ALFABETA_
#define _ALFABETA_

#include "misc.h"
#include "bitboards.h"

/* THINKFORWARD defines how many plies the engine should think.
   THINKFORWARD needs to have a value of at least 2, because otherwise
   it could make illegal moves, which leave the king in check. (Because
   if it only thinks one ply deep, it won't be able to spot that in the
   next move the opponent can take the king.) */
//#define THINKFORWARD 6

#define INFTY 1000000
#define KINGTAKEN 500000
#define MAXNODE 1
#define MINNODE 2

int max(int a, int b);
int min(int a, int b);

int quiescence(struct board *board, int vemstur, int org_color, int nodetype,
	       int alpha, int beta, bitboard tsquare);

int alphabeta(struct board *board, int vemstur, int org_color, int nodetype,
	      int alpha, int beta, int depth, int org_depth, int null_ok);

void thinkalphabeta(struct board *board, int vemstur, int depth,
		    struct move *movelist, int mcount);

#endif       //_ALFABETA_

