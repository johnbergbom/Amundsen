#ifndef _MISC_
#define _MISC_

#define INFOLOGFILE "log.info"
#define DEBUGLOGFILE "log.debug"
#define RESULTLOGFILE "log.result"
#define MYSELF "Amundsen"

#define PAWN 0
#define KNIGHT 1
#define BISHOP 2
#define ROOK 3
#define QUEEN 4
#define KING 5

#define EMPTY 7

#define VAL_PAWN 100
#define VAL_KNIGHT 300
#define VAL_BISHOP 300
#define VAL_ROOK 500
#define VAL_QUEEN 900
#define VAL_KING 10000

/*------------------------------------------------------------------------
 | The variable CUT_BAD_MOVES_AT_LOWEST_LEVEL_SEARCH_DEPTH_START tells   |
 | at which (original) search depth the bad moves (according to SEE)     |
 | will be skipped at the lowest level of the search.                    |
 |                                                                       |
 | The variable CUT_ALL_BAD_MOVES_SEARCH_DEPTH_START tells at which      |
 | (org_depth - depth + 1) search depth _all_ bad moves will be skipped. |
 |                                                                       |
 | The variable CUT_NEUTRAL_MOVES_AT_LOWEST_SEARCH_DEPTH_START tells     |
 | at which (original) search depth the "neutral" moves at the lowest    |
 | level will be skipped.                                                |
 ------------------------------------------------------------------------*/

//#define CUT_BAD_MOVES_AT_LOWEST_LEVEL_SEARCH_DEPTH_START 99
//#define CUT_ALL_BAD_MOVES_SEARCH_DEPTH_START 99
//#define CUT_NEUTRAL_MOVES_AT_LOWEST_LEVEL_SEARCH_DEPTH_START 99
#define CUT_BAD_MOVES_AT_LOWEST_LEVEL_SEARCH_DEPTH_START 5
#define CUT_ALL_BAD_MOVES_SEARCH_DEPTH_START 9
#define CUT_NEUTRAL_MOVES_AT_LOWEST_LEVEL_SEARCH_DEPTH_START 8

void switch_colors(int *color);

void infolog(const char *text);
void resultlog(int status, int color, int white, int black);
#ifdef AM_DEBUG
void debuglog(const char *text);
#endif
int draw_score(void);

#endif      //_MISC_






