#ifndef _SLUMP_
#define _SLUMP_

/* This function initiates a seed for random number generation. The
   seed is taken from the system time. */
void init_random_seed(void);

/* This function returns a number between zero and high. */
int get_random_number(int high);

#endif      //_SLUMP_
