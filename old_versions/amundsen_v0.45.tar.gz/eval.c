#include "eval.h"
#include "parse.h"
#include "bitboards.h"
#include "hash.h"
#include "alfabeta.h"

/* If endgame == 0 there is no special endgame. Otherwise the number tells us
   what kind of endgame we are dealing with. See eval.h for endgame types. */
int endgame;

/* Before the search the material values of the pieces and pawns are
   calculated. That way it's possible to see if any pieces or pawns have
   been traded. This is used to encourage piece exchanges when ahead, and
   pawn exchanges when behind. */
int presearch_pieceval[2];
int presearch_pawnval[2];

struct pawn_entry pawn_struct;

extern bitboard col_bitboard[8];
extern bitboard adj_cols[8];
extern int row_nbr[64];
extern int connected_bits[256];
extern struct defense defense;
extern bitboard possible_pawn_attack[2][64];
extern bitboard right_col[8];
extern bitboard left_col[8];
extern bitboard square[64];
extern int dist_to_corn[64];
extern bitboard pawn_start[2];
extern bitboard pawn_lastrow[2];
extern int dist_to_side[64];
extern bitboard white_squares;
extern bitboard black_squares;
extern int dist_to_square[64][64];

static const unsigned bishop_reach[64] = {
  7, 7, 7, 7, 7, 7, 7, 7,
  7, 9, 9, 9, 9, 9, 9, 7,
  7, 9, 11, 11, 11, 11, 9, 7,
  7, 9, 11, 13, 13, 11, 9, 7,
  7, 9, 11, 13, 13, 11, 9, 7,
  7, 9, 11, 11, 11, 11, 9, 7,
  7, 9, 9, 9, 9, 9, 9, 7,
  7, 7, 7, 7, 7, 7, 7, 7
};

static const unsigned knight_reach[64] = {
  2, 3, 4, 4, 4, 4, 3, 2,
  3, 4, 6, 6, 6, 6, 4, 3,
  4, 6, 8, 8, 8, 8, 6, 4,
  4, 6, 8, 8, 8, 8, 6, 4,
  4, 6, 8, 8, 8, 8, 6, 4,
  4, 6, 8, 8, 8, 8, 6, 4,
  3, 4, 6, 6, 6, 6, 4, 3,
  2, 3, 4, 4, 4, 4, 3, 2
};

static const int king_reach_early[64] = {
  5, 6, -2, -6, -6, -2, 6, 5,
  -8, -10, -14, -16, -16, -14, -10, -8,
  -10, -15, -18, -20, -20, -18, -15, -10,
  -14, -20, -25, -30, -30, -25, -20, -14,
  -14, -20, -25, -30, -30, -25, -20, -14,
  -10, -15, -18, -20, -20, -18, -15, -10,
  -8, -10, -14, -16, -16, -14, -10, -8,
  5, 6, -2, -6, -6, -2, 6, 5
};

static const unsigned king_reach_late[64] = {
  3, 5, 5, 5, 5, 5, 5, 3,
  5, 8, 8, 8, 8, 8, 8, 5,
  5, 8, 8, 8, 8, 8, 8, 5,
  5, 8, 8, 8, 8, 8, 8, 5,
  5, 8, 8, 8, 8, 8, 8, 5,
  5, 8, 8, 8, 8, 8, 8, 5,
  5, 8, 8, 8, 8, 8, 8, 5,
  3, 5, 5, 5, 5, 5, 5, 3
};

static const unsigned queen_reach[64] = {
  21,21,21,21,21,21,21,21,
  21,23,23,23,23,23,23,21,
  21,23,25,25,25,25,23,21,
  21,23,25,27,27,25,23,21,
  21,23,25,27,27,25,23,21,
  21,23,25,25,25,25,23,21,
  21,23,23,23,23,23,23,21,
  21,21,21,21,21,21,21,21
};

void eval_pawn_structure(struct board *board, int *wval, int *bval) {
  int i;
  unsigned char connected[2] = { 0, 0 };
  bitboard pawn_col;
  int counter;
  //bitboard pieces, piece;

  if (probe_pawn_hash(board,&pawn_struct) == UNKNOWN) {
    pawn_struct.white_value = pawn_struct.black_value = 0;
    pawn_struct.passed_pawn[0] = pawn_struct.passed_pawn[1]
      = pawn_struct.weak_pawn[0] = pawn_struct.weak_pawn[1]
      = pawn_struct.pawn_hole[0] = pawn_struct.pawn_hole[1]
      = pawn_struct.open_file = 0;
    
    counter = 0;
    for (i = 0; i < 8; i++) {
      pawn_col = board->piece[WHITE][PAWN] & col_bitboard[i];
      
      /*------------------------------------
       | Check openings in the pawn chain. |
       ------------------------------------*/
      if (pawn_col == 0) {
	counter++;
	if (i > 0 && i < 7 && adj_cols[i] && board->piece[WHITE][PAWN])
	  pawn_struct.white_value -= 8;  //opening in the pawn chain

	/*-------------------------------------------------------
	 | A pawn which doesn't have an opposing pawn on the    |
	 | same file should be protected by another pawn, or    |
	 | at least have another pawn behind, ready to defend   |
	 | by advancing. So here we check the opponent's pawns. |
	 -------------------------------------------------------*/
	if (board->piece[BLACK][PAWN] & col_bitboard[i]) {
	  if (defense.pawn[BLACK][get_last_bitpos(board->piece[BLACK][PAWN]
						  & col_bitboard[i])]
	      & board->piece[BLACK][PAWN]) {
	    pawn_struct.black_value += 4;
	  } else if (possible_pawn_attack[BLACK]
		     [get_last_bitpos(board->piece[BLACK][PAWN]
				      & col_bitboard[i])]
		     & board->piece[BLACK][PAWN]) {
	    pawn_struct.black_value += 3;
	  } else {
	    pawn_struct.black_value -= 4;
	  }
	} else
	  pawn_struct.open_file |= col_bitboard[i];
      } else {
	/* Possibly doubled pawn. */
	pawn_struct.white_value -= (bitcount(pawn_col)-1)*8;
	
	/*----------------------------------------------------------------------
	 | A passed pawn is given an added constant value + a bonus related to |
	 | the number of rows it has advanced + a bonus if the passed pawn is  |
	 | far away from the center (a distant passed pawn is better than a    |
	 | centralized passed pawn).                                           |
	 ----------------------------------------------------------------------*/
	if (!(possible_pawn_attack[BLACK][get_first_bitpos(pawn_col)] & board->piece[BLACK][PAWN])) {
	  pawn_struct.passed_pawn[WHITE] |= col_bitboard[i];
	  connected[WHITE] |= (1<<i);
	  pawn_struct.white_value += (10 + 12*row_nbr[get_first_bitpos(pawn_col)] + 2*(3 - min(i,7-i)));
	}
	
	/*-------------------------------------------------------------------
	 | Check for "holes" in the pawn chain, i.e. squares that cannot be |
	 | attacked by the pawns, where the opponent can place pieces.      |
	 -------------------------------------------------------------------*/
	if (!(possible_pawn_attack[WHITE][get_first_bitpos(pawn_col)-8]
	      & board->piece[WHITE][PAWN])) {
	  pawn_struct.weak_pawn[WHITE] |= col_bitboard[i];
	  pawn_struct.white_value -= 8;     //eg. pawn c2, d3, e4 or c4, d3, e4
	  if ((right_col[i] & board->piece[WHITE][PAWN])
	      && (left_col[i] & board->piece[WHITE][PAWN])) {
	    pawn_struct.pawn_hole[WHITE] |= square[get_first_bitpos(pawn_col)-8];
	    pawn_struct.white_value -= 16;   //eg. pawn c4, d3, e4
	  }
	}
      }
    }
    /*-----------------------------------------
     | It's bad to have no open files at all. |
     -----------------------------------------*/
    if (counter == 0)
      pawn_struct.white_value -= 20;

    
    /*------------------------------------------
     | Okay, now do the same checks for black. |
     ------------------------------------------*/
    counter = 0;
    for (i = 0; i < 8; i++) {
      pawn_col = board->piece[BLACK][PAWN] & col_bitboard[i];
      
      /*------------------------------------
       | Check openings in the pawn chain. |
       ------------------------------------*/
      if (pawn_col == 0) {
	counter++;
	if (i > 0 && i < 7 && adj_cols[i] && board->piece[BLACK][PAWN])
	  pawn_struct.black_value -= 8;  //opening in the pawn chain

	/*-------------------------------------------------------
	 | A pawn which doesn't have an opposing pawn on the    |
	 | same file should be protected by another pawn, or    |
	 | at least have another pawn behind, ready to defend   |
	 | by advancing. So here we check the opponent's pawns. |
	 -------------------------------------------------------*/
	if (board->piece[WHITE][PAWN] & col_bitboard[i]) {
	  if (defense.pawn[WHITE][get_first_bitpos(board->piece[WHITE][PAWN]
						   & col_bitboard[i])]
	      & board->piece[WHITE][PAWN]) {
	    pawn_struct.white_value += 4;
	  } else if (possible_pawn_attack[WHITE]
		     [get_first_bitpos(board->piece[WHITE][PAWN]
				       & col_bitboard[i])]
		     & board->piece[WHITE][PAWN]) {
	    pawn_struct.white_value += 3;
	  } else {
	    pawn_struct.white_value -= 4;
	  }
	}
      } else {
	/* Possibly doubled pawn. */
	pawn_struct.black_value -= (bitcount(pawn_col)-1)*8;
	
	/*----------------------------------------------------------------------
	 | A passed pawn is given an added constant value + a bonus related to |
	 | the number of rows it has advanced + a bonus if the passed pawn is  |
	 | far away from the center (a distant passed pawn is better than a    |
	 | centralized passed pawn).                                           |
	 ----------------------------------------------------------------------*/
	if (!(possible_pawn_attack[WHITE][get_last_bitpos(pawn_col)] & board->piece[WHITE][PAWN])) {
	  pawn_struct.passed_pawn[BLACK] |= col_bitboard[i];
	  connected[BLACK] |= (1<<i);
	  pawn_struct.black_value += (10 + 12*(7-row_nbr[get_last_bitpos(pawn_col)]) + 2*(3 - min(i,7-i)));
	}
	
	/*-------------------------------------------------------------------
	 | Check for "holes" in the pawn chain, i.e. squares that cannot be |
	 | attacked by the pawns, where the opponent can place pieces.      |
	 -------------------------------------------------------------------*/
	if (!(possible_pawn_attack[BLACK][get_last_bitpos(pawn_col)+8]
	      & board->piece[BLACK][PAWN])) {
	  pawn_struct.weak_pawn[BLACK] |= col_bitboard[i];
	  pawn_struct.black_value -= 8;     //eg. pawn c2, d3, e4 or c4, d5, e4
	  if ((right_col[i] & board->piece[BLACK][PAWN])
	      && (left_col[i] & board->piece[BLACK][PAWN])) {
	    pawn_struct.pawn_hole[BLACK] |= square[get_last_bitpos(pawn_col)+8];
	    pawn_struct.black_value -= 16;   //eg. pawn c4, d5, e4
	  }
	}
      }
    }
    /*-----------------------------------------
     | It's bad to have no open files at all. |
     -----------------------------------------*/
    if (counter == 0)
      pawn_struct.black_value -= 20;


    /*--------------------------------------------------
     | Give a higher value for connected passed pawns. |
     --------------------------------------------------*/
    pawn_struct.white_value += 8*connected_bits[connected[WHITE]];
    pawn_struct.black_value += 8*connected_bits[connected[BLACK]];

    /*--------------------------------------------------
     | Check pawn reach.                               |
     --------------------------------------------------*/
    /*pieces = board->piece[WHITE][PAWN];
    while (pieces != 0) {
      piece = getlsb(pieces);
      pawn_struct.white_value += pawn_reach[get_first_bitpos(piece)];
      pieces &= ~piece;
    }
    pieces = board->piece[BLACK][PAWN];
    while (pieces != 0) {
      piece = getlsb(pieces);
      pawn_struct.black_value += pawn_reach[get_first_bitpos(piece)];
      pieces &= ~piece;
      }*/

    /*---------------------------------------------------
     | Record the pawn structure in the pawn hashtable. |
     ---------------------------------------------------*/
    record_pawn_hash(board,&pawn_struct);

  }

  *wval += pawn_struct.white_value;
  *bval += pawn_struct.black_value;
}

void eval_piece_placement(struct board *board, int *wval, int *bval) {
  bitboard pieces, piece;

  /*-----------------------------------------------------------------------
   | Check if knights or bishops are placed in "holes" in the pawn chain. |
   -----------------------------------------------------------------------*/
  *wval += 8*bitcount(pawn_struct.pawn_hole[BLACK] & (board->piece[WHITE][KNIGHT]
		      | board->piece[WHITE][BISHOP]));
  *bval += 8*bitcount(pawn_struct.pawn_hole[WHITE] & (board->piece[BLACK][KNIGHT]
		      | board->piece[BLACK][BISHOP]));

  /*-------------------------------------------------------------------------
   | Check if rooks are on the same file as a passed pawn. (The rook should |
   | really stand _behind_ the pawn, but this code doesn't check that.)     |
   | Note that it's good to stand on the same file as a passed pawn, no     |
   | matter what color the pawn has.                                        |
   -------------------------------------------------------------------------*/
  *wval += 5*bitcount(board->piece[WHITE][ROOK] &
		      (pawn_struct.passed_pawn[WHITE] | pawn_struct.passed_pawn[BLACK]));
  *bval += 5*bitcount(board->piece[BLACK][ROOK] &
		      (pawn_struct.passed_pawn[WHITE] | pawn_struct.passed_pawn[BLACK]));

  /*-----------------------------------------------
   | It's good to attack a weak pawn with a rook. |
   -----------------------------------------------*/
  *wval += 5*bitcount(board->piece[WHITE][ROOK] & pawn_struct.weak_pawn[BLACK]);
  *bval += 5*bitcount(board->piece[BLACK][ROOK] & pawn_struct.weak_pawn[WHITE]);

  /*------------------------------------------
   | It's good to place rooks in open files. |
   ------------------------------------------*/
  *wval += 3*bitcount(board->piece[WHITE][ROOK] & pawn_struct.open_file);
  *bval += 3*bitcount(board->piece[BLACK][ROOK] & pawn_struct.open_file);

  /* Knights should be standing close to the middle. */
  pieces = board->piece[WHITE][KNIGHT];
  while (pieces != 0) {
    piece = getlsb(pieces);
    *wval += knight_reach[get_first_bitpos(piece)];
    pieces &= ~piece;
  }

  pieces = board->piece[BLACK][KNIGHT];
  while (pieces != 0) {
    piece = getlsb(pieces);
    *bval += knight_reach[get_first_bitpos(piece)];
    pieces &= ~piece;
  }

  /* Check bishop's placement. */
  pieces = board->piece[WHITE][BISHOP];
  while (pieces != 0) {
    piece = getlsb(pieces);
    /*if (piece & pawn_lastrow[BLACK])
     *wval -= 1;*/
    *wval += bishop_reach[get_first_bitpos(piece)];
    pieces &= ~piece;
  }

  pieces = board->piece[BLACK][BISHOP];
  while (pieces != 0) {
    piece = getlsb(pieces);
    /*if (piece & pawn_lastrow[WHITE])
     *bval -= 1;*/
    *bval += bishop_reach[get_first_bitpos(piece)];
    pieces &= ~piece;
  }

  /* Encourage 7th rank attacks by rooks. */
  pieces = board->piece[WHITE][ROOK];
  while (pieces != 0) {
    piece = getlsb(pieces);
    if (piece & pawn_start[BLACK])
      *wval += 5;
    pieces &= ~piece;
  }
  pieces = board->piece[BLACK][ROOK];
  while (pieces != 0) {
    piece = getlsb(pieces);
    if (piece & pawn_start[WHITE])
      *bval += 5;
    pieces &= ~piece;
  }

  /* Check queen's placement. */
  pieces = board->piece[WHITE][QUEEN];
  while (pieces != 0) {
    piece = getlsb(pieces);
    *wval += queen_reach[get_first_bitpos(piece)];
    pieces &= ~piece;
  }
  pieces = board->piece[BLACK][QUEEN];
  while (pieces != 0) {
    piece = getlsb(pieces);
    *bval += queen_reach[get_first_bitpos(piece)];
    pieces &= ~piece;
  }

  /* Check king's placement. */
  piece = getlsb(board->piece[WHITE][KING]);
  if (board->material_pieces[BLACK] >= VAL_KING + VAL_QUEEN + VAL_ROOK*2)
    *wval += king_reach_early[get_first_bitpos(piece)];
  else
    *wval += king_reach_late[get_first_bitpos(piece)];

  piece = getlsb(board->piece[BLACK][KING]);
  if (board->material_pieces[WHITE] >= VAL_KING + VAL_QUEEN + VAL_ROOK*2)
    *bval += king_reach_early[get_first_bitpos(piece)];
  else
    *bval += king_reach_late[get_first_bitpos(piece)];
}

/* This function returns a value for how good a position is. A high value
   for the player at move means he is well off in the game. */
int eval(int *color, struct board *board) {
  int wvalue = 0, bvalue = 0;
  bitboard pawns, pawn;

  /* Check the material balance. */
  wvalue += board->material_pieces[WHITE] + board->material_pawns[WHITE];
  bvalue += board->material_pieces[BLACK] + board->material_pawns[BLACK];

  /*-------------------------------------------------------------------------
   | Add incentive to trade pieces when ahead, and trade pawns when behind. |
   -------------------------------------------------------------------------*/
  if (board->material_pieces[WHITE] > board->material_pieces[BLACK]) {
    if (board->material_pieces[BLACK] < presearch_pieceval[BLACK])
      wvalue += (presearch_pieceval[BLACK] - board->material_pieces[BLACK]) / 10;
    if (board->material_pawns[WHITE] < presearch_pawnval[WHITE])
      bvalue += 1;
  } else if (board->material_pieces[BLACK] > board->material_pieces[WHITE]) {
    if (board->material_pieces[WHITE] < presearch_pieceval[WHITE])
      bvalue += (presearch_pieceval[WHITE] - board->material_pieces[WHITE]) / 10;
    if (board->material_pawns[BLACK] < presearch_pawnval[BLACK])
      wvalue += 1;
  }

  /* Add the capture-values to make shallower captures (or promotions)
     to be worth a little bit more than deeper captures/promotions. This
     can be good if for example the engine detects that the loss of a pawn
     is inevitable to the maximum search depth. However beyond the horizon
     of the search it might turn out that it's indeed possible to save the
     pawn, and therefore we should try to keep it for as long as possible.
     Another use of this is if for example the engine has the possibility
     to promote a pawn to a queen. Then it needs some encouragement to do
     it soon, rather than waiting. */
  wvalue += board->captures[WHITE];
  bvalue += board->captures[BLACK];

  /* Add incentive to castle. */
  if (board->castling_status[WHITE] & CASTLED)
    wvalue += 50;
  else if (board->castling_status[WHITE]
	   & (LONG_CASTLING_OK | SHORT_CASTLING_OK))
    wvalue += 10;
  else
    wvalue -= 50;
  if (board->castling_status[BLACK] & CASTLED)
    bvalue += 50;
  else if (board->castling_status[BLACK]
	   & (LONG_CASTLING_OK | SHORT_CASTLING_OK))
    bvalue += 10;
  else
    bvalue -= 50;

  eval_pawn_structure(board,&wvalue,&bvalue);
  eval_piece_placement(board,&wvalue,&bvalue);

  /* Rudimentary king safety. */
  /*if (board->material_pieces[BLACK] >= VAL_KING + VAL_QUEEN + VAL_ROOK*2) {
    if (board->piece[WHITE][KING] & pawn_lastrow[BLACK])
      wvalue += 10;
  }
  if (board->material_pieces[WHITE] >= VAL_KING + VAL_QUEEN + VAL_ROOK*2) {
    if (board->piece[BLACK][KING] & pawn_lastrow[WHITE])
      bvalue += 10;
      }*/

  if (endgame) {
    int wsquare, bsquare;
    wsquare = get_first_bitpos(board->piece[WHITE][KING]);
    bsquare = get_first_bitpos(board->piece[BLACK][KING]);

    if (endgame == KRK || endgame == KQK) {
      /* In KRK and KQK the color who is having the advantage should try
	 to force the enemy king to the side, and to come close with his king. */

      if (bitcount(board->all_pieces[WHITE]) > 1) {    //white is ahead
	wvalue -= dist_to_side[bsquare]*10;
	wvalue -= 2*(abs(wsquare%8-bsquare%8) + abs(wsquare/8-bsquare/8));
	wvalue -= dist_to_corn[bsquare];
	wvalue += dist_to_side[wsquare];
      } else {   //black is ahead
	bvalue -= dist_to_side[wsquare]*10;
	bvalue -= 2*(abs(wsquare%8-bsquare%8) + abs(wsquare/8-bsquare/8));
	bvalue -= dist_to_corn[wsquare];
	bvalue += dist_to_side[bsquare];
      }
    } else if (endgame == UNKNOWN_ENDGAME) {
      /* If endgame, then the king should be centralized. */
      /*if (board->material_pieces[BLACK] <= VAL_KING + VAL_ROOK*2) {
	wvalue += 4*dist_to_corn[wsquare];
      }
      if (board->material_pieces[WHITE] <= VAL_KING + VAL_ROOK*2) {
	bvalue += 4*dist_to_corn[bsquare];
      }*/

      /* Make sure the opponent doesn't get an unstoppable passed pawn. */
      if (board->material_pieces[WHITE] == VAL_KING
	  && board->material_pawns[WHITE] == 0
	  && pawn_struct.passed_pawn[BLACK]) {
        pawns = pawn_struct.passed_pawn[BLACK] & board->piece[BLACK][PAWN];
	while (pawns != 0) {
	  pawn = getlsb(pawns);
	  if (dist_to_square[wsquare]
	      [get_first_bitpos(col_bitboard[get_first_bitpos(pawn)%8]
				& pawn_lastrow[BLACK])]
	      > dist_to_square[get_first_bitpos(pawn)]
	      [get_first_bitpos(col_bitboard[get_first_bitpos(pawn)%8]
				& pawn_lastrow[BLACK])]) {
	    wvalue -= 600;
	    pawns = 0;
	  }
	  pawns &= ~pawn;
	}
      } else if (board->material_pieces[BLACK] == VAL_KING
		 && board->material_pawns[BLACK] == 0
		 && pawn_struct.passed_pawn[WHITE]) {
        pawns = pawn_struct.passed_pawn[WHITE] & board->piece[WHITE][PAWN];
	while (pawns != 0) {
	  pawn = getlsb(pawns);
	  if (dist_to_square[bsquare]
	      [get_first_bitpos(col_bitboard[get_first_bitpos(pawn)%8]
				& pawn_lastrow[WHITE])]
	      > dist_to_square[get_first_bitpos(pawn)]
	      [get_first_bitpos(col_bitboard[get_first_bitpos(pawn)%8]
				& pawn_lastrow[WHITE])]) {
	    bvalue -= 600;
	    pawns = 0;
	  }
	  pawns &= ~pawn;
	}
      }
      /* If the king is losing, then force him to the edge of the board. */
      if (board->material_pieces[BLACK] <= VAL_KING + VAL_BISHOP
	  && board->material_pawns[BLACK] <= VAL_PAWN*2
	  && pawn_struct.passed_pawn[BLACK] == 0) {
	wvalue -= dist_to_side[bsquare]*10;
	wvalue -= 2*(abs(wsquare%8-bsquare%8) + abs(wsquare/8-bsquare/8));
	wvalue -= dist_to_corn[bsquare];
	wvalue += dist_to_side[wsquare];
      }
      if (board->material_pieces[WHITE] <= VAL_KING + VAL_BISHOP
	  && board->material_pawns[WHITE] <= VAL_PAWN*2
	  && pawn_struct.passed_pawn[WHITE] == 0) {
	bvalue -= dist_to_side[wsquare]*10;
	bvalue -= 2*(abs(wsquare%8-bsquare%8) + abs(wsquare/8-bsquare/8));
	bvalue -= dist_to_corn[wsquare];
	bvalue += dist_to_side[bsquare];
      }

      /*--------------------------------------------------------------------
	| Give a slightly higher value if the pawns are on opposite colored |
	| squares of the opponents bishop.                                  |
	--------------------------------------------------------------------*/
      if (bitcount(board->piece[BLACK][BISHOP]) == 1) {
	if (board->piece[BLACK][BISHOP] & white_squares)
	  pawn_struct.white_value += 2*bitcount(board->piece[WHITE][PAWN]
						& black_squares);
	else
	  pawn_struct.white_value += 2*bitcount(board->piece[WHITE][PAWN]
						& white_squares);
      }
      if (bitcount(board->piece[WHITE][BISHOP]) == 1) {
	if (board->piece[WHITE][BISHOP] & white_squares)
	  pawn_struct.black_value += 2*bitcount(board->piece[BLACK][PAWN]
						& black_squares);
	else
	  pawn_struct.black_value += 2*bitcount(board->piece[BLACK][PAWN]
						& white_squares);
      }
    }
  }

  if (*color == WHITE) {
    return (wvalue - bvalue);
  } else {   //black's turn, invert the value
    return bvalue - wvalue;
  }
}
