#ifndef _ITERDEEP_
#define _ITERDEEP_

#include "bitboards.h"
#include "misc.h"

#define VALWINDOW (VAL_PAWN/2)
#define SECOND_ATTEMPT_VALWINDOW (VAL_PAWN)
#define MAX_ITERATIONS 40

int next_state(int val, int *alpha, int *beta, int *org_alpha, int *org_beta,
	       int *state, int *re_searches);
void iterative_deepening_aspiration_search(struct board *board, int color,
					   struct move *movelist, int mcount, int histpos);

#endif        //_ITERDEEP_

