#include "genmoves.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "bitboards.h"
#include "diverse.h"
//#include "bonde.h"
//#include "torn.h"
//#include "hast.h"
//#include "lopare.h"
//#include "dam.h"
//#include "kung.h"

//#define MALLOC_CHECK_ 0

/* Denna funktion reallokerar en listas storlek i minnet. */
int change_list_size(struct move **list, int new_size) {
  struct move *ny_lista;

  if((ny_lista = (struct move *) realloc(*list,(new_size + 1)*sizeof(struct move))) == NULL) {
    perror("Realloc failed");
    exit(1);
  } else
    *list = ny_lista;
  
  return new_size;
}

int generate_pawnmoves(struct board *board, int color, struct move **movelist, int *listsize, int *mcount, int hpos, int boardpos) {
  int64 targets, target;
  int oppcolor = color;
  extern bitboard square[64];
  extern bitboard pawn_start[2];
  extern bitboard pawn_lastrow[2];
  extern bitboard pawn_passantrow[2];
  extern struct attack attack;
  extern struct move **historik;

  switch_colors(&oppcolor);

  if (color == WHITE) {
    /* White pawn goes one step forward. */
    targets = (square[boardpos] >> 8) &
      ~(board->all_pieces[WHITE] | board->all_pieces[BLACK]);
    if (square[boardpos] & pawn_start[WHITE]) //white pawn at starting square
      if (targets)    //the pawn can go one step forward
	/* White pawn goes two steps forward. */
	targets = targets | ((square[boardpos] >> 16) &
			     ~(board->all_pieces[WHITE]
			       | board->all_pieces[BLACK]));
  } else {    //color == BLACK
    /* BLACK pawn goes one step forward. */
    targets = (square[boardpos] << 8) &
      ~(board->all_pieces[WHITE] | board->all_pieces[BLACK]);
    if (square[boardpos] & pawn_start[BLACK]) //black pawn at starting square
      if (targets)    //the pawn can go one step forward
	/* BLACK pawn goes two steps forward. */
	targets = targets | ((square[boardpos] << 16) &
			     ~(board->all_pieces[WHITE]
			       | board->all_pieces[BLACK]));
  }
  /* We also need to add the capture moves. */
  targets = targets | (attack.pawn[color][boardpos] & board->all_pieces[oppcolor]);
  
  /* We also need to add the passant moves. First we check if the opponent's
     last move was a pawn move, which went to a square to where I can
     possibly make a passant move. */
  if ((*historik)[hpos-1].tsquare & board->piece[oppcolor][PAWN] & pawn_passantrow[oppcolor]) {
    /* Then we check if the opponent's pawn went from his starting square.
       (Passant is only allowed when you go from eg. e2e4, and not for
       e3e4). We also check that the pawn in the process of making the move
       is standing on the passant row. */
    if ((square[boardpos] & pawn_passantrow[oppcolor])
	&& ((*historik)[hpos-1].fsquare & pawn_start[oppcolor])) {
      /* Make sure passant can only be done to an adjacent column.
	 (h2h4 doesn't make the passant move c4h3 legal.) */
      if (((square[boardpos] << 1) & (*historik)[hpos-1].tsquare)
	  || ((square[boardpos] >> 1) & (*historik)[hpos-1].tsquare)) {
	if (color == WHITE)
	  targets = targets | ((*historik)[hpos-1].tsquare >> 8);
	else
	  targets = targets | ((*historik)[hpos-1].tsquare << 8);
      }
    }
  }
  
  /* Check if the opponent's king can be taken. */
  if (targets & board->piece[oppcolor][KING])
    return 0;
  
  /* Go through the destinations to where the given piece can attack. */
  while (targets != 0) {
    //target = square[get_first_bitpos(targets)];
    target = getlsb(targets);
    /* One target square can generate up to 4 moves (the promotion moves). */
    if (*mcount + 4 >= *listsize)
      *listsize = change_list_size(movelist,(*listsize)+20);
    (*movelist)[*mcount].fsquare = square[boardpos];
    (*movelist)[*mcount].tsquare = target;
    
    /* Find out what type of move it was. */
    if (target & board->all_pieces[oppcolor])
      (*movelist)[*mcount].type = CAPTURE_MOVE;
    else if (attack.pawn[color][boardpos] & target) {
      /* If the move is an attack to a square with no enemy piece
	 occupying it. */
      (*movelist)[*mcount].type = CAPTURE_MOVE | PASSANT_MOVE;
    } else
      (*movelist)[*mcount].type = NORMAL_MOVE;
    (*movelist)[*mcount].piece = PAWN;
    (*mcount)++;
    
    /* If the pawn goes to the last row, then we set the move that was
       just added to the movelist, to be a queen promotion, and then add
       moves for promotion to rook, bishop and knight respectively. */
    if (target & pawn_lastrow[color]) {
      (*movelist)[(*mcount)-1].type = (*movelist)[(*mcount)-1].type | QUEEN_PROMOTION_MOVE;
      (*movelist)[*mcount].fsquare = square[boardpos];
      (*movelist)[*mcount].tsquare = target;
      (*movelist)[*mcount].type = ((*movelist)[(*mcount)-1].type | ROOK_PROMOTION_MOVE) & ~QUEEN_PROMOTION_MOVE;
      (*movelist)[*mcount].piece = PAWN;
      (*mcount)++;
      (*movelist)[*mcount].fsquare = square[boardpos];
      (*movelist)[*mcount].tsquare = target;
      (*movelist)[*mcount].type = ((*movelist)[(*mcount)-1].type | BISHOP_PROMOTION_MOVE) & ~ROOK_PROMOTION_MOVE;
      (*movelist)[*mcount].piece = PAWN;
      (*mcount)++;
      (*movelist)[*mcount].fsquare = square[boardpos];
      (*movelist)[*mcount].tsquare = target;
      (*movelist)[*mcount].type = ((*movelist)[(*mcount)-1].type | KNIGHT_PROMOTION_MOVE) & ~BISHOP_PROMOTION_MOVE;
      (*movelist)[*mcount].piece = PAWN;
      (*mcount)++;
    }
    /* Unset the bit in targets that contained the target. */
    targets = targets & ~target;
  }
  return 1;
}

int generate_kingmoves(struct board *board, int color, struct move **movelist, int *listsize, int *mcount, int boardpos) {
  int64 targets, target;
  int oppcolor = color;
  extern bitboard square[64];
  extern struct attack attack;

  switch_colors(&oppcolor);

  targets = attack.king[boardpos] & (~board->all_pieces[color]);

  if (color == WHITE) {
    if (board->status[WHITE] & SHORT_CASTLING_OK)
      /* Check if the squares between the king and the rook are empty. */
      if (((board->all_pieces[WHITE] | board->all_pieces[BLACK]) &
	   (square[61] | square[62])) == 0) {
	/* Make a final check to see if the king's square is in check,
	   or if the destination square is in check, or if the square in
	   between is in check. */
	if (!in_check(board,color)) {
	  board->piece[color][KING] = square[61];
	  if (!in_check(board,color)) {
	    board->piece[color][KING] = square[62];
	    if (!in_check(board,color))
	      targets = targets | square[62];
	  }
	  board->piece[color][KING] = square[60];
	}
      }
    if (board->status[WHITE] & LONG_CASTLING_OK)
      /* Check if the squares between the king and the rook are empty. */
      if (((board->all_pieces[WHITE] | board->all_pieces[BLACK]) &
	   (square[57] | square[58] | square[59])) == 0) {
	/* Make a final check to see if the king's square is in check,
	   or if the destination square is in check, or if the square in
	   between is in check. */
	if (!in_check(board,color)) {
	  board->piece[color][KING] = square[59];
	  if (!in_check(board,color)) {
	    board->piece[color][KING] = square[58];
	    if (!in_check(board,color))
	      targets = targets | square[58];
	  }
	  board->piece[color][KING] = square[60];
	}
      }
  } else {    //color == BLACK
    if (board->status[BLACK] & SHORT_CASTLING_OK)
      /* Check if the squares between the king and the rook are empty. */
      if (((board->all_pieces[WHITE] | board->all_pieces[BLACK]) &
	   (square[5] | square[6])) == 0) {
	/* Make a final check to see if the king's square is in check,
	   or if the destination square is in check, or if the square in
	   between is in check. */
	if (!in_check(board,color)) {
	  board->piece[color][KING] = square[5];
	  if (!in_check(board,color)) {
	    board->piece[color][KING] = square[6];
	    if (!in_check(board,color))
	      targets = targets | square[6];
	  }
	  board->piece[color][KING] = square[4];
	}
      }
    if (board->status[BLACK] & LONG_CASTLING_OK)
      /* Check if the squares between the king and the rook are empty. */
      if (((board->all_pieces[WHITE] | board->all_pieces[BLACK]) &
	   (square[1] | square[2] | square[3])) == 0) {
	/* Make a final check to see if the king's square is in check,
	   or if the destination square is in check, or if the square in
	   between is in check. */
	if (!in_check(board,color)) {
	  board->piece[color][KING] = square[3];
	  if (!in_check(board,color)) {
	    board->piece[color][KING] = square[2];
	    if (!in_check(board,color))
	      targets = targets | square[2];
	  }
	  board->piece[color][KING] = square[4];
	}
      }
  }

  /* Check if the opponent's king can be taken. */
  if (targets & board->piece[oppcolor][KING])
    return 0;
  
  /* Go through the destinations to where the given piece can attack. */
  while (targets != 0) {
    //target = square[get_first_bitpos(targets)];
    target = getlsb(targets);
    if (*mcount == *listsize)
      *listsize = change_list_size(movelist,(*listsize)+20);
    (*movelist)[*mcount].fsquare = square[boardpos];
    (*movelist)[*mcount].tsquare = target;
    
    /* Find out what type of move it was. */
    if (target & board->all_pieces[oppcolor])
      (*movelist)[*mcount].type = CAPTURE_MOVE;
    else if ((color == WHITE && (board->piece[color][KING] & square[60])
	     && ((target & square[62]) || (target & square[58])))
	     || (color == BLACK && (board->piece[color][KING] & square[4])
	     && ((target & square[6]) || (target & square[2]))))
      (*movelist)[*mcount].type = CASTLING_MOVE;
    else
      (*movelist)[*mcount].type = NORMAL_MOVE;
    (*movelist)[*mcount].piece = KING;
    (*mcount)++;
    /* Unset the bit in targets that contained the target. */
    targets = targets & ~target;
  }
  return 1;
}

/* This function generates moves that don't use any rotated bitboards.
   Diagonal movement and vertical movement needs rotated bitboards.
   Knight moves and king moves don't need rotated bitboards. */
int generate_horizontal_moves(struct board *board, int color, struct move **movelist, int *listsize, int *mcount, int piecetype, int boardpos) {
  int64 targets, target;
  int oppcolor = color, occupancy;
  extern bitboard square[64];
  extern struct attack attack;

  switch_colors(&oppcolor);
  if (piecetype == KNIGHT)
    targets = attack.knight[boardpos] & (~board->all_pieces[color]);
  else {
    occupancy = ((board->all_pieces[WHITE]
		  | board->all_pieces[BLACK]) >> ((boardpos/8)*8)) & 255;
    targets = attack.hslider[boardpos][occupancy] & (~board->all_pieces[color]);
  }

  /* Check if the opponent's king can be taken. */
  if (targets & board->piece[oppcolor][KING])
    return 0;
      
  /* Go through the destinations to where the given piece can attack. */
  while (targets != 0) {
    //target = square[get_first_bitpos(targets)];
    target = getlsb(targets);
    if (*mcount == *listsize)
      *listsize = change_list_size(movelist,(*listsize)+20);
    (*movelist)[*mcount].fsquare = square[boardpos];
    (*movelist)[*mcount].tsquare = target;

    /* Find out what type of move it was. */
    if (target & board->all_pieces[oppcolor])
      (*movelist)[*mcount].type = CAPTURE_MOVE;
    else
      (*movelist)[*mcount].type = NORMAL_MOVE;
    (*movelist)[*mcount].piece = piecetype;
    (*mcount)++;
    /* Unset the bit in targets that contained the target. */
    targets = targets & ~target;
  }
  return 1;
}

/* This function generates moves that go vertically along the board.
   This function is needed for generating queen and rook moves. */
int generate_vertical_moves(struct board *board, int color, struct move **movelist, int *listsize, int *mcount, int piecetype, int boardpos) {
  int64 targets;
  int oppcolor = color, occupancy, target;
  extern bitboard square[64];
  extern struct attack attack;
  extern int rotate90to0[64];
  extern int rotate0to90[64];

  switch_colors(&oppcolor);

  /* We calculate the vertical moves (files) by using the rotated
     bitboard board.rot90_pieces, and getting the occupancy number of
     the file in question by reading off the occupancy of the rank in
     this rotated bitboard. Then we switch back to "unrotated" before
     we add the move to the movelist. */
  occupancy = ((board->rot90_pieces[WHITE]
		| board->rot90_pieces[BLACK]) >> (rotate0to90[boardpos]/8)*8) & 255;
  targets = attack.hslider[rotate0to90[boardpos]][occupancy] & (~board->rot90_pieces[color]);

  /* Check if the opponent's king can be taken. */
  if (targets & square[rotate0to90[get_first_bitpos(board->piece[oppcolor][KING])]])
    return 0;
      
  /* Go through the destinations to where the given piece can attack. */
  while (targets != 0) {
    target = get_first_bitpos(targets);
    if (*mcount == *listsize)
      *listsize = change_list_size(movelist,(*listsize)+20);
    (*movelist)[*mcount].fsquare = square[boardpos];
    (*movelist)[*mcount].tsquare = square[rotate90to0[target]];

    /* Find out what type of move it was. */
    if (square[target] & board->rot90_pieces[oppcolor])
      (*movelist)[*mcount].type = CAPTURE_MOVE;
    else
      (*movelist)[*mcount].type = NORMAL_MOVE;
    (*movelist)[*mcount].piece = piecetype;
    (*mcount)++;
    /* Unset the bit in targets that contained the target. */
    targets = targets & ~(square[target]);
  }
  return 1;
}

/* This function generates moves that go diagonally along the board
   in the northeast direction (the a1-h8 diagonal). This function is
   needed for generating queen and bishop moves. */
int generate_NEdiag_moves(struct board *board, int color, struct move **movelist, int *listsize, int *mcount, int piecetype, int boardpos) {
  int64 targets, target;
  int oppcolor = color, occupancy;
  extern bitboard square[64];
  extern struct attack attack;
  //extern int rotateNEto0[64];
  extern int rotate0toNE[64];
  extern int ones[9];
  extern int diagNE_start[64];
  extern int diagNE_length[64];

  switch_colors(&oppcolor);

  occupancy = (board->rotNE_pieces[WHITE] | board->rotNE_pieces[BLACK]) >> (rotate0toNE[diagNE_start[boardpos]]) & ones[diagNE_length[boardpos]];
  targets = attack.sliderNE[boardpos][occupancy] & (~board->all_pieces[color]);

  /* Check if the opponent's king can be taken. */
  if (targets & board->piece[oppcolor][KING])
    return 0;
      
  /* Go through the destinations to where the given piece can attack. */
  while (targets != 0) {
    //target = square[get_first_bitpos(targets)];
    target = getlsb(targets);
    if (*mcount == *listsize)
      *listsize = change_list_size(movelist,(*listsize)+20);
    (*movelist)[*mcount].fsquare = square[boardpos];
    (*movelist)[*mcount].tsquare = target;

    /* Find out what type of move it was. */
    if (target & board->all_pieces[oppcolor])
      (*movelist)[*mcount].type = CAPTURE_MOVE;
    else
      (*movelist)[*mcount].type = NORMAL_MOVE;
    (*movelist)[*mcount].piece = piecetype;
    (*mcount)++;
    /* Unset the bit in targets that contained the target. */
    targets = targets & ~target;
  }
  return 1;
}

/* This function generates moves that go diagonally along the board
   in the northwest direction (the h1-a8 diagonal). This function is
   needed for generating queen and bishop moves. */
int generate_NWdiag_moves(struct board *board, int color, struct move **movelist, int *listsize, int *mcount, int piecetype, int boardpos) {
  int64 targets, target;
  int oppcolor = color, occupancy;
  extern bitboard square[64];
  extern struct attack attack;
  //extern int rotateNWto0[64];
  extern int rotate0toNW[64];
  extern int ones[9];
  extern int diagNW_start[64];
  extern int diagNW_length[64];

  switch_colors(&oppcolor);

  occupancy = (board->rotNW_pieces[WHITE] | board->rotNW_pieces[BLACK]) >> (rotate0toNW[diagNW_start[boardpos]]) & ones[diagNW_length[boardpos]];
  targets = attack.sliderNW[boardpos][occupancy] & (~board->all_pieces[color]);

  /* Check if the opponent's king can be taken. */
  if (targets & board->piece[oppcolor][KING])
    return 0;
      
  /* Go through the destinations to where the given piece can attack. */
  while (targets != 0) {
    //target = square[get_first_bitpos(targets)];
    target = getlsb(targets);
    if (*mcount == *listsize)
      *listsize = change_list_size(movelist,(*listsize)+20);
    (*movelist)[*mcount].fsquare = square[boardpos];
    (*movelist)[*mcount].tsquare = target;

    /* Find out what type of move it was. */
    if (target & board->all_pieces[oppcolor])
      (*movelist)[*mcount].type = CAPTURE_MOVE;
    else
      (*movelist)[*mcount].type = NORMAL_MOVE;
    (*movelist)[*mcount].piece = piecetype;
    (*mcount)++;
    /* Unset the bit in targets that contained the target. */
    targets = targets & ~target;
  }
  return 1;
}

/* This method returns true(=1) if the king in the specified color is
   threatened. Else false(=0).*/
int in_check(struct board *board, int color) {
  int64 pieces;
  struct move **movelist;
  int oppcolor = color;
  int quit = 0;
  int listsize = 40;
  int retval = 1, i, piece_nbr;
  int mcount = 0;
  extern bitboard square[64];

  switch_colors(&oppcolor);
  movelist = (struct move **) malloc(sizeof(struct move *));
  *movelist = (struct move *) malloc(listsize*sizeof(struct move));

  /* Go through all the piecetypes and pieces, and see if the opponent can
     take the king. */
  for (i = 0; i < 6; i++) {
    pieces = board->piece[oppcolor][i];
    while (pieces != 0) {
      piece_nbr = get_first_bitpos(pieces);
      if (i == PAWN) {
	/* The value you use for hpos doesn't matter, because hpos is
	   only used for determining if passant moves are possible, and
	   passant can't take kings, only pawns. So we only have to make
	   sure we use a value that doesn't give us any segmentation
	   fault. A value of for example 5 will do. */
	if (!generate_pawnmoves(board,oppcolor,movelist,&listsize,&mcount,5,piece_nbr))
	  quit = 1;
      } else if (i == ROOK) {
        if (!generate_horizontal_moves(board,oppcolor,movelist,
                                       &listsize,&mcount,i,piece_nbr))
          quit = 1;
        if (!generate_vertical_moves(board,oppcolor,movelist,
                                     &listsize,&mcount,i,piece_nbr))
          quit = 1;
      } else if (i == KNIGHT) {
        if (!generate_horizontal_moves(board,oppcolor,movelist,
                                       &listsize,&mcount,i,piece_nbr))
          quit = 1;
      } else if (i == BISHOP) {
        if (!generate_NEdiag_moves(board,oppcolor,movelist,
                                   &listsize,&mcount,i,piece_nbr))
          quit = 1;
        if (!generate_NWdiag_moves(board,oppcolor,movelist,
                                   &listsize,&mcount,i,piece_nbr))
          quit = 1;
      } else if (i == QUEEN) {
        if (!generate_horizontal_moves(board,oppcolor,movelist,
                                       &listsize,&mcount,i,piece_nbr))
          quit = 1;
        if (!generate_vertical_moves(board,oppcolor,movelist,
                                     &listsize,&mcount,i,piece_nbr))
          quit = 1;
        if (!generate_NEdiag_moves(board,oppcolor,movelist,
                                   &listsize,&mcount,i,piece_nbr))
          quit = 1;
        if (!generate_NWdiag_moves(board,oppcolor,movelist,
                                   &listsize,&mcount,i,piece_nbr))
          quit = 1;
      } else if (i == KING) {
	//do nothing, a king can't take it's opponent king
      }
      if (quit)
	break;
      pieces = pieces & ~square[piece_nbr];
    }
    if (quit)
      break;
  }
  if (!quit)
    retval = 0;
  free(*movelist);
  free(movelist);
  return retval;
}

/* This function returns all pseudo-legal moves in a given position. Meaning
   it doesn't check if the move places it's own king in check. That has to be
   checked elsewhere. If the opponent's king can be taken 0 is returned. */
int generate_moves(struct board *board, int color, struct move **movelist, int *mcount, int hpos) {
  int64 pieces;
  int i, listsize, piece_nbr;
  extern bitboard square[64];
  int oppcolor = color;

  switch_colors(&oppcolor);
  *mcount = 0;
  listsize = 40;
  *movelist = (struct move *) malloc(listsize*sizeof(struct move));

  /* Go through all types of pieces (6 types) */
  for (i = 0; i < 6; i++) {
    pieces = board->piece[color][i];

    /* Go through the pieces of the given type */
    while (pieces != 0) {
      piece_nbr = get_first_bitpos(pieces);
      if (i == PAWN) {
	if (!generate_pawnmoves(board,color,movelist,&listsize,mcount,hpos,piece_nbr))
	  return 0;
      } else if (i == ROOK) {
	if (!generate_horizontal_moves(board,color,movelist,
				       &listsize,mcount,i,piece_nbr))
	  return 0;
	if (!generate_vertical_moves(board,color,movelist,
				     &listsize,mcount,i,piece_nbr))
	  return 0;
      } else if (i == KNIGHT) {
	if (!generate_horizontal_moves(board,color,movelist,
				       &listsize,mcount,i,piece_nbr))
	  return 0;
      }	else if (i == BISHOP) {
	if (!generate_NEdiag_moves(board,color,movelist,
				   &listsize,mcount,i,piece_nbr))
	  return 0;
	if (!generate_NWdiag_moves(board,color,movelist,
				   &listsize,mcount,i,piece_nbr))
	  return 0;
      } else if (i == QUEEN) {
	if (!generate_horizontal_moves(board,color,movelist,
				       &listsize,mcount,i,piece_nbr))
	  return 0;
	if (!generate_vertical_moves(board,color,movelist,
				     &listsize,mcount,i,piece_nbr))
	  return 0;
	if (!generate_NEdiag_moves(board,color,movelist,
				   &listsize,mcount,i,piece_nbr))
	  return 0;
	if (!generate_NWdiag_moves(board,color,movelist,
				   &listsize,mcount,i,piece_nbr))
	  return 0;
      } else if (i == KING) {
	if (!generate_kingmoves(board,color,movelist,&listsize,
				mcount,piece_nbr))
	  return 0;
      }
      pieces = pieces & ~square[piece_nbr];
    }
  }
  return 1;
}


