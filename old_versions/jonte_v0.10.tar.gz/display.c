#include "display.h"
#include <stdio.h>
#include "symboler.h"
#include "bitboards.h"
#include "diverse.h"

/*void printmoves(struct drag *draglista) {
  int i = 0;
  char *dragstr;

  dragstr = (char *) malloc(20*sizeof(char));
  while (draglista[i].fromrow != -99) {
    drag2str(draglista[i],dragstr);
    printf("%s\n",dragstr);
    i++;
  }
  free(dragstr);
  }*/

char getPjasBokstav(int pjas) {
  switch(pjas) {
    case PAWN : return 'p';
                break;
    case ROOK : return 'R';
                break;
    case KNIGHT : return 'N';
                  break;
    case BISHOP : return 'B';
                  break;
    case QUEEN : return 'D';
                 break;
    case KING : return 'K';
                break;
    case EMPTY : return ' ';
                 break;
  }
  return '?';
}

/*void print_table(int **spelplan) {
  int rad = 0, kol = 0;
  //CLRSCR;
  //GOTOXY(0,0);
  printf("  ---------------------------------\n");
  for (rad = 0; rad < 8; rad++) {
    printf("%d ",8 - rad);
    for (kol = 0; kol < 8; kol++) {
      printf("|");
      if (spelplan[rad][kol] > 0)
	INVERT;
      printf(" %c ",getPjasBokstav(spelplan[rad][kol]));
      //printf(" %d ",spelplan[rad][kol]);
      NORMAL;
    }
    printf("|\n");
    if (rad < 7)
      printf("  |---+---+---+---+---+---+---+---|\n");
  }
  printf("  ---------------------------------\n");
  printf("    A   B   C   D   E   F   G   H\n");
  }*/

void showboard(struct board *board) {
  int rad = 0, kol = 0;
  int temp[64];
  int i, square_nbr;
  int64 pieces;
  extern bitboard square[64];

  for (kol = 0; kol < 64; kol++)
    temp[kol] = EMPTY;

  for (i = 0; i < 6; i++) {
    pieces = board->piece[WHITE][i];
    while (pieces != 0) {
      square_nbr = get_first_bitpos(pieces);
      if (i == PAWN)
	temp[square_nbr] = PAWN;
      else if (i == ROOK)
	temp[square_nbr] = ROOK;
      else if (i == KNIGHT)
	temp[square_nbr] = KNIGHT;
      else if (i == BISHOP)
	temp[square_nbr] = BISHOP;
      else if (i == QUEEN)
	temp[square_nbr] = QUEEN;
      else if (i == KING)
	temp[square_nbr] = KING;
      pieces = pieces & ~square[square_nbr];
    }
  }

  for (i = 0; i < 6; i++) {
    pieces = board->piece[BLACK][i];
    while (pieces != 0) {
      square_nbr = get_first_bitpos(pieces);
      if (i == PAWN)
	temp[square_nbr] = PAWN;
      else if (i == ROOK)
	temp[square_nbr] = ROOK;
      else if (i == KNIGHT)
	temp[square_nbr] = KNIGHT;
      else if (i == BISHOP)
	temp[square_nbr] = BISHOP;
      else if (i == QUEEN)
	temp[square_nbr] = QUEEN;
      else if (i == KING)
	temp[square_nbr] = KING;
      pieces = pieces & ~square[square_nbr];
    }
  }

  printf("  ---------------------------------\n");
  for (rad = 0; rad < 8; rad++) {
    printf("%d ",8 - rad);
    for (kol = 0; kol < 8; kol++) {
      printf("|");
      //if (temp[rad*8 + kol] > 0)
      //INVERT;
      if (board->piece[WHITE][temp[rad*8+kol]] & square[rad*8+kol])
	INVERT;
      printf(" %c ",getPjasBokstav(temp[rad*8 + kol]));
      NORMAL;
    }
    printf("|\n");
    if (rad < 7)
      printf("  |---+---+---+---+---+---+---+---|\n");
  }
  printf("  ---------------------------------\n");
  printf("    A   B   C   D   E   F   G   H\n");
}

void showsettings(int *white, int *black, int *vemstur, int *started) {
  //int i;

  printf("Vit     : ");
  if (*white == COMPUTER)
    printf("dator\n");
  else
    printf("m�nniska\n");
  printf("Svart   : ");
  if (*black == COMPUTER)
    printf("dator\n");
  else
    printf("m�nniska\n");
  printf("Vems tur: ");
  if (*vemstur == WHITE)
    printf("vit\n");
  else
    printf("svart\n");
  printf("Algoritm: ");
  if (STRATEGY == RANDOM)
    printf("slumpm�ssigt drag\n");
  else if (STRATEGY == MINMAX)
    printf("minmax (t�nker %.1f drag fram�t)\n",(double)THINKFORWARD/2);
  else if (STRATEGY == ALPHABETA)
    printf("alfa-beta besk�rning (t�nker %.1f drag fram�t)\n",(double)THINKFORWARD/2);
  else
    printf("ERROR\n");
  /*printf("\nServer: hastighet = %d\n",speed);
  printf("\nKlienter:\n");
  if (clientcount == 0) {
    printf("inga\n");
  } else {
    for (i = 0; i < clientcount; i++) {
      printf("%s (hastighet = %d)\n",clientlist[i].hostname,clientlist[i].speed);
    }
    }*/
  if (!*started)
    printf("\nParti ej startat.\n");
}

void showhelp() {
  printf("\nCommand:    Meaning:\n\n");
  printf("visa         Draw the board\n");
  printf("starta       Start a new game\n");
  //printf("tanke        Skriv ut hur datorn t�nkte\n");
  printf("hist         Show move history\n");
  printf("inst         Show settings\n");
  printf("vitdator     Computer plays white\n");
  printf("vitman       Human plays white (default)\n");
  printf("svartdator   Computer plays black (default)\n");
  printf("svartman     Human plays black\n");
  printf("xboard       enter xboard-mode\n\n");
  //printf("(Notera att datorn kan spela mot sig sj�lv, eller\n");
  //printf(" om man s� vill, tv� m�nniskor mot varandra.)\n\n");

  printf("?            Show help\n");
  printf("help         Show help\n");
  printf("quit         Quit the program\n\n");

  printf("If you make a move, it should be written in the form\n");
  printf("e2e4 for normal moves, and a7a8[q|r|b|n] for pawn promotions.\n");
}


