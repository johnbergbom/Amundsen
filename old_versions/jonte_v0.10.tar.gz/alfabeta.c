#include "alfabeta.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include "moves.h"
#include "genmoves.h"
#include "eval.h"
#include "slump.h"
//#include "history.h"
//#include "netdiverse.h"
//#include "serialization.h"

extern int xboard_mode;
int lagge = 0;
int lagge_int = 0;
//int lagge_int2 = 0;
//int lagge_int3 = 0;
//int lagge_int4 = 0;
//int lagge_int5 = 0;

int max(int a, int b) {
  if (a > b)
    return a;
  else
    return b;
}

int min(int a, int b) {
  if (a > b)
    return b;
  else
    return a;
}

int quiescence(struct board *board, int vemstur, int org_color, int nodetype, int alpha, int beta, bitboard tsquare, int hpos) {
  struct move *movelist;
  struct board newpos;
  int mcount;
  int retval;
  int q_val;
  int i = 0;
  int qmoves = 0;
  extern struct move **historik;
  int oppcolor = vemstur;

  switch_colors(&vemstur);
  if (nodetype == MAX) {
    retval = -INFTY;
    //showboard(board);
    if (generate_moves(board,vemstur,&movelist,&mcount,hpos)) {
      for (i = 0; i < mcount; i++) {
	/* G�r bara de drag som sl�r i samma ruta. */
	if (movelist[i].tsquare == tsquare) {
	  makemove(board,&newpos,vemstur,movelist[i]);
	  (*historik)[hpos] = movelist[i];
	  q_val = quiescence(&newpos,vemstur,org_color,MIN,alpha,beta,tsquare,hpos+1);
	  if (q_val != KINGTAKEN) {
	    qmoves++;
	    retval = max(retval,q_val);
	    alpha = max(alpha,retval);
	    if (retval >= beta)
	      break;
	  }
	}
      }
    } else
      retval = KINGTAKEN;
    free(movelist);
  } else {   //nodetype == MIN
    retval = INFTY;
    if (generate_moves(board,vemstur,&movelist,&mcount,hpos)) {
      for (i = 0; i < mcount; i++) {
	/* G�r bara de drag som sl�r i samma ruta. */
	if (movelist[i].tsquare == tsquare) {
	  makemove(board,&newpos,vemstur,movelist[i]);
	  (*historik)[hpos] = movelist[i];
	  q_val = quiescence(&newpos,vemstur,org_color,MAX,alpha,beta,tsquare,hpos+1);
	  if (q_val != KINGTAKEN) {
	    qmoves++;
	    retval = min(retval,q_val);
	    beta = min(beta,retval);
	    if (retval <= alpha)
	      break;
	  }
	}
      }
    } else
      retval = KINGTAKEN;
    free(movelist);
  }

  if (!qmoves && retval != KINGTAKEN)
    retval = eval(&org_color,board);
  return retval;
}

int alphabeta(struct board *board, int vemstur, int org_color, int nodetype, int alpha, int beta, int depth, int hpos) {
  struct move *movelist;
  struct board newpos;
  int mcount;
  int retval;
  int a_val;
  int i = 0;
  int oppcolor = vemstur;
  extern struct move **historik;
  int opp_piece;
  extern int pieceval[6];

  switch_colors(&vemstur);
  if (depth == 0) {
    retval = eval(&org_color,board);
  } else if (nodetype == MAX) {
    retval = -INFTY;
    if (generate_moves(board,vemstur,&movelist,&mcount,hpos)) {
      for (i = 0; i < mcount; i++) {
	//old_to_square = board->all_pieces[oppcolor] & movelist[i].tsquare;
	makemove(board,&newpos,vemstur,movelist[i]);
	(*historik)[hpos] = movelist[i];
	/* Om detta drag blir det sista draget i s�kningen, och draget
	   sl�r en motst�ndarpj�s, s� skall quiescence-s�kningen k�ras,
	   annars vanlig alphabeta. */
	if ((depth-1 == 0) && (movelist[i].type & CAPTURE_MOVE)) {
	  /* If move is a capture, then figure out what piece it's taking. */
	  
	  /* LATTE!!!!!!!!!!!!!!!!! HAR KOLLAR DEN TVA GANGER OM
	     movelist[i] & CAPTURE_MOVE. BORDE INTE BEHOVAS!!! */
	  
	  if (movelist[i].type & CAPTURE_MOVE) {
	    if (movelist[i].type & PASSANT_MOVE)
	      opp_piece = PAWN;
	    else
	      for (opp_piece = 0; opp_piece < 6; opp_piece++) {
		if (board->piece[oppcolor][opp_piece] & movelist[i].tsquare)
		  break;
	      }
	  }
	  /* If a lower valued piece takes a better one, we don't care about
	     quiescence search. */
	  if (pieceval[opp_piece] > pieceval[movelist[i].piece])
	    a_val = alphabeta(&newpos,vemstur,org_color,MIN,alpha,beta,depth-1,hpos+1);
	  else
	    a_val = quiescence(&newpos,vemstur,org_color,MIN,alpha,beta,movelist[i].tsquare,hpos+1);
	} else
	  a_val = alphabeta(&newpos,vemstur,org_color,MIN,alpha,beta,depth-1,hpos+1);
	if (a_val != KINGTAKEN) {
	  retval = max(retval,a_val);
	  alpha = max(alpha,retval);
	  if (retval >= beta)
	    break;
	}
      }
    } else
      retval = KINGTAKEN;
    free(movelist);
  } else {   //nodetype == MIN
    retval = INFTY;
    if (generate_moves(board,vemstur,&movelist,&mcount,hpos)) {
      for (i = 0; i < mcount; i++) {
	makemove(board,&newpos,vemstur,movelist[i]);
	(*historik)[hpos] = movelist[i];
	/* Om detta drag blir det sista draget i s�kningen, och draget
	   sl�r en motst�ndarpj�s, s� skall quiescence-s�kningen k�ras,
	   annars vanlig alphabeta. */
	if ((depth-1 == 0) && (movelist[i].type & CAPTURE_MOVE)) {
	  /* If move is a capture, then figure out what piece it's taking. */
	  if (movelist[i].type & CAPTURE_MOVE) {
	    if (movelist[i].type & PASSANT_MOVE)
	      opp_piece = PAWN;
	    else
	      for (opp_piece = 0; opp_piece < 6; opp_piece++) {
		if (board->piece[oppcolor][opp_piece] & movelist[i].tsquare)
		  break;
	      }
	  }
	  /* If a lower valued piece takes a better one, we don't care about
	     quiescence search. */
	  if (pieceval[opp_piece] > pieceval[movelist[i].piece])
	    a_val = alphabeta(&newpos,vemstur,org_color,MAX,alpha,beta,depth-1,hpos+1);
	  else
	    a_val = quiescence(&newpos,vemstur,org_color,MAX,alpha,beta,movelist[i].tsquare,hpos+1);
	} else
	  a_val = alphabeta(&newpos,vemstur,org_color,MAX,alpha,beta,depth-1,hpos+1);
	if (a_val != KINGTAKEN) {
	  retval = min(retval,a_val);
	  beta = min(beta,retval);
	  if (retval <= alpha)
	    break;
	}
      }
    } else
      retval = KINGTAKEN;
    free(movelist);
  } 
  return retval;
}

struct move thinkalphabeta(struct board *board, int vemstur, int depth, int hpos) {
  struct move *movelist;
  struct move *bestmove;
  struct move *validmoves;
  struct board newpos;
  int mcount = 0;
  int bestvalue, b;
  struct move returnmove;
  int alpha = -INFTY, beta = INFTY;
  int org_color = vemstur;
  int i = 0, j = 0;
  char *dragstr;
  extern struct move **historik;

  generate_moves(board,vemstur,&movelist,&mcount,hpos);
  for (i = 0; i < mcount; i++) {
    
    dragstr = (char *) malloc(20*sizeof(char));
    move2str(board,vemstur,movelist[i],dragstr);
    //fprintf(stderr,"move %s\n",dragstr);
    free(dragstr);
    
    makemove(board,&newpos,vemstur,movelist[i]);
    (*historik)[hpos] = movelist[i];
    movelist[i].value = alphabeta(&newpos,vemstur,org_color,MIN,alpha,beta,depth-1,hpos+1);
  }

  /* Remove all invalid moves from the list. (The invalid ones have
     value == KINGTAKEN, those are the moves that checks one's own king) */
  validmoves = (struct move *) malloc(mcount * sizeof(struct move));
  for (i = 0; i < mcount; i++)
    if (movelist[i].value != KINGTAKEN)
      validmoves[j++] = movelist[i];
  mcount = j;

  if (mcount > 0) {
    /* Put the best moves in the array bestmove, and chose a random best move.
       (Provided there are several moves which are equally good.) */
    bestmove = (struct move *) malloc(mcount * sizeof(struct move));
    bestvalue = validmoves[0].value;
    b = 0;
    for (i = 0; i < mcount; i++) {
      if (validmoves[i].value >= bestvalue) {
	if (validmoves[i].value > bestvalue)
	  b = 0;
	bestvalue = validmoves[i].value;
	bestmove[b++] = validmoves[i];
      }
    }
    returnmove = bestmove[get_random_number(b-1)];
    free(bestmove);
  } else
    returnmove = movelist[0];

  if (!xboard_mode)
    printf("Value = %d\n",returnmove.value);

  free(movelist);
  free(validmoves);
  return returnmove;
}















