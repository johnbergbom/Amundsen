#include "eval.h"
#include "diverse.h"

/*int getPjasValue(int pjas) {
  switch(pjas) {
    case WHITE_PAWN : return 1;
                      break;
    case WHITE_ROOK : return 5;
                      break;
    case WHITE_KNIGHT : return 3;
                      break;
    case WHITE_BISHOP : return 3;
                      break;
    case WHITE_QUEEN : return 9;
                      break;
    case WHITE_KING : return 1;
                      break;
    case BLACK_PAWN : return -1;
                      break;
    case BLACK_ROOK : return -5;
                      break;
    case BLACK_KNIGHT : return -3;
                      break;
    case BLACK_BISHOP : return -3;
                      break;
    case BLACK_QUEEN : return -9;
                      break;
    case BLACK_KING : return -1;
                      break;
    case EMPTY : return 0;
                      break;
  }
  return -99;
  }*/

/* Denna funktion returnerar ett v�rde f�r hur bra en viss st�llning �r.
   H�gt v�rde f�r den spelare som �r vid draget inneb�r att han ligger
   bra till i spelet. */
int eval(int *vemstur, struct board *board) {
  int wvalue = 0, bvalue = 0;
  int i, num;
  extern bitboard col_bitboard[8];
  //int *oppositecolor;

  /*  if (*vemstur == WHITE) {
    for (rad = 0; rad < 8; rad++) {
      for (kol = 0; kol < 8; kol++) {
        value += getPjasValue(spelplan[rad][kol]);
      }
    }
  } else {
    for (rad = 0; rad < 8; rad++) {
      for (kol = 0; kol < 8; kol++) {
        value -= getPjasValue(spelplan[rad][kol]);
      }
    }
    }*/

  /* Check the material balance. */
  wvalue += bitcount(board->piece[WHITE][PAWN])*VAL_PAWN;
  wvalue += bitcount(board->piece[WHITE][ROOK])*VAL_ROOK;
  wvalue += bitcount(board->piece[WHITE][KNIGHT])*VAL_KNIGHT;
  wvalue += bitcount(board->piece[WHITE][BISHOP])*VAL_BISHOP;
  wvalue += bitcount(board->piece[WHITE][QUEEN])*VAL_QUEEN;
  wvalue += bitcount(board->piece[WHITE][KING])*VAL_KING;
  bvalue += bitcount(board->piece[BLACK][PAWN])*VAL_PAWN;
  bvalue += bitcount(board->piece[BLACK][ROOK])*VAL_ROOK;
  bvalue += bitcount(board->piece[BLACK][KNIGHT])*VAL_KNIGHT;
  bvalue += bitcount(board->piece[BLACK][BISHOP])*VAL_BISHOP;
  bvalue += bitcount(board->piece[BLACK][QUEEN])*VAL_QUEEN;
  bvalue += bitcount(board->piece[BLACK][KING])*VAL_KING;

  /* Check for doubled pawns. Each doubled pawn is worth 25% less than
     a normal pawn. */
  /*  for (i = 0; i < 8; i++) {
    num = bitcount(board->piece[WHITE][PAWN] & col_bitboard[i]);
    if (num > 1)
      wvalue = wvalue - num*VAL_PAWN*0.25;
  }
  for (i = 0; i < 8; i++) {
    num = bitcount(board->piece[BLACK][PAWN] & col_bitboard[i]);
    if (num > 1)
      bvalue = bvalue - num*VAL_PAWN*0.25;
      }*/

  //return 0;

  if (*vemstur == WHITE) {
    return (wvalue - bvalue);
  } else {   //black's turn, invert the value
    /*if (value > 0)
      return -value;
    else
    return abs(value);*/
    return bvalue - wvalue;
  }

  //return 0;

  //return value;
}

/* Denna funktion returnerar ett v�rde f�r hur bra en viss st�llning �r.
   Om returv�rdet �r positivt, ligger vit b�ttre till �n svart, och om
   returv�rdet �r negativt, ligger svart b�ttre till �n vit. */
  /*int eval_abs(int **spelplan) {
  int rad, kol, value = 0;

  for (rad = 0; rad < 8; rad++) {
    for (kol = 0; kol < 8; kol++) {
      value += getPjasValue(spelplan[rad][kol]);
    }
  }
  return value;
  }*/




