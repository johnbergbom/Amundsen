#ifndef _GENMOVES_
#define _GENMOVES_

//#include "diverse.h"
#include "bitboards.h"

/* Denna funktion reallokerar en listas storlek i minnet. */
int change_list_size(struct move **list, int new_size);

//int generate_pawnmoves(struct board *board, int color, struct move **movelist, int *listsize, int *mcount, int hpos, int boardpos);

int in_check(struct board *board, int color);

int generate_moves(struct board *board, int color, struct move **movelist, int *mcount, int hpos);

#endif      //_GENMOVES_
