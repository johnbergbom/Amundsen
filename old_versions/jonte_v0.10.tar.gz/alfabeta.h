#ifndef _ALFABETA_
#define _ALFABETA_

#include "diverse.h"
#include "bitboards.h"

#define SAMRE_SLAR_BATTRE 1
#define LIKA_SLAR_LIKA 2
#define BATTRE_SLAR_SAMRE 3

#define KINGTAKEN 500000

int max(int a, int b);

int min(int a, int b);

int quiescence(struct board *board, int vemstur, int org_color, int nodetype, int alpha, int beta, bitboard tsquare, int hpos);

int alphabeta(struct board *board, int vemstur, int org_color, int nodetype, int alpha, int beta, int depth, int hpos);

struct move thinkalphabeta(struct board *board, int vemstur, int depth, int hpos);

#endif       //_ALFABETA_
