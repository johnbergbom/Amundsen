#include <stdio.h>
#include "diverse.h"
#include "slump.h"
#include "bitboards.h"
#include "parse.h"

//extern char *LATTEMINDRAG;
//extern char *LATTEMAXDRAG;

int main(int argc, char **argv) {
  //LATTEMINDRAG = (char *) malloc(20*sizeof(char));
  //LATTEMAXDRAG = (char *) malloc(20*sizeof(char));
  
  setbuf(stdin,NULL);      //set unbuffered input
  setbuf(stdout,NULL);     //set unbuffered output

  debuglog("------------------------------");
  init_random_seed();
  set_bitboards();
  printf("\nThis is Jonte v. 0.25\n");
  printf("Copyright (C)2002-2003 John Bergbom\n");
  printf("\nType \'help\' for a list of commands.\n");

  //spel->spelplan = get_test_board();
  //spel->spelplan = get_test_board2();
  //spel->spelplan = get_test_board3();
  //spel->spelplan = get_test_board4();
  //spel = get_test_board5();
  //spel = get_new_board();

  parse();

  return 0;
}




