#ifndef _DIVERSE_
#define _DIVERSE_

#define DEBUGLOGFILE "log.debug"

/* STRATEGY definierar den strategi datorn ska anv�nda f�r att t�nka
   ut vilket drag den ska g�ra. */
#define RANDOM 1
#define MINMAX 2
#define ALPHABETA 3
#define DEFAULT_STRATEGY ALPHABETA
#ifndef STRATEGY
#define STRATEGY DEFAULT_STRATEGY
#endif

#if STRATEGY < RANDOM || STRATEGY > ALPHABETA
#error STRATEGY ska ha v�rde mellan 1 och 3
#endif

/* Om du inte vill k�ra i debugl�ge, kan du s�tta DEBUG till noll. */
#ifndef DEBUG
#define DEBUG 0
#endif

/*
#define WHITE_PAWN 1
#define WHITE_KNIGHT 2
#define WHITE_BISHOP 3
#define WHITE_ROOK 4
#define WHITE_QUEEN 5
#define WHITE_KING 6

#define BLACK_PAWN -1
#define BLACK_KNIGHT -2
#define BLACK_BISHOP -3
#define BLACK_ROOK -4
#define BLACK_QUEEN -5
#define BLACK_KING -6
*/

#define PAWN 0
#define ROOK 1
#define KNIGHT 2
#define BISHOP 3
#define QUEEN 4
#define KING 5

#define EMPTY 7

#define VAL_PAWN 100
#define VAL_ROOK 500
#define VAL_KNIGHT 300
#define VAL_BISHOP 300
#define VAL_QUEEN 900
#define VAL_KING 10000

/*MAX_PAWN_MOVE ar 12 eftersom en bonde pa nast sista raden kan ga till
  sista raden pa tre olika satt (ta at hoger, ta at vanster, eller ga
  rakt fram), och pa varje stalle kan den forvandlas till fyra olika
  pjaser. */
/*
#define MAX_PAWN_MOVE 12
#define MAX_ROOK_MOVE 14
#define MAX_BISHOP_MOVE 13
#define MAX_QUEEN_MOVE 27
#define MAX_KNIGHT_MOVE 8
#define MAX_KING_MOVE 8

#define PAWN_LETTER 'B'
#define KNIGHT_LETTER 'H'
#define BISHOP_LETTER 'L'
#define ROOK_LETTER 'T'
#define QUEEN_LETTER 'D'
#define KING_LETTER 'K'
#define EMPTY_LETTER ' '
*/

/* THINKFORWARD definierar hur m�nga ply fram�t datorn ska t�nka.
   THINKFORWARD m�ste l�gst ha v�rdet 2, f�r annars kan datorn
   g�ra felaktiga drag, som l�mnar kungen i schack. (Ty om den
   bara t�nker en ply fram�t, s� ser den inte att motst�ndaren
   i n�sta drag kan ta kungen.) */
#define THINKFORWARD 10

#define INFTY 1000000

#define MAX 1
#define MIN 2

#define HUMAN 1
#define COMPUTER 2

#define WHITE 0
#define BLACK 1

//#define KORT_ROCKAD 1
//#define LANG_ROCKAD 2

/*struct drag {
  int fromrow;
  int fromcol;
  int frompjas;
  int torow;
  int tocol;
  int topjas;    //topjas anvands tex. om en bonde forvandlas till dam eller ett torn
  int value;
  int rockad;
  int i_schack;  //blir ettst�lld om draget i fr�ga g�r motst�ndaren schack
};

struct s {
  int vitrockerat;
  int vitkingmoved;
  int vitAtornmoved;
  int vitHtornmoved;
  int svartrockerat;
  int svartkingmoved;
  int svartAtornmoved;
  int svartHtornmoved;
  int **spelplan;
  int evalboard;
  int i_schack;        //ettst�lld om spelaren vid draget st�r i schack
  struct drag *draglista;       //lista pa mojliga drag utifran given spelplan
};
*/

/* OBS! Funktionen kor inte free pa spel->draglista! */
//void freespel(struct s *spel);

void switch_colors(int *color);

void debuglog(char *text);

/*struct s *get_new_board();

int **get_test_board();

int **get_test_board2();

int **get_test_board3();

int **get_test_board4();

struct s *get_test_board5();
*/

#endif      //_DIVERSE_






