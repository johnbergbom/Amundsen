#ifndef _ITERDEEP_
#define _ITERDEEP_

#include "bitboards.h"
#include "diverse.h"

#define VALWINDOW (VAL_PAWN/2)
#define SECOND_ATTEMPT_VALWINDOW (VAL_PAWN)

//struct move iterative_deepening(struct board *board, int color, int maxdepth, int hpos);
struct move iterative_deepening_aspiration_search(struct board *board,
						  int color, int maxdepth,
						  int hpos);

#endif        //_ITERDEEP_

