#ifndef _MOVES_
#define _MOVES_

#include "diverse.h"
#include "bitboards.h"

/*Denna funktion satter som default topjas == frompjas, och rockad == 0. Det
  eftersom detta galler i 99% av fallen. Vid bondeforvandling eller rockad
  far man sjalv satta ratt varde efter att man anropat denna funktion. */
//void initdrag(struct drag *drag, int frad, int fkol, int trad, int tkol, int pjas);

/* This method returns true(=1) if the king in the specified color is
   threatened. Else false(=0).*/
int in_check(struct board *board, int color);

/* This function returns 1 if the move is legal, and 0 if it's illegal. */
int legal_move(struct move move_to_check, struct board *board, int hpos, int color);

/* Denna funktion omvandlar en str�ng till ett struct drag-objekt. Om str�ngen
   �r felaktig returneras -99. */
struct move str2move(char *vilket_drag, struct board *board, int vemstur);

/* Denna funktion omvandlar ett drag till en str�ng. */
//void drag2str(struct drag draget, char *vilket_drag);

//void move2str(struct move move, char *str);
void move2str(struct board *board, int color, struct move move, char *str);

//void undomove(struct s *spel, struct drag *vilket_drag, struct s *oldflags, int oldsquare);

//struct board makemove(struct board *board, int color, struct move move);
void makemove(struct board *oldboard, struct board *newboard, int color, struct move move, int depth);

#endif      //_MOVES_
