#include "timectrl.h"
#include <sys/timeb.h>
#include "diverse.h"

/* own_time and opp_time measures the clocks of the engine and the opponent
   respectively, measured in milliseconds. */
int own_time;
int opp_time;
int own_checkpoint_time;
int opp_checkpoint_time;

void showtime(int engine_color) {
  if (engine_color == WHITE)
    printf("White: %d:%d, Black: %d:%d\n",
	   ((own_time - time_elapsed(own_checkpoint_time))/1000)/60,
	   ((own_time - time_elapsed(own_checkpoint_time))/1000)%60,
	   ((opp_time - time_elapsed(opp_checkpoint_time))/1000)/60,
	   ((opp_time - time_elapsed(opp_checkpoint_time))/1000)%60);
  else
    printf("White: %d:%d, Black: %d:%d\n",
	   ((opp_time - time_elapsed(opp_checkpoint_time))/1000)/60,
	   ((opp_time - time_elapsed(opp_checkpoint_time))/1000)%60,
	   ((own_time - time_elapsed(own_checkpoint_time))/1000)/60,
	   ((own_time - time_elapsed(own_checkpoint_time))/1000)%60);
}

int get_checkpoint_time() {
  struct timeb tp;

  ftime(&tp);
  return tp.time * 1000 + tp.millitm;
}

void start_own_clock() {
  own_checkpoint_time = get_checkpoint_time();
}

void start_opp_clock() {
  opp_checkpoint_time = get_checkpoint_time();
}

void stop_own_clock() {
  own_time = own_time - time_elapsed(own_checkpoint_time);
  own_checkpoint_time = -1;
}

void stop_opp_clock() {
  opp_time = opp_time - time_elapsed(opp_checkpoint_time);
  opp_checkpoint_time = -1;
}

int time_elapsed(int checkpoint) {
  struct timeb tp;
  int currtime;

  if (checkpoint == -1)
    return 0;

  ftime(&tp);
  currtime = tp.time * 1000 + tp.millitm;
  return currtime - checkpoint;
}

/* This function returns 1 if the engine has to stop thinking, and
   0 if it can continue. It is used by the iterative_deepening-function
   to determine how deep to search. movenumber is actually the number of
   the current "half-move". (move = white's move and black's move,
   "half-move" = movement of one piece (white's or black's) In other
   words movenumber describes how far in the game we have gotten, in
   terms of white's moves + black's moves. branching_factor determines
   how many moves can be made in average from the current position. And
   that in turn determines how quickly the search tree will grow very
   large. */
int time_is_up(int movenumber, int branching_factor) {
  int time_per_move;

  /* We divide the initial time in 40 slices. For the first 20 moves we
     use up one of those slices. Then we cut up the remaining time in 30
     slices, and for the next 10 moves we use up one of those slices.
     Then, after move number 30 we use one tenth of the remaining time
     for each move. */
  if (movenumber/2 <= 20) {
    time_per_move = own_time / (40 - movenumber/2);
  } else if (movenumber/2 <= 30) {
    time_per_move = own_time / (50 - movenumber/2);
  } else {
    time_per_move = own_time / 10;
  }
  printf("time_per_move = %d\n",time_per_move);
  printf("time_elapsed = %d\n\n",time_elapsed(own_checkpoint_time));

  /* We multiply the elapsed time by the branching factor to get a good
     idea of how long time an extra ply of search will take. */
  //if (time_elapsed(own_checkpoint_time)*branching_factor >= time_per_move)
  /* It turns out that the increase in re-search time between one level and
     one level deeper, doesn't increase as fast as the branching factor.
     I dont't understand why. But anyway, that's why I divide the branching
     factor by three. */
  if (time_elapsed(own_checkpoint_time)*branching_factor/3 >= time_per_move)
    return 1;
  else
    return 0;
}
