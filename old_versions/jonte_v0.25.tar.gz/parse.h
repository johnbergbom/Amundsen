#ifndef _PARSE_
#define _PARSE_

#include "diverse.h"
#include "bitboards.h"

//#define MAX_NBR_OF_PLIES 200
//#define MAX_NBR_OF_PLIES 50

/* We initiate histpos to 6, to allow searching for draws according
   to the 3-move repetition rule, already from the start. Then we don't
   need to treat the first few moves as a separate case. */
#define HISTPOS_INIT 6

void computer_make_move(struct board **board, int *vemstur, int *started);

int parsemove(char *input, struct board **board, int *vemstur, int *started);

//void parse(int *white, int *black, int *vemstur, int *started);
void parse();

#endif      //_PARSE_
