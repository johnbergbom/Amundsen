#include "parse.h"
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include "alfabeta.h"
#include "iterdeep.h"
#include "moves.h"
#include "genmoves.h"
#include "display.h"
#include "timectrl.h"

extern int xboard_mode;
struct move **historik;
int histpos = HISTPOS_INIT;
int hlistsize = 100;

/* Denna funktion reallokerar en listas storlek i minnet. */
int change_list_size(struct move **list, int new_size) {
  struct move *ny_lista;

  if((ny_lista = (struct move *) realloc(*list,(new_size + 1)*sizeof(struct move))) == NULL) {
    perror("Realloc failed");
    exit(1);
  } else
    *list = ny_lista;
  
  return new_size;
}

void move2history(struct move *move) {
  (*historik)[histpos++] = *move;

  if (histpos > hlistsize - 50) {
    debuglog("Increasing size of game history.\n");
    hlistsize = change_list_size(historik,hlistsize + 100);
  }
}

/* This function returns 0 if game is not ended, 1 if stalemate,
   2 if check mate, and 3 if draw by the 50 move rule. */
int game_ended(struct board *board, int hpos, int color_to_move) {
  struct moves moves[16];
  int movables, piece_nbr;
  bitboard target;
  struct move move;
  struct board newpos;
  int color = color_to_move;

  if (board->moves_left_to_draw <= 0)
    return 3;

  /* Basically what we do in this function, is this:
     if (can make move which doesn't place him in check)
       return game is not over;
     else {
       if (in check now)
         return game is lost;
       else
         return stalemate;
     }
  */

  if (generate_moves_ny(board,color,hpos,moves,&movables) != 0) {
    /* If we get here, it means that the last move by the opponent
       left him in check, which is illegal. */
    printf("Kalle\n");
    debuglog("ERROR! ILLEGAL POSITION!");
    printf("ERROR! ILLEGAL POSITION!\n");
    exit(1);
  }

  /* Try to make all the moves, and see if the player is still in check. */
  piece_nbr = 0;
  while (piece_nbr < movables) {
    while (moves[piece_nbr].targets != 0) {
      target = getlsb(moves[piece_nbr].targets);
      move.fsquare = moves[piece_nbr].source;
      move.tsquare = target;
      move.piece = moves[piece_nbr].piece;
      move.type = get_movetype(board,color,
			       get_first_bitpos(moves[piece_nbr].source),
			       moves[piece_nbr].piece,target);
      makemove(board,&newpos,color,move,0);
      if (!in_check(&newpos,color)) {
	/* The player has a move that will not place him in check.
	   So the game is not over. */
	return 0;
      }
      moves[piece_nbr].targets = moves[piece_nbr].targets & ~target;
    }
    piece_nbr++;
  }
  /* Every move places him in check. The game is over. */
  if (in_check(board,color))
    return 2;     //the game is lost
  else
    return 1;     //stalemate
}

void computer_make_move(struct board **board, int *vemstur, int *started) {
  struct move move;
  struct board tempboard;
  char *str;
  char *str2;
  int status;
  int temp;

  str2 = (char *) malloc(100*sizeof(char));
  str = (char *) malloc(100*sizeof(char));
  //move = thinkalphabeta(*board,*vemstur,THINKFORWARD,histpos);
  move = iterative_deepening_aspiration_search(*board,*vemstur,THINKFORWARD,histpos);

  move2history(&move);
  makemove(*board,&tempboard,*vemstur,move,0);
  **board = tempboard;

  if (!xboard_mode) {
    showboard(*board);
    showtime(*vemstur);
  } else {
    move2str(*board,*vemstur,move,str);
    printf("move %s\n",str);
    sprintf(str2,"engine's move: move %s",str);
    debuglog(str2);
  }
  //printf("Moves until draw = %d\n",(*board)->moves_left_to_draw);
  if (*vemstur == WHITE)
    *vemstur = BLACK;
  else
    *vemstur = WHITE;

  /* Check if game is over. */
  if ((status = game_ended(*board,histpos,*vemstur))) {
    /* If we are in xboard mode, we won't quit playing until xboard tells us
       that the game is over. */
    if (!xboard_mode)
      *started = 0;
    if (status == 2) {
      if (*vemstur == WHITE)
	sprintf(str,"0-1 {Black mates}");
      else
	sprintf(str,"1-0 {White mates}");
      printf("%s\n",str);
      if (xboard_mode) {
	sprintf(str2,"output sent = %s",str);
	debuglog(str2);
      }
    } else if (status == 1) {
      sprintf(str,"1/2-1/2 {Stalemate}");
      printf("%s\n",str);
      if (xboard_mode) {
	sprintf(str2,"output sent = %s",str);
	debuglog(str2);
	debuglog("Stalemate (Patt)");
      }
    } else {  //draw by the 50 move rule
      if (*vemstur == WHITE)    //the engine plays black
	temp = BLACK;
      else
	temp = WHITE;
      if (eval(&temp,board) > 0) {
	/* Don't claim a draw when you have a better position. */
	debuglog("Draw according to the 50 move rule possible");
	*started = 1;
      } else {
	/* If the positions are equal or you are worse off than
	   your opponent, then accept a draw. However, we don't
	   quit playing until xboard tells us that the game is over. */
	printf("1/2-1/2 {50 move rule}\n");
	debuglog("Draw according to the 50 move rule claimed");
      }
    }
  }
  free(str);
  free(str2);
  return;
}

/* Returns false(=0) on error, and true(=1) if no error. */
int parsemove(char *input, struct board **board, int *vemstur, int *started) {
  struct move move;
  struct board tempboard;
  char *str;
  char *str2;
  int returnval = 0;
  int status;
  int temp;

  str2 = (char *) malloc(100*sizeof(char));
  str = (char *) malloc(100*sizeof(char));
  move = str2move(input,*board,*vemstur);
  if (move.value != -99) {
    if (!*started && !xboard_mode)
      printf("You haven't started any game.\n");
    else {
      sprintf(str,"xboard's move: %s",input);
      debuglog(str);
      /* If we are in xboard mode, we check if the move is legal,
         otherwise we accept illegal moves. */
      if (xboard_mode && !legal_move(move,*board,histpos,*vemstur)) {
	//sprintf(str,"Illegal move (no matching move): %s",input);
	sprintf(str,"Illegal move: %s",input);
	printf("%s\n",str);
	debuglog(str);
      } else {
	move2history(&move);
	makemove(*board,&tempboard,*vemstur,move,0);
	**board = tempboard;
	if (*vemstur == WHITE)
	  *vemstur = BLACK;
	else
	  *vemstur = WHITE;
	if (!xboard_mode) {
	  showboard(*board);
	  showtime(*vemstur);
	}
	//printf("Moves until draw = %d\n",(*board)->moves_left_to_draw);

	/* Check if game is over. */
	if ((status = game_ended(*board,histpos,*vemstur))) {
	  //if (!xboard_mode)
	  *started = 0;
	  returnval = 0;
	  if (status == 2) {
	    if (*vemstur == WHITE)
	      sprintf(str,"0-1 {Black mates}");
	    else
	      sprintf(str,"1-0 {White mates}");
	    printf("%s\n",str);
	    if (xboard_mode) {
	      sprintf(str2,"output sent = %s",str);
	      debuglog(str2);
	    }
	  } else if (status == 1) {
	    sprintf(str,"1/2-1/2 {Stalemate}");
	    printf("%s\n",str);
	    if (xboard_mode) {
	      sprintf(str2,"output sent = %s",str);
	      debuglog(str2);
	      debuglog("Stalemate (Patt)");
	    }
	  } else {  //draw by the 50 move rule
	    if (*vemstur == BLACK)     //opponent plays white
	      temp = BLACK;
	    else
	      temp = WHITE;
	    if (eval(&temp,board) > 0) {
	      /* Don't claim a draw when you have a better position. */
	      debuglog("Draw according to the 50 move rule possible");
	      *started = 1;
	      returnval = 1;
	    } else {
	      /* If the positions are equal or you are worse off than
		 your opponent, then accept a draw. However, we don't
		 quit playing until xboard tells us that the game is over. */
	      printf("1/2-1/2 {50 move rule}\n");
	      debuglog("Draw according to the 50 move rule claimed");
	    }
	  }
	}
	
	/* If xboard_mode is on and *started = 0, then we will make the
	   move, but not start thinking until xboard sends a go. This
	   is done by returning a 0.*/
	if (*started)
	  returnval = 1;
      }
    }
  } else {
    if (!xboard_mode)
      printf("Command could not be interpreted. Press '?' for help.\n");
    else {
      printf("Error (unknown command): %s\n",input);
      sprintf(str,"unknown input received = \"%s\"",input);
      debuglog(str);
    }
  }
  free(str);
  free(str2);
  return returnval;
}

void parse() {
  int white = HUMAN;     //by default white is a human
  int black = COMPUTER;  //by default the engine is black
  int vemstur = WHITE;   //white always starts
  int started = 0;       //is zero before a game is started
  char *input;
  extern struct board *board;
  int run = 1, i;
  char *str;
  extern bitboard square[64];
  extern int own_time;
  extern int opp_time;
  int temp;

  historik = (struct move **) malloc(sizeof(struct move *));
  *historik = (struct move *) malloc(hlistsize*sizeof(struct move));
  input = (char *) malloc(100*sizeof(char));
  str = (char *) malloc(100*sizeof(char));

  while (run) {
    if (!xboard_mode)
      fprintf(stderr,">");
    fgets(input,100,stdin);   //reads a whole line
    input[strlen(input)-1] = '\0';   //remove trailing newline

    if (xboard_mode) {
      debuglog(input);
      if (strcmp(input,"new") == 0) {
	set_board(board);
	vemstur = WHITE;
	white = HUMAN;
	black = COMPUTER;
	started = 1;
	histpos = HISTPOS_INIT;   //nollst�ll draghistoriken
	stop_own_clock();
	stop_opp_clock();
	own_time = 300000;    //5 minutes;
	opp_time = 300000;    //5 minutes;
      } else if (strcmp(input,"random") == 0) {
	//do nothing, we always use random evaluation
      } else if (strcmp(input,"force") == 0) {
	started = 0;
	stop_own_clock();
	stop_opp_clock();
      } else if (strncmp(input,"level",5) == 0) {
	//do nothing, the enginge doesn't support timing
      } else if (strncmp(input,"time",4) == 0) {
	sscanf(input,"time %d",&own_time);
	/* Internally the engine works with milliseconds, and xboard gives
	   us the time in centiseconds, so we have to multiply by 10 here.*/
	own_time *= 10;
      } else if (strncmp(input,"otim",4) == 0) {
	sscanf(input,"otim %d",&opp_time);
	/* Internally the engine works with milliseconds, and xboard gives
	   us the time in centiseconds, so we have to multiply by 10 here.*/
	opp_time *= 10;
      } else if (strncmp(input,"result",6) == 0) {
	started = 0;
      } else if (strcmp(input,"hard") == 0) {
	//do nothing, the enginge doesn't support pondering
      } else if (strcmp(input,"draw") == 0) {
	if (white == COMPUTER)
	  temp = WHITE;
	else
	  temp = BLACK;
	if (eval(&temp,board) > 0) {
	  //decline the offer when you have a better position
	  debuglog("draw declined");
	} else {
	  /* If the positions are equal or you are worse off than
	     your opponent, then accept a draw. However, we shouldn't
	     quit playing until xboard tells us that the game is over.
	     That's because when playing on ICS, it's possible that the
	     draw offer has been withdrawn by the time we accept it. */
	  printf("offer draw\n");
	  debuglog("draw accepted");
	}
      } else if (strcmp(input,"dumpa") == 0) {
	//Used for debugging purposes
	showboard(board);
      } else if (strcmp(input,"quit") == 0) {
	started = 0;
	run = 0;
      } else if (strcmp(input,"white") == 0) {
	vemstur = WHITE;
	white = HUMAN;
	black = COMPUTER;
	stop_own_clock();
	stop_opp_clock();
      } else if (strcmp(input,"black") == 0) {
	vemstur = BLACK;
	white = COMPUTER;
	black = HUMAN;
	stop_own_clock();
	stop_opp_clock();
      } else if (strcmp(input,"go") == 0) {
	started = 1;
	if (vemstur == WHITE) {
	  white = COMPUTER;
	  black = HUMAN;
	} else {
	  black = COMPUTER;
	  white = HUMAN;
	}
	start_own_clock();
	computer_make_move(&board,&vemstur,&started);
	stop_own_clock();
	start_opp_clock();
      } else {
	if (parsemove(input,&board,&vemstur,&started)) {
	  stop_opp_clock();
	  start_own_clock();
	  computer_make_move(&board,&vemstur,&started);
	  stop_own_clock();
	  start_opp_clock();
	}
      }
    } else {
      if (strcmp(input,"xboard") == 0) {
	xboard_mode = 1;
	printf("\n");   //xboard wants a newline here
	signal(SIGINT,SIG_IGN);  //ignore SIGINT to work okay with xboard
	debuglog("xboard");
      } else if (strcmp(input,"hist") == 0) {
	//showhistory();
      } else if (strcmp(input,"quit") == 0)
	run = 0;
      else if ((strcmp(input,"help") == 0) || (strcmp(input,"?") == 0))
	showhelp();
      else if (strcmp(input,"visa") == 0) {
	showboard(board);
      } else if (strcmp(input,"vitdator") == 0)
	white = COMPUTER;
      else if (strcmp(input,"vitman") == 0)
	white = HUMAN;
      else if (strcmp(input,"dumpa") == 0) {
	//Used for debugging purposes
	for (i = 0; i < 64; i++) {
	  if ((board->rotNW_pieces[WHITE] | board->rotNW_pieces[BLACK]) & square[i])
	    printf("1");
	  else
	    printf("0");
	  if (i == 55 || i == 47 || i == 39 || i == 31
	      || i == 23 || i == 15 || i == 7)
	    printf("\n");
	}
	printf("\n\n");
      } else if (strcmp(input,"svartdator") == 0)
	black = COMPUTER;
      else if (strcmp(input,"svartman") == 0)
	black = HUMAN;
      else if (strcmp(input,"starta") == 0) {
	if (started != 1) {
	  //set_board(board);
	  //set_testboard(board);
	  stop_own_clock();
	  stop_opp_clock();
	  own_time = 300000;    //5 minutes;
	  opp_time = 300000;    //5 minutes;
	  started = 1;
	  histpos = HISTPOS_INIT;   //nollst�ll draghistoriken
	  if (white == COMPUTER) {
	    start_own_clock();
	    computer_make_move(&board,&vemstur,&started);
	    stop_own_clock();
	  }
	  start_opp_clock();
	}
      } else if (strcmp(input,"inst") == 0)
	showsettings(&white,&black,&vemstur,&started);
      else if (input[0] != '\0') {
	if (parsemove(input,&board,&vemstur,&started)) {
	  stop_opp_clock();
	  start_own_clock();
	  computer_make_move(&board,&vemstur,&started);
	  stop_own_clock();
	  start_opp_clock();
	}
      }
    }
  }
  free(input);
  free(str);
  free(*historik);
  free(historik);
  free(board);
}
