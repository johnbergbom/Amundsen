#ifndef _TIMECTRL_
#define _TIMECTRL_

void showtime(int engine_color);
void start_own_clock();
void start_opp_clock();
void stop_own_clock();
void stop_opp_clock();
int time_is_up(int movenumber, int branching_factor);

#endif         //_TIMECTRL_
