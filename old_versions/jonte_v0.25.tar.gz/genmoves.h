#ifndef _GENMOVES_
#define _GENMOVES_

//#include "diverse.h"
#include "bitboards.h"

/* The prune types make it easy to generate certain types of moves. The way
   we use them is to first generate all possible moves for a certain piece,
   and put all the targets in a bitboard. Then we prune those targets by
   calling the function get_pruned_targets with the prunetype that we want.
   Notice that passant moves are not included in the CAPTURE_PRUNETYPE. That
   is because passant captures toward an empty square, and therefore cannot
   be included as a CAPTURE_PRUNETYPE with a simple AND with the opponents
   pieces. This could be fixed, but the increased complexity will probably
   make the program run slower rather than faster. */
#define KILLER_CAPTURE_PRUNETYPE 0
#define KILLER_NONCAPTURE_PRUNETYPE 1
#define NONKILLER_CAPTURE_PRUNETYPE 2
#define NONKILLER_NONCAPTURE_PRUNETYPE 3
#define NBR_PRUNETYPES 4

/*#define QUEEN_ROOK_CAPTURE_PRUNETYPE 0
//#define ROOK_CAPTURE_PRUNETYPE 1
#define KNIGHT_BISHOP_PAWN_CAPTURE_PRUNETYPE 1
//#define PAWN_CAPTURE_PRUNETYPE 2
#define NONCAPTURE_PRUNETYPE 2
#define NBR_PRUNETYPES 3*/

/* Denna funktion reallokerar en listas storlek i minnet. */
//int change_list_size(struct move **list, int new_size);

//int generate_pawnmoves(struct board *board, int color, struct move **movelist, int *listsize, int *mcount, int hpos, int boardpos);
bitboard generate_pawnmoves(struct board *board, int color, int hpos, int boardpos);
bitboard generate_kingmoves(struct board *board, int color, int boardpos);
bitboard generate_knight_moves(struct board *board, int color, int boardpos);
bitboard generate_horizontal_moves(struct board *board, int color, int boardpos);
bitboard generate_vertical_moves(struct board *board, int color, int boardpos);
bitboard generate_NEdiag_moves(struct board *board, int color, int boardpos);
bitboard generate_NWdiag_moves(struct board *board, int color, int boardpos);

int get_movetype(struct board *board, int color, int boardpos, int piecetype, bitboard target);

/* For move generation we use the moves struct. The source represents the
   square that a piece will move from. The targets represent all the
   squares the piece can move to. Piece tells what kind of piece we are
   dealing with. */
struct moves {
  bitboard source;
  bitboard targets;
  int piece;
};

//int in_check(struct board *board, int color);

/* This function returns 0 if game is not ended, 1 if stalemate,
   and 2 if check mate. */
//int game_ended(struct board *board, int hpos, int color_to_move);

bitboard get_pruned_targets(bitboard targets, int prunetype, bitboard killers, struct board *board, int color);

//int generate_moves(struct board *board, int color, struct move **movelist, int *mcount, int hpos, int movetype, struct move *killermove);
bitboard generate_moves(struct board *board, int color, int hpos, int piecetype, int boardpos);

int generate_moves_ny(struct board *board, int color, int hpos, struct moves *moves, int *movables);

#endif      //_GENMOVES_


