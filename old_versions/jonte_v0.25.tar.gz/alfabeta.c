#include "alfabeta.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include "moves.h"
#include "genmoves.h"
#include "eval.h"
#include "slump.h"

int lagge = 0;
int lagge_int = 0;
int lagge_int2 = 0;
int lagge_int3 = 0;
int lagge_int4 = 0;

/* killers keep track of the moves that cause a cutoff at each level
   of the search. The killer move implementation is very simple, namely
   every time a cutoff has occurred at a certain node, the killer bitboard
   for the particular depth is OR:ed with the target square. */
bitboard *killers;

int max(int a, int b) {
  if (a > b)
    return a;
  else
    return b;
}

int min(int a, int b) {
  if (a > b)
    return b;
  else
    return a;
}

int quiescence(struct board *board, int color, int org_color, int nodetype, int alpha, int beta, bitboard tsquare, int hpos) {
  struct board newpos;
  int retval;
  int q_val;
  int piece_nbr = 0;
  extern struct move **historik;
  //int oppcolor = color;
  int piecetype;
  bitboard pieces, typetargets, target;
  int boardpos, movables = 0;
  struct moves moves[16];
  extern bitboard square[64];
  struct move move;
  char *dragstr;

  switch_colors(&color);

  if (generate_moves_ny(board,color,hpos,moves,&movables) != 0)
    return KINGTAKEN;

  if (nodetype == MAX) {
    //retval = -INFTY;
    /* We init retval to the static score of the position. Then the engine
       will take whatever is best of continuing the capture line, or to
       accept the static score of the position. */
    retval = eval(&org_color,board);
    piece_nbr = 0;
    /* Go through all movable pieces. */
    while (piece_nbr < movables) {
      typetargets = moves[piece_nbr].targets & tsquare; //only moves to tsquare
      while (typetargets != 0) {
	target = getlsb(typetargets);
	move.fsquare = moves[piece_nbr].source;
	move.tsquare = target;
	move.piece = moves[piece_nbr].piece;
	move.type = get_movetype(board,color,get_first_bitpos(moves[piece_nbr].source),moves[piece_nbr].piece,target);

	/* Test code for printing out the moves the engine is processing. */
	/*dragstr = (char *) malloc(20*sizeof(char));
	move2str(board,color,move,dragstr);
	if (lagge_int3 && (strncmp(dragstr,"h8g8",4) == 0))
	  lagge_int4 = 1;
	else
	  lagge_int4 = 0;
	if (lagge_int3)
	  fprintf(stderr,"        move %s",dragstr);
	  free(dragstr);*/

	makemove(board,&newpos,color,move,0);
	(*historik)[hpos] = move;
	q_val = quiescence(&newpos,color,org_color,MIN,alpha,beta,tsquare,hpos+1);
	//if (lagge_int3)
	//printf(" (%d)\n",q_val);
	if (q_val != KINGTAKEN) {
	  retval = max(retval,q_val);
	  alpha = max(alpha,retval);
	  if (retval >= beta) {
	    //if (lagge_int4)
	    //printf("DFFFFFFFFFFFFF");
	    //lagge_int4 = 0;
	    return retval;
	  }
	}
	typetargets = typetargets & ~target;
      }
      piece_nbr++;
    }
    /* We get here when we have gone through all the capture moves, and
       when none of them were good enough to merit a cutoff. */
    return retval;
  } else {   //nodetype == MIN
    //retval = INFTY;
    /* We init retval to the static score of the position. Then the engine
       will take whatever is best of continuing the capture line, or to
       accept the static score of the position. */
    retval = eval(&org_color,board);
    piece_nbr = 0;
    /* Go through all movable pieces. */
    while (piece_nbr < movables) {
      typetargets = moves[piece_nbr].targets & tsquare; //only moves to tsquare
      while (typetargets != 0) {
	target = getlsb(typetargets);
	move.fsquare = moves[piece_nbr].source;
	move.tsquare = target;
	move.piece = moves[piece_nbr].piece;
	move.type = get_movetype(board,color,get_first_bitpos(moves[piece_nbr].source),moves[piece_nbr].piece,target);

	/* Test code for printing out the moves the engine is processing. */
	//dragstr = (char *) malloc(20*sizeof(char));
	//move2str(board,color,move,dragstr);
	/*if (lagge_int3 && (strncmp(dragstr,"h8g8",4) == 0))
	  lagge_int4 = 1;
	else
	lagge_int4 = 0;*/
	//if (lagge_int4)
	//fprintf(stderr,"          move %s",dragstr);
	//free(dragstr);

	makemove(board,&newpos,color,move,0);
	(*historik)[hpos] = move;
	q_val = quiescence(&newpos,color,org_color,MAX,alpha,beta,tsquare,hpos+1);
	//if (lagge_int4)
	//printf(" (%d)\n",q_val);
	if (q_val != KINGTAKEN) {
	  retval = min(retval,q_val);
	  beta = min(beta,retval);
	  if (retval <= alpha)
	    return retval;
	}
	typetargets = typetargets & ~target;
      }
      piece_nbr++;
    }
    /* We get here when we have gone through all the capture moves, and
       when none of them were good enough to merit a cutoff. */
    return retval;
  }

  /* We get here if no quiescence moves are found, i.e. no moves to the
     destination tsquare. That is, at the end of the series of captures. */
  //if (lagge_int4)
  //printf("fyran: %d",eval(&org_color,board));
  //return eval(&org_color,board);

  /* We should never get to this code. */
  printf("ERROR IN QUIESCENCE!!!\n");
}

int alphabeta(struct board *board, int color, int org_color, int nodetype, int alpha, int beta, int depth, int hpos) {
  struct board newpos;
  int retval;
  int a_val;
  int piece_nbr = 0;
  int oppcolor = color;
  extern struct move **historik;
  int opp_piece;
  extern int pieceval[6];
  int prunetype = 0;
  struct moves moves[16];
  int movables = 0;
  int piecetype = 0;
  bitboard pieces, typetargets, target;
  int boardpos;
  extern bitboard square[64];
  struct move move;
  char *dragstr;
  //int temp = 0;
  //int temp2 = 0;
  //int i;
  //int ilagge = 0;

  switch_colors(&color);

  if (board->moves_left_to_draw == 0)
    return 0;

  if (depth == 0) {
    return eval(&org_color,board);
  } else {
    if (generate_moves_ny(board,color,hpos,moves,&movables) != 0)
      return KINGTAKEN;

    if (nodetype == MAX) {
      retval = -INFTY;
      /* Go through the different prunetypes. The prunetypes make sure the moves
         are tried in a (pretty) good order. See genmoves.h */
      while (prunetype < NBR_PRUNETYPES) {
	piece_nbr = 0;
	/* Go through all movable pieces. */
	while (piece_nbr < movables) {
	  /* Prune the targets to get a good move ordering. */
	  typetargets = get_pruned_targets(moves[piece_nbr].targets,prunetype,
					   killers[depth],board,color);
	  /* Go through the targets one at a time. */
	  while (typetargets != 0) {
	    target = getlsb(typetargets);
	    move.fsquare = moves[piece_nbr].source;
	    move.tsquare = target;
	    move.piece = moves[piece_nbr].piece;
	    move.type = get_movetype(board,color,
				     get_first_bitpos(moves[piece_nbr].source),
				     moves[piece_nbr].piece,target);

	/* Test code for printing out the moves the engine is processing. */
	    /*dragstr = (char *) malloc(20*sizeof(char));
	move2str(board,color,move,dragstr);
	if (lagge_int && depth == 4 && (strncmp(dragstr,"b7c6",4) == 0))
	  lagge_int2 = 1;
	else
	lagge_int2 = 0;
	if (lagge_int && depth == 4) {
	  fprintf(stderr,"    move %s",dragstr);
	  ilagge = 1;
	  printf("(a=%d,b=%d)",alpha,beta);
	  //alpha = -INFTY;
	  //beta = INFTY;
	} else
	  ilagge = 0;
	  free(dragstr);*/




	    makemove(board,&newpos,color,move,depth);
	    (*historik)[hpos] = move;

	    /* If this move is the last one in the search, and the move is a
	       capture, then quiescence search should be done, otherwise we
	       do alphabeta. */
	    if ((depth-1 == 0) && (move.type & CAPTURE_MOVE)) {
	      /* If move is a capture, then figure out what piece it's taking. */
	      if (move.type & PASSANT_MOVE)
		opp_piece = PAWN;
	      else
		for (opp_piece = 0; opp_piece < 6; opp_piece++) {
		  if (board->piece[oppcolor][opp_piece] & move.tsquare)
		    break;
		}
	      /* If a lower valued piece takes a better one, we don't care about
		 quiescence search. */
	      if (pieceval[opp_piece] > pieceval[move.piece])
		a_val = alphabeta(&newpos,color,org_color,MIN,alpha,beta,
				  depth-1,hpos+1);
	      else
		a_val = quiescence(&newpos,color,org_color,MIN,alpha,beta,
				   move.tsquare,hpos+1);
	    } else
	      a_val = alphabeta(&newpos,color,org_color,MIN,alpha,beta,
				depth-1,hpos+1);

	    /*if (ilagge && depth == 4)
	      printf(" (d4: %d)\n",a_val);*/
	    if (a_val != KINGTAKEN) {
	      retval = max(retval,a_val);
	      alpha = max(alpha,retval);
	      if (retval >= beta) {
		/* Here we got a cutoff, so we'll add this move as a killer. */
		killers[depth] = killers[depth] | move.tsquare;
		//lagge_int2 = 0;
		/*if (temp2)
		  printf(" (d2_ret: %d)\n",retval);*/
		return retval;
	      }
	    }
	    typetargets = typetargets & ~target;
	  }
	  piece_nbr++;
	}
	prunetype++;
      }
      /* If we get here, and retval == -INFTY, it means all possible moves
         from this position leads to a check position. If we are already in
         check, then it's mate. If we're not in check, then it's stalemate. */
      if (retval == -INFTY) {
	if (in_check(board,color))
	  /* Return retval+1 instead of retval. That's because it's only
	     at the deepest level we should do this test. Otherwise this
	     could happen: Let's say at a deeper node we discovered a mate,
	     which means retval is -INFTY when we reach this code. But that
	     might be for a few moves ahead of us (deeper in the search tree).
	     And at the CURRENT position (at THIS level in the tree, we are
	     not in check, and then we would falsely return 0 instead of
	     -INFTY. So therefore, if we return retval+1 at the checkmate
	     level, then we won't reach this code at a shallower level.
	     We also add the +(100-depth), to give shallower mates a worse
	     value than mates deeper down in the tree. */
	  return retval + 1 + (100-depth);     //check mate
	else
	  return 0;         //stalemate
      }
    } else {   //nodetype == MIN
      retval = INFTY;
      /* Go through the different prunetypes. The prunetypes make sure the moves
	 are tried in a (pretty) good order. See genmoves.h */
      while (prunetype < NBR_PRUNETYPES) {
	piece_nbr = 0;
        /* Go through all movable pieces. */
        while (piece_nbr < movables) {
          /* Prune the targets to get a good move ordering. */
          typetargets = get_pruned_targets(moves[piece_nbr].targets,prunetype,
					   killers[depth],board,color);
          /* Go through the targets one at a time. */
          while (typetargets != 0) {
            target = getlsb(typetargets);
            move.fsquare = moves[piece_nbr].source;
            move.tsquare = target;
            move.piece = moves[piece_nbr].piece;
	    move.type = get_movetype(board,color,
				     get_first_bitpos(moves[piece_nbr].source),
				     moves[piece_nbr].piece,target);


	/* Test code for printing out the moves the engine is processing. */
	    /*dragstr = (char *) malloc(20*sizeof(char));
	move2str(board,color,move,dragstr);
	if (lagge && depth == 5 && (strncmp(dragstr,"c5c7",4) == 0))
	  lagge_int = 1;
	else
	lagge_int = 0;
	if (lagge && depth == 6)
	  fprintf(stderr,"  move %s",dragstr);

	if (lagge_int2 && (strncmp(dragstr,"a8g8",4) == 0))
	  lagge_int3 = 1;
	else
	  lagge_int3 = 0;
	if (lagge_int2 && depth == 2)
	fprintf(stderr,"      move %s (type = %d) ",dragstr,move.type);
	free(dragstr);*/



            makemove(board,&newpos,color,move,depth);
            (*historik)[hpos] = move;

            /* If this move is the last one in the search, and the move is a
               capture, then quiescence search should be done, otherwise we
	       do alphabeta. */
	    if ((depth-1 == 0) && (move.type & CAPTURE_MOVE)) {
	      //if (lagge_int2 && depth == 1)
	      //fprintf(stderr,"CAPTURE ");
	      /* If move is a capture, then figure out what piece it's taking. */
	      if (move.type & PASSANT_MOVE)
		opp_piece = PAWN;
	      else
		for (opp_piece = 0; opp_piece < 6; opp_piece++) {
		  if (board->piece[oppcolor][opp_piece] & move.tsquare)
		    break;
		}
	      /* If a lower valued piece takes a better one, we don't care about
		 quiescence search. */
	      if (pieceval[opp_piece] > pieceval[move.piece]) {
		//if (lagge_int2 && depth == 1)
		//fprintf(stderr,"ALF ");
		a_val = alphabeta(&newpos,color,org_color,MAX,alpha,beta,
				  depth-1,hpos+1);
	      } else {
		//if (lagge_int2 && depth == 1)
		//fprintf(stderr,"QUI ");
		a_val = quiescence(&newpos,color,org_color,MAX,alpha,beta,
				   move.tsquare,hpos+1);
	      }
	    } else {
	      //if (lagge_int2 && depth == 1)
	      //fprintf(stderr,"NONCAPTURE ");
	      a_val = alphabeta(&newpos,color,org_color,MAX,alpha,beta,
				depth-1,hpos+1);
	    }

	    /*if (lagge && depth == 6)
	      printf(" (d6: %d)\n",a_val);
	    if (lagge_int2 && depth == 1)
	    printf(" (d1: %d)\n",a_val);*/
	    if (a_val != KINGTAKEN) {
	      retval = min(retval,a_val);
	      beta = min(beta,retval);
	      if (retval <= alpha) {
                /* Here we got a cutoff, so we'll add this move as a killer. */
		killers[depth] = killers[depth] | move.tsquare;
		//if (depth == 3)
		//lagge_int = 0;
		/*if (lagge_int2 && depth == 1)
		  printf(" (d1_ret: %d)\n",retval);*/
		return retval;
	      }
	    }
	    typetargets = typetargets & ~target;
	  }
	  piece_nbr++;
	}
	prunetype++;
      }
      /* If we get here, and retval == INFTY, it means all possible moves
         from this position leads to a check position. If we are already in
         check, then it's mate. If we're not in check, then it's stalemate. */
      if (retval == INFTY) {
	if (in_check(board,color)) {
	  /* Return retval-1 instead of retval. That's because it's only
	     at the deepest level we should do this test. Otherwise this
	     could happen: Let's say at a deeper node we discovered a mate,
	     which means retval is INFTY when we reach this code. But that
	     might be for a few moves ahead of us (deeper in the search tree).
	     And at the CURRENT position (at THIS level in the tree, we are
	     not in check, and then we would falsely return 0 instead of
	     INFTY. So therefore, if we return retval-1 at the checkmate
	     level, then we won't reach this code at a shallower level.
	     We also add the -(100-depth), to give shallower mates a higher
	     value than mates deeper down in the tree. */
	  return retval - 1 - (100-depth);     //check mate
	} else {
	  return 0;         //stalemate
	}
      }
    }
  }
  return retval;
}

struct move thinkalphabeta(struct board *board, int color, int depth, int hpos) {
  struct move *movelist;
  struct move *bestmove;
  struct move *validmoves;
  struct board newpos;
  int mcount = 0;
  int bestvalue, b;
  struct move returnmove;
  int alpha = -INFTY, beta = INFTY;
  int org_color = color;
  int piece_nbr = 0, i, j = 0;
  char *dragstr;
  extern struct move **historik;
  int prunetype;
  int nbr_moves = 0;
  int piecetype, boardpos, movables;
  bitboard pieces, typetargets, target;
  struct moves moves[16];
  //int oppcolor = color;
  extern bitboard square[64];
  extern int xboard_mode;

  //switch_colors(&oppcolor);

  /* A board position should be in a legal state upon calling this
     function, so we should never be able to take the opponents king. */
  if (generate_moves_ny(board,color,hpos,moves,&movables) != 0) {
    debuglog("ERROR!!! ILLEGAL MOVES SHOULD NOT BE FOUND HERE!");
    printf("ERROR!!! ILLEGAL MOVES SHOULD NOT BE FOUND HERE!\n");
    exit(1);
  }

  /* Count the number of possible moves, so we know how to initialize
     the movelist. */
  for (i = 0; i < movables; i++)
    nbr_moves += bitcount(moves[i].targets);
  movelist = (struct move *) malloc(nbr_moves*sizeof(struct move));

  /* We reserve space for killers up to ply == depth, and that's allright,
     because we don't use killer moves in the quiescence search. */
  killers = (bitboard *) calloc(depth,sizeof(bitboard)); //calloc clears memory
  /*killers = (bitboard *) malloc(depth*sizeof(bitboard));
  for (i = 0; i < depth; i++)    //clear the killer moves
  killers[i] = 0;*/

  /* Go through the different prunetypes. The prunetypes make sure the moves
     are tried in a (pretty) good order. See genmoves.h */
  //alpha = -50;
  //beta = 50;
  //printf("alpha = %d, beta = %d\n",alpha,beta);
  for (prunetype = 0; prunetype < NBR_PRUNETYPES; prunetype++) {
    /* Go through all movable pieces. */
    for (piece_nbr = 0; piece_nbr < movables; piece_nbr++) {
      /* Here we set the killer moves to zero, because we don't use killer
         moves at the top level of alpha beta search. */
      typetargets = get_pruned_targets(moves[piece_nbr].targets,prunetype,
				       0,board,color);
      /* Go through the targets one at a time. */
      while (typetargets != 0) {
	target = getlsb(typetargets);
	movelist[mcount].fsquare = moves[piece_nbr].source;
	movelist[mcount].tsquare = target;
	movelist[mcount].piece = moves[piece_nbr].piece;
	movelist[mcount].type = get_movetype(board,color,get_first_bitpos(moves[piece_nbr].source),moves[piece_nbr].piece,target);

	/* Test code for printing out the moves the engine is processing. */
	dragstr = (char *) malloc(20*sizeof(char));
	move2str(board,color,movelist[mcount],dragstr);
	/*if (strncmp(dragstr,"a2d5",4) == 0)
	  lagge = 1;
	else
	lagge = 0;*/
	//if (lagge)
	//fprintf(stderr,"move %s",dragstr);
	free(dragstr);

	makemove(board,&newpos,color,movelist[mcount],depth);
	(*historik)[hpos] = movelist[mcount];
	movelist[mcount].value = alphabeta(&newpos,color,org_color,MIN,alpha,beta,depth-1,hpos+1);
	//if (lagge)
	//printf(" (r: %d)\n",movelist[mcount].value);
	/* Clear the killer moves so they don't get too clogged up with
	   stale killers. */
	for (i = 0; i < depth; i++)
	  killers[i] = 0;
	mcount++;
	typetargets = typetargets & ~target;
      }
    }
  }

  /* Remove all invalid moves from the list. (The invalid ones have
     value == KINGTAKEN, those are the moves that checks one's own king) */
  validmoves = (struct move *) malloc(mcount * sizeof(struct move));
  j = 0;
  for (i = 0; i < mcount; i++)
    if (movelist[i].value != KINGTAKEN)
      validmoves[j++] = movelist[i];

  mcount = j;

  if (mcount > 0) {
    /* Put the best moves in the array bestmove, and chose a random best move.
       (Provided there are several moves which are equally good.) */
    bestmove = (struct move *) malloc(mcount * sizeof(struct move));
    bestvalue = validmoves[0].value;
    b = 0;
    for (i = 0; i < mcount; i++) {
      if (validmoves[i].value >= bestvalue) {
	if (validmoves[i].value > bestvalue)
	  b = 0;
	bestvalue = validmoves[i].value;
	bestmove[b++] = validmoves[i];
      }
    }
    returnmove = bestmove[get_random_number(b-1)];
    free(bestmove);
  } else {
    //returnmove = movelist[0];
    printf("ERROR, NO LEGAL MOVE FOUND!\n");
    debuglog("ERROR, NO LEGAL MOVE FOUND!\n");
    exit(1);
  }

  /* These are only used in the search, and they should be cleared before
     next search. */
  board->captures[WHITE] = 0;
  board->captures[BLACK] = 0;

  printf("\n");
  if (!xboard_mode)
    printf("Value = %d\n",returnmove.value);

  free(killers);
  free(movelist);
  free(validmoves);

  return returnmove;
}
