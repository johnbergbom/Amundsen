#include "genmoves.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "bitboards.h"
#include "diverse.h"
//#include "bonde.h"
//#include "torn.h"
//#include "hast.h"
//#include "lopare.h"
//#include "dam.h"
//#include "kung.h"

//#define MALLOC_CHECK_ 0

/* killers_added keeps track of how many killers have been added to
   the movelist. */
//int killers_added;

/* The movetype TAKE_KING_CHECK only checks if the king can be taken,
   and then returns. It doesn't add any moves to the movelist.
   CAPTURE_MOVETYPE on the other hand adds moves to the movelist if
   the king can't be taken. */
//#define TAKE_KING_CHECK 10

/* This function is used for putting a killer move at the top of
   the movelist.*/
/*void switchmoves(struct move *m1, struct move *m2) {
  //if (m1 != m2) {
    struct move sprmove = *m1;
    *m1 = *m2;
    *m2 = sprmove;
    //} else {
    //printf("SAMMA");
    //}
}*/

bitboard generate_pawnmoves(struct board *board, int color, int hpos, int boardpos) {
  int64 targets;
  int oppcolor = color;
  extern bitboard square[64];
  extern bitboard pawn_start[2];
  //extern bitboard pawn_lastrow[2];
  extern bitboard pawn_passantrow[2];
  extern struct attack attack;
  extern struct move **historik;
  //int i;

  switch_colors(&oppcolor);

  if (boardpos > 55 || boardpos < 8)
    printf("GENERATE_PAWNMOVES");
  if (color == WHITE) {
    /* White pawn goes one step forward. */
    targets = (square[boardpos] >> 8) &
      ~(board->all_pieces[WHITE] | board->all_pieces[BLACK]);
    if (square[boardpos] & pawn_start[WHITE]) //white pawn at starting square
      if (targets)    //the pawn can go one step forward
	/* White pawn goes two steps forward. */
	targets = targets | ((square[boardpos] >> 16) &
			     ~(board->all_pieces[WHITE]
			       | board->all_pieces[BLACK]));
  } else {    //color == BLACK
    /* BLACK pawn goes one step forward. */
    targets = (square[boardpos] << 8) &
      ~(board->all_pieces[WHITE] | board->all_pieces[BLACK]);
    if (square[boardpos] & pawn_start[BLACK]) //black pawn at starting square
      if (targets)    //the pawn can go one step forward
	/* BLACK pawn goes two steps forward. */
	targets = targets | ((square[boardpos] << 16) &
			     ~(board->all_pieces[WHITE]
			       | board->all_pieces[BLACK]));
  }

  /* We also need to add the capture moves. */
  targets = targets | (attack.pawn[color][boardpos] & board->all_pieces[oppcolor]);

  /* We also need to add the passant moves. First we check if the opponent's
     last move was a pawn move, which went to a square to where I can
     possibly make a passant move. */
  if ((*historik)[hpos-1].tsquare & board->piece[oppcolor][PAWN] & pawn_passantrow[oppcolor]) {
    /* Then we check if the opponent's pawn went from his starting square.
       (Passant is only allowed when you go from eg. e2e4, and not for
       e3e4). We also check that the pawn in the process of making the move
       is standing on the passant row. */
    if ((square[boardpos] & pawn_passantrow[oppcolor])
	&& ((*historik)[hpos-1].fsquare & pawn_start[oppcolor])) {
      /* Make sure passant can only be done to an adjacent column.
	 (h2h4 doesn't make the passant move c4h3 legal.) */
      if (((square[boardpos] << 1) & (*historik)[hpos-1].tsquare)
	  || ((square[boardpos] >> 1) & (*historik)[hpos-1].tsquare)) {
	if (color == WHITE)
	  targets = targets | ((*historik)[hpos-1].tsquare >> 8);
	else
	  targets = targets | ((*historik)[hpos-1].tsquare << 8);
      }
    }
  }

  return targets;
}

int get_pawnmove_movetype(struct board *board, int color, int boardpos, bitboard target) {
  int type;
  int oppcolor = color;
  extern bitboard pawn_lastrow[2];
  extern struct attack attack;

  switch_colors(&oppcolor);

  /* Find out what type of move it was. */
  if (target & board->all_pieces[oppcolor])
    type = CAPTURE_MOVE;
  else if (attack.pawn[color][boardpos] & target) {
    /* If the move is an attack to a square with no enemy piece
       occupying it. */
    type = CAPTURE_MOVE | PASSANT_MOVE;
  } else
    type = NORMAL_MOVE;
    
  /* If the pawn goes to the last row, then we set the move to be a
     queen promotion. Notice that we don't take care of different
     kinds of promotions. */
  if (target & pawn_lastrow[color])
    type = type | QUEEN_PROMOTION_MOVE;
  return type;
}

bitboard generate_kingmoves(struct board *board, int color, int boardpos) {
  int64 targets;
  //int oppcolor = color;
  extern bitboard square[64];
  extern struct attack attack;

  //switch_colors(&oppcolor);

  targets = attack.king[boardpos] & (~board->all_pieces[color]);

  /* Check castling. */
  if (color == WHITE) {
    if (board->castling_status[WHITE] & SHORT_CASTLING_OK)
      /* Check if the squares between the king and the rook are empty. */
      if (((board->all_pieces[WHITE] | board->all_pieces[BLACK]) &
	   (square[61] | square[62])) == 0) {
	/* Make a final check to see if the king's square is in check,
	   or if the destination square is in check, or if the square in
	   between is in check. */
	if (!in_check(board,color)) {
	  board->piece[color][KING] = square[61];
	  if (!in_check(board,color)) {
	    board->piece[color][KING] = square[62];
	    if (!in_check(board,color))
	      targets = targets | square[62];
	  }
	  board->piece[color][KING] = square[60];
	}
      }
    if (board->castling_status[WHITE] & LONG_CASTLING_OK)
      /* Check if the squares between the king and the rook are empty. */
      if (((board->all_pieces[WHITE] | board->all_pieces[BLACK]) &
	   (square[57] | square[58] | square[59])) == 0) {
	/* Make a final check to see if the king's square is in check,
	   or if the destination square is in check, or if the square in
	   between is in check. */
	if (!in_check(board,color)) {
	  board->piece[color][KING] = square[59];
	  if (!in_check(board,color)) {
	    board->piece[color][KING] = square[58];
	    if (!in_check(board,color))
	      targets = targets | square[58];
	  }
	  board->piece[color][KING] = square[60];
	}
      }
  } else {    //color == BLACK
    if (board->castling_status[BLACK] & SHORT_CASTLING_OK)
      /* Check if the squares between the king and the rook are empty. */
      if (((board->all_pieces[WHITE] | board->all_pieces[BLACK]) &
	   (square[5] | square[6])) == 0) {
	/* Make a final check to see if the king's square is in check,
	   or if the destination square is in check, or if the square in
	   between is in check. */
	if (!in_check(board,color)) {
	  board->piece[color][KING] = square[5];
	  if (!in_check(board,color)) {
	    board->piece[color][KING] = square[6];
	    if (!in_check(board,color))
	      targets = targets | square[6];
	  }
	  board->piece[color][KING] = square[4];
	}
      }
    if (board->castling_status[BLACK] & LONG_CASTLING_OK)
      /* Check if the squares between the king and the rook are empty. */
      if (((board->all_pieces[WHITE] | board->all_pieces[BLACK]) &
	   (square[1] | square[2] | square[3])) == 0) {
	/* Make a final check to see if the king's square is in check,
	   or if the destination square is in check, or if the square in
	   between is in check. */
	if (!in_check(board,color)) {
	  board->piece[color][KING] = square[3];
	  if (!in_check(board,color)) {
	    board->piece[color][KING] = square[2];
	    if (!in_check(board,color))
	      targets = targets | square[2];
	  }
	  board->piece[color][KING] = square[4];
	}
      }
  }

  return targets;
}

int get_kingmove_movetype(struct board *board, int color, bitboard target) {
  extern bitboard square[64];
  int oppcolor = color;

  switch_colors(&oppcolor);

  /* Find out what type of move it was. */
  if (target & board->all_pieces[oppcolor])
    return CAPTURE_MOVE;
  else if ((color == WHITE && (board->piece[color][KING] & square[60])
	    && ((target & square[62]) || (target & square[58])))
	   || (color == BLACK && (board->piece[color][KING] & square[4])
	       && ((target & square[6]) || (target & square[2]))))
    return CASTLING_MOVE;
  else
    return NORMAL_MOVE;
}

bitboard generate_knight_moves(struct board *board, int color, int boardpos) {
  extern struct attack attack;

  return attack.knight[boardpos] & (~board->all_pieces[color]);
}

/* This function generates moves that go horizontally along the board.
   This function is needed for generating queen and rook moves. */
bitboard generate_horizontal_moves(struct board *board, int color, int boardpos) {
  //int64 targets;
  int occupancy;
  //extern bitboard square[64];
  extern struct attack attack;

  //switch_colors(&oppcolor);
  occupancy = ((board->all_pieces[WHITE]
		| board->all_pieces[BLACK]) >> ((boardpos/8)*8)) & 255;
  return attack.hslider[boardpos][occupancy] & (~board->all_pieces[color]);

  //return targets;
}

/* This function returns the movetype of all pieces other than pawns
   and king. */
int get_othermove_movetype(struct board *board, int color, bitboard target) {
  int oppcolor = color;

  switch_colors(&oppcolor);

  /* Find out what type of move it was. */
  if (target & board->all_pieces[oppcolor])
    return CAPTURE_MOVE;
  else
    return NORMAL_MOVE;
}

/* This function generates moves that go vertically along the board.
   This function is needed for generating queen and rook moves. */
bitboard generate_vertical_moves(struct board *board, int color, int boardpos) {
  //int64 targets;
  int occupancy;
  //extern bitboard square[64];
  extern struct attack attack;
  //extern int rotate90to0[64];
  extern int rotate0to90[64];

  //switch_colors(&oppcolor);

  /* We calculate the vertical moves (files) by using the rotated
     bitboard board.rot90_pieces, and getting the occupancy number of
     the file in question by reading off the occupancy of the rank in
     this rotated bitboard. Then we switch back to "unrotated" before
     we add the move to the movelist. */
  occupancy = ((board->rot90_pieces[WHITE]
		| board->rot90_pieces[BLACK]) >> (rotate0to90[boardpos]/8)*8) & 255;

  return attack.vslider[boardpos][occupancy] & (~board->all_pieces[color]);
}

/* This function generates moves that go diagonally along the board
   in the northeast direction (the a1-h8 diagonal). This function is
   needed for generating queen and bishop moves. */
bitboard generate_NEdiag_moves(struct board *board, int color, int boardpos) {
  //int64 targets;
  int occupancy;
  //extern bitboard square[64];
  extern struct attack attack;
  //extern int rotateNEto0[64];
  extern int rotate0toNE[64];
  extern int ones[9];
  extern int diagNE_start[64];
  extern int diagNE_length[64];

  //switch_colors(&oppcolor);

  occupancy = (board->rotNE_pieces[WHITE] | board->rotNE_pieces[BLACK]) >> (rotate0toNE[diagNE_start[boardpos]]) & ones[diagNE_length[boardpos]];
  return attack.sliderNE[boardpos][occupancy] & (~board->all_pieces[color]);
}

/* This function generates moves that go diagonally along the board
   in the northwest direction (the h1-a8 diagonal). This function is
   needed for generating queen and bishop moves. */
bitboard generate_NWdiag_moves(struct board *board, int color, int boardpos) {
  int occupancy;
  extern struct attack attack;
  extern int rotate0toNW[64];
  extern int ones[9];
  extern int diagNW_start[64];
  extern int diagNW_length[64];

  occupancy = (board->rotNW_pieces[WHITE] | board->rotNW_pieces[BLACK]) >> (rotate0toNW[diagNW_start[boardpos]]) & ones[diagNW_length[boardpos]];
  return attack.sliderNW[boardpos][occupancy] & (~board->all_pieces[color]);
}

bitboard get_pruned_targets(bitboard targets, int prunetype, bitboard killers, struct board *board, int color) {
  int oppcolor = color;

  switch_colors(&oppcolor);
  if (prunetype == KILLER_CAPTURE_PRUNETYPE)
      return ((targets & board->all_pieces[oppcolor]) & (killers));
  else if (prunetype == KILLER_NONCAPTURE_PRUNETYPE)
    return ((targets & (~board->all_pieces[oppcolor])) & (killers));
  if (prunetype == NONKILLER_CAPTURE_PRUNETYPE)
    return ((targets & board->all_pieces[oppcolor]) & (~killers));
  else if (prunetype == NONKILLER_NONCAPTURE_PRUNETYPE)
    return ((targets & (~board->all_pieces[oppcolor])) & (~killers));

  /*  if (prunetype == QUEEN_ROOK_CAPTURE_PRUNETYPE)
    return targets & (board->piece[oppcolor][QUEEN]
		      | board->piece[oppcolor][ROOK]);
  //else if (prunetype == ROOK_CAPTURE_PRUNETYPE)
  //return targets & board->piece[oppcolor][ROOK];
  else if (prunetype == KNIGHT_BISHOP_PAWN_CAPTURE_PRUNETYPE)
    return targets & ((board->piece[oppcolor][KNIGHT]
		      | board->piece[oppcolor][BISHOP])
		      | board->piece[oppcolor][PAWN]);
  //else if (prunetype == PAWN_CAPTURE_PRUNETYPE)
  //return targets & board->piece[oppcolor][PAWN];
  else if (prunetype == NONCAPTURE_PRUNETYPE)
  return targets & (~board->all_pieces[oppcolor]);*/
}

int get_movetype(struct board *board, int color, int boardpos, int piecetype, bitboard target) {
  if (piecetype == PAWN) {
    return get_pawnmove_movetype(board,color,boardpos,target);
  } else if (piecetype == ROOK) {
    return get_othermove_movetype(board,color,target);
  } else if (piecetype == KNIGHT) {
    return get_othermove_movetype(board,color,target);
  } else if (piecetype == BISHOP) {
    return get_othermove_movetype(board,color,target);
  } else if (piecetype == QUEEN) {
    return get_othermove_movetype(board,color,target);
  } else if (piecetype == KING) {
    return get_kingmove_movetype(board,color,target);
  }
}


/* This function returns all pseudo-legal moves in a given position.
   Pseudo-legal move generation means that no checking is done to see
   if the move places it's own king in check. That has to be checked
   elsewhere.
     This function returns 0 on no error, and -1 on error, which is if
   the opposite king can be taken.
     There is at most 16 pieces of one color, so struct moves *moves needs
   to have room for 16 entries, and no more. */
int generate_moves_ny(struct board *board, int color, int hpos, struct moves *moves, int *movables) {
  int piecetype, boardpos;
  bitboard pieces;
  int oppcolor = color;
  extern bitboard square[64];

  switch_colors(&oppcolor);
  *movables = 0;

  for (piecetype = 0; piecetype < 6; piecetype++) {
    pieces = board->piece[color][piecetype];
    /* Go through all the pieces for the given piece type. */
    while (pieces != 0) {
      boardpos = get_first_bitpos(pieces);

      if (piecetype == PAWN) {
	moves[*movables].targets =
	  generate_pawnmoves(board,color,hpos,boardpos);
      } else if (piecetype == ROOK) {
	moves[*movables].targets =
	  generate_horizontal_moves(board,color,boardpos)
	  | generate_vertical_moves(board,color,boardpos);
      } else if (piecetype == KNIGHT) {
	moves[*movables].targets = generate_knight_moves(board,color,boardpos);
      } else if (piecetype == BISHOP) {
	moves[*movables].targets = generate_NEdiag_moves(board,color,boardpos)
	  | generate_NWdiag_moves(board,color,boardpos);
      } else if (piecetype == QUEEN) {
	moves[*movables].targets =
	  generate_horizontal_moves(board,color,boardpos)
	  | generate_vertical_moves(board,color,boardpos)
	  | generate_NEdiag_moves(board,color,boardpos)
	  | generate_NWdiag_moves(board,color,boardpos);
      } else if (piecetype == KING) {
	moves[*movables].targets = generate_kingmoves(board,color,boardpos);
      }

      if (moves[*movables].targets & board->piece[oppcolor][KING])
	return -1;
      /* Only add this piece if it can go somewhere. */
      if (moves[*movables].targets != 0) {
	moves[*movables].source = square[boardpos];
	moves[*movables].piece = piecetype;
	(*movables)++;
      }
      pieces = pieces & ~square[boardpos];
    }
  }
  return 0;
}

/* This function returns all pseudo-legal moves in a given position for the
   piece at square boardpos. Pseudo-legal move generation means that no
   checking is done to see if the move places it's own king in check. That
   has to be checked elsewhere. */
/*bitboard generate_moves(struct board *board, int color, int hpos, int piecetype, int boardpos) {
  //int64 pieces;
  //int i, listsize, piece_nbr;
  //extern bitboard square[64];
  //int oppcolor = color;

  //switch_colors(&oppcolor);

  if (piecetype == PAWN) {
    return generate_pawnmoves(board,color,hpos,boardpos);
  } else if (piecetype == ROOK) {
    return generate_horizontal_moves(board,color,boardpos)
      | generate_vertical_moves(board,color,boardpos);
  } else if (piecetype == KNIGHT) {
    return generate_knight_moves(board,color,boardpos);
  } else if (piecetype == BISHOP) {
    return generate_NEdiag_moves(board,color,boardpos)
      | generate_NWdiag_moves(board,color,boardpos);
  } else if (piecetype == QUEEN) {
    return generate_horizontal_moves(board,color,boardpos)
      | generate_vertical_moves(board,color,boardpos)
      | generate_NEdiag_moves(board,color,boardpos)
      | generate_NWdiag_moves(board,color,boardpos);
  } else if (piecetype == KING) {
    return generate_kingmoves(board,color,boardpos);
  }
  }*/
