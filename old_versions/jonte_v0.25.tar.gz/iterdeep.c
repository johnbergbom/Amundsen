#include "iterdeep.h"
#include <stdio.h>
#include "diverse.h"
#include "alfabeta.h"
#include "genmoves.h"
#include "timectrl.h"
#include "moves.h"

/* This function sorts the moves in the movelist from better moves to
   lower valued moves. The sorting algorithm is very slow, but this code
   is not time critical, and I didn't feel like spending time implementing
   a better algorithm. It removes any move with value == KINGTAKEN */
/*void sort_movelist(struct move **movelist, int *mcount) {
  struct move *newlist;
  int ceiling = INFTY;
  int newpek = 0;
  int added = 1;
  int bestvalue, i;

  newlist = (struct move *) malloc((*mcount)*sizeof(struct move));
  while (added) {
    added = 0;
    /* Find best value. /
    bestvalue = -INFTY;
    for (i = 0; i < (*mcount); i++)
      if ((*movelist)[i].value > bestvalue && (*movelist)[i].value != KINGTAKEN
	  && (*movelist)[i].value < ceiling)
	bestvalue = (*movelist)[i].value;
    /* Add the best values. /
    for (i = 0; i < (*mcount); i++)
      if ((*movelist)[i].value == bestvalue) {
	newlist[newpek++] = (*movelist)[i];
	added++;
      }
    /* Lower the ceiling. /
    ceiling = bestvalue;
  }
  *mcount = newpek;
  free(*movelist);
  *movelist = newlist;
  }*/

struct move iterative_deepening_aspiration_search(struct board *board,
						  int color, int maxdepth,
						  int hpos) {
  struct move *movelist;
  struct move *bestmove;
  struct move *validmoves;
  struct board newpos;
  int mcount = 0;
  int bestvalue, b;
  struct move returnmove;
  int alpha = -INFTY, beta = INFTY;
  int valmax = -INFTY;
  int org_color = color;
  int piece_nbr = 0, i, j = 0;
  char *dragstr;
  extern struct move **historik;
  int prunetype;
  int nbr_moves = 0;
  int piecetype, boardpos, movables = 0, oppmovables = 0;
  bitboard pieces, typetargets, target;
  struct moves moves[16];
  struct moves oppmoves[16];
  int oppcolor = color;
  extern bitboard square[64];
  extern bitboard *killers;
  extern int xboard_mode;
  int depth;
  //int ITER_INFTY;
  int branchfact;
  int nbrmoves1, nbrmoves2;
  int attempt_nbr;

  /* Since we do the test "if (valmax <= alpha)" after each iteration,
     we would keep iterating forever if we are at a loosing position,
     because in that case valmax will be -INFTY. Therefore we use a
     local ITER_INFTY that we use instead of the normal INFTY, to make
     sure we iterate forever in a loosing (or winning) position.
     (Alphabeta uses the normal INFTY) */
  //ITER_INFTY = INFTY + 1;
  //alpha = -ITER_INFTY;
  //beta = ITER_INFTY;

  switch_colors(&oppcolor);

  /* A board position should be in a legal state upon calling this
     function, so we should never be able to take the opponents king. */
  if (generate_moves_ny(board,color,hpos,moves,&movables) != 0) {
    debuglog("ERROR!!! ILLEGAL MOVES SHOULD NOT BE FOUND HERE!");
    fprintf(stderr,"ERROR!!! ILLEGAL MOVES SHOULD NOT BE FOUND HERE!\n");
    exit(1);
  }

  /* Count the number of possible moves, so we know how to initialize
     the movelist. */
  for (i = 0; i < movables; i++)
    nbr_moves += bitcount(moves[i].targets);
  movelist = (struct move *) malloc(nbr_moves*sizeof(struct move));

  /* Go through all movable pieces and add them to the movelist. */
  for (piece_nbr = 0; piece_nbr < movables; piece_nbr++) {
      typetargets = moves[piece_nbr].targets;
      /* Go through the targets one at a time. */
      while (typetargets != 0) {
        target = getlsb(typetargets);
        movelist[mcount].fsquare = moves[piece_nbr].source;
        movelist[mcount].tsquare = target;
        movelist[mcount].piece = moves[piece_nbr].piece;
        movelist[mcount].type = get_movetype(board,color,get_first_bitpos(moves[piece_nbr].source),moves[piece_nbr].piece,target);
	movelist[mcount].value = 0; //so we can check if != KINGTAKEN
        mcount++;
        typetargets = typetargets & ~target;
      }
  }

  /* We reserve space for killers up to ply == depth, and that's allright,
     because we don't use killer moves in the quiescence search. */
  killers = (bitboard *) calloc(maxdepth,sizeof(bitboard)); //calloc clears mem
  /*killers = (bitboard *) malloc(maxdepth*sizeof(bitboard));
  for (i = 0; i < maxdepth; i++)    //clear the killer moves
  killers[i] = 0;*/

  /* Calculate the average branching factor of searching the tree. */
  nbrmoves1 = nbr_moves;   //one's own moves
  /* We will also calculate the opponent's moves. */
  if (generate_moves_ny(board,oppcolor,hpos,oppmoves,&oppmovables) != 0) {
    /* The opponent could take our king, and when the move generation
       function discovers that, it quits immediately, without generating
       the rest of the moves. Therefore we don't know the opponent's
       branching factor, and therefore we set the branching factor to
       the number of moves oneself can do. */
    branchfact = nbrmoves1;
  } else {
  /* Count the number of possible moves for the opponent. */
    nbrmoves2 = 0;
    for (i = 0; i < oppmovables; i++)
      nbrmoves2 += bitcount(oppmoves[i].targets);
    branchfact = (nbrmoves1 + nbrmoves2) / 2;
  }
  printf("Branch factor = %d\n",branchfact);

  /* Go through the moves in the movelist and play them by calling
     alphabeta. Go deeper and deeper iteratively. */
  depth = 2;
  //while (depth <= maxdepth) {
  attempt_nbr = 1;
  while (1) {
    //printf("Depth = %d (alpha = %d, beta = %d):\n",depth,alpha,beta);
    /* valmax has to be cleared (=-INFTY) for each new turn */
    valmax = -INFTY;
    for (mcount = 0; mcount < nbr_moves; mcount++) {
      /* Test code for printing out the moves the engine is processing. */
      dragstr = (char *) malloc(20*sizeof(char));
      move2str(board,color,movelist[mcount],dragstr);
      //printf("        move %s",dragstr);
      free(dragstr);
      
      makemove(board,&newpos,color,movelist[mcount],depth);
      (*historik)[hpos] = movelist[mcount];
      movelist[mcount].value = alphabeta(&newpos,color,org_color,MIN,alpha,beta,depth-1,hpos+1);
      if (movelist[mcount].value != KINGTAKEN) {
	valmax = max(movelist[mcount].value,valmax);
      }
      //printf(" (r: %d)\n",movelist[mcount].value);
      
      /* Clear the killer moves so they don't get too clogged up with
	 stale killers. */
      for (i = 0; i < maxdepth; i++)
	killers[i] = 0;
    }
    /* If we failed high, we set alpha to -INFTY, and keep beta the same.
       If we failed low, we set beta to INFTY, and keep alpha the same.
       This is so we won't keep failing high,low,high,low,... on the
       re-search. I have not done any extensive analysis of this. */
    //printf("valmax = %d\n",valmax);
    /* If alpha already has the value -INFTY and valmax <= alpha, then
       it means all moves lead to check mate, and then, to avoid infinite
       re-searching, we add the condition that alpha shouldn't already have
       the value -INFTY to make a research. Same thing holds for beta. */
    /* Re-searches seem to be faster most of the time if we don't strech
       out the window to infinity right away. First we try a smaller opening
       by using the variable attempt_nbr. */
    if ((valmax <= alpha) && (alpha != -INFTY)) {
      //alpha = -ITER_INFTY;
      if (attempt_nbr == 1) {
	attempt_nbr++;
	alpha = valmax - SECOND_ATTEMPT_VALWINDOW;
      } else {
	alpha = -INFTY;
	attempt_nbr = 1;
      }
      //beta = valmax + VALWINDOW;    //ev. beta = gamla v�rdet p� beta???
      //printf("Re-search: ");
      printf("R-alpha\n");
    } else if ((valmax >= beta) && (beta != INFTY)) {
      //alpha = valmax - VALWINDOW;    //ev. alfa = gamla v�rdet p� alfa???
      //beta = ITER_INFTY;
      if (attempt_nbr == 1) {
	attempt_nbr++;
	beta = valmax + SECOND_ATTEMPT_VALWINDOW;
      } else {
	beta = INFTY;
	attempt_nbr = 1;
      }
      //printf("Re-search: ");
      printf("R-beta\n");
    } else {
      alpha = valmax - VALWINDOW;
      beta = valmax + VALWINDOW;
      if (time_is_up(hpos,branchfact))
	break;
      depth++;
      attempt_nbr = 1;
    }
    //sort_movelist(&movelist,&nbr_moves);
  }

  if (depth >= maxdepth) {
    printf("ERROR, KILLER-MOVE-ARRAY WAS WRITTEN PAST THE END!\n");
    debuglog("ERROR, KILLER-MOVE-ARRAY WAS WRITTEN PAST THE END!\n");
    exit(1);
  }

  /* Remove all invalid moves from the list. (The invalid ones have
     value == KINGTAKEN, those are the moves that checks one's own king) */
  validmoves = (struct move *) malloc(mcount * sizeof(struct move));
  j = 0;
  for (i = 0; i < nbr_moves; i++)
    if (movelist[i].value != KINGTAKEN)
      validmoves[j++] = movelist[i];

  //mcount = nbr_moves;
  mcount = j;

  if (mcount > 0) {
    /* Put the best moves in the array bestmove, and chose a random best move.
       (Provided there are several moves which are equally good.) */
    bestmove = (struct move *) malloc(mcount * sizeof(struct move));
    bestvalue = validmoves[0].value;
    b = 0;
    for (i = 0; i < mcount; i++) {
      if (validmoves[i].value >= bestvalue) {
	if (validmoves[i].value > bestvalue)
	  b = 0;
	bestvalue = validmoves[i].value;
	bestmove[b++] = validmoves[i];
      }
    }
    returnmove = bestmove[get_random_number(b-1)];
    free(bestmove);
  } else {
    //returnmove = movelist[0];
    printf("ERROR, NO LEGAL MOVE FOUND!\n");
    debuglog("ERROR, NO LEGAL MOVE FOUND!\n");
    exit(1);
  }

  /* These are only used in the search, and they should be cleared before
     next search. */
  board->captures[WHITE] = 0;
  board->captures[BLACK] = 0;

  //if (!xboard_mode)
    printf("Value = %d (ply = %d)\n",returnmove.value,depth);

  free(killers);
  free(movelist);
  free(validmoves);

  return returnmove;
}

