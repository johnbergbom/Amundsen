#ifndef _ALFABETA_
#define _ALFABETA_

#include "diverse.h"
#include "bitboards.h"

#define SAMRE_SLAR_BATTRE 1
#define LIKA_SLAR_LIKA 2
#define BATTRE_SLAR_SAMRE 3

#define KINGTAKEN 500000

/* For move generation we use the moves struct. The source represents the
   square that a piece will move from. The targets represent all the
   squares the piece can move to. Piece tells what kind of piece we are
   dealing with. */
/*struct moves {
  bitboard source;
  bitboard targets;
  int piece;
  };*/

int max(int a, int b);
int min(int a, int b);

int quiescence(struct board *board, int vemstur, int org_color, int nodetype, int alpha, int beta, bitboard tsquare, int hpos);

int alphabeta(struct board *board, int vemstur, int org_color, int nodetype, int alpha, int beta, int depth, int hpos);

struct move thinkalphabeta(struct board *board, int vemstur, int depth, int hpos);

#endif       //_ALFABETA_
