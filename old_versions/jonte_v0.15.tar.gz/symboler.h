#define CLRSCR printf("\033[2J")
#define GOTOXY(rad,kol) printf("\033[%d;%df",rad,kol)
#define TRUE 1
#define FALSE 0
#define PI 3.1415962535
#define BEGIN {
#define END }
#define INVERT printf("\033[7m")
#define BLINK printf("\033[5m")
#define UNDERLINE printf("\033[4m")
#define BOLD printf("\033[1m")
#define NORMAL printf("\033[0m")
#define BELL printf("\a")

