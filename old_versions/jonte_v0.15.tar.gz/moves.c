#include "moves.h"
#include <stdio.h>
#include <stdlib.h>

extern int xboard_mode;

/*Denna funktion satter som default topjas == frompjas, och rockad == 0. Det
  eftersom detta galler i 99% av fallen. Vid bondeforvandling eller rockad
  far man sjalv satta ratt varde efter att man anropat denna funktion. */
/*void initdrag(struct drag *drag, int frad, int fkol, int trad, int tkol, int pjas) {
  drag->fromrow = frad;
  drag->fromcol = fkol;
  drag->frompjas = pjas;
  drag->torow = trad;
  drag->tocol = tkol;
  drag->topjas = pjas;
  drag->value = 0;
  drag->rockad = 0;
  drag->i_schack = 0;
  }*/

/* Denna funktion omvandlar en str�ng till ett struct drag-objekt. Om str�ngen
   �r felaktig returneras -99. */
struct move str2move(char *vilket_drag, struct board *board, int vemstur) {
  struct move draget;
  int frow, fcol, trow, tcol;
  char *str;
  extern bitboard square[64];
  extern bitboard pawn_lastrow[2];
  extern struct attack attack;
  int oppcolor = vemstur;
  int i, movetype;

  switch_colors(&oppcolor);

  if (strlen(vilket_drag) != 4 && strlen(vilket_drag) != 5) {
    draget.value = -99;
    return draget;
  }

  frow = '8' - vilket_drag[1];
  fcol = vilket_drag[0] - 'a';
  trow = '8' - vilket_drag[3];
  tcol = vilket_drag[2] - 'a';
  draget.fsquare = square[frow*8 + fcol];
  draget.tsquare = square[trow*8 + tcol];

  /* Denna test beh�vs eftersom det inte r�cker att kolla om
     strlen(vilket_drag) != 7, ty man kan ju skriva in tex.
     str�ngen "hhhhhhh", som ocks� har 7 tecken. */
  if ((frow > 7) || (frow < 0) ||
      (fcol > 7) || (fcol < 0) ||
      (trow > 7) || (trow < 0) ||
      (tcol > 7) || (tcol < 0)) {
    draget.value = -99;
    return draget;
  }

  /* Find out what kind of piece made this move. */
  for (i = 0; i < 6; i++)
    if (board->piece[vemstur][i] & draget.fsquare)
      draget.piece = i;

  /* Find out if this move was a capture or a normal move. Do this
     by going through the bitboards of the opponent's pieces and see
     if we find a piece that this move will be taking. */
  movetype = NORMAL_MOVE;
  /*  for (i = 0; i < 6; i++)
    if (board->piece[oppcolor][i] & draget.tsquare) {
      movetype = CAPTURE_MOVE;
      break;
      }*/
  /* Find out if this move was a capture or a normal move. This is a
     more efficient way of doing it than the above method. */
  if (board->all_pieces[oppcolor] & draget.tsquare)
    movetype = CAPTURE_MOVE;

  /* Find out if the move is a passant move. First check if a pawn
     makes the move. */
  //if (board->piece[vemstur][PAWN] & draget.fsquare) {
  if (draget.piece == PAWN) {
    /* Then check if the pawn is making an attack, and if the attack goes
       towards a square that is not occupied by an enemy piece. */
    if ((attack.pawn[vemstur][frow*8+fcol] & draget.tsquare)
	&& !(board->all_pieces[oppcolor] & draget.tsquare))
      movetype = CAPTURE_MOVE | PASSANT_MOVE;
  }

  /* Find out if the move is a castling move. */
  //if (draget.fsquare & board->piece[vemstur][KING]) {
  if (draget.piece == KING) {
    if (vemstur == WHITE) {
      if ((draget.fsquare & square[60]) &&
	  ((draget.tsquare & square[58]) || (draget.tsquare & square[62])))
	movetype = CASTLING_MOVE;
    } else {     //vemstur == BLACK
      if ((draget.fsquare & square[4]) &&
	  ((draget.tsquare & square[2]) || (draget.tsquare & square[6])))
	movetype = CASTLING_MOVE;
    }
  }
  draget.type = movetype;

  /* If the move is a pawn that advances to the last row, then find out
     what kind of promotion it is. */
  //if (draget.fsquare & board->piece[vemstur][PAWN] && draget.tsquare & pawn_lastrow[vemstur]) {
  if ((draget.piece == PAWN) && (draget.tsquare & pawn_lastrow[vemstur])) {
    if (strlen(vilket_drag) == 5) {
      switch(vilket_drag[4]) {
      case 'r' : draget.type = draget.type | ROOK_PROMOTION_MOVE;     break;
      case 'q' : draget.type = draget.type | QUEEN_PROMOTION_MOVE;     break;
      case 'n' : draget.type = draget.type | KNIGHT_PROMOTION_MOVE;     break;
      case 'b' : draget.type = draget.type | BISHOP_PROMOTION_MOVE;     break;
      default : if (!xboard_mode)
	          printf("Invalid piece!\n");
                else {
		  str = (char *) malloc(30*sizeof(char));
		  sprintf(str,"Invalid piece = %s",vilket_drag);
		  debuglog(str);
		  free(str);
		}
                draget.value = -99;
		return draget;
      }
    } else {
      if (!xboard_mode)
	printf("Invalid move format!\n");
      else {
	str = (char *) malloc(30*sizeof(char));
	sprintf(str,"Invalid move format (%s)",vilket_drag);
	debuglog(str);
	free(str);
      }
      draget.value = -99;
      return draget;
    }
  }

  return draget;
}

/* Denna funktion omvandlar ett drag till en str�ng. */
//void drag2str(struct drag draget, char *vilket_drag) {
  /*  vilket_drag[1] = '8' - draget.fromrow;
  vilket_drag[0] = draget.fromcol + 'a';
  vilket_drag[3] = '8' - draget.torow;
  vilket_drag[2] = draget.tocol + 'a';

  if (draget.frompjas != draget.topjas) {
    switch(abs(draget.topjas)) {
      case ABS_ROOK : vilket_drag[4] = 'r';     break;
      case ABS_QUEEN : vilket_drag[4] = 'q';     break;
      case ABS_KNIGHT : vilket_drag[4] = 'n';     break;
      case ABS_BISHOP : vilket_drag[4] = 'b';     break;
    }
    vilket_drag[5] = '\0';
  } else
  vilket_drag[4] = '\0';*/
//}

void move2str(struct board *board, int color, struct move move, char *str) {
  extern bitboard pawn_lastrow[2];
  int square, row, col;

  square = get_first_bitpos(move.fsquare);
  row = square / 8;
  col = square % 8;
  str[1] = '8' - row;
  str[0] = col + 'a';
  square = get_first_bitpos(move.tsquare);
  row = square / 8;
  col = square % 8;
  str[3] = '8' - row;
  str[2] = col + 'a';
  str[4] = '\0';
  /* If the move is a pawn that advances to the last row, then find out
     what kind of promotion it is. */
  if (move.fsquare & board->piece[color][PAWN] && move.tsquare & pawn_lastrow[color]) {
    if (move.type & QUEEN_PROMOTION_MOVE)
      str[4] = 'q';
    else if (move.type & ROOK_PROMOTION_MOVE)
      str[4] = 'r';
    else if (move.type & KNIGHT_PROMOTION_MOVE)
      str[4] = 'n';
    else if (move.type & BISHOP_PROMOTION_MOVE)
      str[4] = 'b';
    else
      printf("ERROR, wrong kind of promotion!!!\n");
    str[5] = '\0';
  }
}

/*void kopiera(struct board *fromboard, struct board *toboard) {
  *toboard = *fromboard;
  }*/

void makemove(struct board *oldboard, struct board *newboard, int color, struct move move) {
  //struct board newboard;
  int oppcolor = color;
  int j;
  bitboard rookfsquare, rooktsquare;
  extern bitboard square[64];
  extern int rotate0to90[64];
  extern int rotate0toNE[64];
  extern int rotate0toNW[64];

  switch_colors(&oppcolor);
  *newboard = *oldboard;
  //kopiera(oldboard,&newboard);

  //i = move.piece;
  //for (i = 0; i < 6; i++) {
  ///* Find the piece type to which the move belongs. */
  //if (oldboard->piece[color][i] & move.fsquare) {

  /* Check if the move is a capture. If it is, then we have to clear
     the bitboard of the taken piece. */
  if (move.type & CAPTURE_MOVE) {
    /* If it's a passant capture, then we have to remove the taken piece in
       a different way than for a normal capture. */
    if (move.type & PASSANT_MOVE) {
      if (color == WHITE) {
	newboard->piece[oppcolor][PAWN] = newboard->piece[oppcolor][PAWN] & (~(move.tsquare << 8));
	newboard->all_pieces[oppcolor] = newboard->all_pieces[oppcolor] & (~(move.tsquare << 8));
	newboard->rot90_pieces[oppcolor] = newboard->rot90_pieces[oppcolor]
	  & ~(square[rotate0to90[get_first_bitpos(move.tsquare << 8)]]);
	newboard->rotNE_pieces[oppcolor] = newboard->rotNE_pieces[oppcolor]
	  & ~(square[rotate0toNE[get_first_bitpos(move.tsquare << 8)]]);
	newboard->rotNW_pieces[oppcolor] = newboard->rotNW_pieces[oppcolor]
	  & ~(square[rotate0toNW[get_first_bitpos(move.tsquare << 8)]]);
      } else {   //color == BLACK
	newboard->piece[oppcolor][PAWN] = newboard->piece[oppcolor][PAWN] & (~(move.tsquare >> 8));
	newboard->all_pieces[oppcolor] = newboard->all_pieces[oppcolor] & (~(move.tsquare >> 8));
	newboard->rot90_pieces[oppcolor] = newboard->rot90_pieces[oppcolor]
	  & ~(square[rotate0to90[get_first_bitpos(move.tsquare >> 8)]]);
	newboard->rotNE_pieces[oppcolor] = newboard->rotNE_pieces[oppcolor]
	  & ~(square[rotate0toNE[get_first_bitpos(move.tsquare >> 8)]]);
	newboard->rotNW_pieces[oppcolor] = newboard->rotNW_pieces[oppcolor]
	  & ~(square[rotate0toNW[get_first_bitpos(move.tsquare >> 8)]]);
      }
    } else {   //normal capture (not passant)
      newboard->all_pieces[oppcolor] = newboard->all_pieces[oppcolor] & (~move.tsquare);
      newboard->rot90_pieces[oppcolor] = newboard->rot90_pieces[oppcolor]
	& ~(square[rotate0to90[get_first_bitpos(move.tsquare)]]);
      newboard->rotNE_pieces[oppcolor] = newboard->rotNE_pieces[oppcolor]
	& ~(square[rotate0toNE[get_first_bitpos(move.tsquare)]]);
      newboard->rotNW_pieces[oppcolor] = newboard->rotNW_pieces[oppcolor]
	& ~(square[rotate0toNW[get_first_bitpos(move.tsquare)]]);
      for (j = 0; j < 6; j++)
	if (newboard->piece[oppcolor][j] & move.tsquare) {
	  newboard->piece[oppcolor][j] = newboard->piece[oppcolor][j] & (~move.tsquare);
	  break;
	}
    }
  }

  /* Update the bitboard for the piece that made the move. */
  newboard->piece[color][move.piece] = newboard->piece[color][move.piece] & (~move.fsquare);
  if (move.type & QUEEN_PROMOTION_MOVE)
    newboard->piece[color][QUEEN] = newboard->piece[color][QUEEN] | move.tsquare;
  else if (move.type & ROOK_PROMOTION_MOVE)
    newboard->piece[color][ROOK] = newboard->piece[color][ROOK] | move.tsquare;
  else if (move.type & BISHOP_PROMOTION_MOVE)
    newboard->piece[color][BISHOP] = newboard->piece[color][BISHOP] | move.tsquare;
  else if (move.type & KNIGHT_PROMOTION_MOVE)
    newboard->piece[color][KNIGHT] = newboard->piece[color][KNIGHT] | move.tsquare;
  else
    newboard->piece[color][move.piece] = newboard->piece[color][move.piece] | move.tsquare;

  /* Update the all_pieces bitboard and the rotated bitboards. */
  newboard->all_pieces[color] = newboard->all_pieces[color] & (~move.fsquare);
  newboard->all_pieces[color] = newboard->all_pieces[color] | move.tsquare;
  newboard->rot90_pieces[color] = newboard->rot90_pieces[color]
    & ~(square[rotate0to90[get_first_bitpos(move.fsquare)]]);
  newboard->rot90_pieces[color] = newboard->rot90_pieces[color]
    | square[rotate0to90[get_first_bitpos(move.tsquare)]];
  newboard->rotNE_pieces[color] = newboard->rotNE_pieces[color]
    & ~(square[rotate0toNE[get_first_bitpos(move.fsquare)]]);
  newboard->rotNE_pieces[color] = newboard->rotNE_pieces[color]
    | square[rotate0toNE[get_first_bitpos(move.tsquare)]];
  newboard->rotNW_pieces[color] = newboard->rotNW_pieces[color]
    & ~(square[rotate0toNW[get_first_bitpos(move.fsquare)]]);
  newboard->rotNW_pieces[color] = newboard->rotNW_pieces[color]
    | square[rotate0toNW[get_first_bitpos(move.tsquare)]];

  /* Update the castling flags. */
  if (move.piece == ROOK) {
    if (color == WHITE) {
      if (move.fsquare & square[56])
	newboard->status[color] = newboard->status[color] & ~LONG_CASTLING_OK;
      else if (move.fsquare & square[63])
	newboard->status[color] = newboard->status[color] & ~SHORT_CASTLING_OK;
    } else {    //color == BLACK
      if (move.fsquare & square[0])
	newboard->status[color] = newboard->status[color] & ~LONG_CASTLING_OK;
      else if (move.fsquare & square[7])
	newboard->status[color] = newboard->status[color] & ~SHORT_CASTLING_OK;
    }
  } else if (move.piece == KING)
    newboard->status[color] = newboard->status[color]
      & ~(SHORT_CASTLING_OK | LONG_CASTLING_OK);

  if (move.type & CASTLING_MOVE) {
    /* check if short castling. */
    if ((move.tsquare & square[6]) || (move.tsquare & square[62])) {
      rookfsquare = move.tsquare << 1;
      rooktsquare = move.tsquare >> 1;
    } else {   //long castling
      rookfsquare = move.tsquare >> 2;
      rooktsquare = move.tsquare << 1;
    }
    newboard->piece[color][ROOK] = newboard->piece[color][ROOK] & (~rookfsquare);
    newboard->piece[color][ROOK] = newboard->piece[color][ROOK] | rooktsquare;
    newboard->all_pieces[color] = newboard->all_pieces[color] & (~rookfsquare);
    newboard->all_pieces[color] = newboard->all_pieces[color] | rooktsquare;
    newboard->rot90_pieces[color] = newboard->rot90_pieces[color]
      & ~(square[rotate0to90[get_first_bitpos(rookfsquare)]]);
    newboard->rot90_pieces[color] = newboard->rot90_pieces[color]
      | square[rotate0to90[get_first_bitpos(rooktsquare)]];
    newboard->rotNE_pieces[color] = newboard->rotNE_pieces[color]
      & ~(square[rotate0toNE[get_first_bitpos(rookfsquare)]]);
    newboard->rotNE_pieces[color] = newboard->rotNE_pieces[color]
      | square[rotate0toNE[get_first_bitpos(rooktsquare)]];
    newboard->rotNW_pieces[color] = newboard->rotNW_pieces[color]
      & ~(square[rotate0toNW[get_first_bitpos(rookfsquare)]]);
    newboard->rotNW_pieces[color] = newboard->rotNW_pieces[color]
      | square[rotate0toNW[get_first_bitpos(rooktsquare)]];
    newboard->status[color] = CASTLED;
  }

  //break;
  //}
  //}
  //return newboard;
}












