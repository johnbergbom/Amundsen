#include "parse.h"
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
//#include <unistd.h>
#include "alfabeta.h"
//#include "history.h"
#include "moves.h"
#include "genmoves.h"
#include "display.h"

extern int xboard_mode;
struct move **historik;
/* We initiate histpos to 6, to allow searching for draws according
   to the 3-move repetition rule, already from the start. Then we don't
   need to treat the first few moves as a separate case. */
#define HISTPOS_INIT 6
int histpos = HISTPOS_INIT;
int hlistsize = 100;

void move2history(struct move *move) {
  (*historik)[histpos++] = *move;

  if (histpos > hlistsize - 10) {
    //printf("Rapportera: Stort parti!\n");
    printf("INCREASING SIZE OF GAME HISTORY!!!!\n");
    hlistsize = change_list_size(historik,hlistsize + 100);
  }
  //printf("histpos = %d, hlistsize = %d\n",histpos,hlistsize);
  //printf("hstorik = %d, *hstorik = %d\n",hstorik,*hstorik);
}

void computer_make_move(struct board **board, int *vemstur, int *started) {
  struct move move;
  //int antal_drag;
  //int kungrad, kungkol;
  struct board tempboard;
  char *str;
  char *str2;
  //extern bitboard square[64];
  //int i;

  str2 = (char *) malloc(50*sizeof(char));
  str = (char *) malloc(50*sizeof(char));
  move = thinkalphabeta(*board,*vemstur,THINKFORWARD,histpos);

  /* Make a test to see if all moves lead to one's king being taken. */
  if (move.value == KINGTAKEN) {  /* Inga giltiga drag fanns. */
    if (in_check(*board,*vemstur)) {
      if (*vemstur == WHITE)
	sprintf(str,"0-1 {Black mates}");
      else
	sprintf(str,"1-0 {White mates}");
      printf("%s\n",str);  //this output goes for both xboard and non-xboard mode
      if (xboard_mode) {
	sprintf(str2,"output sent = %s",str);
	debuglog(str2);
      }
    } else {
      sprintf(str,"1/2-1/2 {Stalemate}");
      printf("%s\n",str);  //this output goes for both xboard and non-xboard mode
      if (xboard_mode) {
	sprintf(str2,"output sent = %s",str);
	debuglog(str2);
	debuglog("Stalemate (Patt)");
      }
    }
    *started = 0;
  } else {
    move2history(&move);
    makemove(*board,&tempboard,*vemstur,move);
    **board = tempboard;
    if (!xboard_mode)
      showboard(*board);
    else {
      move2str(*board,*vemstur,move,str);
      printf("move %s\n",str);
      sprintf(str2,"output sent = move %s",str);
      debuglog(str2);
    }
    if (*vemstur == WHITE)
      *vemstur = BLACK;
    else
      *vemstur = WHITE;

    /* I'M NOT TOTALY SURE IF THIS CODE IS NEEDED OR NOT!!! */
    /* (I think it's needed if the computer wins the game...) */
    if (move.value == INFTY) {
      if (*vemstur == WHITE)
	sprintf(str,"0-1 {Black mates}");
      else
	sprintf(str,"1-0 {White mates}");
      printf("%s\n",str);  //this output goes for both xboard and non-xboard mode
      if (xboard_mode) {
        sprintf(str2,"output sent = %s",str);
        debuglog(str2);
      }
      debuglog("DETTA FOREKOMMER JU!!!!");
      printf("LATTE GERRRRRRRRRAAAAAAAAAAAAAHH!!!!!!\n");
      *started = 0;
    }
  }

  free(str);
  free(str2);
  return;
}

/* Returns false(=0) on error, and true(=1) if no error. */
int parsemove(char *input, struct board **board, int *vemstur, int *started) {
  struct move move;
  struct board tempboard;
  char *str;
  //char *dragstr;
  int returnval = 0;
  //extern int lagge;

  str = (char *) malloc(50*sizeof(char));
  move = str2move(input,*board,*vemstur);
  /*if (strcmp(input,"a6a7") == 0)
    lagge = 1;
  else
  lagge = 0;*/
  if (move.value != -99) {
    if (!*started && !xboard_mode)
      printf("You haven't started any game.\n");
    else {
      debuglog(input);
      move2history(&move);
      makemove(*board,&tempboard,*vemstur,move);
      **board = tempboard;
      if (!xboard_mode)
	showboard(*board);
      if (*vemstur == WHITE)
	*vemstur = BLACK;
      else
	*vemstur = WHITE;
      /* If xboard_mode is on and *started = 0, then we will make the
         move, but not start thinking until xboard sends a go. This
         is done by returning a 0.*/
      if (*started)
	returnval = 1;
    }
  } else {
    if (!xboard_mode)
      printf("Command could not be interpreted. Press '?' for help.\n");
    else {
      sprintf(str,"unknown input received = \"%s\"",input);
      debuglog(str);
    }
  }
  free(str);
  return returnval;
}

void parse(int *white, int *black, int *vemstur, int *started) {
  char *input;
  extern struct board *board;
  int run = 1, i;
  char *str;
  extern bitboard square[64];

  historik = (struct move **) malloc(sizeof(struct move *));
  *historik = (struct move *) malloc(hlistsize*sizeof(struct move));
  input = (char *) malloc(100*sizeof(char));
  str = (char *) malloc(100*sizeof(char));

  while (run) {
    if (!xboard_mode)
      fprintf(stderr,">");
    //scanf("%s",input);
    //read(0,input,20);
    fgets(input,100,stdin);   //reads a whole line
    input[strlen(input)-1] = '\0';   //remove trailing newline
    //sprintf(str,"input received = \"%s\"",input);
    //debuglog(str);
    //fprintf(stderr,"input = \"%s\"\n",input);

    if (xboard_mode) {
      if (strcmp(input,"new") == 0) {
	set_board(board);
	//set_testboard(board);
	*vemstur = WHITE;
	*white = HUMAN;
	*black = COMPUTER;
	*started = 1;
	histpos = HISTPOS_INIT;   //nollst�ll draghistoriken
	debuglog("new");
      } else if (strcmp(input,"random") == 0) {
	//do nothing, we always use random evaluation
	debuglog("random");
      } else if (strcmp(input,"force") == 0) {
	*started = 0;
	debuglog("force");
      } else if (strncmp(input,"level",5) == 0) {
	//do nothing, the enginge doesn't support timing
	debuglog("level");
      } else if (strncmp(input,"time",4) == 0) {
	//do nothing, the enginge doesn't support timing
	debuglog("time");
      } else if (strncmp(input,"otim",4) == 0) {
	//do nothing, the enginge doesn't support timing
	debuglog("otime");
      } else if (strncmp(input,"result",6) == 0) {
	debuglog("result");
      } else if (strcmp(input,"hard") == 0) {
	//do nothing, the enginge doesn't support pondering
	debuglog("hard");
      } else if (strcmp(input,"dumpa") == 0) {
	//Used for debugging purposes
	debuglog("dumpa");
	showboard(board);
      } else if (strcmp(input,"quit") == 0) {
	*started = 0;
	run = 0;
	debuglog("quit");
      } else if (strcmp(input,"white") == 0) {
	*vemstur = WHITE;
	*white = HUMAN;
	*black = COMPUTER;
	debuglog("white");
      } else if (strcmp(input,"black") == 0) {
	*vemstur = BLACK;
	*white = COMPUTER;
	*black = HUMAN;
	debuglog("black");
      } else if (strcmp(input,"go") == 0) {
	*started = 1;
	if (*vemstur == WHITE) {
	  *white = COMPUTER;
	  *black = HUMAN;
	} else {
	  *black = COMPUTER;
	  *white = HUMAN;
	}
	debuglog("go");
	computer_make_move(&board,vemstur,started);
      } else {
	if (parsemove(input,&board,vemstur,started)) {
	  computer_make_move(&board,vemstur,started);
	}
      }
    } else {
      if (strcmp(input,"xboard") == 0) {
	xboard_mode = 1;
	printf("\n");   //xboard wants a newline here
	signal(SIGINT,SIG_IGN);  //ignore SIGINT
	debuglog("xboard");
      } else if (strcmp(input,"hist") == 0) {
	//showhistory();
      } else if (strcmp(input,"quit") == 0)
	run = 0;
      else if ((strcmp(input,"help") == 0) || (strcmp(input,"?") == 0))
	showhelp();
      else if (strcmp(input,"visa") == 0) {
	//print_table(spel->spelplan);
	showboard(board);
      } else if (strcmp(input,"vitdator") == 0)
	*white = COMPUTER;
      else if (strcmp(input,"vitman") == 0)
	*white = HUMAN;
      else if (strcmp(input,"dumpa") == 0) {
	//Used for debugging purposes
	for (i = 0; i < 64; i++) {
	  if ((board->rot90_pieces[BLACK]) & square[i])
	    printf("1");
	  else
	    printf("0");
	  if (i == 55 || i == 47 || i == 39 || i == 31 || i == 23 || i == 15 || i == 7)
	    printf("\n");
	}
	printf("\n");
      } else if (strcmp(input,"svartdator") == 0)
	*black = COMPUTER;
      else if ((strcmp(input,"svartman") == 0) || (strcmp(input,"neger") == 0))
	*black = HUMAN;
      else if (strcmp(input,"starta") == 0) {
	if (*started != 1) {
	  //set_board(board);
	  //set_testboard(board);
	  *started = 1;
	  histpos = HISTPOS_INIT;   //nollst�ll draghistoriken
	  if (*white == COMPUTER)
	    computer_make_move(&board,vemstur,started);
	}
      } else if (strcmp(input,"inst") == 0)
	showsettings(white,black,vemstur,started);
      else if (input[0] != '\0') {
	if (parsemove(input,&board,vemstur,started))
	  computer_make_move(&board,vemstur,started);
      }
    }
  }
  free(input);
  free(str);
  free(*historik);
  free(historik);
  free(board);
}













