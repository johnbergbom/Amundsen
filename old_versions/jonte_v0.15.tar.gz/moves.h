#ifndef _MOVES_
#define _MOVES_

#include "diverse.h"
#include "bitboards.h"

/*Denna funktion satter som default topjas == frompjas, och rockad == 0. Det
  eftersom detta galler i 99% av fallen. Vid bondeforvandling eller rockad
  far man sjalv satta ratt varde efter att man anropat denna funktion. */
//void initdrag(struct drag *drag, int frad, int fkol, int trad, int tkol, int pjas);

/* Denna funktion omvandlar en str�ng till ett struct drag-objekt. Om str�ngen
   �r felaktig returneras -99. */
struct move str2move(char *vilket_drag, struct board *board, int vemstur);

/* Denna funktion omvandlar ett drag till en str�ng. */
//void drag2str(struct drag draget, char *vilket_drag);

//void move2str(struct move move, char *str);
void move2str(struct board *board, int color, struct move move, char *str);

//void undomove(struct s *spel, struct drag *vilket_drag, struct s *oldflags, int oldsquare);

//struct board makemove(struct board *board, int color, struct move move);
void makemove(struct board *oldboard, struct board *newboard, int color, struct move move);

#endif      //_MOVES_
