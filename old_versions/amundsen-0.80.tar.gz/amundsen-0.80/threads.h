#ifndef _THREADS_
#define _THREADS_

int start_input_thread();
void stop_input_thread();

#endif       //_THREADS_
