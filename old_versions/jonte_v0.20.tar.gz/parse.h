#ifndef _PARSE_
#define _PARSE_

#include "diverse.h"
#include "bitboards.h"

//#define MAX_NBR_OF_PLIES 200
//#define MAX_NBR_OF_PLIES 50

void computer_make_move(struct board **board, int *vemstur, int *started);

int parsemove(char *input, struct board **board, int *vemstur, int *started);

void parse(int *white, int *black, int *vemstur, int *started);

#endif      //_PARSE_
