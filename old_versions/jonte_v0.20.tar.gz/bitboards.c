#include "bitboards.h"
#include <math.h>
#include <stdlib.h>
#include "diverse.h"

bitboard square[64];
bitboard lower[64];
bitboard higher[64];
struct attack attack;
struct board *board;
bitboard pawn_start[2];
bitboard pawn_lastrow[2];
bitboard pawn_passantrow[2];
int bits_in_16bits[65536];
int first_bit_in_16bits[65536];
//int last_bit_in_16bits[65536];
bitboard col_bitboard[8];
int pieceval[6];

/* Stuff for handling the sliders. */
int rotate90to0[64];
int rotate0to90[64];
int rotateNEto0[64];
int rotate0toNE[64];
int rotateNWto0[64];
int rotate0toNW[64];
int diagNE_length[64];
int diagNE_start[64];
int diagNW_length[64];
int diagNW_start[64];
int ones[9];

void set_square(bitboard *square) {
  int i;

  square[0] = 1;
  for (i = 1; i < 64; i++)
    square[i] = square[i-1] << 1;
}

void set_lower(bitboard *lower) {
  int i;

  lower[0] = 0;
  lower[1] = 1;
  for (i = 2; i < 64; i++)
    lower[i] = (lower[i-1] << 1) | 1;
  /*  lower[0] = ~1;
  for (i = 1; i < 64; i++)
  lower[i] = lower[i-1] << 1;*/
}

void set_higher(bitboard *higher) {
  int i;

  higher[0] = ~1;
  for (i = 1; i < 64; i++)
    higher[i] = higher[i-1] & (~((int64) pow(2,i)));
  /*higher[0] = 0;
  higher[1] = 1;
  for (i = 2; i < 64; i++)
    higher[i] = (higher[i-1] << 1) | 1;
    //higher[i] = higher[i+1] & (~((int64) pow(2,i)));*/
}

void set_rotate90to0(int *rot) {
  int i;

  for (i = 0; i < 64; i++)
    rot[(i%8)*8 + 7 - i/8] = i;
}

void set_rotate0to90(int *rot) {
  int i;

  for (i = 0; i < 64; i++)
    rot[i] = (i%8)*8 + 7 - i/8;
}

void set_rotate0toNE(int *rot) {
  int square = 0;
  int i, j;

  /* Do the upper left hand side of the board. */
  for (i = 0; i < 8; i++)
    for (j = 0; j < (i+1); j++)
      rot[(i-j)*8 + j] = square++;

  /* Do the lower right hand side of the board. */
  for (i = 1; i < 8; i++)
    for (j = 0; j < (8-i); j++)
      rot[(7-j)*8 + j + i] = square++;
}

void set_rotateNEto0(int *rot) {
  int i;

  for (i = 0; i < 64; i++)
    rot[rotate0toNE[i]] = i;
}

void set_rotate0toNW(int *rot) {
  int square = 0;
  int i, j;

  /* Do the upper right hand side of the board. */
  for (i = 0; i < 8; i++)
    for (j = 0; j < (i+1); j++)
      rot[(i-j)*8 + (7-j)] = square++;

  /* Do the lower left hand side of the board. */
  for (i = 1; i < 8; i++)
    for (j = 0; j < (8-i); j++)
      rot[(7-j)*8 + (7-j) - i] = square++;
}

void set_rotateNWto0(int *rot) {
  int i;

  for (i = 0; i < 64; i++)
    rot[rotate0toNW[i]] = i;
}

void set_col_bitboard(bitboard *col_bitboard) {
  int row, col;

  for (col = 0; col < 8; col++) {
    for (row = 0; row < 8; row++)
      col_bitboard[col] = col_bitboard[col] | square[row*8 + col];
  }
}

void set_ones(int *arr) {
  arr[0] = 0;
  arr[1] = 1;
  arr[2] = 1 | 2;
  arr[3] = 1 | 2 | 4;
  arr[4] = 1 | 2 | 4 | 8;
  arr[5] = 1 | 2 | 4 | 8 | 16;
  arr[6] = 1 | 2 | 4 | 8 | 16 | 32;
  arr[7] = 1 | 2 | 4 | 8 | 16 | 32 | 64;
  arr[8] = 1 | 2 | 4 | 8 | 16 | 32 | 64 | 128;
}

void set_pieceval(int *pieceval) {
  pieceval[PAWN] = VAL_PAWN;
  pieceval[ROOK] = VAL_ROOK;
  pieceval[KNIGHT] = VAL_KNIGHT;
  pieceval[BISHOP] = VAL_BISHOP;
  pieceval[QUEEN] = VAL_QUEEN;
  pieceval[KING] = VAL_KING;
}

void set_pawn_start(bitboard pawnstart[2]) {
  int i;

  pawnstart[WHITE] = 0;
  pawnstart[BLACK] = 0;
  for (i = 48; i < 56; i++)
    pawnstart[WHITE] = pawnstart[WHITE] | square[i];
  for (i = 8; i < 16; i++)
    pawnstart[BLACK] = pawnstart[BLACK] | square[i];
}

void set_pawn_lastrow(bitboard pawnlastrow[2]) {
  int i;

  pawnlastrow[WHITE] = 0;
  pawnlastrow[BLACK] = 0;
  for (i = 0; i < 8; i++)
    pawnlastrow[WHITE] = pawnlastrow[WHITE] | square[i];
  for (i = 56; i < 64; i++)
    pawnlastrow[BLACK] = pawnlastrow[BLACK] | square[i];
}

void set_pawn_passantrow(bitboard pawnstart[2]) {
  int i;

  pawnstart[WHITE] = 0;
  pawnstart[BLACK] = 0;
  for (i = 32; i < 40; i++)
    pawnstart[WHITE] = pawnstart[WHITE] | square[i];
  for (i = 24; i < 32; i++)
    pawnstart[BLACK] = pawnstart[BLACK] | square[i];
}

/* Calculates the length of each diagonal. Eg. diagNE_length[b4] == 6 */
void set_diagNE_length(int diagNElen[64]) {
  int row, col, i;

  for (row = 0; row < 8; row++) {
    col = 0;
    for (i = row+1; i < 9; i++)
      diagNElen[row*8 + col++] = i;
    i = 7;
    while (col < 8)
      diagNElen[row*8 + col++] = i--;
  }
}

/* Calculates where a certain diagonal starts. Eg. diagNE_start[b4] == a3 */
void set_diagNE_start(int diagNEstart[64]) {
  int row, col;

  /* Calculate the upper row. */
  for (col = 0; col < 8; col++)
    diagNEstart[col] = col * 8;

  /* Calculate the upper left half of the board by copying the earlier
     calculated upper diagonal value. Eg. diagNEstart[b7] == diag45start[c8] */
  for (row = 1; row < 8; row++)
    for (col = 0; col + row < 8; col++)
      diagNEstart[row*8 + col] = diagNEstart[(row-1)*8 + col + 1];

  /* Calculate the bottom row. */
  for (col = 1; col < 8; col++)
    diagNEstart[7*8 + col] = 7*8 + col;

  /* Calculate the bottom right half of the board by copying the earlier
     calculated value that's diagonally below.
     Eg. diagNEstart[e2] == diagNEstart[d1] */
  for (row = 6; row > 0; row--)
    for (col = 8 - row; col < 8; col++)
      diagNEstart[row*8 + col] = diagNEstart[(row+1)*8 + col - 1];
}

/* Calculates the length of each diagonal. Eg. diagNW_length[f7] == 4 */
void set_diagNW_length(int diagNWlen[64]) {
  int row, col, i;

  for (row = 0; row < 8; row++) {
    col = 7;
    for (i = row+1; i < 9; i++)
      diagNWlen[row*8 + col--] = i;
    i = 7;
    while (col >= 0)
      diagNWlen[row*8 + col--] = i--;
  }
}

/* Calculates where a certain diagonal starts. Eg. diagNW_start[f6] == h4 */
void set_diagNW_start(int diagNWstart[64]) {
  int row, col;

  /* Calculate the upper row. */
  for (col = 7; col >= 0; col--)
    diagNWstart[col] = (8-col) * 8 - 1;

  /* Calculate the upper right half of the board by copying the earlier
     calculated upper diagonal value. Eg. diagNEstart[c7] == diag45start[b8] */
  for (row = 1; row < 8; row++)
    for (col = 7; (7-col) + row < 8; col--)
      diagNWstart[row*8 + col] = diagNWstart[(row-1)*8 + col - 1];

  /* Calculate the bottom row. */
  for (col = 6; col >= 0; col--)
    diagNWstart[7*8 + col] = 7*8 + col;

  /* Calculate the bottom left half of the board by copying the earlier
     calculated value that's diagonally below.
     Eg. diagNWstart[d2] == diagNWstart[e1] */
  for (row = 6; row > 0; row--)
    for (col = row - 1; col >= 0; col--)
      diagNWstart[row*8 + col] = diagNWstart[(row+1)*8 + col + 1];
}

void set_attack_knight(bitboard *knight) {
  int rad, kol, i, j;
  int squares[12][12], temp[8][8];

  /* Empty squares and knight. */
  for (rad = 2; rad < 10; rad++)
    for (kol = 2; kol < 10; kol++) {
      knight[(rad-2)*8 + (kol-2)] = 0;
      squares[rad][kol] = 0;
    }

  for (rad = 2; rad < 10; rad++)
    for (kol = 2; kol < 10; kol++) {
      squares[rad-2][kol+1] = 1;
      squares[rad-1][kol+2] = 1;
      squares[rad+1][kol+2] = 1;
      squares[rad+2][kol+1] = 1;
      squares[rad+2][kol-1] = 1;
      squares[rad+1][kol-2] = 1;
      squares[rad-1][kol-2] = 1;
      squares[rad-2][kol-1] = 1;
      for (i = 2; i < 10; i++)
	for (j = 2; j < 10; j++)
	  temp[i-2][j-2] = squares[i][j];
      for (i = 0; i < 8; i++)
	for (j = 0; j < 8; j++)
	  if (temp[i][j])
	    knight[(rad-2)*8 + (kol-2)] = knight[(rad-2)*8+(kol-2)]
	      | square[i*8+j];
      /* Empty squares. */
      for (i = 2; i < 10; i++)
	for (j = 2; j < 10; j++)
	  squares[i][j] = 0;
    }
}

void set_attack_king(bitboard *king) {
  int rad, kol, i, j;
  int squares[12][12], temp[8][8];

  /* Empty squares and knight. */
  for (rad = 2; rad < 10; rad++)
    for (kol = 2; kol < 10; kol++) {
      king[(rad-2)*8 + (kol-2)] = 0;
      squares[rad][kol] = 0;
    }

  for (rad = 2; rad < 10; rad++)
    for (kol = 2; kol < 10; kol++) {
      squares[rad-1][kol+1] = 1;
      squares[rad][kol+1] = 1;
      squares[rad+1][kol+1] = 1;
      squares[rad+1][kol] = 1;
      squares[rad+1][kol-1] = 1;
      squares[rad][kol-1] = 1;
      squares[rad-1][kol-1] = 1;
      squares[rad-1][kol] = 1;
      for (i = 2; i < 10; i++)
	for (j = 2; j < 10; j++)
	  temp[i-2][j-2] = squares[i][j];
      for (i = 0; i < 8; i++)
	for (j = 0; j < 8; j++)
	  if (temp[i][j])
	    king[(rad-2)*8 + (kol-2)] = king[(rad-2)*8+(kol-2)]
	      | square[i*8+j];
      /* Empty squares. */
      for (i = 2; i < 10; i++)
	for (j = 2; j < 10; j++)
	  squares[i][j] = 0;
    }
}

void set_attack_hslider(bitboard hslider[64][256]) {
  int kol, occ, i, file;

  for (kol = 0; kol < 64; kol++) {
    file = kol % 8;
    for (occ = 0; occ < 256; occ++) {
      if (file > 0) {
	for (i = file - 1; i >= 0; i--) {  //go to the left from current file
	  /* In this attack bitboard, the first encountered piece
	     should be capturable. */
	  hslider[kol][occ] = hslider[kol][occ] | square[kol + i - file];
	  if ((1 << i) & occ)     //if we found a piece, then stop
	    break;
	}
      }
      if (file < 7) {
	for (i = file + 1; i < 8; i++) {  //go to the right from current file
	  hslider[kol][occ] = hslider[kol][occ] | square[kol + i - file];
	  if ((1 << i) & occ)     //if we found a piece, then stop
	    break;
	}
      }
    }
  }
}

void set_attack_vslider(bitboard vslider[64][256]) {
  int kol, occ, i, rank;

  for (kol = 0; kol < 64; kol++) {
    //file = kol % 8;
    rank = kol / 8;
    for (occ = 0; occ < 256; occ++) {
      if (rank < 7) {
	for (i = rank + 1; i < 8; i++) {  //go south from the current rank
	  /* In this attack bitboard, the first encountered piece
	     should be capturable. */
	  vslider[kol][occ] = vslider[kol][occ] | square[kol + (i-rank)*8];
	  if ((1 << (7-i)) & occ)     //if we found a piece, then stop
	    break;
	}
      }
      if (rank > 0) {
	for (i = rank - 1; i >= 0; i--) {  //go north from the current piece
	  vslider[kol][occ] = vslider[kol][occ] | square[kol + (i-rank)*8];
	  if ((1 << (7-i)) & occ)
	    break;
	}
      }
    }
  }
}

void set_attack_sliderNE(bitboard sliderNE[64][256]) {
  int kol, occ, file, i, j, rank;

  for (kol = 0; kol < 64; kol++) {
    file = kol % 8;
    rank = kol / 8;
    for (occ = 0; occ < (1 << diagNE_length[kol]); occ++) {
      if (file + rank <= 8) {  //if we are at the upper left half of the board
	if (file > 0) {
	  j = 1;
	  /* Go southwest from the current square until you hit the side. */
	  for (i = file - 1; i >= 0; i--) {
	    /* In this attack bitboard, the first encountered piece should
	       be capturable. */
	    sliderNE[kol][occ] = sliderNE[kol][occ] | square[kol + j*7];
	    j++;
	    if ((1 << i) & occ)  //if we found a piece, then stop
	      break;
	  }
	}
	if (file < diagNE_length[kol]) {
	  j = 1;
	  /* Go northeast from the current square until you hit the side. */
	  for (i = file + 1; i < diagNE_length[kol]; i++) {
	    sliderNE[kol][occ] = sliderNE[kol][occ] | square[kol - j*7];
	    j++;
	    if ((1 << i) & occ)  //if we found a piece, then stop
	      break;
	  }
	}
      } else {     //we are at the lower right half of the board
	if (rank < 7) {
	  /* Go southwest from the current square until you hit the side. */
	  j = rank + 1;   //j indicates which row we're at
	  for (i = file - 1; i >= (diagNE_start[kol] % 8); i--) {
	    sliderNE[kol][occ] = sliderNE[kol][occ] | square[j*8 + i];
	    if ((1 << (7-j)) & occ)   //if we found a piece, then stop
	      break;
	    j++;
	  }
	}
	if (file < 7) {
	  /* Go northeast from the current square until you hit the side. */
	  j = rank - 1;   //j indicates which row we're at
	  for (i = file + 1; i < 8; i++) {
	    sliderNE[kol][occ] = sliderNE[kol][occ] | square[j*8 + i];
	    if ((1 << (7 - j)) & occ)
	      break;
	    j--;
	  }
	}
      }
    }
  }
}

void set_attack_sliderNW(bitboard sliderNW[64][256]) {
  int kol, occ, file, i, j, rank;

  for (kol = 0; kol < 64; kol++) {
    file = kol % 8;
    rank = kol / 8;
    //printf("kol = %d\n",kol);
    for (occ = 0; occ < (1 << diagNW_length[kol]); occ++) {
      //if (kol == 9)
      //printf("occ = %d\n",occ);
      if ((7-file) + rank < 8) {  //if we are at the upper right half of the board
	if (file < 7) {
	  //if (kol == 9)
	  //printf("1\n");
	  j = 1;
	  /* Go southeast from the current square until you hit the side. */
	  for (i = file + 1; i <= 7; i++) {
	    /* In this attack bitboard, the first encountered piece should
	       be capturable. */
	    sliderNW[kol][occ] = sliderNW[kol][occ] | square[kol + j*9];
	    j++;
	    if ((1 << (7-i)) & occ)  //if we found a piece, then stop
	      break;
	  }
	}
	if (rank > 0) {
	  j = 1;
	  /* Go northwest from the current square until you hit the side. */
	  for (i = file - 1; (7-i) < diagNW_length[kol]; i--) {
	    sliderNW[kol][occ] = sliderNW[kol][occ] | square[kol - j*9];
	    j++;
	    if ((1 << (7-i)) & occ)  //if we found a piece, then stop
	      break;
	  }
	}
      } else {     //we are at the lower left half of the board
	if (rank < 7) {
	  /* Go southeast from the current square until you hit the side. */
	  j = rank + 1;   //j indicates which row we're at
	  for (i = file + 1; i <= (diagNW_start[kol] % 8); i++) {
	    sliderNW[kol][occ] = sliderNW[kol][occ] | square[j*8 + i];
	    if ((1 << (7-j)) & occ)   //if we found a piece, then stop
	      break;
	    j++;
	  }
	}
	if (file > 0) {
	  /* Go northwest from the current square until you hit the side. */
	  j = rank - 1;   //j indicates which row we're at
	  for (i = file - 1; i >= 0; i--) {
	    sliderNW[kol][occ] = sliderNW[kol][occ] | square[j*8 + i];
	    if ((1 << (7 - j)) & occ)
	      break;
	    j--;
	  }
	}
      }
    }
  }
}

/* The attack bitboard for the pawns represent the squares to which a
   pawn can attack, and not the squares it can go to without a capture.
   Normally piece color is irrelevant as far as the attack bitboard
   is concerned. The exception is handing of the pawns, where they move
   in opposite directions. */
void set_attack_pawn(bitboard pawn[2][64]) {
  int rad, kol, i, j;
  int wsquares[12][12], bsquares[12][12], wtemp[8][8], btemp[8][8];

  /* Empty squares and knight. */
  for (rad = 2; rad < 10; rad++)
    for (kol = 2; kol < 10; kol++) {
      pawn[WHITE][(rad-2)*8 + (kol-2)] = 0;
      pawn[BLACK][(rad-2)*8 + (kol-2)] = 0;
      wsquares[rad][kol] = 0;
      bsquares[rad][kol] = 0;
    }

  for (rad = 2; rad < 10; rad++)
    for (kol = 2; kol < 10; kol++) {
      wsquares[rad-1][kol-1] = 1;
      wsquares[rad-1][kol+1] = 1;
      bsquares[rad+1][kol-1] = 1;
      bsquares[rad+1][kol+1] = 1;
      for (i = 2; i < 10; i++)
	for (j = 2; j < 10; j++) {
	  wtemp[i-2][j-2] = wsquares[i][j];
	  btemp[i-2][j-2] = bsquares[i][j];
	}
      for (i = 0; i < 8; i++)
	for (j = 0; j < 8; j++) {
	  if (wtemp[i][j])
	    pawn[WHITE][(rad-2)*8 + (kol-2)] = pawn[WHITE][(rad-2)*8+(kol-2)]
	      | square[i*8+j];
	  if (btemp[i][j])
	    pawn[BLACK][(rad-2)*8 + (kol-2)] = pawn[BLACK][(rad-2)*8+(kol-2)]
	      | square[i*8+j];
	}
      /* Empty squares. */
      for (i = 2; i < 10; i++)
	for (j = 2; j < 10; j++) {
	  wsquares[i][j] = 0;
	  bsquares[i][j] = 0;
	}
    }
}

/* Initializes the board to the starting position. */
void set_board(struct board *board) {
  int i;

  board->piece[BLACK][ROOK] = square[0] | square[7];
  board->piece[BLACK][KNIGHT] = square[1] | square[6];
  board->piece[BLACK][BISHOP] = square[2] | square[5];
  board->piece[BLACK][QUEEN] = square[3];
  board->piece[BLACK][KING] = square[4];
  board->piece[BLACK][PAWN] = square[8] | square[9] | square[10]
    | square[11] | square[12] | square[13] | square[14] | square[15];

  board->piece[WHITE][ROOK] = square[56] | square[63];
  board->piece[WHITE][KNIGHT] = square[57] | square[62];
  board->piece[WHITE][BISHOP] = square[58] | square[61];
  board->piece[WHITE][QUEEN] = square[59];
  board->piece[WHITE][KING] = square[60];
  board->piece[WHITE][PAWN] = square[48] | square[49] | square[50]
    | square[51] | square[52] | square[53] | square[54] | square[55];

  board->all_pieces[BLACK] = 0;
  board->all_pieces[WHITE] = 0;
  for (i = 0; i < 16; i++)
    board->all_pieces[BLACK] = board->all_pieces[BLACK] | square[i];
  for (i = 0; i < 16; i++)
    board->all_pieces[WHITE] = board->all_pieces[WHITE] | square[48+i];
  for (i = 0; i < 64; i++)
    board->rot90_pieces[WHITE] = board->rot90_pieces[WHITE]
      | (((board->all_pieces[WHITE] & square[rotate90to0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rot90_pieces[BLACK] = board->rot90_pieces[BLACK]
      | (((board->all_pieces[BLACK] & square[rotate90to0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rotNE_pieces[WHITE] = board->rotNE_pieces[WHITE]
      | (((board->all_pieces[WHITE] & square[rotateNEto0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rotNE_pieces[BLACK] = board->rotNE_pieces[BLACK]
      | (((board->all_pieces[BLACK] & square[rotateNEto0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rotNW_pieces[WHITE] = board->rotNW_pieces[WHITE]
      | (((board->all_pieces[WHITE] & square[rotateNWto0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rotNW_pieces[BLACK] = board->rotNW_pieces[BLACK]
      | (((board->all_pieces[BLACK] & square[rotateNWto0[i]]) != 0)
	 * square[i]);
  board->status[WHITE] = SHORT_CASTLING_OK | LONG_CASTLING_OK;
  board->status[BLACK] = SHORT_CASTLING_OK | LONG_CASTLING_OK;
}

/* Initializes the board to the starting position. */
void set_testboard(struct board *board) {
  int i;

  board->piece[BLACK][ROOK] = square[7] | square[58];
  board->piece[BLACK][KNIGHT] = square[6];
  board->piece[BLACK][BISHOP] = square[5];
  board->piece[BLACK][QUEEN] = square[13];
  board->piece[BLACK][KING] = square[4];
  board->piece[BLACK][PAWN] = square[14] | square[23] | square[25]
    | square[34];

  board->piece[WHITE][ROOK] = 0;
  board->piece[WHITE][KNIGHT] = 0;
  board->piece[WHITE][BISHOP] = square[28] | square[31];
  board->piece[WHITE][QUEEN] = square[45];
  board->piece[WHITE][KING] = square[55];
  board->piece[WHITE][PAWN] = square[40] | square[33] | square[53]
    | square[54] | square[47];

  board->all_pieces[BLACK] = 0;
  board->all_pieces[WHITE] = 0;
  for (i = 0; i < 6; i++)
    board->all_pieces[BLACK] = board->all_pieces[BLACK] | board->piece[BLACK][i];
  for (i = 0; i < 6; i++)
    board->all_pieces[WHITE] = board->all_pieces[WHITE] | board->piece[WHITE][i];
  for (i = 0; i < 64; i++)
    board->rot90_pieces[WHITE] = board->rot90_pieces[WHITE]
      | (((board->all_pieces[WHITE] & square[rotate90to0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rot90_pieces[BLACK] = board->rot90_pieces[BLACK]
      | (((board->all_pieces[BLACK] & square[rotate90to0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rotNE_pieces[WHITE] = board->rotNE_pieces[WHITE]
      | (((board->all_pieces[WHITE] & square[rotateNEto0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rotNE_pieces[BLACK] = board->rotNE_pieces[BLACK]
      | (((board->all_pieces[BLACK] & square[rotateNEto0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rotNW_pieces[WHITE] = board->rotNW_pieces[WHITE]
      | (((board->all_pieces[WHITE] & square[rotateNWto0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rotNW_pieces[BLACK] = board->rotNW_pieces[BLACK]
      | (((board->all_pieces[BLACK] & square[rotateNWto0[i]]) != 0)
	 * square[i]);
  board->status[WHITE] = CASTLED;
  board->status[BLACK] = 0;
}

/* Initializes the board to the starting position. */
void set_testboard2(struct board *board) {
  int i;

  board->piece[BLACK][ROOK] = square[1] | square[7];
  board->piece[BLACK][KNIGHT] = square[16] | square[6];
  board->piece[BLACK][BISHOP] = square[5] | square[38];
  board->piece[BLACK][QUEEN] = square[3];
  board->piece[BLACK][KING] = square[4];
  board->piece[BLACK][PAWN] = square[8] | square[10] | square[12]
    | square[13] | square[14] | square[17] | square[19] | square[31];

  board->piece[WHITE][ROOK] = square[56] | square[63];
  board->piece[WHITE][KNIGHT] = square[57] | square[62];
  board->piece[WHITE][BISHOP] = square[58] | square[61];
  board->piece[WHITE][QUEEN] = square[59];
  board->piece[WHITE][KING] = square[60];
  board->piece[WHITE][PAWN] = square[40] | square[33] | square[34]
    | square[27] | square[36] | square[53] | square[54] | square[55];

  board->all_pieces[BLACK] = 0;
  board->all_pieces[WHITE] = 0;
  for (i = 0; i < 6; i++)
    board->all_pieces[BLACK] = board->all_pieces[BLACK] | board->piece[BLACK][i];
  for (i = 0; i < 6; i++)
    board->all_pieces[WHITE] = board->all_pieces[WHITE] | board->piece[WHITE][i];
  for (i = 0; i < 64; i++)
    board->rot90_pieces[WHITE] = board->rot90_pieces[WHITE]
      | (((board->all_pieces[WHITE] & square[rotate90to0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rot90_pieces[BLACK] = board->rot90_pieces[BLACK]
      | (((board->all_pieces[BLACK] & square[rotate90to0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rotNE_pieces[WHITE] = board->rotNE_pieces[WHITE]
      | (((board->all_pieces[WHITE] & square[rotateNEto0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rotNE_pieces[BLACK] = board->rotNE_pieces[BLACK]
      | (((board->all_pieces[BLACK] & square[rotateNEto0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rotNW_pieces[WHITE] = board->rotNW_pieces[WHITE]
      | (((board->all_pieces[WHITE] & square[rotateNWto0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rotNW_pieces[BLACK] = board->rotNW_pieces[BLACK]
      | (((board->all_pieces[BLACK] & square[rotateNWto0[i]]) != 0)
	 * square[i]);
  board->status[WHITE] = LONG_CASTLING_OK | SHORT_CASTLING_OK;
  board->status[BLACK] = LONG_CASTLING_OK | SHORT_CASTLING_OK;
}

/* Initializes the board to the starting position. */
void set_testboard3(struct board *board) {
  int i;

  board->piece[BLACK][ROOK] = square[0] | square[7];
  board->piece[BLACK][KNIGHT] = square[6];
  board->piece[BLACK][BISHOP] = square[2];
  board->piece[BLACK][QUEEN] = square[1];
  board->piece[BLACK][KING] = square[10];
  board->piece[BLACK][PAWN] = square[8] | square[9] | square[11]
    | square[12] | square[14] | square[23];

  board->piece[WHITE][ROOK] = square[56] | square[63];
  board->piece[WHITE][KNIGHT] = square[57] | square[30];
  board->piece[WHITE][BISHOP] = square[58] | square[61];
  board->piece[WHITE][QUEEN] = square[5];
  board->piece[WHITE][KING] = square[60];
  board->piece[WHITE][PAWN] = square[26] | square[33] | square[48]
    | square[53] | square[54] | square[55];

  board->all_pieces[BLACK] = 0;
  board->all_pieces[WHITE] = 0;
  for (i = 0; i < 6; i++)
    board->all_pieces[BLACK] = board->all_pieces[BLACK] | board->piece[BLACK][i];
  for (i = 0; i < 6; i++)
    board->all_pieces[WHITE] = board->all_pieces[WHITE] | board->piece[WHITE][i];
  for (i = 0; i < 64; i++)
    board->rot90_pieces[WHITE] = board->rot90_pieces[WHITE]
      | (((board->all_pieces[WHITE] & square[rotate90to0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rot90_pieces[BLACK] = board->rot90_pieces[BLACK]
      | (((board->all_pieces[BLACK] & square[rotate90to0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rotNE_pieces[WHITE] = board->rotNE_pieces[WHITE]
      | (((board->all_pieces[WHITE] & square[rotateNEto0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rotNE_pieces[BLACK] = board->rotNE_pieces[BLACK]
      | (((board->all_pieces[BLACK] & square[rotateNEto0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rotNW_pieces[WHITE] = board->rotNW_pieces[WHITE]
      | (((board->all_pieces[WHITE] & square[rotateNWto0[i]]) != 0)
	 * square[i]);
  for (i = 0; i < 64; i++)
    board->rotNW_pieces[BLACK] = board->rotNW_pieces[BLACK]
      | (((board->all_pieces[BLACK] & square[rotateNWto0[i]]) != 0)
	 * square[i]);
  board->status[WHITE] = LONG_CASTLING_OK | SHORT_CASTLING_OK;
  board->status[BLACK] = LONG_CASTLING_OK | SHORT_CASTLING_OK;
}

/*int rakna(unsigned long long int b) {
  b = (b & 0x5555555555555555LU) + (b >> 1 & 0x5555555555555555LU);
  b = (b & 0x3333333333333333LU) + (b >> 2 & 0x3333333333333333LU);
  b = b + (b >> 4) & 0x0F0F0F0F0F0F0F0FLU;
  b = b + (b >> 8);
  b = b + (b >> 16);
  b = b + (b >> 32) & 0x0000007F;
  return (int) b;
  }*/

int iterated_bitcount(int64 n) {
  int count = 0;

  while (n) {
    count += n & 0x1;
    n >>= 1;
  }
  return count;
}

void set_bits_in_16bits(int *arr) {
  int i;

  for (i = 0; i < 65536; i++) {
    arr[i] = iterated_bitcount(i);
  }
}

void set_first_bit_in_16bits(int *arr) {
  int i;

  for (i = 0; i < 65536; i++) {
    arr[i] = fbit(i);
  }
}

/*void set_last_bit_in_16bits(int *arr) {
  int i;

  for (i = 0; i < 65536; i++) {
    arr[i] = lbit((int64)i);
  }
  }*/

/*int set_bits_in_8bits(int *arr) {
  int i;

  for (i = 0; i < 256; i++) {
    arr[i] = iterated_bitcount(i);
  }
  }*/

/* This function returns the number of bits that are set in an int64. */
int bitcount(int64 n) {
  return bits_in_16bits[n & 0xffff]
    + bits_in_16bits[(n >> 16) & 0xffff]
    + bits_in_16bits[(n >> 32) & 0xffff]
    + bits_in_16bits[(n >> 48) & 0xffff];
}

/* This function returns the number of the first set bit in an int64.
   The search is done from LSB to MSB. */
int get_first_bitpos(int64 n) {
  if (first_bit_in_16bits[n & 0xffff] >= 0)
    return first_bit_in_16bits[n & 0xffff];
  if (first_bit_in_16bits[(n >> 16) & 0xffff] >= 0)
    return first_bit_in_16bits[(n >> 16) & 0xffff] + 16;
  if (first_bit_in_16bits[(n >> 32) & 0xffff] >= 0)
    return first_bit_in_16bits[(n >> 32) & 0xffff] + 32;
  if (first_bit_in_16bits[(n >> 48) & 0xffff] >= 0)
    return first_bit_in_16bits[(n >> 48) & 0xffff] + 48;

  return -1;
}

/* This function returns the number of the first set bit in an int64.
   The search is done from MSB to LSB. */
/*int get_last_bitpos(int64 n) {
  if (last_bit_in_16bits[(n >> 48) & 0xffff] >= 0)
    return last_bit_in_16bits[(n >> 48) & 0xffff] + 48;
  if (last_bit_in_16bits[(n >> 32) & 0xffff] >= 0)
    return last_bit_in_16bits[(n >> 32) & 0xffff] + 32;
  if (last_bit_in_16bits[(n >> 16) & 0xffff] >= 0)
    return last_bit_in_16bits[(n >> 16) & 0xffff] + 16;
  if (last_bit_in_16bits[n & 0xffff] >= 0)
    return last_bit_in_16bits[n & 0xffff];

  return -1;
  }*/

/* This function returns the number of the first set bit in an int64.
   The search is done from LSB to MSB. */
/*int get_first_bitposMSB(int64 n) {
  if (first_bit_in_16bits[(n >> 48) & 0xffff] >= 0)
    return first_bit_in_16bits[(n >> 48) & 0xffff] + 48;
  if (first_bit_in_16bits[(n >> 32) & 0xffff] >= 0)
    return first_bit_in_16bits[(n >> 32) & 0xffff] + 32;
  if (first_bit_in_16bits[(n >> 16) & 0xffff] >= 0)
    return first_bit_in_16bits[(n >> 16) & 0xffff] + 16;
  if (first_bit_in_16bits[n & 0xffff] >= 0)
    return first_bit_in_16bits[n & 0xffff];

  return -1;
  }*/

/*int bitcount8bits(int64 n) {
  return bits_in_8bits[n & 0xffff]
    + bits_in_8bits[(n >> 8) & 0xffff]
    + bits_in_8bits[(n >> 16) & 0xffff]
    + bits_in_8bits[(n >> 24) & 0xffff]
    + bits_in_8bits[(n >> 32) & 0xffff]
    + bits_in_8bits[(n >> 40) & 0xffff]
    + bits_in_8bits[(n >> 48) & 0xffff]
    + bits_in_8bits[(n >> 56) & 0xffff];
    }*/

/*int64 getlsb(int64 b) {
  return b & ((~b)+1);
  }*/

void set_bitboards() {
  int i;
  bitboard teazza, teazza2;
  int temp, occ;

  set_square(square);
  set_lower(lower);
  set_higher(higher);
  set_bits_in_16bits(bits_in_16bits);
  set_first_bit_in_16bits(first_bit_in_16bits);
  //set_last_bit_in_16bits(last_bit_in_16bits);
  set_col_bitboard(col_bitboard);
  set_rotate90to0(rotate90to0);
  set_rotate0to90(rotate0to90);
  set_rotate0toNE(rotate0toNE);
  set_rotateNEto0(rotateNEto0);
  set_rotate0toNW(rotate0toNW);
  set_rotateNWto0(rotateNWto0);
  set_ones(ones);
  set_pieceval(pieceval);
  set_pawn_start(pawn_start);
  set_pawn_lastrow(pawn_lastrow);
  set_pawn_passantrow(pawn_passantrow);
  set_diagNE_length(diagNE_length);
  set_diagNE_start(diagNE_start);
  set_diagNW_length(diagNW_length);
  set_diagNW_start(diagNW_start);
  set_attack_knight(attack.knight);
  set_attack_king(attack.king);
  set_attack_hslider(attack.hslider);
  set_attack_vslider(attack.vslider);
  set_attack_sliderNE(attack.sliderNE);
  set_attack_sliderNW(attack.sliderNW);
  set_attack_pawn(attack.pawn);
  board = (struct board *) malloc(1*sizeof(struct board));
  set_board(board);
  //set_testboard(board);
  //set_testboard2(board);
  //set_testboard3(board);
  //printf("diagNWstart[4] = %d\n",diagNW_start[4]);
  /*for (i = 0; i < 10000000; i++)
    //teazza2 = square[get_first_bitpos(teazza)];
    teazza2 = getlsb(teazza);
    exit(0);*/
  //teazza = square[1] | square[5] | square[40] | square[61];
  /*teazza = 0;
  for (i = 0; i < 30; i++)
  teazza = teazza | square[i];*/
  //printf("bitcount(teazza) = %d\n",bitcount(teazza));
  /*for (i = 0; i < 100000000; i++)
    temp = bitcount(teazza);
    //temp = iterated_bitcount(teazza);
    //temp = rakna(teazza);
    exit(0);*/
  /*printf("iterated_bitcount(teazza) = %d\n",rakna(teazza));
  printf("iterated_bitcount(65535) = %d\n",iterated_bitcount(65535));
  printf("rakna(65535) = %d\n",rakna(65535));
  printf("bits_in_16bits[65535] = %d\n",bits_in_16bits[65535]);*/
  //temp = (1 << 8) | (1 << 14);
  //printf("bits_in_16bits[temp] = %d\n",bits_in_16bits[temp]);
  //printf("first_bit_in_16bits[temp] = %d\n",first_bit_in_16bits[temp]);
  //printf("first_bit_in_48to63bits[temp] = %d\n",first_bit_in_48to63bits[temp]);
  //teazza = square[0];
  /*printf("fbit(teazza) = %d\n",fbit(teazza));
  printf("lbit(teazza) = %d\n",lbit(teazza));
  printf("lbit((int64) 0) = %d\n",lbit((int64)0));
  printf("lbit((int64)1) = %d\n",lbit((int64)1));
  printf("lbit((int64)2) = %d\n",lbit((int64)2));
  printf("lbit((int64)3) = %d\n",lbit((int64)3));
  printf("lbit((int64)4) = %d\n",lbit((int64)4));
  printf("lbit((int64)5) = %d\n",lbit((int64)5));
  printf("lbit((int64)6) = %d\n",lbit((int64)6));
  printf("lbit((int64)7) = %d\n",lbit((int64)7));
  printf("lbit(7) = %d\n",lbit(7));
  printf("get_first_bitpos(teazza) = %d\n",get_first_bitpos(teazza));
  printf("get_last_bitpos(teazza) = %d\n",get_last_bitpos(teazza));
  temp = (1 << 0);
  for (i = 0; i < 8; i++) {
    last_bit_in_16bits[i] = lbit((int64)i);
    printf("i, = %d, last_bit_in_16bits[i] = %d, lbit(i) = %d\n",i,last_bit_in_16bits[i],lbit(i));
  }
  printf("last_bit_in_16bits[temp] = %d\n",last_bit_in_16bits[temp]);
  exit(0);*/
  /*teazza = square[5];
  for (i = 0; i < 10000000; i++)
    //temp = fbit(teazza);
    temp = get_first_bitpos(teazza);
    //temp = get_last_bitpos(teazza);
  printf("temp = %d\n",temp);
  exit(0);*/
  /*for (i = 63; i >= 0; i--) {
    if (attack.vslider[9][occ] & square[i])
      printf("1");
    else
      printf("0");
  }
  printf("\n");*/
  /*occ = 2 | 16 | 128;
  for (i = 0; i < 64; i++) {
    if (attack.vslider[27][occ] & square[i])
      printf("1");
    else
      printf("0");
    if (i == 55 || i == 47 || i == 39 || i == 31 || i == 23 || i == 15 || i == 7)
      printf("\n");
  }
  printf("\n");*/
}

/* This function returns the position of the first bit that is set.
   We search from LSB to MSB. -1 is returned if no bit is set. */
int fbit(int64 bitpattern) {
  int i;
  int low = 0, high = 63, middle = 31;

  /* A one can always be found in at most 6 iterations. We need one
     more than that though, when the most significant bit is set. */
  for (i = 0; i < 7; i++) {
    if (lower[middle] & bitpattern) {        //exists below middle
      high = middle - 1;
      middle = (low + high)/2;
    } else if (square[middle] & bitpattern)  //exists in the midde
      return middle;
    else {
      low = middle + 1;
      middle = (low + high)/2;
    }
  }
  return -1;   //no bit set in the bitpattern
}

/* This function returns the position of the first bit that is set.
   We search from MSB to LSB. -1 is returned if no bit is set. */
/*int lbit(int64 bitpattern) {
  int i;
  int low = 0, high = 63, middle = 31;

  /* A one can always be found in at most 6 iterations. We need one
     more than that though, when the most significant bit is set. /
  for (i = 0; i < 7; i++) {
    if (higher[middle] & bitpattern) {        //exists above middle
      low = middle + 1;
      middle = (low + high)/2;
    } else if (square[middle] & bitpattern)  //exists in the midde
      return middle;
    else {
      high = middle - 1;
      middle = (low + high)/2;
    }
  }
  return -1;   //no bit set in the bitpattern
}*/














