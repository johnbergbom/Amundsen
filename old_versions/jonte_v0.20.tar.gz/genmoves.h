#ifndef _GENMOVES_
#define _GENMOVES_

//#include "diverse.h"
#include "bitboards.h"

/* The prune types make it easy to generate certain types of moves. The way
   we use them is to first generate all possible moves for a certain piece,
   and put all the targets in a bitboard. Then we prune those targets by
   calling the function get_pruned_targets with the prunetype that we want.
   Notice that passant moves are not included in the CAPTURE_PRUNETYPE. That
   is because passant captures toward an empty square, and therefore cannot
   be included as a CAPTURE_PRUNETYPE with a simple AND with the opponents
   pieces. This could be fixed, but the increased complexity will probably
   make the program run slower rather than faster. */
#define KILLER_CAPTURE_PRUNETYPE 0
#define KILLER_NONCAPTURE_PRUNETYPE 1
#define NONKILLER_CAPTURE_PRUNETYPE 2
#define NONKILLER_NONCAPTURE_PRUNETYPE 3
#define NBR_PRUNETYPES 4

/* Denna funktion reallokerar en listas storlek i minnet. */
//int change_list_size(struct move **list, int new_size);

//int generate_pawnmoves(struct board *board, int color, struct move **movelist, int *listsize, int *mcount, int hpos, int boardpos);

int in_check(struct board *board, int color);

bitboard get_pruned_targets(bitboard targets, int prunetype, bitboard killers, struct board *board, int color);

//int generate_moves(struct board *board, int color, struct move **movelist, int *mcount, int hpos, int movetype, struct move *killermove);
bitboard generate_moves(struct board *board, int color, int hpos, int piecetype, int boardpos);

#endif      //_GENMOVES_

