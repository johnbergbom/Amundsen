#include "alfabeta.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include "moves.h"
#include "genmoves.h"
#include "eval.h"
#include "slump.h"

extern int xboard_mode;
int lagge = 0;
int lagge_int = 0;

/* killers keep track of the moves that cause a cutoff at each level
   of the search. The killer move implementation is very simple, namely
   every time a cutoff has occurred at a certain node, the killer bitboard
   for the particular depth is OR:ed with the target square. */
bitboard *killers;

/* For move generation we use the moves struct. The source represents the
   square that a piece will move from. The targets represent all the
   squares the piece can move to. Piece tells what kind of piece we are
   dealing with. */
struct moves {
  bitboard source;
  bitboard targets;
  int piece;
};


int max(int a, int b) {
  if (a > b)
    return a;
  else
    return b;
}

int min(int a, int b) {
  if (a > b)
    return b;
  else
    return a;
}

int quiescence(struct board *board, int vemstur, int org_color, int nodetype, int alpha, int beta, bitboard tsquare, int hpos) {
  struct board newpos;
  int retval;
  int q_val;
  int piece_nbr = 0;
  extern struct move **historik;
  int oppcolor = vemstur;
  int piecetype;
  bitboard pieces, typetargets, target;
  int boardpos, movables = 0;
  struct moves moves[16];
  extern bitboard square[64];
  struct move move;

  switch_colors(&vemstur);

  /* Generate all (pseudo)legal moves for this position, and return
     KINGTAKEN if the opposite king can be taken. Start by going through
     all the piece types. */
  for (piecetype = 0; piecetype < 6; piecetype++) {
    pieces = board->piece[vemstur][piecetype];
    /* Go through all the pieces for the given piece type. */
    while (pieces != 0) {
      boardpos = get_first_bitpos(pieces);
      moves[movables].targets = generate_moves(board,vemstur,hpos,
					       piecetype,boardpos);
      if (moves[movables].targets & board->piece[oppcolor][KING])
	return KINGTAKEN;
      /* Only add this piece if it can go somewhere. */
      if (moves[movables].targets != 0) {
	moves[movables].source = square[boardpos];
	moves[movables].piece = piecetype;
	movables++;
      }
      pieces = pieces & ~square[boardpos];
    }
  }

  if (nodetype == MAX) {
    retval = -INFTY;
    piece_nbr = 0;
    /* Go through all movable pieces. */
    while (piece_nbr < movables) {
      typetargets = moves[piece_nbr].targets & tsquare; //only moves to tsquare
      while (typetargets != 0) {
	target = getlsb(typetargets);
	move.fsquare = moves[piece_nbr].source;
	move.tsquare = target;
	move.piece = moves[piece_nbr].piece;
	move.type = get_movetype(board,vemstur,get_first_bitpos(moves[piece_nbr].source),moves[piece_nbr].piece,target);
	makemove(board,&newpos,vemstur,move);
	(*historik)[hpos] = move;
	q_val = quiescence(&newpos,vemstur,org_color,MIN,alpha,beta,tsquare,hpos+1);
	if (q_val != KINGTAKEN) {
	  retval = max(retval,q_val);
	  alpha = max(alpha,retval);
	  if (retval >= beta)
	    return retval;
	}
	typetargets = typetargets & ~target;
      }
      piece_nbr++;
    }
  } else {   //nodetype == MIN
    retval = INFTY;
    piece_nbr = 0;
    /* Go through all movable pieces. */
    while (piece_nbr < movables) {
      typetargets = moves[piece_nbr].targets & tsquare; //only moves to tsquare
      while (typetargets != 0) {
	target = getlsb(typetargets);
	move.fsquare = moves[piece_nbr].source;
	move.tsquare = target;
	move.piece = moves[piece_nbr].piece;
	move.type = get_movetype(board,vemstur,get_first_bitpos(moves[piece_nbr].source),moves[piece_nbr].piece,target);
	makemove(board,&newpos,vemstur,move);
	(*historik)[hpos] = move;

	q_val = quiescence(&newpos,vemstur,org_color,MAX,alpha,beta,tsquare,hpos+1);
	if (q_val != KINGTAKEN) {
	  retval = min(retval,q_val);
	  beta = min(beta,retval);
	  if (retval <= alpha)
	    return retval;
	}
	typetargets = typetargets & ~target;
      }
      piece_nbr++;
    }
  }

  /* We get here if no quiescence moves are found, i.e. no moves to the
     destination tsquare. That is, at the end of the series of captures. */
  return eval(&org_color,board);
}

int alphabeta(struct board *board, int vemstur, int org_color, int nodetype, int alpha, int beta, int depth, int hpos) {
  struct board newpos;
  int retval;
  int a_val;
  int piece_nbr = 0;
  int oppcolor = vemstur;
  extern struct move **historik;
  int opp_piece;
  extern int pieceval[6];
  int prunetype = 0;
  struct moves moves[16];
  int movables = 0;
  int piecetype = 0;
  bitboard pieces, typetargets, target;
  int boardpos;
  extern bitboard square[64];
  struct move move;
  int temp;

  switch_colors(&vemstur);
  if (depth == 0) {
    return eval(&org_color,board);
  } else {
    /* First generate all (pseudo)legal moves for this position, and return
       KINGTAKEN if the opposite king can be taken. */
    for (piecetype = 0; piecetype < 6; piecetype++) {
      pieces = board->piece[vemstur][piecetype];
      /* Go through all the pieces for the given piece type. */
      while (pieces != 0) {
	boardpos = get_first_bitpos(pieces);
	moves[movables].targets = generate_moves(board,vemstur,hpos,
						 piecetype,boardpos);
	if (moves[movables].targets & board->piece[oppcolor][KING])
	  return KINGTAKEN;
	/* Only add this piece if it can go somewhere. */
	if (moves[movables].targets != 0) {
	  moves[movables].source = square[boardpos];
	  moves[movables].piece = piecetype;
	  movables++;
	}
	pieces = pieces & ~square[boardpos];
      }
    }

    if (nodetype == MAX) {
      retval = -INFTY;
      /* Go through the different prunetypes. The prunetypes make sure the moves
         are tried in a (pretty) good order. See genmoves.h */
      while (prunetype < NBR_PRUNETYPES) {
	piece_nbr = 0;
	/* Go through all movable pieces. */
	while (piece_nbr < movables) {
	  /* Prune the targets to get a good move ordering. */
	  typetargets = get_pruned_targets(moves[piece_nbr].targets,prunetype,
					   killers[depth],board,vemstur);
	  /* Go through the targets one at a time. */
	  while (typetargets != 0) {
	    target = getlsb(typetargets);
	    move.fsquare = moves[piece_nbr].source;
	    move.tsquare = target;
	    move.piece = moves[piece_nbr].piece;
	    move.type = get_movetype(board,vemstur,
				     get_first_bitpos(moves[piece_nbr].source),
				     moves[piece_nbr].piece,target);
	    makemove(board,&newpos,vemstur,move);
	    (*historik)[hpos] = move;

	    /* If this move is the last one in the search, and the move is a
	       capture, then quiescence search should be done, otherwise we
	       do alphabeta. */
	    if ((depth-1 == 0) && (move.type & CAPTURE_MOVE)) {
	      /* If move is a capture, then figure out what piece it's taking. */
	      if (move.type & PASSANT_MOVE)
		opp_piece = PAWN;
	      else
		for (opp_piece = 0; opp_piece < 6; opp_piece++) {
		  if (board->piece[oppcolor][opp_piece] & move.tsquare)
		    break;
		}
	      /* If a lower valued piece takes a better one, we don't care about
		 quiescence search. */
	      if (pieceval[opp_piece] > pieceval[move.piece])
		a_val = alphabeta(&newpos,vemstur,org_color,MIN,alpha,beta,
				  depth-1,hpos+1);
	      else
		a_val = quiescence(&newpos,vemstur,org_color,MIN,alpha,beta,
				   move.tsquare,hpos+1);
	    } else
	      a_val = alphabeta(&newpos,vemstur,org_color,MIN,alpha,beta,
				depth-1,hpos+1);
	    if (a_val != KINGTAKEN) {
	      retval = max(retval,a_val);
	      alpha = max(alpha,retval);
	      if (retval >= beta) {
		/* Here we got a cutoff, so we'll add this move as a killer. */
		killers[depth] = killers[depth] | move.tsquare;
		return retval;
	      }
	    }
	    typetargets = typetargets & ~target;
	  }
	  piece_nbr++;
	}
	prunetype++;
      }
    } else {   //nodetype == MIN
      retval = INFTY;
      /* Go through the different prunetypes. The prunetypes make sure the moves
	 are tried in a (pretty) good order. See genmoves.h */
      while (prunetype < NBR_PRUNETYPES) {
	piece_nbr = 0;
        /* Go through all movable pieces. */
        while (piece_nbr < movables) {
          /* Prune the targets to get a good move ordering. */
          typetargets = get_pruned_targets(moves[piece_nbr].targets,prunetype,
					   killers[depth],board,vemstur);
          /* Go through the targets one at a time. */
          while (typetargets != 0) {
            target = getlsb(typetargets);
            move.fsquare = moves[piece_nbr].source;
            move.tsquare = target;
            move.piece = moves[piece_nbr].piece;
	    move.type = get_movetype(board,vemstur,
				     get_first_bitpos(moves[piece_nbr].source),
				     moves[piece_nbr].piece,target);
            makemove(board,&newpos,vemstur,move);
            (*historik)[hpos] = move;

            /* If this move is the last one in the search, and the move is a
               capture, then quiescence search should be done, otherwise we
	       do alphabeta. */
	    if ((depth-1 == 0) && (move.type & CAPTURE_MOVE)) {
	      /* If move is a capture, then figure out what piece it's taking. */
	      if (move.type & PASSANT_MOVE)
		opp_piece = PAWN;
	      else
		for (opp_piece = 0; opp_piece < 6; opp_piece++) {
		  if (board->piece[oppcolor][opp_piece] & move.tsquare)
		    break;
		}
	      /* If a lower valued piece takes a better one, we don't care about
		 quiescence search. */
	      if (pieceval[opp_piece] > pieceval[move.piece])
		a_val = alphabeta(&newpos,vemstur,org_color,MAX,alpha,beta,
				  depth-1,hpos+1);
	      else
		a_val = quiescence(&newpos,vemstur,org_color,MAX,alpha,beta,
				   move.tsquare,hpos+1);
	    } else
	      a_val = alphabeta(&newpos,vemstur,org_color,MAX,alpha,beta,
				depth-1,hpos+1);

	    if (a_val != KINGTAKEN) {
	      retval = min(retval,a_val);
	      beta = min(beta,retval);
	      if (retval <= alpha) {
                /* Here we got a cutoff, so we'll add this move as a killer. */
		killers[depth] = killers[depth] | move.tsquare;
		return retval;
	      }
	    }
	    typetargets = typetargets & ~target;
	  }
	  piece_nbr++;
	}
	prunetype++;
      }
    }
  }
  return retval;
}

struct move thinkalphabeta(struct board *board, int vemstur, int depth, int hpos) {
  struct move *movelist;
  struct move *bestmove;
  struct move *validmoves;
  struct board newpos;
  int mcount = 0;
  int bestvalue, b;
  struct move returnmove;
  int alpha = -INFTY, beta = INFTY;
  int org_color = vemstur;
  int piece_nbr = 0, i, j = 0;
  char *dragstr;
  extern struct move **historik;
  int prunetype;
  int nbr_moves = 0;
  int piecetype, boardpos, movables = 0;
  bitboard pieces, typetargets, target;
  struct moves moves[16];
  int oppcolor = vemstur;
  extern bitboard square[64];

  switch_colors(&oppcolor);

  /* First generate all (pseudo)legal moves for this position, and return
     KINGTAKEN if the opposite king can be taken. */
  for (piecetype = 0; piecetype < 6; piecetype++) {
    pieces = board->piece[vemstur][piecetype];
    /* Go through all the pieces for the given piece type. */
    while (pieces != 0) {
      boardpos = get_first_bitpos(pieces);
      moves[movables].targets = generate_moves(board,vemstur,hpos,
					       piecetype,boardpos);
      /* A board position should be in a legal state upon calling this
	 function, so we shoud never be abe to take the opponents king. */
      if (moves[movables].targets & board->piece[oppcolor][KING]) {
	debuglog("ERROR IN THE PROGRAM!!! ILLEGAL MOVES SHOULD NOT BE FOUND HERE!");
	printf("ERROR IN THE PROGRAM!!! ILLEGAL MOVES SHOULD NOT BE FOUND HERE!\n");
	exit(1);
      }
      /* Only add this piece if it can go somewhere. */
      if (moves[movables].targets != 0) {
	moves[movables].source = square[boardpos];
	moves[movables].piece = piecetype;
	movables++;
      }
      pieces = pieces & ~square[boardpos];
    }
  }

  /* Count the number of possible moves, so we know how to initialize
     the movelist. */
  for (i = 0; i < movables; i++)
    nbr_moves += bitcount(moves[i].targets);
  movelist = (struct move *) malloc(nbr_moves*sizeof(struct move));

  /* We reserve space for killers up to ply == depth, and that's allright,
     because we don't use killer moves in the quiescence search. */
  killers = (bitboard *) malloc(depth*sizeof(bitboard));
  for (i = 0; i < depth; i++)    //clear the killer moves
    killers[i] = 0;

  /* Go through the different prunetypes. The prunetypes make sure the moves
     are tried in a (pretty) good order. See genmoves.h */
  for (prunetype = 0; prunetype < NBR_PRUNETYPES; prunetype++) {
    /* Go through all movable pieces. */
    for (piece_nbr = 0; piece_nbr < movables; piece_nbr++) {
      /* Here we set the killer moves to zero, because we don't use killer
         moves at the top level of alpha beta search. */
      typetargets = get_pruned_targets(moves[piece_nbr].targets,prunetype,
				       0,board,vemstur);
      /* Go through the targets one at a time. */
      while (typetargets != 0) {
	target = getlsb(typetargets);
	movelist[mcount].fsquare = moves[piece_nbr].source;
	movelist[mcount].tsquare = target;
	movelist[mcount].piece = moves[piece_nbr].piece;
	movelist[mcount].type = get_movetype(board,vemstur,get_first_bitpos(moves[piece_nbr].source),moves[piece_nbr].piece,target);

	/* Test code for printing out the moves the engine is processing. */
	dragstr = (char *) malloc(20*sizeof(char));
	move2str(board,vemstur,movelist[mcount],dragstr);
	//fprintf(stderr,"move %s",dragstr);
	free(dragstr);

	makemove(board,&newpos,vemstur,movelist[mcount]);
	(*historik)[hpos] = movelist[mcount];
	movelist[mcount].value = alphabeta(&newpos,vemstur,org_color,MIN,alpha,beta,depth-1,hpos+1);

	/* Clear the killer moves so they don't get too clogged up with
	   stale killers. */
	for (i = 0; i < depth; i++)
	  killers[i] = 0;
	mcount++;
	typetargets = typetargets & ~target;
      }
    }
  }

  /* Remove all invalid moves from the list. (The invalid ones have
     value == KINGTAKEN, those are the moves that checks one's own king) */
  validmoves = (struct move *) malloc(mcount * sizeof(struct move));
  for (i = 0; i < mcount; i++)
    if (movelist[i].value != KINGTAKEN)
      validmoves[j++] = movelist[i];
  mcount = j;

  if (mcount > 0) {
    /* Put the best moves in the array bestmove, and chose a random best move.
       (Provided there are several moves which are equally good.) */
    bestmove = (struct move *) malloc(mcount * sizeof(struct move));
    bestvalue = validmoves[0].value;
    b = 0;
    for (i = 0; i < mcount; i++) {
      if (validmoves[i].value >= bestvalue) {
	if (validmoves[i].value > bestvalue)
	  b = 0;
	bestvalue = validmoves[i].value;
	bestmove[b++] = validmoves[i];
      }
    }
    returnmove = bestmove[get_random_number(b-1)];
    free(bestmove);
  } else
    returnmove = movelist[0];

  if (!xboard_mode)
    printf("Value = %d\n",returnmove.value);

  free(killers);
  free(movelist);
  free(validmoves);

  return returnmove;
}















