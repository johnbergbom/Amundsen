#ifndef _SLUMP_
#define _SLUMP_

/* Denna funktion initierar ett fr� f�r slumptalsgenerering. Fr�et tas fr�n
   systemklockan. */
void init_random_seed();

/* Denna funktion returnerar ett tal som ligger mellan noll och high. */
int get_random_number(int high);

#endif      //_SLUMP_
