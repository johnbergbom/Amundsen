#include "timectrl.h"
#if GETTIME == GETTIMEOFDAY
#ifndef _MSC_VER
  #include <sys/time.h>
  #include <unistd.h>
#else
  #include "timeoday.c"
#endif
#else
  #include <sys/timeb.h>
#endif
#include "misc.h"
#include "parse.h"
#include <stdio.h>

/* own_time and opp_time measure the clocks of the engine and the opponent
   respectively, measured in milliseconds. */
int own_time;
int opp_time;
int own_checkpoint_time;
int opp_checkpoint_time;
int new_level_checkpoint;

/* Default timectrl is TIMECTRL_NEWTIME, which is what xboard uses
   by default, when you don't run in ICS-mode. */
int timectrl = TIMECTRL_NEWTIME;
int moves_per_timecontrol;
int base;
int increment;
int time_per_move = 1000;
int clock_mode = NORMAL_CLOCK_MODE;
int64 vain_thinking = 0;
int total_moves;
int at_move;
int total_nbr_moves;
int fixed_thinking_time = 1000;
extern int nbr_researches_at_curr_level;

void showtime(int engine_color) {
  if (engine_color == WHITE)
    printf("White: %d:%d, Black: %d:%d\n",
	   ((own_time - time_elapsed(own_checkpoint_time))/1000)/60,
	   ((own_time - time_elapsed(own_checkpoint_time))/1000)%60,
	   ((opp_time - time_elapsed(opp_checkpoint_time))/1000)/60,
	   ((opp_time - time_elapsed(opp_checkpoint_time))/1000)%60);
  else
    printf("White: %d:%d, Black: %d:%d\n",
	   ((opp_time - time_elapsed(opp_checkpoint_time))/1000)/60,
	   ((opp_time - time_elapsed(opp_checkpoint_time))/1000)%60,
	   ((own_time - time_elapsed(own_checkpoint_time))/1000)/60,
	   ((own_time - time_elapsed(own_checkpoint_time))/1000)%60);
}

int get_checkpoint_time() {
  #if GETTIME == GETTIMEOFDAY
    struct timeval tval;
    if (gettimeofday(&tval,0) != 0) {
      perror("Error getting the time.");
      infolog("Error getting the time.");
      exit(0);
    } else
      return tval.tv_sec * 1000 + tval.tv_usec / 1000;
  #else
    struct timeb tp;

    ftime(&tp);
    return tp.time * 1000 + tp.millitm;
  #endif
}

void start_own_clock() {
  own_checkpoint_time = get_checkpoint_time();
  new_level_checkpoint = own_checkpoint_time;
}

void start_opp_clock() {
  opp_checkpoint_time = get_checkpoint_time();
}

void stop_own_clock() {
  own_time = own_time - time_elapsed(own_checkpoint_time);
  own_checkpoint_time = -1;
}

void stop_opp_clock() {
  opp_time = opp_time - time_elapsed(opp_checkpoint_time);
  opp_checkpoint_time = -1;
}

void level_completed() {
  new_level_checkpoint = get_checkpoint_time();
}

int time_elapsed(int checkpoint) {
  #if GETTIME == GETTIMEOFDAY
    struct timeval tval;
    int currtime;

    if (checkpoint == -1)
      return 0;

    if (gettimeofday(&tval,0) != 0) {
      perror("Error with getting the time.");
      infolog("Error with getting the time.");
      exit(0);
    } else {
      currtime =  tval.tv_sec * 1000 + tval.tv_usec / 1000;
      return currtime - checkpoint;
    }
  #else
    struct timeb tp;
    int currtime;

    if (checkpoint == -1)
      return 0;

    ftime(&tp);
    currtime = tp.time * 1000 + tp.millitm;
    return currtime - checkpoint;
  #endif
}

void print_elapsed_time() {
  printf("Elapsed time = %d\n",time_elapsed(own_checkpoint_time));
}

void set_nbr_moves(int m) {
  total_nbr_moves = m;
}

/* Call this function if the engine should get a specific number of
   milliseconds to think. Of course it can still stop earlier, if all
   the nodes for the specified depth have been searched. */
void set_fixed_thinking_time(int f) {
  fixed_thinking_time = f;
}

/* The mode can be NORMAL_CLOCK_MODE or FIXED_CLOCK_MODE. */
void set_clock_mode(int mode) {
  clock_mode = mode;
}

int get_clock_mode() {
  return clock_mode;
}

void set_time_per_move(struct board *board) {
  if (clock_mode == NORMAL_CLOCK_MODE) {
    if (timectrl == TIMECTRL_NEWTIME) {
      /* Make sure we have some extra time left at the end by
	 adding +1 in the denominator. */
      time_per_move = (int) ((double) own_time /
			     (1 + moves_per_timecontrol - ((double)((board->move_number)%(moves_per_timecontrol*2))/2)));
    } else if (timectrl == TIMECTRL_INC) {
      /* If Amundsen has more than a minute left, then think a little
	 more than increment seconds. Else if more than half a minute,
	 then think for increment seconds, else think for a little
	 less than increment seconds. */
      if (own_time > 60*1000)
	time_per_move = increment + increment*0.3;
      else if (own_time > 30*1000)
	time_per_move = increment;
      else
	time_per_move = increment - increment*0.3;
    } else {    //timectrl == TIMECTRL_NOINC
      time_per_move = own_time/15;
      
      /* If one has more time left than one's opponent, then it's okay
	 to think longer, or else if one has less time left than the
	 opponent, then decrease the time allowed for thinking. */
      if (own_time < opp_time)
	time_per_move -= own_time/60;
      else if (own_time > 20*1000) {
	if (own_time > 2*opp_time)
	  time_per_move += own_time/15;
	else
	  time_per_move += own_time/30;
      }
    }
    printf("time_per_move = %d\n",time_per_move);
  } else {    //clock_mode == FIXED_CLOCK_MODE
    //do nothing
  }
}

/* This function returns 1 if the engine has to stop thinking, and
   0 if it can continue. Basically this function tries to be restrictive
   with aborting a search in the tree, and more willing to abort if a
   whole level of search has been completed. */
int time_is_up(int depth, int in_tree) {
  int time_elapsed_since_last_level, time_left, estimated_time_to_finish;
  double percentage_done;

  /* It's not possible to abort a search before search has been completed
     to at least 2 plies, since otherwise it might not be discovered that
     one's on king is in check, and an illegal move can therefore be done. */
  if (depth <= 2)
    return 0;
  time_elapsed_since_last_level = time_elapsed(new_level_checkpoint);
  time_left = time_per_move - time_elapsed(own_checkpoint_time);
  percentage_done = (double) at_move / total_nbr_moves;

  /* First check if we are in a mood where a specified number of seconds
     should be used for thinking. */
  if (clock_mode == FIXED_CLOCK_MODE) {
    if (time_elapsed(own_checkpoint_time) > fixed_thinking_time) {
      vain_thinking += time_elapsed_since_last_level;
      return 1;
    } else
      return 0;
  }

  /* If search is 0% done or 100% done it hard to make an accurate
     estimation of remaining search time, so then the estimation is based
     on total search time so far times a factor. It's assumed that the
     time to finish doubles for every re-search that has been done for
     the current level. */
  if (at_move == total_nbr_moves) {
    estimated_time_to_finish = 6 * (nbr_researches_at_curr_level + 1) *
      (time_elapsed(own_checkpoint_time));
    if (estimated_time_to_finish > time_left) {
      if (nbr_researches_at_curr_level > 0)
	vain_thinking += time_elapsed_since_last_level;
      return 1;
    } else
      return 0;
  } else if (at_move == 0) {
    estimated_time_to_finish = 3 * (nbr_researches_at_curr_level + 1) *
      (time_elapsed(own_checkpoint_time));
  } else {
    estimated_time_to_finish = time_elapsed_since_last_level
      * (1/percentage_done) * (nbr_researches_at_curr_level + 1)
      - time_elapsed_since_last_level;
  }

  /* If this time check is done in the tree and there is less than 5 seconds
     left on the clock, then exit right away if estimated time to finish
     is greater than the available search time. Or if in the tree and
     less than 10 seconds on the clock, and it's estimated that the search
     won't be completed on time, and less than half of the search is
     completed, then abort the search. */
  if (in_tree && own_time < 5*1000 && estimated_time_to_finish > time_left) {
    vain_thinking += time_elapsed_since_last_level;
    return 1;
  } else if (in_tree && own_time < 10*1000
	     && ((estimated_time_to_finish > time_left
		  && time_elapsed_since_last_level > 0.5*1000)
		 || percentage_done < 0.4)) {
    vain_thinking += time_elapsed_since_last_level;
    return 1;
  }

  /* If the engine has been thinking longer than 3 times the allowed
     thinking time, or if more than one sixth of the total available
     time (for the whole game) has been used up for this move, or if
     more than one third of the remaining search time has been used up,
     then abort the search no matter what. */
  if ((time_elapsed(own_checkpoint_time) > 3*time_per_move)
      || ((double) time_elapsed(own_checkpoint_time) > (double) base/6)
      || ((double) time_elapsed(own_checkpoint_time) > (double) own_time / 3)) {
    vain_thinking += time_elapsed_since_last_level;
    return 1;
  }

  /* If we have thought for a longer time than we should, then abort
     the search if we haven't gotten very far. But if we have already
     searched quite far, and there is lots of time left on the clock
     compared to how long it will take to finish the search, then
     continue. */
  if (time_left < 0) {
    if (in_tree && percentage_done > 0.2)
      return 0;
    vain_thinking += time_elapsed_since_last_level;
    return 1;
  }

  /* If we are within the boundaries, then continue the search. */
  if (estimated_time_to_finish <= time_left) {
    return 0;
  } else {
    /* If we are still searching the first move, and we've been searching
       for less than 0.5 seconds, then we don't really have enough
       information to make an accurate prediction of the estimated time
       to complete the search. If there is more than 20 seconds left on the
       clock, then we'll continue the search. */
    if (at_move < 1 && time_elapsed_since_last_level < 1*500
	&& own_time > 20*1000) {
      return 0;
    }
    
    if (in_tree && at_move < 1) {
      vain_thinking += time_elapsed_since_last_level;
      return 1;
    }
    
    /* Keep searching if we have already searched quite far compared to
       the available time left on the clock. */
    if (estimated_time_to_finish < own_time*percentage_done*0.30) {
      return 0;
    }
  }
  
  if (!in_tree) {
    vain_thinking += time_elapsed_since_last_level;
    return 1;
  } else
    return 0;
}
