#include "genmoves.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "bitboards.h"
#include "misc.h"
#include "parse.h"
#include "hash.h"
#include "makemove.h"

extern bitboard square[64];
extern bitboard pawn_start[2];
extern bitboard pawn_passantrow[2];
extern struct attack attack;
extern bitboard pawn_lastrow[2];
extern int rotate0to90[64];
extern int rotate0toNE[64];
extern int ones[9];
extern int diagNE_start[64];
extern int diagNE_length[64];
extern int rotate0toNW[64];
extern int diagNW_start[64];
extern int diagNW_length[64];
extern int pieceval[6];

bitboard generate_pawnmoves(struct board *board, int boardpos) {
  int64 targets;

  if (Color == WHITE) {
    /* White pawn goes one step forward. */
    targets = (square[boardpos] >> 8) &
      ~(board->all_pieces[WHITE] | board->all_pieces[BLACK]);
    if (square[boardpos] & pawn_start[WHITE]) //white pawn at starting square
      if (targets)    //the pawn can go one step forward
	/* White pawn goes two steps forward. */
	targets |= ((square[boardpos] >> 16) &
		    ~(board->all_pieces[WHITE]
		      | board->all_pieces[BLACK]));
  } else {    //color == BLACK
    /* BLACK pawn goes one step forward. */
    targets = (square[boardpos] << 8) &
      ~(board->all_pieces[WHITE] | board->all_pieces[BLACK]);
    if (square[boardpos] & pawn_start[BLACK]) //black pawn at starting square
      if (targets)    //the pawn can go one step forward
	/* BLACK pawn goes two steps forward. */
	targets |= ((square[boardpos] << 16) &
		    ~(board->all_pieces[WHITE]
		      | board->all_pieces[BLACK]));
  }

  /* We also need to add the capture moves. */
  targets |= (attack.pawn[(int)Color][boardpos] & board->all_pieces[(int)Oppcolor]);

  /* We also need to add the passant moves. */
  if (board->passant)
    targets |= (attack.pawn[(int)Color][boardpos] & square[(int)board->passant]);

  return targets;
}

int get_pawnmove_movetype(struct board *board, int boardpos, bitboard target) {
  int type;

  /* Find out what type of move it was. */
  if (target & board->all_pieces[Oppcolor])
    type = CAPTURE_MOVE;
  else if (attack.pawn[(int)Color][boardpos] & target) {
    /* If the move is an attack to a square with no enemy piece
       occupying it. */
    type = CAPTURE_MOVE | PASSANT_MOVE;
  } else
    type = NORMAL_MOVE;
    
  /* If the pawn goes to the last row, then we set the move to be a
     queen promotion. Notice that we don't take care of different
     kinds of promotions. */
  if (target & pawn_lastrow[(int)Color])
    type |= QUEEN_PROMOTION_MOVE;
  return type;
}

bitboard generate_kingmoves(struct board *board, int boardpos) {
  int64 targets;

  targets = attack.king[boardpos] & (~board->all_pieces[(int)Color]);

  /* Check castling. */
  if (Color == WHITE) {
    if (board->castling_status[WHITE] & SHORT_CASTLING_OK)
      /* Check if the squares between the king and the rook are empty. */
      if (((board->all_pieces[WHITE] | board->all_pieces[BLACK]) &
	   (square[61] | square[62])) == 0) {
	/* Make a final check to see if the king's square is in check,
	   or if the destination square is in check, or if the square in
	   between is in check. */
	if (!in_check(board)) {
	  board->piece[(int)Color][KING] = square[61];
	  if (!in_check(board)) {
	    board->piece[(int)Color][KING] = square[62];
	    if (!in_check(board))
	      targets = targets | square[62];
	  }
	  board->piece[(int)Color][KING] = square[60];
	}
      }
    if (board->castling_status[WHITE] & LONG_CASTLING_OK)
      /* Check if the squares between the king and the rook are empty. */
      if (((board->all_pieces[WHITE] | board->all_pieces[BLACK]) &
	   (square[57] | square[58] | square[59])) == 0) {
	/* Make a final check to see if the king's square is in check,
	   or if the destination square is in check, or if the square in
	   between is in check. */
	if (!in_check(board)) {
	  board->piece[(int)Color][KING] = square[59];
	  if (!in_check(board)) {
	    board->piece[(int)Color][KING] = square[58];
	    if (!in_check(board))
	      targets = targets | square[58];
	  }
	  board->piece[(int)Color][KING] = square[60];
	}
      }
  } else {    //color == BLACK
    if (board->castling_status[BLACK] & SHORT_CASTLING_OK)
      /* Check if the squares between the king and the rook are empty. */
      if (((board->all_pieces[WHITE] | board->all_pieces[BLACK]) &
	   (square[5] | square[6])) == 0) {
	/* Make a final check to see if the king's square is in check,
	   or if the destination square is in check, or if the square in
	   between is in check. */
	if (!in_check(board)) {
	  board->piece[(int)Color][KING] = square[5];
	  if (!in_check(board)) {
	    board->piece[(int)Color][KING] = square[6];
	    if (!in_check(board))
	      targets = targets | square[6];
	  }
	  board->piece[(int)Color][KING] = square[4];
	}
      }
    if (board->castling_status[BLACK] & LONG_CASTLING_OK)
      /* Check if the squares between the king and the rook are empty. */
      if (((board->all_pieces[WHITE] | board->all_pieces[BLACK]) &
	   (square[1] | square[2] | square[3])) == 0) {
	/* Make a final check to see if the king's square is in check,
	   or if the destination square is in check, or if the square in
	   between is in check. */
	if (!in_check(board)) {
	  board->piece[(int)Color][KING] = square[3];
	  if (!in_check(board)) {
	    board->piece[(int)Color][KING] = square[2];
	    if (!in_check(board))
	      targets = targets | square[2];
	  }
	  board->piece[(int)Color][KING] = square[4];
	}
      }
  }

  return targets;
}

int get_kingmove_movetype(struct board *board, bitboard target) {
  /* Find out what type of move it was. */
  if (target & board->all_pieces[Oppcolor])
    return CAPTURE_MOVE;
  else if ((Color == WHITE && (board->piece[(int)Color][KING] & square[60])
	    && ((target & square[62]) || (target & square[58])))
	   || (Color == BLACK && (board->piece[(int)Color][KING] & square[4])
	       && ((target & square[6]) || (target & square[2]))))
    return CASTLING_MOVE;
  else
    return NORMAL_MOVE;
}

bitboard generate_knight_moves(struct board *board, int boardpos) {
  return attack.knight[boardpos] & (~board->all_pieces[(int)Color]);
}

/* This function generates moves that go horizontally along the board.
   It is needed for generating queen and rook moves. */
bitboard generate_horizontal_moves(struct board *board, int boardpos) {
  int occupancy;

  occupancy = ((board->all_pieces[WHITE]
		| board->all_pieces[BLACK]) >> ((boardpos/8)*8)) & 255;
  return attack.hslider[boardpos][occupancy] & (~board->all_pieces[(int)Color]);
}

/* This function returns the movetype of all pieces other than pawns
   and king. */
int get_othermove_movetype(struct board *board, bitboard target) {
  /* Find out what type of move it was. */
  if (target & board->all_pieces[Oppcolor])
    return CAPTURE_MOVE;
  else
    return NORMAL_MOVE;
}

/* This function generates moves that go vertically along the board.
   This function is needed for generating queen and rook moves. */
bitboard generate_vertical_moves(struct board *board, int boardpos) {
  int occupancy;

  /* We calculate the vertical moves (files) by using the rotated
     bitboard board.rot90_pieces, and getting the occupancy number of
     the file in question by reading off the occupancy of the rank in
     this rotated bitboard. Then we switch back to "unrotated" before
     we add the move to the movelist. */
  occupancy = ((board->rot90_pieces[WHITE]
		| board->rot90_pieces[BLACK])
	       >> (rotate0to90[boardpos]/8)*8) & 255;

  return attack.vslider[boardpos][occupancy] & (~board->all_pieces[(int)Color]);
}

/* This function generates moves that go diagonally along the board
   in the northeast direction (the a1-h8 diagonal). This function is
   needed for generating queen and bishop moves. */
bitboard generate_NEdiag_moves(struct board *board , int boardpos) {
  int occupancy;

  occupancy = (board->rotNE_pieces[WHITE] | board->rotNE_pieces[BLACK]) >> (rotate0toNE[diagNE_start[boardpos]]) & ones[diagNE_length[boardpos]];
  return attack.sliderNE[boardpos][occupancy] & (~board->all_pieces[(int)Color]);
}

/* This function generates moves that go diagonally along the board
   in the northwest direction (the h1-a8 diagonal). This function is
   needed for generating queen and bishop moves. */
bitboard generate_NWdiag_moves(struct board *board, int boardpos) {
  int occupancy;

  occupancy = (board->rotNW_pieces[WHITE] | board->rotNW_pieces[BLACK]) >> (rotate0toNW[diagNW_start[boardpos]]) & ones[diagNW_length[boardpos]];
  return attack.sliderNW[boardpos][occupancy] & (~board->all_pieces[(int)Color]);
}

/* This function returns moves to try in the quiescence search. If there
   are moves left 1 is returned, else 0 is returned. Moves are generated
   in the following order: 1. Hash moves, 2. Lower valued piece captures
   higher valued one, 3. Equal captures where there are more attackers than
   defenders, 4. Higher valued piece captures lower valued one, and more
   attackers than defenders */
int get_next_quiet_move(struct board *board, struct moves *moves, int movables,
			struct move *returnmove, int *order, bitboard target) {
  int i, j;
  bitboard opp_pieces;

  /* Extract the moves where a lower valued piece captures a better one. */
  if (*order == 0) {
    /* Find the best piece to take. We take advantage of the fact that the
     moves are ordered in a lower valued piece -> higher valued piece fashion,
     to try the moves in an approximately MVV/LVA-order. And in order to make
     sure that knight takes bishop is not considered to be a lower valued
     one taking a higher valued one, we also have to make sure the piece-values
     are not the same. */
    for (j = QUEEN; j > PAWN; j--) {
      for (i = 0; i < movables && moves[i].piece < j; i++) {
	if (moves[i].targets & board->piece[Oppcolor][j] && pieceval[moves[i].piece] < pieceval[j]) {
	  returnmove->piece = moves[i].piece;
	  returnmove->fsquare = moves[i].source;
	  returnmove->tsquare = getlsb(moves[i].targets
				       & board->piece[Oppcolor][j]);
	  returnmove->type = get_movetype
	    (board,get_first_bitpos(returnmove->fsquare),
	     returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  return 1;
	}
      }
    }
    (*order)++;
  }

  /* Extract the equal captures where there are more attackers than defenders.
     Make sure knights and bishops are considered equal. */
  if (*order == 1) {
    for (i = 0; i < movables; i++) {
      if (moves[i].piece == KNIGHT || moves[i].piece == BISHOP)
	opp_pieces = moves[i].targets
	  & (board->piece[Oppcolor][KNIGHT] | board->piece[Oppcolor][BISHOP]);
      else
	opp_pieces = moves[i].targets & board->piece[Oppcolor][moves[i].piece];
      if (opp_pieces
	  && (get_number_of_defenders(board,Color,getlsb(opp_pieces)) >
	      get_number_of_defenders(board,Oppcolor,getlsb(opp_pieces)))) {
	returnmove->piece = moves[i].piece;
	returnmove->fsquare = moves[i].source;
	returnmove->tsquare = getlsb(opp_pieces);
	returnmove->type = get_movetype
	  (board,get_first_bitpos(returnmove->fsquare),
	   returnmove->piece,returnmove->tsquare);
	moves[i].targets &= ~(returnmove->tsquare);
	return 1;
      }
    }
    (*order)++;
  }

  /* Extract the moves where a higher valued piece captures a lower
     valued one, and there are more attackers than defenders. */
  if (*order == 2) {
    for (i = 0; i < movables; i++) {
      for (j = PAWN; j < moves[i].piece; j++) {
	if ((moves[i].targets & board->piece[Oppcolor][j])
	    && (get_number_of_defenders(board,Color,getlsb(moves[i].targets & board->piece[Oppcolor][j])) > get_number_of_defenders(board,Oppcolor,getlsb(moves[i].targets & board->piece[Oppcolor][j])))) {
	  returnmove->piece = moves[i].piece;
	  returnmove->fsquare = moves[i].source;
	  returnmove->tsquare = getlsb(moves[i].targets
				       & board->piece[Oppcolor][j]);
	  returnmove->type = get_movetype
	    (board,get_first_bitpos(returnmove->fsquare),
	     returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  return 1;
	}
      }
    }
    (*order)++;
  }
  return 0;
}

/* This function returns 1 if there is moves left, and 0 if there are no
   moves left to generate. Moves are generated in the following order:
   1. Hash moves, 2. Lower valued piece captures higher valued one,
   3. Equal captures where there are more attackers than defenders,
   4. Higher valued piece captures a lower valued one, and more
   attackers than defenders, 5. Move one's best enprise piece into safety,
   6. Killer moves, 7. Other equal captures, 8. Non-captures,
   9. The rest (=bad captures according to SEE) */
int get_next_move(struct board *board , struct moves *moves,
		  int movables, int *refval, struct move *refmove,
		  int *transpval, struct move *transpmove,
		  struct killers *killers, struct move *returnmove,
		  int *order, int org_depth, int depth) {
  int i, j, k_counter;
  bitboard enprise, safe_square, opp_pieces;
  bitboard targets, positions;
  int occupancy;
  int pos_to;

  /* Extract the hashmove(s), if any. */
  if (*order == 0) {
    if (*refval == HASH_MOVE) {
      /* Instead of taking the hash move directly, we extract it from
	 the move list. It's done this way for two reasons:
         - If the hash move doesn't cause a cutoff, we will have to search
	   the other moves in the list, and then the hash move will be
	   searched twice if it isn't removed from the list the first time.
	 - If two different boards happen to hash to the same key, the hash
	   move is probably invalid.
      */
      for (i = 0; i < movables; i++)
	if (refmove->fsquare & moves[i].source
	    && refmove->tsquare & moves[i].targets) {
	  returnmove->fsquare = refmove->fsquare;
	  returnmove->tsquare = refmove->tsquare;
	  returnmove->piece = moves[i].piece;
	  returnmove->type = get_movetype
	    (board,get_first_bitpos(returnmove->fsquare),
	     returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  (*order)++;
	  return 1;
	}
      /* If we don't find the hashmove in the movelist, it's not a serious
	 error. It probably means two different boards hashed to the same key.
	 Since that only happens once in a blue moon, we'll print out a
	 message here. */
      infolog("REF-HASHMOVE NOT FOUND.");
    }
    (*order)++;
  }
  if (*order == 1) {
    if (*transpval == HASH_MOVE) {
      for (i = 0; i < movables; i++)
	if (transpmove->fsquare & moves[i].source
	    && transpmove->tsquare & moves[i].targets) {
	  returnmove->fsquare = transpmove->fsquare;
	  returnmove->tsquare = transpmove->tsquare;
	  returnmove->piece = moves[i].piece;
	  returnmove->type = get_movetype
	    (board,get_first_bitpos(returnmove->fsquare),
	     returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  (*order)++;
	  return 1;
	}
      /* Also keep track of transposition moves that were not found, but
	 don't print out anything if the refutation move was the same,
	 and that one already has been tried. */
      if (*refval != HASH_MOVE || (refmove->fsquare != transpmove->fsquare
				   || refmove->tsquare != transpmove->tsquare))
	infolog("TRANSP-HASHMOVE NOT FOUND.");
    }
    (*order)++;
  }

  /* Extract the moves where a lower valued piece captures a better one. */
  if (*order == 2) {
    /* Find the best piece to take. We take advantage of the fact that the
     moves are ordered in a lower valued piece -> higher valued piece fashion,
     to try the moves in an approximately MVV/LVA-order. And in order to make
     sure that knight takes bishop is not considered to be a lower valued
     one taking a higher valued one, we also have to make sure the piece-values
     are not the same. */
    for (j = QUEEN; j > PAWN; j--) {
      for (i = 0; i < movables && moves[i].piece < j; i++) {
	if (moves[i].targets & board->piece[Oppcolor][j] && pieceval[moves[i].piece] < pieceval[j]) {
	  returnmove->piece = moves[i].piece;
	  returnmove->fsquare = moves[i].source;
	  returnmove->tsquare = getlsb(moves[i].targets
				       & board->piece[Oppcolor][j]);
	  returnmove->type = get_movetype
	    (board,get_first_bitpos(returnmove->fsquare),
	     returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  return 1;
	}
      }
    }
    (*order)++;
  }

  /* Extract the equal captures where there are more attackers than defenders.
     Make sure knights and bishops are considered equal. */
  if (*order == 3) {
    for (i = 0; i < movables; i++) {
      if (moves[i].piece == KNIGHT || moves[i].piece == BISHOP)
	opp_pieces = moves[i].targets
	  & (board->piece[Oppcolor][KNIGHT] | board->piece[Oppcolor][BISHOP]);
      else
	opp_pieces = moves[i].targets & board->piece[Oppcolor][moves[i].piece];
      /* This code is just testing the least significant bit on the opp_pieces
	 bitboard. Shouldn't we also test the other bits? */
      if (opp_pieces
	  && (get_number_of_defenders(board,Color,getlsb(opp_pieces)) >
	      get_number_of_defenders(board,Oppcolor,getlsb(opp_pieces)))) {
	returnmove->piece = moves[i].piece;
	returnmove->fsquare = moves[i].source;
	returnmove->tsquare = getlsb(opp_pieces);
	returnmove->type = get_movetype
	  (board,get_first_bitpos(returnmove->fsquare),
	   returnmove->piece,returnmove->tsquare);
	moves[i].targets &= ~(returnmove->tsquare);
	return 1;
      }
    }
    (*order)++;
  }

  /* Extract the moves where a higher valued piece captures a lower
     valued one, and there are more attackers than defenders. */
  if (*order == 4) {
    for (i = 0; i < movables; i++) {
      for (j = PAWN; j < moves[i].piece; j++) {
	if ((moves[i].targets & board->piece[Oppcolor][j])
	    && (get_number_of_defenders(board,Color,getlsb(moves[i].targets & board->piece[Oppcolor][j])) > get_number_of_defenders(board,Oppcolor,getlsb(moves[i].targets & board->piece[Oppcolor][j])))) {
	  returnmove->piece = moves[i].piece;
	  returnmove->fsquare = moves[i].source;
	  returnmove->tsquare = getlsb(moves[i].targets
				       & board->piece[Oppcolor][j]);
	  returnmove->type = get_movetype
	    (board,get_first_bitpos(returnmove->fsquare),
	     returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  return 1;
	}
      }
    }
    (*order)++;
  }

  /* Try a move that will move one's best enprise piece into safety.
     If it's not possible to move it to a safe square, we try to defend
     one of our enprise-pieces. Note that we only try one such move. */
  if (*order == 5) {
    enprise = (~get_defending_squares(board,Color)) & board->all_pieces[(int)Color]
      & get_defending_squares(board,Oppcolor);
    if (enprise != 0) {
      safe_square = ~get_defending_squares(board,Oppcolor);
      for (i = movables - 1; i >= 0; i--) {
      //for (i = 0; i < movables; i++) {
	if ((moves[i].source & enprise) && (moves[i].targets & safe_square)) {
	  returnmove->fsquare = moves[i].source;
	  returnmove->tsquare = getlsb(moves[i].targets & safe_square);
	  returnmove->piece = moves[i].piece;
	  returnmove->type = get_movetype
	    (board,get_first_bitpos(returnmove->fsquare),
	     returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  (*order)++;
	  return 1;
	}
      }
      for (i = 0; i < movables; i++) {
	positions = moves[i].targets;
	while (positions != 0) {
	  pos_to = get_first_bitpos(positions);
	  targets = 0;

	  if (moves[i].piece == PAWN) {
	    targets |= attack.pawn[(int)Color][pos_to];
	  } else if (moves[i].piece == KNIGHT) {
	    targets |= attack.knight[pos_to];
	  } else if (moves[i].piece == BISHOP) {
	    occupancy = (board->rotNE_pieces[WHITE] | board->rotNE_pieces[BLACK])
	      >> (rotate0toNE[diagNE_start[pos_to]]) & ones[diagNE_length[pos_to]];
	    targets |= attack.sliderNE[pos_to][occupancy];
	    occupancy = (board->rotNW_pieces[WHITE] | board->rotNW_pieces[BLACK])
	      >> (rotate0toNW[diagNW_start[pos_to]]) & ones[diagNW_length[pos_to]];
	    targets |= attack.sliderNW[pos_to][occupancy];
	  } else if (moves[i].piece == ROOK) {
	    occupancy = ((board->all_pieces[WHITE]
			  | board->all_pieces[BLACK]) >> ((pos_to/8)*8)) & 255;
	    targets |= attack.hslider[pos_to][occupancy];
	    occupancy = ((board->rot90_pieces[WHITE] | board->rot90_pieces[BLACK])
			 >> (rotate0to90[pos_to]/8)*8) & 255;
	    targets |= attack.vslider[pos_to][occupancy];
	  } else if (moves[i].piece == QUEEN) {
	    occupancy = ((board->all_pieces[WHITE]
			  | board->all_pieces[BLACK]) >> ((pos_to/8)*8)) & 255;
	    targets |= attack.hslider[pos_to][occupancy];
	    occupancy = ((board->rot90_pieces[WHITE] | board->rot90_pieces[BLACK])
			 >> (rotate0to90[pos_to]/8)*8) & 255;
	    targets |= attack.vslider[pos_to][occupancy];
	    occupancy = (board->rotNE_pieces[WHITE] | board->rotNE_pieces[BLACK])
	      >> (rotate0toNE[diagNE_start[pos_to]]) & ones[diagNE_length[pos_to]];
	    targets |= attack.sliderNE[pos_to][occupancy];
	    occupancy = (board->rotNW_pieces[WHITE] | board->rotNW_pieces[BLACK])
	      >> (rotate0toNW[diagNW_start[pos_to]]) & ones[diagNW_length[pos_to]];
	    targets |= attack.sliderNW[pos_to][occupancy];
	  } else if (moves[i].piece == KING) {
	    targets |= attack.king[pos_to];
	  }
	  if (targets & enprise) {
	    returnmove->fsquare = moves[i].source;
	    returnmove->tsquare = square[pos_to];
	    returnmove->piece = moves[i].piece;
	    returnmove->type = get_movetype
	      (board,get_first_bitpos(returnmove->fsquare),
	       returnmove->piece,returnmove->tsquare);
	    moves[i].targets &= ~(returnmove->tsquare);
	    (*order)++;
	    return 1;
	  }
	  positions &= ~square[pos_to];
	}
      }
    }
    (*order)++;
  }

  /* Killer moves. */
  if (*order == 6) {
    for (k_counter = 0; k_counter < NBR_KILLERS; k_counter++) {
      for (i = 0; i < movables; i++) {
	if (moves[i].source & killers[k_counter].fsquare
	    && moves[i].targets & killers[k_counter].tsquare) {
	  returnmove->fsquare = moves[i].source;
	  returnmove->tsquare = getlsb(moves[i].targets & killers[k_counter].tsquare);
	  returnmove->piece = moves[i].piece;
	  returnmove->type = get_movetype
	    (board,get_first_bitpos(returnmove->fsquare),
	     returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  return 1;
	}
      }
    }
    (*order)++;
  }

  /* Equal captures. Make sure knights and bishops are considered equal. */
  if (*order == 7) {
    for (i = 0; i < movables; i++) {
      if (moves[i].piece == KNIGHT || moves[i].piece == BISHOP)
	opp_pieces = moves[i].targets
	  & (board->piece[Oppcolor][KNIGHT] | board->piece[Oppcolor][BISHOP]);
      else
	opp_pieces = moves[i].targets & board->piece[Oppcolor][moves[i].piece];
      if (opp_pieces) {
	returnmove->piece = moves[i].piece;
	returnmove->fsquare = moves[i].source;
	returnmove->tsquare = getlsb(opp_pieces);
	returnmove->type = get_movetype
	  (board,get_first_bitpos(returnmove->fsquare),
	   returnmove->piece,returnmove->tsquare);
	moves[i].targets &= ~(returnmove->tsquare);
	return 1;
      }
    }
    (*order)++;
  }

  /* Non-captures. */
  if (*order == 8) {
    if (org_depth > 2 && depth <= CUT_NEUTRAL_MOVES_FROM_DEPTH)
      (*order)++;
    else {
      for (i = 0; i < movables; i++) {
	if (moves[i].targets & ~(board->all_pieces[Oppcolor])) {
	  returnmove->fsquare = moves[i].source;
	  returnmove->tsquare = getlsb(moves[i].targets
				       & ~(board->all_pieces[Oppcolor]));
	  returnmove->piece = moves[i].piece;
	  returnmove->type = get_movetype
	    (board,get_first_bitpos(returnmove->fsquare),
	     returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  return 1;
	}
      }
      (*order)++;
    }
  }

  /* The rest of the moves, in no special ordering. */
  if (*order == 9) {
    if (org_depth > 2 && depth <= CUT_BAD_MOVES_FROM_DEPTH)
      (*order)++;
    else {
      for (i = 0; i < movables; i++) {
	if (moves[i].targets) {
	  returnmove->fsquare = moves[i].source;
	  returnmove->tsquare = getlsb(moves[i].targets);
	  returnmove->piece = moves[i].piece;
	  returnmove->type = get_movetype
	    (board,get_first_bitpos(returnmove->fsquare),
	     returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  return 1;
	}
      }
      (*order)++;
    }
  }
  return 0;
}

/* This function returns 1 if there is moves left, and 0 if there are no
   moves left to generate. Moves are generated in the following order:
   1. Hash moves, 2. Lower valued piece captures higher valued one,
   3. Equal captures where there are more attackers than defenders,
   4. Higher valued piece captures a lower valued one, and more
   attackers than defenders, 5. Move one's best enprise piece into safety,
   6. Other equal captures, 7. Non-captures,
   8. The rest (=bad captures according to SEE) */
int get_next_root_move(struct board *board, struct move *movelist,
		       int mcount, int *order, int *searched_list) {
  int i, j;
  bitboard enprise, safe_square, opp_pieces;
  int best;

  /* Extract the moves where a lower valued piece captures a better one. */
  if (*order == 0) {
    /* Find the best piece to take. In order to make sure that knight
       takes bishop is not considered to be a lower valued one taking
       a higher valued one, we have to make sure the piece-values are
       not the same. */
    for (i = 0; i < mcount; i++)
      for (j = QUEEN; j > movelist[i].piece; j--)
	if (movelist[i].tsquare & board->piece[Oppcolor][j] && pieceval[movelist[i].piece] < pieceval[j] && searched_list[i] == 0)
	  return i;
    (*order)++;
  }

  /* Extract the equal captures where there are more attackers than defenders.
     Make sure knights and bishops are considered equal. */
  if (*order == 1) {

    for (i = 0; i < mcount; i++) {
      if (movelist[i].piece == KNIGHT || movelist[i].piece == BISHOP)
	opp_pieces = movelist[i].tsquare
	  & (board->piece[Oppcolor][KNIGHT] | board->piece[Oppcolor][BISHOP]);
      else
	opp_pieces = movelist[i].tsquare & board->piece[Oppcolor][movelist[i].piece];
      if (opp_pieces
	  && (get_number_of_defenders(board,Color,getlsb(opp_pieces)) >
	      get_number_of_defenders(board,Oppcolor,getlsb(opp_pieces)))
	  && searched_list[i] == 0) {
	return i;
      }
    }
    (*order)++;
  }

  /* Extract the moves where a higher valued piece captures a lower
     valued one, and there are more attackers than defenders. */
  if (*order == 2) {
    for (i = 0; i < mcount; i++) {
      for (j = PAWN; j < movelist[i].piece; j++) {
	opp_pieces = movelist[i].tsquare & board->piece[Oppcolor][j];
	if (opp_pieces
	    && (get_number_of_defenders(board,Color,getlsb(opp_pieces)) >
		get_number_of_defenders(board,Oppcolor,getlsb(opp_pieces)))
	    && searched_list[i] == 0)
	  return i;
      }
    }
    (*order)++;
  }

  /* Try a move that will move one's best enprise piece into safety.
     Note that we only try one such move. */
  if (*order == 3) {
    enprise = (~get_defending_squares(board,Color)) & board->all_pieces[(int)Color]
      & get_defending_squares(board,Oppcolor);
    if (enprise != 0) {
      safe_square = ~get_defending_squares(board,Oppcolor);

      for (i = mcount - 1; i >= 0; i--)
	if ((movelist[i].fsquare & enprise) && (movelist[i].tsquare & safe_square) && searched_list[i] == 0) {
	  (*order)++;
	  return i;
	}
    }
    (*order)++;
  }

  /* Equal captures. Make sure knights and bishops are considered equal. */
  if (*order == 4) {
    for (i = 0; i < mcount; i++) {
      if (movelist[i].piece == KNIGHT || movelist[i].piece == BISHOP)
	opp_pieces = movelist[i].tsquare
	  & (board->piece[Oppcolor][KNIGHT] | board->piece[Oppcolor][BISHOP]);
      else
	opp_pieces = movelist[i].tsquare & board->piece[Oppcolor][movelist[i].piece];
      if (opp_pieces && searched_list[i] == 0)
	return i;
    }
    (*order)++;
  }

  /* Non-captures, ordered according to the values of the
     previous iteration. */
  if (*order == 5) {
    /* Find out a starting value for best. */
    best = 0;
    while (((searched_list[best] == 1) || (movelist[best].type & CAPTURE_MOVE))
	   && best < mcount)
      best++;
    if (best >= mcount)
      (*order)++;
    if (*order == 5) {
      /* Pick the best move next. */
      for (i = best + 1; i < mcount; i++)
	if ((movelist[i].value > movelist[best].value) && searched_list[i] == 0
	    && !(movelist[i].type & CAPTURE_MOVE))
	  best = i;
      if (best >= mcount) {
	printf("best >= mcount!+n");
	exit(0);
      }
      return best;
    (*order)++;
    }
  }

  /* The rest of the moves, ordered according to the values of the
     previous iteration. */
  if (*order == 6) {
    /* Find out a starting value for best. */
    best = 0;
    while (searched_list[best] == 1 && best < mcount)
      best++;
    if (best >= mcount) {
      (*order)++;
      return -1;
    }
      
    /* Pick the best move next. */
    for (i = best + 1; i < mcount; i++)
      if (movelist[i].value > movelist[best].value && searched_list[i] == 0)
	best = i;
    if (best >= mcount) {
      printf("best >= mcount!+n");
      exit(0);
    }
    return best;
    (*order)++;
  }
  printf("e");
  return -1;
}

int get_movetype(struct board *board, int boardpos, int piecetype, bitboard target) {
  if (piecetype == PAWN)
    return get_pawnmove_movetype(board,boardpos,target);
  else if (piecetype == KING)
    return get_kingmove_movetype(board,target);
  else
    return get_othermove_movetype(board,target);
}

/* This function returns the number of pieces defending a certain square. */
int get_number_of_defenders(struct board *board, int color, bitboard target) {
  int piecetype, boardpos;
  bitboard pieces;
  int occupancy;
  int number = 0;

  for (piecetype = 0; piecetype < 6; piecetype++) {
    pieces = board->piece[color][piecetype];
    /* Go through all the pieces for the given piece type. */
    while (pieces != 0) {
      boardpos = get_first_bitpos(pieces);

      if (piecetype == PAWN) {
	number += bitcount(attack.pawn[color][boardpos] & target);
      } else if (piecetype == KNIGHT) {
	number += bitcount(attack.knight[boardpos] & target);
      } else if (piecetype == BISHOP) {
	occupancy = (board->rotNE_pieces[WHITE] | board->rotNE_pieces[BLACK])
	  >> (rotate0toNE[diagNE_start[boardpos]]) & ones[diagNE_length[boardpos]];
	number += bitcount(attack.sliderNE[boardpos][occupancy] & target);
	occupancy = (board->rotNW_pieces[WHITE] | board->rotNW_pieces[BLACK])
	  >> (rotate0toNW[diagNW_start[boardpos]]) & ones[diagNW_length[boardpos]];
	number += bitcount(attack.sliderNW[boardpos][occupancy] & target);
      } else if (piecetype == ROOK) {
	occupancy = ((board->all_pieces[WHITE]
		      | board->all_pieces[BLACK]) >> ((boardpos/8)*8)) & 255;
	number += bitcount(attack.hslider[boardpos][occupancy] & target);
	occupancy = ((board->rot90_pieces[WHITE] | board->rot90_pieces[BLACK])
		     >> (rotate0to90[boardpos]/8)*8) & 255;
	number += bitcount(attack.vslider[boardpos][occupancy] & target);
      } else if (piecetype == QUEEN) {
	occupancy = ((board->all_pieces[WHITE]
		      | board->all_pieces[BLACK]) >> ((boardpos/8)*8)) & 255;
	number += bitcount(attack.hslider[boardpos][occupancy] & target);
	occupancy = ((board->rot90_pieces[WHITE] | board->rot90_pieces[BLACK])
		     >> (rotate0to90[boardpos]/8)*8) & 255;
	number += bitcount(attack.vslider[boardpos][occupancy] & target);
	occupancy = (board->rotNE_pieces[WHITE] | board->rotNE_pieces[BLACK])
	  >> (rotate0toNE[diagNE_start[boardpos]]) & ones[diagNE_length[boardpos]];
	number += bitcount(attack.sliderNE[boardpos][occupancy] & target);
	occupancy = (board->rotNW_pieces[WHITE] | board->rotNW_pieces[BLACK])
	  >> (rotate0toNW[diagNW_start[boardpos]]) & ones[diagNW_length[boardpos]];
	number += bitcount(attack.sliderNW[boardpos][occupancy] & target);
      } else if (piecetype == KING) {
	number += bitcount(attack.king[boardpos] & target);
      }
      pieces &= ~square[boardpos];
    }
  }
  return number;
}

/* This function returns the squares that a player is defending, and returns
   the squares in a bitboard. Note the slight difference between defending
   and attacking. Pieces of the same color cannot attack each other,
   however they can defend each other. A piece can also defend a square
   that's occupied by a piece of opposite color. */
bitboard get_defending_squares(struct board *board, int color) {
  int piecetype, boardpos;
  bitboard pieces, targets = 0;

  int occupancy;

  for (piecetype = 0; piecetype < 6; piecetype++) {
    pieces = board->piece[color][piecetype];
    /* Go through all the pieces for the given piece type. */
    while (pieces != 0) {
      boardpos = get_first_bitpos(pieces);

      if (piecetype == PAWN) {
	targets |= attack.pawn[color][boardpos];
      } else if (piecetype == KNIGHT) {
	targets |= attack.knight[boardpos];
      } else if (piecetype == BISHOP) {
	occupancy = (board->rotNE_pieces[WHITE] | board->rotNE_pieces[BLACK])
	  >> (rotate0toNE[diagNE_start[boardpos]]) & ones[diagNE_length[boardpos]];
	targets |= attack.sliderNE[boardpos][occupancy];
	occupancy = (board->rotNW_pieces[WHITE] | board->rotNW_pieces[BLACK])
	  >> (rotate0toNW[diagNW_start[boardpos]]) & ones[diagNW_length[boardpos]];
	targets |= attack.sliderNW[boardpos][occupancy];
      } else if (piecetype == ROOK) {
	occupancy = ((board->all_pieces[WHITE]
		      | board->all_pieces[BLACK]) >> ((boardpos/8)*8)) & 255;
	targets |= attack.hslider[boardpos][occupancy];
	occupancy = ((board->rot90_pieces[WHITE] | board->rot90_pieces[BLACK])
		     >> (rotate0to90[boardpos]/8)*8) & 255;
	targets |= attack.vslider[boardpos][occupancy];
      } else if (piecetype == QUEEN) {
	occupancy = ((board->all_pieces[WHITE]
		      | board->all_pieces[BLACK]) >> ((boardpos/8)*8)) & 255;
	targets |= attack.hslider[boardpos][occupancy];
	occupancy = ((board->rot90_pieces[WHITE] | board->rot90_pieces[BLACK])
		     >> (rotate0to90[boardpos]/8)*8) & 255;
	targets |= attack.vslider[boardpos][occupancy];
	occupancy = (board->rotNE_pieces[WHITE] | board->rotNE_pieces[BLACK])
	  >> (rotate0toNE[diagNE_start[boardpos]]) & ones[diagNE_length[boardpos]];
	targets |= attack.sliderNE[boardpos][occupancy];
	occupancy = (board->rotNW_pieces[WHITE] | board->rotNW_pieces[BLACK])
	  >> (rotate0toNW[diagNW_start[boardpos]]) & ones[diagNW_length[boardpos]];
	targets |= attack.sliderNW[boardpos][occupancy];
      } else if (piecetype == KING) {
	targets |= attack.king[boardpos];
      }
      pieces &= ~square[boardpos];
    }
  }
  return targets;
}

/* This function returns all pseudo-legal moves in a given position.
   Pseudo-legal move generation means that no checking is done to see
   if the move places it's own king in check. That has to be checked
   elsewhere.
     This function returns 0 on no error, and -1 on error, which is if
   the opposite king can be taken.
     There is at most 16 pieces of one color, so struct moves *moves needs
   to have room for 16 entries, and no more. */
int generate_moves(struct board *board, struct moves *moves, int *movables) {
  int piecetype, boardpos;
  bitboard pieces;

  *movables = 0;

  for (piecetype = 0; piecetype < 6; piecetype++) {
    pieces = board->piece[(int)Color][piecetype];
    /* Go through all the pieces for the given piece type. */
    while (pieces != 0) {
      boardpos = get_first_bitpos(pieces);

      if (piecetype == PAWN) {
	moves[*movables].targets =
	  generate_pawnmoves(board,boardpos);
      } else if (piecetype == KNIGHT) {
	moves[*movables].targets = generate_knight_moves(board,boardpos);
      } else if (piecetype == BISHOP) {
	moves[*movables].targets = generate_NEdiag_moves(board,boardpos)
	  | generate_NWdiag_moves(board,boardpos);
      } else if (piecetype == ROOK) {
	moves[*movables].targets =
	  generate_horizontal_moves(board,boardpos)
	  | generate_vertical_moves(board,boardpos);
      } else if (piecetype == QUEEN) {
	moves[*movables].targets =
	  generate_horizontal_moves(board,boardpos)
	  | generate_vertical_moves(board,boardpos)
	  | generate_NEdiag_moves(board,boardpos)
	  | generate_NWdiag_moves(board,boardpos);
      } else if (piecetype == KING) {
	moves[*movables].targets = generate_kingmoves(board,boardpos);
      }

      if (moves[*movables].targets & board->piece[Oppcolor][KING])
	return -1;
      /* Only add this piece if it can go somewhere. */
      if (moves[*movables].targets != 0) {
	moves[*movables].source = square[boardpos];
	moves[*movables].piece = piecetype;
	(*movables)++;
      }
      pieces = pieces & ~square[boardpos];
    }
  }

  return 0;
}

