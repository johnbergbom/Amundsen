#ifndef _MAKEMOVE_
#define _MAKEMOVE_

#include "misc.h"
#include "bitboards.h"

void make_nullmove(struct board *oldboard, struct board *newboard);

void makemove(struct board *oldboard, struct board *newboard,
	      struct move move, int depth);
//bitboard make_zobrist_move(struct board *board, int color, struct move move);

#endif      //_MAKEMOVE_
