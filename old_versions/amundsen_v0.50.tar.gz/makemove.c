#include "makemove.h"
#include "parse.h"
#include <stdio.h>
#include <stdlib.h>
#include "hash.h"

extern bitboard square[64];
extern int64 CHANGE_COLOR;
extern int rotate0to90[64];
extern int rotate0toNE[64];
extern int rotate0toNW[64];
extern int promotion_piece[129];
extern int64 zobrist[6][2][64];
extern int64 zobrist_castling[2][5];
extern bitboard pawn_start[2];
extern bitboard pawn_passantrow[2];
extern int pieceval[6];

void make_nullmove(struct board *oldboard, struct board *newboard) {
  *newboard = *oldboard;
  newboard->color_at_move = 1 - oldboard->color_at_move;
  newboard->zobrist_key ^= CHANGE_COLOR;
  newboard->moves_left_to_draw -= 1;
  newboard->passant = 0;
  newboard->zobrist_key ^= square[(int)oldboard->passant];
  newboard->zobrist_key ^= square[(int)newboard->passant];
}

void makemove(struct board *oldboard, struct board *newboard, struct move move, int depth) {
  int color, oppcolor;
  int j;
  bitboard rookfsquare, rooktsquare;

  color = oldboard->color_at_move;
  oppcolor = 1 - color;
  *newboard = *oldboard;
  newboard->color_at_move = oppcolor;

  newboard->passant = 0;
  newboard->zobrist_key ^= CHANGE_COLOR;
  newboard->zobrist_key ^= square[(int)oldboard->passant];

  /* Check if the move is a capture. If it is, then we have to clear
     the bitboard of the taken piece. */
  if (move.type & CAPTURE_MOVE) {
    /* A shallow (=early) capture is worth more than a deeper one. */
    newboard->captures[color] += depth;
    newboard->moves_left_to_draw = 100;
    /* If it's a passant capture, then we have to remove the taken piece in
       a different way than for a normal capture. */
    if (move.type & PASSANT_MOVE) {
      if (color == WHITE) {
	newboard->piece[oppcolor][PAWN] &= (~(move.tsquare << 8));
	newboard->all_pieces[oppcolor] &= (~(move.tsquare << 8));
	newboard->rot90_pieces[oppcolor] &=
	  ~(square[rotate0to90[get_first_bitpos(move.tsquare << 8)]]);
	newboard->rotNE_pieces[oppcolor] &=
	  ~(square[rotate0toNE[get_first_bitpos(move.tsquare << 8)]]);
	newboard->rotNW_pieces[oppcolor] &=
	  ~(square[rotate0toNW[get_first_bitpos(move.tsquare << 8)]]);
	newboard->zobrist_key ^= zobrist[PAWN][oppcolor][get_first_bitpos(move.tsquare << 8)];
	newboard->zobrist_pawn_key ^= zobrist[PAWN][oppcolor][get_first_bitpos(move.tsquare << 8)];
	newboard->material_pawns[BLACK] -= VAL_PAWN;
      } else {   //color == BLACK
	newboard->piece[oppcolor][PAWN] &= (~(move.tsquare >> 8));
	newboard->all_pieces[oppcolor] &= (~(move.tsquare >> 8));
	newboard->rot90_pieces[oppcolor] &=
	  ~(square[rotate0to90[get_first_bitpos(move.tsquare >> 8)]]);
	newboard->rotNE_pieces[oppcolor] &=
	  ~(square[rotate0toNE[get_first_bitpos(move.tsquare >> 8)]]);
	newboard->rotNW_pieces[oppcolor] &=
	  ~(square[rotate0toNW[get_first_bitpos(move.tsquare >> 8)]]);
	newboard->zobrist_key ^= zobrist[PAWN][oppcolor][get_first_bitpos(move.tsquare >> 8)];
	newboard->zobrist_pawn_key ^= zobrist[PAWN][oppcolor][get_first_bitpos(move.tsquare >> 8)];
	newboard->material_pawns[WHITE] -= VAL_PAWN;
      }
    } else {   //normal capture (not passant)
      newboard->all_pieces[oppcolor] &= (~move.tsquare);
      newboard->rot90_pieces[oppcolor] &=
	~(square[rotate0to90[get_first_bitpos(move.tsquare)]]);
      newboard->rotNE_pieces[oppcolor] &=
	~(square[rotate0toNE[get_first_bitpos(move.tsquare)]]);
      newboard->rotNW_pieces[oppcolor] &=
	~(square[rotate0toNW[get_first_bitpos(move.tsquare)]]);
      for (j = 0; j < 6; j++) {
	if (newboard->piece[oppcolor][j] & move.tsquare) {
	  newboard->piece[oppcolor][j] &= (~move.tsquare);

	  /* If a pawn is taken, the pawn hashkey must be updated. */
	  if (j == PAWN) {
	    newboard->zobrist_pawn_key ^= zobrist[PAWN][oppcolor][get_first_bitpos(move.tsquare)];
	    newboard->material_pawns[oppcolor] -= VAL_PAWN;
	  } else
	    newboard->material_pieces[oppcolor] -= pieceval[j];

	  /* If a rook is taken, the opponent's castling rights must be
	     adjusted accordingly. */
	  if (j == ROOK) {
	    newboard->zobrist_key ^= zobrist_castling[oppcolor][(int)newboard->castling_status[oppcolor]];
	    if (color == WHITE) {
	      if (get_first_bitpos(move.tsquare) == 0)
		newboard->castling_status[oppcolor] &= ~LONG_CASTLING_OK;
	      else if (get_first_bitpos(move.tsquare) == 7)
		newboard->castling_status[oppcolor] &= ~SHORT_CASTLING_OK;
	    } else {   //color == BLACK
	      if (get_first_bitpos(move.tsquare) == 56)
		newboard->castling_status[oppcolor] &= ~LONG_CASTLING_OK;
	      else if (get_first_bitpos(move.tsquare) == 63)
		newboard->castling_status[oppcolor] &= ~SHORT_CASTLING_OK;
	    }
	    newboard->zobrist_key ^= zobrist_castling[oppcolor][(int)newboard->castling_status[oppcolor]];
	  }
	  newboard->zobrist_key ^= zobrist[j][oppcolor][get_first_bitpos(move.tsquare)];
	  break;
	}
      }
    }
  } else if (move.piece == PAWN) {   //not a capture move, but a pawn move
    newboard->moves_left_to_draw = 100;
    if ((move.fsquare & pawn_start[color]) && (move.tsquare & pawn_passantrow[color])) {
      if (color == WHITE)
	newboard->passant = get_first_bitpos(move.fsquare >> 8);
      else
	newboard->passant = get_first_bitpos(move.fsquare << 8);
    }
  } else  //not a capture, and not a pawn move
    --(newboard->moves_left_to_draw);
  newboard->zobrist_key ^= square[(int)newboard->passant];

  /* Update the bitboard for the piece that made the move. */
  newboard->piece[color][move.piece] &= (~move.fsquare);
  newboard->zobrist_key ^= zobrist[move.piece][color][get_first_bitpos(move.fsquare)];
  if (move.piece == PAWN)
    newboard->zobrist_pawn_key ^= zobrist[PAWN][color][get_first_bitpos(move.fsquare)];
  if (move.type & PROMOTION_MOVE) {
    newboard->piece[color][promotion_piece[move.type & PROMOTION_MOVE]]
      |= move.tsquare;
    newboard->zobrist_key ^= zobrist[promotion_piece[move.type & PROMOTION_MOVE]][color][get_first_bitpos(move.tsquare)];
    newboard->material_pawns[color] -= VAL_PAWN;
    newboard->material_pieces[color] += pieceval[promotion_piece[move.type & PROMOTION_MOVE]];

    /* An early promotion is worth more than a deeper one, so in case of
       promotion, we increase the value of the capture-flag with the value
       of depth. But if the move is a capture move, then the captures-flag
       has already gotten a higher value, so then we don't update it again. */
    if (!(move.type & CAPTURE_MOVE))
      newboard->captures[color] += depth;

  } else {
    newboard->piece[color][move.piece] |= move.tsquare;
    newboard->zobrist_key ^= zobrist[move.piece][color][get_first_bitpos(move.tsquare)];
    if (move.piece == PAWN)
      newboard->zobrist_pawn_key ^= zobrist[PAWN][color][get_first_bitpos(move.tsquare)];
  }

  /* Update the all_pieces bitboard and the rotated bitboards. */
  newboard->all_pieces[color] &= (~move.fsquare);
  newboard->all_pieces[color] |= move.tsquare;
  newboard->rot90_pieces[color] &=
    ~(square[rotate0to90[get_first_bitpos(move.fsquare)]]);
  newboard->rot90_pieces[color] |=
    square[rotate0to90[get_first_bitpos(move.tsquare)]];
  newboard->rotNE_pieces[color] &=
    ~(square[rotate0toNE[get_first_bitpos(move.fsquare)]]);
  newboard->rotNE_pieces[color] |=
    square[rotate0toNE[get_first_bitpos(move.tsquare)]];
  newboard->rotNW_pieces[color] &=
    ~(square[rotate0toNW[get_first_bitpos(move.fsquare)]]);
  newboard->rotNW_pieces[color] |=
    square[rotate0toNW[get_first_bitpos(move.tsquare)]];

  /* Update the castling flags. */
  newboard->zobrist_key ^=
    zobrist_castling[color][(int)newboard->castling_status[color]];
  if (move.piece == ROOK) {
    if (color == WHITE) {
      if (move.fsquare & square[56])
	newboard->castling_status[color] &= ~LONG_CASTLING_OK;
      else if (move.fsquare & square[63])
	newboard->castling_status[color] &= ~SHORT_CASTLING_OK;
    } else {    //color == BLACK
      if (move.fsquare & square[0])
	newboard->castling_status[color] &= ~LONG_CASTLING_OK;
      else if (move.fsquare & square[7])
	newboard->castling_status[color] &= ~SHORT_CASTLING_OK;
    }
  } else if (move.piece == KING)
    newboard->castling_status[color] &=
      ~(SHORT_CASTLING_OK | LONG_CASTLING_OK);
  if (move.type & CASTLING_MOVE) {
    /* Check if short castling. */
    if ((move.tsquare & square[6]) || (move.tsquare & square[62])) {
      rookfsquare = move.tsquare << 1;
      rooktsquare = move.tsquare >> 1;
    } else {   //long castling
      rookfsquare = move.tsquare >> 2;
      rooktsquare = move.tsquare << 1;
    }
    newboard->zobrist_key ^= zobrist[ROOK][color][get_first_bitpos(rookfsquare)];
    newboard->zobrist_key ^= zobrist[ROOK][color][get_first_bitpos(rooktsquare)];
    newboard->piece[color][ROOK] &= (~rookfsquare);
    newboard->piece[color][ROOK] |= rooktsquare;
    newboard->all_pieces[color] &= (~rookfsquare);
    newboard->all_pieces[color] |= rooktsquare;
    newboard->rot90_pieces[color] &=
      ~(square[rotate0to90[get_first_bitpos(rookfsquare)]]);
    newboard->rot90_pieces[color] |=
      square[rotate0to90[get_first_bitpos(rooktsquare)]];
    newboard->rotNE_pieces[color] &=
      ~(square[rotate0toNE[get_first_bitpos(rookfsquare)]]);
    newboard->rotNE_pieces[color] |=
      square[rotate0toNE[get_first_bitpos(rooktsquare)]];
    newboard->rotNW_pieces[color] &=
      ~(square[rotate0toNW[get_first_bitpos(rookfsquare)]]);
    newboard->rotNW_pieces[color] |=
      square[rotate0toNW[get_first_bitpos(rooktsquare)]];
    newboard->castling_status[color] = CASTLED;
  }
  newboard->zobrist_key ^= zobrist_castling[color][(int)newboard->castling_status[color]];
}
