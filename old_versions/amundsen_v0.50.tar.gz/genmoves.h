#ifndef _GENMOVES_
#define _GENMOVES_

#include "bitboards.h"

bitboard generate_pawnmoves(struct board *board, int boardpos);
bitboard generate_kingmoves(struct board *board, int boardpos);
bitboard generate_knight_moves(struct board *board, int boardpos);
bitboard generate_horizontal_moves(struct board *board, int boardpos);
bitboard generate_vertical_moves(struct board *board, int boardpos);
bitboard generate_NEdiag_moves(struct board *board, int boardpos);
bitboard generate_NWdiag_moves(struct board *board, int boardpos);

int get_movetype(struct board *board, int boardpos, int piecetype, bitboard target);

/* For move generation we use the moves struct. The source represents the
   square that a piece will move from. The targets represent all the
   squares the piece can move to. Piece tells what kind of piece we are
   dealing with. */
struct moves {
  bitboard source;
  bitboard targets;
  int piece;
};

struct killers {
  bitboard fsquare;
  bitboard tsquare;
  int value;
};

#define NBR_KILLERS 1

int get_next_quiet_move(struct board *board, struct moves *moves, int movables,
			struct move *returnmove, int *order, bitboard target);
int get_next_move(struct board *board, struct moves *moves,
		  int movables, int *refval, struct move *refmove,
		  int *transpval, struct move *transpmove,
		  struct killers *killers, struct move *returnmove,
		  int *order, int org_depth, int depth);
int get_number_of_defenders(struct board *board, int color, bitboard target);
bitboard get_defending_squares(struct board *board, int color);
int generate_moves(struct board *board, struct moves *moves, int *movables);


int get_pawnmove_movetype(struct board *board, int boardpos, bitboard target);
int get_kingmove_movetype(struct board *board, bitboard target);
int get_othermove_movetype(struct board *board, bitboard target);
int get_next_root_move(struct board *board, struct move *movelist,
		       int mcount, int *order, int *searched_list);

#endif      //_GENMOVES_

