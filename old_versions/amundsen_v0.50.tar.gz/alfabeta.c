#include "alfabeta.h"
#include <stdio.h>
#include <stdlib.h>
#ifndef _MSC_VER
#include <sys/resource.h>
#endif
#include "makemove.h"
#include "genmoves.h"
#include "eval.h"
#include "hash.h"
#include "slump.h"
#include "parse.h"
#include "display.h"
#include "timectrl.h"

/* R = reduction factor for the null-move search. */
#define R 2

int visited_nodes;       //total number (quiescence + normal search)
int quiescence_nodes;
int cutoffs = 0;             //counts the number of cutoffs
int cutoffs_first = 0;

/* Killers keep track of the moves that cause a cutoff at each level
   of the search. */
struct killers **killers;

/* if zugswang is set, then no null-move pruning will be used. */
int zugswang = 0;

/* The following variables are used for hash statistics. */
int probes = 0;
int sc_hits = 0;  //a score was returned
int m_hits = 0;   //a move was returned
int b_hits = 0;   //alpha/beta bounds were changed
int misses = 0;

/* We don't do the time checking too often, so we define a macro
   telling how many nodes should be searched before we check if
   there is time left. */
int abort_search;
int NODES_TO_SEARCH_BETWEEN_TIME_CHECKS = 1000;
int node_count_at_last_check = 0;

int max(int a, int b) {
  if (a > b)
    return a;
  else
    return b;
}

int min(int a, int b) {
  if (a > b)
    return b;
  else
    return a;
}

/* Don't use the hashtable in the quiescence search. It's probably better to
   save the hashtable for the upper parts of the search tree. */
int quiescence(struct board *board, int org_color, int nodetype, int alpha, int beta, bitboard tsquare) {
  struct board newpos;
  int retval;
  int q_val;
  int movables = 0;
  struct moves moves[16];
  struct move move = {0};
  int order = 0;

  if (generate_moves(board,moves,&movables) != 0)
    return KINGTAKEN;

  visited_nodes++;
  quiescence_nodes++;
  retval = (nodetype == MAXNODE) ? -INFTY : INFTY;

  if (nodetype == MAXNODE) {
    /* We init retval to the static score of the position. Then the engine
       will take whatever is best of continuing the capture line, or to
       accept the static score of the position. */
    retval = max(eval(org_color,board),retval);
    if (retval >= beta) {
      return retval;
    } else
      alpha = max(alpha,retval);
    while(get_next_quiet_move(board,moves,movables,&move,&order,tsquare)) {
      makemove(board,&newpos,move,0);
      q_val = quiescence(&newpos,org_color,MINNODE,alpha,beta,tsquare);
      if (q_val != KINGTAKEN) {
	retval = max(retval,q_val);
	alpha = max(alpha,retval);
	if (retval >= beta) {
	  return retval;
	}
      }
    }
    /* We get here when we have gone through all the capture moves, and
       when none of them were good enough to merit a cutoff. */
    return retval;
  } else {   //nodetype == MINNODE
    /* We init retval to the static score of the position. Then the engine
       will take whatever is best of continuing the capture line, or to
       accept the static score of the position. */
    retval = min(eval(org_color,board),retval);
    if (retval <= alpha) {
      return retval;
    } else
      beta = min(beta,retval);
    while(get_next_quiet_move(board,moves,movables,&move,&order,tsquare)) {
      makemove(board,&newpos,move,0);
      q_val = quiescence(&newpos,org_color,MAXNODE,alpha,beta,tsquare);
      if (q_val != KINGTAKEN) {
	retval = min(retval,q_val);
	beta = min(beta,retval);
	if (retval <= alpha) {
	  return retval;
	}
      }
    }
    /* We get here when we have gone through all the capture moves, and
       when none of them were good enough to merit a cutoff. */
    return retval;
  }
}

int alphabeta(struct board *board, int org_color, int nodetype, int alpha, int beta, int depth, int org_depth, int null_ok) {
  struct board newpos;
  int retval;
  int a_val;
  struct moves moves[16];
  int movables = 0;
  struct move move = {0};
  struct move best_move = {0};
  int extension = 0;
  int ref_val = 0, transp_val = 0;
  struct move refmove = {0};
  struct move transpmove = {0};
  int best;
  int order = 0;
  int cutcount = 0;
  int org_alpha = alpha, org_beta = beta;

  best_move.value = retval = (nodetype == MAXNODE) ? -INFTY : INFTY;
  visited_nodes++;

  /* Check if there is time left to think. */
  if (abort_search)
    return 0;
  if (visited_nodes - node_count_at_last_check
      >= NODES_TO_SEARCH_BETWEEN_TIME_CHECKS) {
    //printf(" TTT(%d) \n",visited_nodes - node_count_at_last_check);
    //printf(".\n");
    node_count_at_last_check = visited_nodes;
    if (time_is_up(org_depth,1)) {
      //printf("Aborting: ");
      //print_elapsed_time();
      abort_search = 1;
      return 0;
    }
  }

  /*-------------------------------------------------------------------
   | Probe refutation table and transposition table. First try the    |
   | transposition table since it handles the 3 position repetition,  |
   | so a value of zero is returned in case of excessive repetitions, |
   | rather than something that's in the refutation table.            |
   -------------------------------------------------------------------*/
  probes++;
  transp_val = probe_transposition((char)depth,board,&transpmove,
				   &alpha,&beta,&retval);
  if (transp_val != UNKNOWN && transp_val != HASH_MOVE) {
    sc_hits++;
    return transp_val;
  }
  ref_val = probe_refutation((char)depth,board,&refmove,
			     &alpha,&beta,&retval);
  if (ref_val != UNKNOWN && ref_val != HASH_MOVE) {
    sc_hits++;
    /* TODO: Get the right flag-value (MAXNODE, ALPHA or BETA
       can be taken from the transposition table. */
    //printf("NUUUUUUUUUUUUUUUUUDANNNNNNNNNNNNVVVVVVVVVVVVUUUUUUUULLLLLLL (%d) ",retval);
    /*printf("NUUUUUUD (%d) ",retval);
    if (nodetype == MAXNODE)
      printf("MAXNODE\n");
    else
    printf("MINNODE\n");*/
    //close_transposition((char)depth,board,&move,0,ref_val,
    //	(nodetype == MAXNODE ? BETA : ALPHA));
    close_transposition(get_refutation_depth(board),board,&move,0,ref_val,
			get_refutation_status(board));
    return ref_val;
  }
  if (transp_val == HASH_MOVE || ref_val == HASH_MOVE)
    m_hits++;
  else if (org_alpha != alpha || org_beta != beta)
    b_hits++;
  else if (transp_val == UNKNOWN && ref_val == UNKNOWN)
    misses++;
  
  
  /* Generate the moves, so we detect whether the position is legal or not.
     Otherwise an invalid position can be null move pruned, or if the depth
     is zero a value can be returned. */
  if (generate_moves(board,moves,&movables) != 0) {
    close_transposition((char)depth,board,&move,0,KINGTAKEN,EXACT);
    return KINGTAKEN;
  }
  /* We can't test move_left_to_draw until after we have generated
     the moves, to see if this is an illegal position. Because otherwise
     it might happen that a zero is returned for an illegal position
     instead of KINGTAKEN. And that can lead to making an illegal move
     when we are getting close to draw by the 50-move rule. */
  if (board->moves_left_to_draw <= 0) {
    close_transposition((char)depth,board,&move,0,draw_score(),EXACT);
    return draw_score();
  }

  if (depth <= 0) {
    retval = eval(org_color,board);
    close_transposition((char)depth,board,&move,0,retval,EXACT);
    return retval;
  } else {
    if (nodetype == MAXNODE) {
      /* Null-move pruning. */
      if (!in_check(board)) {
	if (!zugswang && null_ok && (depth > 0)) {
	  make_nullmove(board,&newpos);
	  /* Search with a minimal window around beta. Values outside of the
	     minimal window are invalid. We record values above beta in the
	     transposition table, since they are outside of the sought
	     range, and therefore doesn't need to be correct. However we
	     do not record values below beta, since we will probably want to
	     have correct values in that interval later on in the search.
	     The best move will always be recorded though, no matter where
	     in the search we are. */
	  //nullmove = 1;
	  //null_high = INFTY;
	  //null_low = beta - 1;
	  a_val = alphabeta(&newpos,org_color,MINNODE,beta-1,beta,
			    depth-1-R,org_depth,0);
	  //nullmove = 0;
	  if (a_val >= beta) {
	    retval = a_val;
	    close_transposition((char)depth,board,&move,0,retval,BETA);
	    return retval;
	  }
	}
      } else
	extension = 1;

      while (get_next_move(board,moves,movables,&ref_val,&refmove,
			   &transp_val,&transpmove,killers[depth],
			   &move,&order,org_depth,depth)) {
	cutcount++;
	makemove(board,&newpos,move,depth);
	
	if (depth-1+extension <= 0) {
	  a_val = quiescence(&newpos,org_color,MINNODE,alpha,beta,
			     move.tsquare);
	} else {
	  a_val = alphabeta(&newpos,org_color,MINNODE,alpha,beta,
			    depth-1+extension,org_depth,1);
	}
	
	if (a_val != KINGTAKEN) {
	  if (a_val > retval)
	    best_move = move;
	  retval = max(retval,a_val);
	  alpha = max(alpha,retval);
	  if (retval >= beta) {
	    cutoffs++;
	    if (cutcount == 1)
	      cutoffs_first++;
	    /* Here we got a cutoff, so we'll add this move as a killer.
	       Replace the best killer. (Not the worst one, because then
	       we don't get any rotation.) */
	    best = 0;
	    killers[depth][best].fsquare = move.fsquare;
	    killers[depth][best].tsquare = move.tsquare;
	    killers[depth][best].value = retval;
	    record_refutation((char) (depth+extension),board,&move,retval,BETA);
	    close_transposition((char) (depth+extension),board,&move,1,
				retval,BETA);
	    return retval;
	  }
	}
      }
      /* If we get here, and retval == -INFTY, it means all possible moves
         from this position leads to a check position. If we are already in
         check, then it's mate. If we're not in check, then it's stalemate. */
      if (retval == -INFTY) {
	if (in_check(board)) {
	  /* Return retval+1 instead of retval. That's because it's only
	     at the deepest level we should do this test. Otherwise this
	     could happen: Let's say at a deeper node we discovered a mate,
	     which means retval is -INFTY when we reach this code. But that
	     might be for a few moves ahead of us (deeper in the search tree).
	     And at the CURRENT position (at THIS level in the tree, we are
	     not in check, and then we would falsely return 0 instead of
	     -INFTY. So therefore, if we return retval+1 at the checkmate
	     level, then we won't reach this code at a shallower level.
	     We also add the +(100-depth), to give shallower mates a worse
	     value than mates deeper down in the tree. */
	  retval = retval + 1 + (100-depth);     //check mate
	} else
	  retval = draw_score();         //stalemate
      }
      close_transposition((char) (depth+extension),board,&best_move,
			  (best_move.value > -INFTY ? 1 : 0),retval,
			  (retval <= org_alpha) ? ALPHA : EXACT);
      return retval;
    } else {   //nodetype == MINNODE
      /* Null-move pruning. Don't do null-move search at the first MINNODE-level.
	 (That's why we have (depth < org_depth-1)) */
      if (!in_check(board)) {
	if (!zugswang && null_ok && (depth > 0) && (depth < org_depth-1)) {
	  //if (!zugswang && null_ok && (depth > 0)) {
	  make_nullmove(board,&newpos);
	  /* Search with a minimal window around alpha. Values outside of the
	     minimal window are invalid. We record values below alpha in the
	     transposition table, since they are outside of the sought
	     range, and therefore doesn't need to be correct. However we
	     do not record values above alpha, since we will probably want to
	     have correct values in that interval later on in the search.
	     The best move will always be recorded though, no matter where
	     in the search we are. */
	  //nullmove = 1;
	  //null_low = -INFTY;
	  //null_high = alpha + 1;
	  a_val = alphabeta(&newpos,org_color,MAXNODE,alpha,alpha+1,
			    depth-1-R,org_depth,0);
	  //nullmove = 0;
	  if (a_val <= alpha) {
	    retval = a_val;
	    close_transposition((char)depth,board,&move,0,retval,ALPHA);
	    return retval;
	  }
	}
      } else
	extension = 1;

      while (get_next_move(board,moves,movables,&ref_val,&refmove,
			   &transp_val,&transpmove,killers[depth],
			   &move,&order,org_depth,depth)) {
	cutcount++;
	makemove(board,&newpos,move,depth);

	if (depth-1+extension <= 0) {
	  a_val = quiescence(&newpos,org_color,MAXNODE,alpha,beta,
			     move.tsquare);
	} else {
	  a_val = alphabeta(&newpos,org_color,MAXNODE,alpha,beta,
			    depth-1+extension,org_depth,1);
	}

	if (a_val != KINGTAKEN) {
	  if (a_val < retval)
	    best_move = move;
	  retval = min(retval,a_val);
	  beta = min(beta,retval);
	  if (retval <= alpha) {
	    cutoffs++;
	    if (cutcount == 1)
	      cutoffs_first++;
	    /* Here we got a cutoff, so we'll add this move as a killer.
	       Replace the best killer. (Not the worst one, because then
	       we don't get any rotation.) */
	    best = 0;
	    killers[depth][best].fsquare = move.fsquare;
	    killers[depth][best].tsquare = move.tsquare;
	    killers[depth][best].value = retval;
	    record_refutation((char)(depth+extension),board,&move,retval,ALPHA);
	    close_transposition((char)(depth+extension),board,&move,1,
				retval,ALPHA);
	    return retval;
	  }
	}
      }
      /* If we get here, and retval == INFTY, it means all possible moves
         from this position leads to a check position. If we are already in
         check, then it's mate. If we're not in check, then it's stalemate. */
      if (retval == INFTY) {
	if (in_check(board)) {
	  /* Return retval-1 instead of retval. That's because it's only
	     at the deepest level we should do this test. Otherwise this
	     could happen: Let's say at a deeper node we discovered a mate,
	     which means retval is INFTY when we reach this code. But that
	     might be for a few moves ahead of us (deeper in the search tree).
	     And at the CURRENT position (at THIS level in the tree, we are
	     not in check, and then we would falsely return 0 instead of
	     INFTY. So therefore, if we return retval-1 at the checkmate
	     level, then we won't reach this code at a shallower level.
	     We also add the -(100-depth), to give shallower mates a higher
	     value than mates deeper down in the tree. */
	  retval = retval - 1 - (100-depth);     //check mate
	} else {
	  retval = draw_score();         //stalemate
	}
      }
      close_transposition((depth+extension),board,&best_move,
			  (best_move.value < INFTY ? 1 : 0),retval,
			  (retval >= org_beta) ? BETA : EXACT);
      return retval;
    }
  }
}
