#ifndef _MISC_
#define _MISC_

#include "bitboards.h"

#define INFOLOGFILE "log.info"
#define DEBUGLOGFILE "log.debug"
#define RESULTLOGFILE "log.result"
#define TESTSUITELOGFILE "log.testsuite"
#define MYSELF "Amundsen"

#define PAWN 0
#define KNIGHT 1
#define BISHOP 2
#define ROOK 3
#define QUEEN 4
#define KING 5

#define EMPTY 7

#define VAL_PAWN 100
#define VAL_KNIGHT 300
#define VAL_BISHOP 300
#define VAL_ROOK 500
#define VAL_QUEEN 900
#define VAL_KING 10000

/*-----------------------------------------------------------------------
 | The variable CUT_BAD_MOVES_FROM_DEPTH tells at which search depth    |
 | the bad moves  (according to SEE) will be skipped. For example if    |
 | the variable has the value 2, it means that the engine will skip     |
 | searching all bad moves whenever (depth <= 2).                       |
 |                                                                      |
 | The variable CUT_NEUTRAL_MOVES_FROM_DEPTH works the same way as      |
 | the variable described above, but it concerns the "neutral" moves    |
 | (according to SEE).                                                  |
 |                                                                      |
 | For example if CUT_BAD_MOVES_FROM_DEPTH is 2, and                    |
 | CUT_NETURAL_MOVES_FROM_DEPTH is 1, and the engine is doing a 5 ply   |
 | search, then the first 3 plies will be a full search, and on the     |
 | fourth ply the bad moves will be skipped, and on the last ply both   |
 | the bad and the neutral moves will be skipped.                       |
 |                                                                      |
 | Note that the two first plies will always be search fully, no matter |
 | what value these variables have. To disable this cutting heuristics, |
 | the variables can be set to for example -99.                         |
 -----------------------------------------------------------------------*/

#define CUT_BAD_MOVES_FROM_DEPTH 2
#define CUT_NEUTRAL_MOVES_FROM_DEPTH -99

void infolog(const char *text);

void testsuitelog(const char *text);

void resultlog(int status, int color, int white, int black);

#ifdef AM_DEBUG
void debuglog(const char *text);
#endif

int draw_score(void);

/* This function reallocates the size of a list in the memory. */
int change_list_size(struct move **list, int new_size);

/* This method returns true(=1) if the king of the color at move is
   threatened. Else false(=0).*/
int in_check(struct board *board);

/* This function returns 1 if the move is legal, and 0 if it's illegal. */
int legal_move(struct move move_to_check, struct board *board);

/* This function returns 0 if game is not ended, 1 if stalemate,
   2 if check mate, 3 if draw by the 50 move rule, 4 if
   insufficient material, and 5 if draw by repetition */
int game_ended(struct board *board);

/* Prints out a move on the screen. */
void printmove(int color, struct move move);

/*--------------------------------------------
 | Define assorted macros.                   |
 --------------------------------------------*/
#define Color (board->color_at_move)
#define Oppcolor (1-board->color_at_move)

#endif      //_MISC_








