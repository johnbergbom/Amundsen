#ifndef _PARSE_
#define _PARSE_

#include "diverse.h"
#include "bitboards.h"

#define HUMAN 1
#define COMPUTER 2
#define WHITE 0
#define BLACK 1
#define BOOKSIZE 3144

void computer_make_move(struct board **board, int *vemstur, int *started);

int parsemove(char *input, struct board **board, int *vemstur, int *started);

void parse();

#endif      //_PARSE_
