#include "iterdeep.h"
#include <stdio.h>
#include "diverse.h"
#include "alfabeta.h"
#include "genmoves.h"
#include "timectrl.h"
#include "moves.h"
#include "parse.h"

/* If post is set, then we will send output of the progress of the search
   to xboard. */
int post = 0;

/* The variable re_search is used to notify the probing of the transposition
   table that the aspiration window failed, and that transposition table
   values outside of the original window are invalid. The variables
   prev_alpha and prev_beta respectively are used to tell the probing of the
   transposition table what the previous bounds were. */
int re_search, prev_alpha, prev_beta;

void iterative_deepening_aspiration_search(struct board *board,
					   int color, int movenumber,
					   struct move *movelist, int mcount) {
  struct move *bestmove;
  struct move *validmoves;
  struct board newpos;
  int bestvalue, b;
  struct move returnmove;
  int alpha = -INFTY, beta = INFTY;
  int valmax = -INFTY;
  int org_color = color;
  int i, j = 0;
  int prunetype;
  int nbr_moves = 0;
  int piecetype, boardpos, oppmovables = 0;
  bitboard pieces;
  struct moves oppmoves[16];
  int oppcolor = color;
  extern bitboard square[64];
  extern struct killers **killers;
  extern int xboard_mode;
  int depth;
  int branchfact;
  int nbrmoves1, nbrmoves2;
  int attempt_nbr;
  char *str;
  char *dragstr;
  //extern int lagge;

  switch_colors(&oppcolor);

  /* We reserve space for killers up to ply == depth, and that's allright,
     because we don't use killer moves in the quiescence search. */
  killers = (struct killers **) calloc(MAX_ITERATIONS,sizeof(struct killers *));
  for (i = 0; i < MAX_ITERATIONS; i++)
    killers[i] = (struct killers *) calloc(NBR_KILLERS,sizeof(struct killers));

  /* Calculate the average branching factor of searching the tree. */
  nbr_moves = mcount;
  nbrmoves1 = nbr_moves;   //one's own moves
  /* We will also calculate the opponent's moves. */
  if (generate_moves(board,oppcolor,oppmoves,&oppmovables) != 0) {
    /* The opponent could take our king, and when the move generation
       function discovers that, it quits immediately, without generating
       the rest of the moves. Therefore we don't know the opponent's
       branching factor, and therefore we set the branching factor to
       the number of moves oneself can do. */
    branchfact = nbrmoves1;
  } else {
    /* Count the number of possible moves for the opponent. */
    nbrmoves2 = 0;
    for (i = 0; i < oppmovables; i++)
      nbrmoves2 += bitcount(oppmoves[i].targets);
    branchfact = (nbrmoves1 + nbrmoves2) / 2;
  }
  printf("Branch factor = %d\n",branchfact);

  /* Go through the moves in the movelist and play them by calling
     alphabeta. Go deeper and deeper iteratively. */
  depth = 2;
  attempt_nbr = 1;
  re_search = 0;
  while (1) {
  //while (depth <= 6) {
    /* valmax has to be cleared (=-INFTY) for each new turn */
    valmax = -INFTY;
    for (mcount = 0; mcount < nbr_moves; mcount++) {

      /* Test code for printing out the moves the engine is processing. */
      /*dragstr = (char *) malloc(20*sizeof(char));
      move2str(color,movelist[mcount],dragstr);
      if (depth == 6 && strcmp(dragstr,"g5g7") == 0) {
	lagge = 1;
      } else
	lagge = 0;
      lagge = 0;
      if (lagge)
	printf("move %s(%d,%d) ",dragstr,alpha,beta);
	free(dragstr);*/

      makemove(board,&newpos,color,movelist[mcount],depth);
      movelist[mcount].value = alphabeta(&newpos,color,org_color,MIN,alpha,beta,depth-1,depth,1);
      //movelist[mcount].value = alphabeta(&newpos,color,org_color,MIN,-INFTY,INFTY,depth-1,depth,1);
      if (movelist[mcount].value != KINGTAKEN) {
	valmax = max(movelist[mcount].value,valmax);
      }
      /*if (lagge)
	printf("%d\n",movelist[mcount].value);*/
    }

    /* If we failed high, we set alpha to -INFTY, and keep beta the same.
       If we failed low, we set beta to INFTY, and keep alpha the same.
       This is so we won't keep failing high,low,high,low,... on the
       re-search. I have not done any extensive analysis of this.
       Re-searches seem to be faster most of the time if we don't strech
       out the window to infinity right away. First we try a smaller opening
       by using the variable attempt_nbr. */
    if (valmax <= alpha) {
      prev_alpha = alpha;
      prev_beta = beta;
      re_search = 1;
      if (attempt_nbr == 1) {
	attempt_nbr++;
	alpha = valmax - SECOND_ATTEMPT_VALWINDOW;
      } else {
	alpha = -INFTY;
	attempt_nbr = 1;
      }
      printf("R-alpha\n");
    } else if (valmax >= beta) {
      prev_alpha = alpha;
      prev_beta = beta;
      re_search = 1;
      if (attempt_nbr == 1) {
	attempt_nbr++;
	beta = valmax + SECOND_ATTEMPT_VALWINDOW;
      } else {
	beta = INFTY;
	attempt_nbr = 1;
      }
      printf("R-beta\n");
    } else {
      alpha = valmax - VALWINDOW;
      beta = valmax + VALWINDOW;
      re_search = 0;
      if (post) {   //then send output to xboard
	printf("%d %d 0 0 ",depth,valmax);
	str = (char *) malloc(100*sizeof(char));
	for (i = 0; i < nbr_moves; i++)
	  if (movelist[i].value == valmax) {
	    move2str(color,movelist[i],str);
	    printf("%s ",str);
	  }
	free(str);
	printf("\n");
      }
      if (time_is_up(movenumber,branchfact))
	//if (time_is_up(movenumber,branchfact) && depth >= 6)
	break;
      /* If there will be a draw, then we don't need to keep searching
	 any deeper. */
      if (board->moves_left_to_draw - depth <= 0 && valmax == 0)
	break;
      /* If we find a quick mate, then we don't need to bother searching
	 deeper. */
      if ((valmax < (-INFTY + 150)) || (valmax > (INFTY - 150)))
	break;
      if (depth == MAX_ITERATIONS)
	break;
      depth++;
      attempt_nbr = 1;
    }
  }
  clear_hashtable();

  if (depth >= MAX_ITERATIONS)
    debuglog("WE REACHED MAXIMUM ITERATIONS!");

  /* These are only used in the search, and they should be cleared before
     next search. */
  board->captures[WHITE] = 0;
  board->captures[BLACK] = 0;

  printf("Ply = %d\n",depth);

  for (i = 0; i < MAX_ITERATIONS; i++)
    free(killers[i]);
  free(killers);
}

