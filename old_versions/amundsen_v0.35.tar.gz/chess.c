#include <stdio.h>
#include "diverse.h"
#include "slump.h"
#include "bitboards.h"
#include "parse.h"
#include "transptable.h"

/*#include <sys/timeb.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>*/

int main(int argc, char **argv) {
  /*int i;
  struct timeb tp;
  struct timeval tval;
  struct timezone tzone;

  printf("Since 1970: %d\n",time(NULL));

  for (i = 0; i < 10; i++) {
    ftime(&tp);
    printf("time = %d, millitm = %d\n",tp.time,tp.millitm);
  }


  //tzone.tz_dsttime = DST_NONE;
  if (gettimeofday(&tval,&tzone) != 0)
    perror("Fel med tidtagningen");
  else {
    printf("sec = %d, usec = %d\n",tval.tv_sec,tval.tv_usec);
  }

  printf("usec = %d\n",tval.tv_usec);
  printf("usec / 1000 = %d\n",tval.tv_usec/1000);
  exit(0);*/




  setbuf(stdin,NULL);      //set unbuffered input
  setbuf(stdout,NULL);     //set unbuffered output

  debuglog("------------------------------");
  init_random_seed();
  set_bitboards();
  init_transptable();     //transposition
  printf("\nThis is Amundsen v. 0.35\n");
  printf("Copyright (C)2002-2003 John Bergbom\n");
  printf("\nType \'help\' for a list of commands.\n");

  parse();

  return 0;
}




