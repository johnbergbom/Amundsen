#include "diverse.h"
#include <stdio.h>
#include "parse.h"

void switch_colors(int *color) {
  if (*color == WHITE)
    *color = BLACK;
  else
    *color = WHITE;
}

void debuglog(char *text) {
  FILE *fp;
  char *filnamn = DEBUGLOGFILE;

  fp = fopen(filnamn,"a");
  if (fp == NULL)
    fprintf(stderr,"Could not open %s\n",DEBUGLOGFILE);
  fprintf(fp,"%s\n",text);
  fclose(fp);
}

/*void resultlog(int status, int color, int white, int black) {
  FILE *fp;
  char *filnamn = RESULTLOGFILE;
  char *str;
  
  str = (char *) malloc(100*sizeof(char));
  if (status == 2) {
    if ((color == WHITE && white == COMPUTER) || (color == BLACK && black == COMPUTER))
      sprintf(str,"%s lost.",MYSELF);
    else if ((color == BLACK && white == COMPUTER) || (color == WHITE && black == COMPUTER))
      sprintf(str,"%s won.",MYSELF);
  } else if (status == 1) {
    sprintf(str,"1/2-1/2 {Stalemate}");
  } else if (status == 3) {
    sprintf(str,"1/2-1/2 {50 move rule}");
  } else {
    sprintf(str,"1/2-1/2 {Insufficient material}");
  }

  fp = fopen(filnamn,"a");
  if (fp == NULL)
    fprintf(stderr,"Could not open %s\n",RESULTLOGFILE);
  fprintf(fp,"%s\n",str);
  fclose(fp);
  free(str);
  }*/



