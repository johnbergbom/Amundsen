#include "genmoves.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "bitboards.h"
#include "diverse.h"
#include "parse.h"
#include "transptable.h"

bitboard generate_pawnmoves(struct board *board, int color, int boardpos) {
  int64 targets;
  int oppcolor = color;
  extern bitboard square[64];
  extern bitboard pawn_start[2];
  extern bitboard pawn_passantrow[2];
  extern struct attack attack;

  switch_colors(&oppcolor);

  //if (boardpos > 55 || boardpos < 8)
  //printf("GENERATE_PAWNMOVES");

  if (color == WHITE) {
    /* White pawn goes one step forward. */
    targets = (square[boardpos] >> 8) &
      ~(board->all_pieces[WHITE] | board->all_pieces[BLACK]);
    if (square[boardpos] & pawn_start[WHITE]) //white pawn at starting square
      if (targets)    //the pawn can go one step forward
	/* White pawn goes two steps forward. */
	targets |= ((square[boardpos] >> 16) &
		    ~(board->all_pieces[WHITE]
		      | board->all_pieces[BLACK]));
  } else {    //color == BLACK
    /* BLACK pawn goes one step forward. */
    targets = (square[boardpos] << 8) &
      ~(board->all_pieces[WHITE] | board->all_pieces[BLACK]);
    if (square[boardpos] & pawn_start[BLACK]) //black pawn at starting square
      if (targets)    //the pawn can go one step forward
	/* BLACK pawn goes two steps forward. */
	targets |= ((square[boardpos] << 16) &
		    ~(board->all_pieces[WHITE]
		      | board->all_pieces[BLACK]));
  }

  /* We also need to add the capture moves. */
  targets |= (attack.pawn[color][boardpos] & board->all_pieces[oppcolor]);

  /* We also need to add the passant moves. */
  if (board->passant)
    targets |= (attack.pawn[color][boardpos] & square[board->passant]);

  return targets;
}

int get_pawnmove_movetype(struct board *board, int color, int boardpos, bitboard target) {
  int type;
  int oppcolor = color;
  extern bitboard pawn_lastrow[2];
  extern struct attack attack;

  switch_colors(&oppcolor);

  /* Find out what type of move it was. */
  if (target & board->all_pieces[oppcolor])
    type = CAPTURE_MOVE;
  else if (attack.pawn[color][boardpos] & target) {
    /* If the move is an attack to a square with no enemy piece
       occupying it. */
    type = CAPTURE_MOVE | PASSANT_MOVE;
  } else
    type = NORMAL_MOVE;
    
  /* If the pawn goes to the last row, then we set the move to be a
     queen promotion. Notice that we don't take care of different
     kinds of promotions. */
  if (target & pawn_lastrow[color])
    type |= QUEEN_PROMOTION_MOVE;
  return type;
}

bitboard generate_kingmoves(struct board *board, int color, int boardpos) {
  int64 targets;
  extern bitboard square[64];
  extern struct attack attack;

  targets = attack.king[boardpos] & (~board->all_pieces[color]);

  /* Check castling. */
  if (color == WHITE) {
    if (board->castling_status[WHITE] & SHORT_CASTLING_OK)
      /* Check if the squares between the king and the rook are empty. */
      if (((board->all_pieces[WHITE] | board->all_pieces[BLACK]) &
	   (square[61] | square[62])) == 0) {
	/* Make a final check to see if the king's square is in check,
	   or if the destination square is in check, or if the square in
	   between is in check. */
	if (!in_check(board,color)) {
	  board->piece[color][KING] = square[61];
	  if (!in_check(board,color)) {
	    board->piece[color][KING] = square[62];
	    if (!in_check(board,color))
	      targets = targets | square[62];
	  }
	  board->piece[color][KING] = square[60];
	}
      }
    if (board->castling_status[WHITE] & LONG_CASTLING_OK)
      /* Check if the squares between the king and the rook are empty. */
      if (((board->all_pieces[WHITE] | board->all_pieces[BLACK]) &
	   (square[57] | square[58] | square[59])) == 0) {
	/* Make a final check to see if the king's square is in check,
	   or if the destination square is in check, or if the square in
	   between is in check. */
	if (!in_check(board,color)) {
	  board->piece[color][KING] = square[59];
	  if (!in_check(board,color)) {
	    board->piece[color][KING] = square[58];
	    if (!in_check(board,color))
	      targets = targets | square[58];
	  }
	  board->piece[color][KING] = square[60];
	}
      }
  } else {    //color == BLACK
    if (board->castling_status[BLACK] & SHORT_CASTLING_OK)
      /* Check if the squares between the king and the rook are empty. */
      if (((board->all_pieces[WHITE] | board->all_pieces[BLACK]) &
	   (square[5] | square[6])) == 0) {
	/* Make a final check to see if the king's square is in check,
	   or if the destination square is in check, or if the square in
	   between is in check. */
	if (!in_check(board,color)) {
	  board->piece[color][KING] = square[5];
	  if (!in_check(board,color)) {
	    board->piece[color][KING] = square[6];
	    if (!in_check(board,color))
	      targets = targets | square[6];
	  }
	  board->piece[color][KING] = square[4];
	}
      }
    if (board->castling_status[BLACK] & LONG_CASTLING_OK)
      /* Check if the squares between the king and the rook are empty. */
      if (((board->all_pieces[WHITE] | board->all_pieces[BLACK]) &
	   (square[1] | square[2] | square[3])) == 0) {
	/* Make a final check to see if the king's square is in check,
	   or if the destination square is in check, or if the square in
	   between is in check. */
	if (!in_check(board,color)) {
	  board->piece[color][KING] = square[3];
	  if (!in_check(board,color)) {
	    board->piece[color][KING] = square[2];
	    if (!in_check(board,color))
	      targets = targets | square[2];
	  }
	  board->piece[color][KING] = square[4];
	}
      }
  }

  return targets;
}

int get_kingmove_movetype(struct board *board, int color, bitboard target) {
  extern bitboard square[64];
  int oppcolor = color;

  switch_colors(&oppcolor);

  /* Find out what type of move it was. */
  if (target & board->all_pieces[oppcolor])
    return CAPTURE_MOVE;
  else if ((color == WHITE && (board->piece[color][KING] & square[60])
	    && ((target & square[62]) || (target & square[58])))
	   || (color == BLACK && (board->piece[color][KING] & square[4])
	       && ((target & square[6]) || (target & square[2]))))
    return CASTLING_MOVE;
  else
    return NORMAL_MOVE;
}

bitboard generate_knight_moves(struct board *board, int color, int boardpos) {
  extern struct attack attack;

  return attack.knight[boardpos] & (~board->all_pieces[color]);
}

/* This function generates moves that go horizontally along the board.
   This function is needed for generating queen and rook moves. */
bitboard generate_horizontal_moves(struct board *board, int color, int boardpos) {
  int occupancy;
  extern struct attack attack;

  occupancy = ((board->all_pieces[WHITE]
		| board->all_pieces[BLACK]) >> ((boardpos/8)*8)) & 255;
  return attack.hslider[boardpos][occupancy] & (~board->all_pieces[color]);
}

/* This function returns the movetype of all pieces other than pawns
   and king. */
int get_othermove_movetype(struct board *board, int color, bitboard target) {
  int oppcolor = color;

  switch_colors(&oppcolor);

  /* Find out what type of move it was. */
  if (target & board->all_pieces[oppcolor])
    return CAPTURE_MOVE;
  else
    return NORMAL_MOVE;
}

/* This function generates moves that go vertically along the board.
   This function is needed for generating queen and rook moves. */
bitboard generate_vertical_moves(struct board *board, int color, int boardpos) {
  int occupancy;
  extern struct attack attack;
  extern int rotate0to90[64];

  /* We calculate the vertical moves (files) by using the rotated
     bitboard board.rot90_pieces, and getting the occupancy number of
     the file in question by reading off the occupancy of the rank in
     this rotated bitboard. Then we switch back to "unrotated" before
     we add the move to the movelist. */
  occupancy = ((board->rot90_pieces[WHITE]
		| board->rot90_pieces[BLACK]) >> (rotate0to90[boardpos]/8)*8) & 255;

  return attack.vslider[boardpos][occupancy] & (~board->all_pieces[color]);
}

/* This function generates moves that go diagonally along the board
   in the northeast direction (the a1-h8 diagonal). This function is
   needed for generating queen and bishop moves. */
bitboard generate_NEdiag_moves(struct board *board, int color, int boardpos) {
  int occupancy;
  extern struct attack attack;
  extern int rotate0toNE[64];
  extern int ones[9];
  extern int diagNE_start[64];
  extern int diagNE_length[64];

  occupancy = (board->rotNE_pieces[WHITE] | board->rotNE_pieces[BLACK]) >> (rotate0toNE[diagNE_start[boardpos]]) & ones[diagNE_length[boardpos]];
  return attack.sliderNE[boardpos][occupancy] & (~board->all_pieces[color]);
}

/* This function generates moves that go diagonally along the board
   in the northwest direction (the h1-a8 diagonal). This function is
   needed for generating queen and bishop moves. */
bitboard generate_NWdiag_moves(struct board *board, int color, int boardpos) {
  int occupancy;
  extern struct attack attack;
  extern int rotate0toNW[64];
  extern int ones[9];
  extern int diagNW_start[64];
  extern int diagNW_length[64];

  occupancy = (board->rotNW_pieces[WHITE] | board->rotNW_pieces[BLACK]) >> (rotate0toNW[diagNW_start[boardpos]]) & ones[diagNW_length[boardpos]];
  return attack.sliderNW[boardpos][occupancy] & (~board->all_pieces[color]);
}

/* This function returns moves to try in the quiescence search. If there
   are moves left 1 is returned, else 0 is returned. Moves are generated
   in the following order: 1. Hash moves, 2. Lower valued piece captures
   higher valued one, 3. Equal captures where there are more attackers than
   defenders, 4. Higher valued piece captures lower valued one, and more
   attackers than defenders */
int get_next_quiet_move(struct board *board, int color, struct moves *moves,
			int movables, int *hashval, struct move *hashmove,
			struct move *returnmove, int *order, bitboard target) {
  int i, j;
  int oppcolor = color;
  //bitboard enprise, best_enprise_pos = 0;
  //int best_enprise_piece;
  bitboard opp_pieces;
  extern int pieceval[6];

  switch_colors(&oppcolor);

  /* Extract the hashmove, if any. */
  if (*order == 0) {
    if (*hashval == HASH_MOVE) {
      for (i = 0; i < movables; i++)
	if (hashmove->fsquare & moves[i].source && hashmove->tsquare & moves[i].targets) {
	  returnmove->fsquare = hashmove->fsquare;
	  returnmove->tsquare = hashmove->tsquare;
	  returnmove->piece = moves[i].piece;
	  returnmove->type = get_movetype(board,color,
					  get_first_bitpos(returnmove->fsquare),
					  returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  (*order)++;
	  return 1;
	}
      /* If we don't find the hashmove in the movelist, it's not a serious
	 error. It probably means two different boards hashed to the same key.
	 Since that only happens once in a blue moon, we'll print out a
	 message here. */
      printf("HASHMOVE NOT FOUND.\n");
      debuglog("HASHMOVE NOT FOUND.");
      exit(1);
    }
    (*order)++;
  }

  /* Extract the moves where a lower valued piece captures a better one. */
  if (*order == 1) {
    /* Find the best piece to take. We take advantage of the fact that the
     moves are ordered in a lower valued piece -> higher valued piece fashion,
     to try the moves in an approximately MVV/LVA-order. And in order to make
     sure that knight takes bishop is not considered to be a lower valued
     one taking a higher valued one, we also have to make sure the piece-values
     are not the same. */
    for (j = QUEEN; j > PAWN; j--) {
      for (i = 0; i < movables && moves[i].piece < j; i++) {
	if (moves[i].targets & board->piece[oppcolor][j] && pieceval[moves[i].piece] < pieceval[j]) {
	  returnmove->piece = moves[i].piece;
	  returnmove->fsquare = moves[i].source;
	  returnmove->tsquare = getlsb(moves[i].targets
				       & board->piece[oppcolor][j]);
	  returnmove->type = get_movetype(board,color,
					  get_first_bitpos(returnmove->fsquare),					  returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  return 1;
	}
      }
    }

    /*for (i = 0; i < movables; i++) {
      for (j = QUEEN; j > moves[i].piece; j--) {
	if (moves[i].targets & board->piece[oppcolor][j] && pieceval[moves[i].piece] < pieceval[j]) {
	  //if (pieceval[moves[i].piece] > pieceval[j])
	  //printf("GR");
	  returnmove->piece = moves[i].piece;
	  returnmove->fsquare = moves[i].source;
	  returnmove->tsquare = getlsb(moves[i].targets
				       & board->piece[oppcolor][j]);
	  returnmove->type = get_movetype(board,color,
					  get_first_bitpos(returnmove->fsquare),					  returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  return 1;
	}
      }
      }*/
    (*order)++;
  }

  /* Extract the equal captures where there are more attackers than defenders.
     Make sure knights and bishops are considered equal. */
  if (*order == 2) {
    for (i = 0; i < movables; i++) {
      if (moves[i].piece == KNIGHT || moves[i].piece == BISHOP)
	opp_pieces = moves[i].targets
	  & (board->piece[oppcolor][KNIGHT] | board->piece[oppcolor][BISHOP]);
      else
	opp_pieces = moves[i].targets & board->piece[oppcolor][moves[i].piece];
      if (opp_pieces
	  && (get_number_of_defenders(board,color,getlsb(opp_pieces)) >
	      get_number_of_defenders(board,oppcolor,getlsb(opp_pieces)))) {
	/*if ((moves[i].targets & board->piece[oppcolor][moves[i].piece])
	  && (get_number_of_defenders(board,color,getlsb(moves[i].targets & board->piece[oppcolor][moves[i].piece])) > get_number_of_defenders(board,oppcolor,getlsb(moves[i].targets & board->piece[oppcolor][moves[i].piece])))) {*/
	returnmove->piece = moves[i].piece;
	returnmove->fsquare = moves[i].source;
	returnmove->tsquare = getlsb(opp_pieces);
	returnmove->type = get_movetype(board,color,
					get_first_bitpos(returnmove->fsquare),
					returnmove->piece,returnmove->tsquare);
	moves[i].targets &= ~(returnmove->tsquare);
	return 1;
      }
    }
    (*order)++;
  }

  /* Extract the moves where a higher valued piece captures a lower
     valued one, and there are more attackers than defenders. */
  if (*order == 3) {
    for (i = 0; i < movables; i++) {
      for (j = PAWN; j < moves[i].piece; j++) {
	if ((moves[i].targets & board->piece[oppcolor][j])
	    && (get_number_of_defenders(board,color,getlsb(moves[i].targets & board->piece[oppcolor][j])) > get_number_of_defenders(board,oppcolor,getlsb(moves[i].targets & board->piece[oppcolor][j])))) {
	  returnmove->piece = moves[i].piece;
	  returnmove->fsquare = moves[i].source;
	  returnmove->tsquare = getlsb(moves[i].targets
				       & board->piece[oppcolor][j]);
	  returnmove->type = get_movetype(board,color,
					  get_first_bitpos(returnmove->fsquare),
					  returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  return 1;
	}
      }
    }
    (*order)++;
  }

  /* Equal captures. */
  /*if (*order == 4) {
    for (i = 0; i < movables; i++) {
      if (moves[i].targets & board->piece[oppcolor][moves[i].piece] & target) {
	returnmove->piece = moves[i].piece;
	returnmove->fsquare = moves[i].source;
	returnmove->tsquare = getlsb(moves[i].targets & target
				     & board->piece[oppcolor][moves[i].piece]);
	returnmove->type = get_movetype(board,color,
					get_first_bitpos(returnmove->fsquare),
					returnmove->piece,returnmove->tsquare);
	moves[i].targets &= ~(returnmove->tsquare);
	return 1;
      }
    }
    (*order)++;
    }*/



  /* Extract the moves where a lower valued piece captures a better one
     on the target square. */
  /*if (*order == 1) {
    for (i = 0; i < movables; i++) {
      for (j = QUEEN; j > moves[i].piece; j--) {
	if (moves[i].targets & board->piece[oppcolor][j] & target) {
	  returnmove->piece = moves[i].piece;
	  returnmove->fsquare = moves[i].source;
	  returnmove->tsquare = getlsb(moves[i].targets
				       & board->piece[oppcolor][j] & target);
	  returnmove->type = get_movetype(board,color,
					  get_first_bitpos(returnmove->fsquare),					  returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  return 1;
	}
      }
    }
    (*order)++;
    }*/

  /* Extract the equal captures on the target square. */
  /*if (*order == 2) {
    for (i = 0; i < movables; i++) {
      if (moves[i].targets & board->piece[oppcolor][moves[i].piece] & target) {
	returnmove->piece = moves[i].piece;
	returnmove->fsquare = moves[i].source;
	returnmove->tsquare = getlsb(moves[i].targets & target
				     & board->piece[oppcolor][moves[i].piece]);
	returnmove->type = get_movetype(board,color,
					get_first_bitpos(returnmove->fsquare),
					returnmove->piece,returnmove->tsquare);
	moves[i].targets &= ~(returnmove->tsquare);
	return 1;
      }
    }
    (*order)++;
    }*/

  /* Extract the moves where a higher valued piece captures a lower
     valued one, and the capture takes place on the target square. */
  /*if (*order == 3) {
    for (i = 0; i < movables; i++) {
      for (j = PAWN; j < moves[i].piece; j++) {
	if (moves[i].targets & board->piece[oppcolor][j] & target) {
	  returnmove->piece = moves[i].piece;
	  returnmove->fsquare = moves[i].source;
	  returnmove->tsquare = getlsb(moves[i].targets
				       & board->piece[oppcolor][j] & target);
	  returnmove->type = get_movetype(board,color,
					  get_first_bitpos(returnmove->fsquare),					  returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  return 1;
	}
      }
    }
    (*order)++;
    }*/

  /* Check enprise moves, and return the one move that takes the highest
     valued enprise piece. */
  /*if (*order == 4) {
    enprise = (~get_attacking_squares(board,oppcolor)) & board->all_pieces[oppcolor];
    /* Find out which enprise piece has the highest value. /
    /*best_enprise_piece = -1;
    for (i = 0; i < movables; i++) {
      if (moves[i].targets & enprise)
	for (j = 0; j < 6; j++)
	  if (board->piece[oppcolor][j] & moves[i].targets & enprise) {
	    if (j > best_enprise_piece) {
	      best_enprise_piece = j;
	      best_enprise_pos = board->piece[oppcolor][j]
	                         & moves[i].targets & enprise;
	    }
	  }
	  }/

    //if (best_enprise_piece > -1) {
      for (i = 0; i < movables; i++) {
	//if (moves[i].targets & best_enprise_pos) {
	if (moves[i].targets & enprise) {
	  returnmove->fsquare = moves[i].source;
	  //returnmove->tsquare = getlsb(moves[i].targets
	  //		       & best_enprise_pos);
	  returnmove->tsquare = getlsb(moves[i].targets
				       & enprise);
	  returnmove->piece = moves[i].piece;
	  returnmove->type = get_movetype(board,color,
					  get_first_bitpos(returnmove->fsquare),
					  returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  //(*order)++;
	  return 1;
	}
      }
      //}
    (*order)++;
  }*/

  return 0;
}

/* This function returns 1 if there is moves left, and 0 if there are no
   moves left to generate. Moves are generated in the following order:
   1. Hash moves, 2. Lower valued piece captures higher valued one,
   3. Equal captures where there are more attackers than defenders,
   4. Higher valued piece captures a lower valued one, and more
   attackers than defenders, 5. Move one's best enprise piece into safety,
   6. Killer moves, 7. Other equal captures, 8. Non-captures,
   9. The rest (=bad captures according to SEE) */
int get_next_move(struct board *board, int color, struct moves *moves,
		  int movables, int *hashval, struct move *hashmove,
		  struct killers *killers, struct move *returnmove,
		  int *order) {
  int i, j, k_counter;
  int oppcolor = color;
  bitboard enprise, safe_square, opp_pieces;
  //extern int lagge6;
  //extern bitboard square[64];
  //extern int g1;
  extern int pieceval[6];

  switch_colors(&oppcolor);

  /* Extract the hashmove, if any. */
  if (*order == 0) {
    if (*hashval == HASH_MOVE) {
      /* Instead of taking the hash move directly, we extract it from
	 the move list. It's done this way for two reasons:
         - If the hash move doesn't cause a cutoff, we will have to search
	   the other moves in the list, and then the hash move will be
	   searched twice if it isn't removed from the list the first time.
	 - If two different boards happen to hash to the same key, the hash
	   move is probably invalid.
      */
      for (i = 0; i < movables; i++)
	if (hashmove->fsquare & moves[i].source && hashmove->tsquare & moves[i].targets) {
	  returnmove->fsquare = hashmove->fsquare;
	  returnmove->tsquare = hashmove->tsquare;
	  returnmove->piece = moves[i].piece;
	  returnmove->type = get_movetype(board,color,
					  get_first_bitpos(returnmove->fsquare),
					  returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  (*order)++;
	  return 1;
	}
      /* If we don't find the hashmove in the movelist, it's not a serious
	 error. It probably means two different boards hashed to the same key.
	 Since that only happens once in a blue moon, we'll print out a
	 message here. */
      printf("HASHMOVE NOT FOUND.\n");
      debuglog("HASHMOVE NOT FOUND.");
      exit(1);
    }
    (*order)++;
  }

  /* Check enprise moves, and return the one move that takes the highest
     valued enprise piece. */
  /*if (*order == 1) {
    enprise = (~get_attacking_squares(board,oppcolor)) & board->all_pieces[oppcolor];
    /* Find out which enprise piece has the highest value. /
    /*best_enprise_piece = -1;
    for (i = 0; i < movables; i++) {
      if (moves[i].targets & enprise)
	for (j = 0; j < 6; j++)
	  if (board->piece[oppcolor][j] & moves[i].targets & enprise) {
	    if (j > best_enprise_piece) {
	      best_enprise_piece = j;
	      best_enprise_pos = board->piece[oppcolor][j]
	                         & moves[i].targets & enprise;
	    }
	  }
	  }/

    //if (best_enprise_piece > -1) {
      for (i = 0; i < movables; i++) {
	//if (moves[i].targets & best_enprise_pos) {
	if (moves[i].targets & enprise) {
	  returnmove->fsquare = moves[i].source;
	  //returnmove->tsquare = getlsb(moves[i].targets
	  //		       & best_enprise_pos);
	  returnmove->tsquare = getlsb(moves[i].targets
				       & enprise);
	  returnmove->piece = moves[i].piece;
	  returnmove->type = get_movetype(board,color,
					  get_first_bitpos(returnmove->fsquare),
					  returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  return 1;
	}
      }
      //}
    (*order)++;
  }*/

  /* Extract the moves where a lower valued piece captures a better one. */
  if (*order == 1) {
    /* Find the best piece to take. We take advantage of the fact that the
     moves are ordered in a lower valued piece -> higher valued piece fashion,
     to try the moves in an approximately MVV/LVA-order. And in order to make
     sure that knight takes bishop is not considered to be a lower valued
     one taking a higher valued one, we also have to make sure the piece-values
     are not the same. */
    for (j = QUEEN; j > PAWN; j--) {
      for (i = 0; i < movables && moves[i].piece < j; i++) {
	if (moves[i].targets & board->piece[oppcolor][j] && pieceval[moves[i].piece] < pieceval[j]) {
	  returnmove->piece = moves[i].piece;
	  returnmove->fsquare = moves[i].source;
	  returnmove->tsquare = getlsb(moves[i].targets
				       & board->piece[oppcolor][j]);
	  returnmove->type = get_movetype(board,color,
					  get_first_bitpos(returnmove->fsquare),					  returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  return 1;
	}
      }
    }

    /*for (i = 0; i < movables; i++) {
      for (j = QUEEN; j > moves[i].piece; j--) {
	if (moves[i].targets & board->piece[oppcolor][j]) { // && pieceval[moves[i].piece] < pieceval[j]) {
	  returnmove->piece = moves[i].piece;
	  returnmove->fsquare = moves[i].source;
	  returnmove->tsquare = getlsb(moves[i].targets
				       & board->piece[oppcolor][j]);
	  returnmove->type = get_movetype(board,color,
					  get_first_bitpos(returnmove->fsquare),					  returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  return 1;
	}
      }
      }*/
    (*order)++;
  }

  /* Extract the equal captures where there are more attackers than defenders.
     Make sure knights and bishops are considered equal. */
  if (*order == 2) {
    for (i = 0; i < movables; i++) {
      if (moves[i].piece == KNIGHT || moves[i].piece == BISHOP)
	opp_pieces = moves[i].targets
	  & (board->piece[oppcolor][KNIGHT] | board->piece[oppcolor][BISHOP]);
      else
	opp_pieces = moves[i].targets & board->piece[oppcolor][moves[i].piece];
      if (opp_pieces
	  && (get_number_of_defenders(board,color,getlsb(opp_pieces)) >
	      get_number_of_defenders(board,oppcolor,getlsb(opp_pieces)))) {
	/*if ((moves[i].targets & board->piece[oppcolor][moves[i].piece])
	  && (get_number_of_defenders(board,color,getlsb(moves[i].targets & board->piece[oppcolor][moves[i].piece])) > get_number_of_defenders(board,oppcolor,getlsb(moves[i].targets & board->piece[oppcolor][moves[i].piece])))) {*/
	returnmove->piece = moves[i].piece;
	returnmove->fsquare = moves[i].source;
	returnmove->tsquare = getlsb(opp_pieces);
	returnmove->type = get_movetype(board,color,
					get_first_bitpos(returnmove->fsquare),
					returnmove->piece,returnmove->tsquare);
	moves[i].targets &= ~(returnmove->tsquare);
	return 1;
      }
    }
    (*order)++;
  }

  /* Extract the moves where a higher valued piece captures a lower
     valued one, and there are more attackers than defenders. */
  if (*order == 3) {
    for (i = 0; i < movables; i++) {
      for (j = PAWN; j < moves[i].piece; j++) {
	if ((moves[i].targets & board->piece[oppcolor][j])
	    && (get_number_of_defenders(board,color,getlsb(moves[i].targets & board->piece[oppcolor][j])) > get_number_of_defenders(board,oppcolor,getlsb(moves[i].targets & board->piece[oppcolor][j])))) {
	  returnmove->piece = moves[i].piece;
	  returnmove->fsquare = moves[i].source;
	  returnmove->tsquare = getlsb(moves[i].targets
				       & board->piece[oppcolor][j]);
	  returnmove->type = get_movetype(board,color,
					  get_first_bitpos(returnmove->fsquare),					  returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  return 1;
	}
      }
    }
    (*order)++;
  }

  /* Try a move that will move one's best enprise piece into safety.
     Note that we only try one such move. */
  if (*order == 4) {
    enprise = (~get_defending_squares(board,color)) & board->all_pieces[color]
      & get_defending_squares(board,oppcolor);
    if (enprise != 0) {
      safe_square = ~get_defending_squares(board,oppcolor);
      for (i = movables - 1; i >= 0; i--) {
      //for (i = 0; i < movables; i++) {
	if ((moves[i].source & enprise) && (moves[i].targets & safe_square)) {
	  returnmove->fsquare = moves[i].source;
	  returnmove->tsquare = getlsb(moves[i].targets & safe_square);
	  returnmove->piece = moves[i].piece;
	  returnmove->type = get_movetype(board,color,
					  get_first_bitpos(returnmove->fsquare),
					  returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  (*order)++;
	  return 1;
	}
      }
    }
    (*order)++;
  }

  /* Killer moves. */
  if (*order == 5) {
    for (k_counter = 0; k_counter < NBR_KILLERS; k_counter++) {
      for (i = 0; i < movables; i++) {
	if (moves[i].source & killers[k_counter].fsquare
	    && moves[i].targets & killers[k_counter].tsquare) {
	  returnmove->fsquare = moves[i].source;
	  returnmove->tsquare = getlsb(moves[i].targets & killers[k_counter].tsquare);
	  returnmove->piece = moves[i].piece;
	  returnmove->type = get_movetype(board,color,
					  get_first_bitpos(returnmove->fsquare),
					  returnmove->piece,returnmove->tsquare);
	  moves[i].targets &= ~(returnmove->tsquare);
	  return 1;
	}
      }
    }
    (*order)++;
  }

  /* Equal captures. Make sure knights and bishops are considered equal. */
  if (*order == 6) {
    for (i = 0; i < movables; i++) {
      if (moves[i].piece == KNIGHT || moves[i].piece == BISHOP)
	opp_pieces = moves[i].targets
	  & (board->piece[oppcolor][KNIGHT] | board->piece[oppcolor][BISHOP]);
      else
	opp_pieces = moves[i].targets & board->piece[oppcolor][moves[i].piece];
      if (opp_pieces) {
	returnmove->piece = moves[i].piece;
	returnmove->fsquare = moves[i].source;
	returnmove->tsquare = getlsb(opp_pieces);
	returnmove->type = get_movetype(board,color,
					get_first_bitpos(returnmove->fsquare),
					returnmove->piece,returnmove->tsquare);
	moves[i].targets &= ~(returnmove->tsquare);
	return 1;
      }
    }
    (*order)++;
  }

  /* Non-captures. */
  if (*order == 7) {
    for (i = 0; i < movables; i++) {
      if (moves[i].targets & ~(board->all_pieces[oppcolor])) {
	returnmove->fsquare = moves[i].source;
	returnmove->tsquare = getlsb(moves[i].targets
				     & ~(board->all_pieces[oppcolor]));
	returnmove->piece = moves[i].piece;
	returnmove->type = get_movetype(board,color,
					get_first_bitpos(returnmove->fsquare),
					returnmove->piece,returnmove->tsquare);
	moves[i].targets &= ~(returnmove->tsquare);
	return 1;
      }
    }
    (*order)++;
  }

  /* The rest of the moves, in no special ordering. */
  if (*order == 8) {
    for (i = 0; i < movables; i++) {
      if (moves[i].targets) {
	returnmove->fsquare = moves[i].source;
	returnmove->tsquare = getlsb(moves[i].targets);
	returnmove->piece = moves[i].piece;
	returnmove->type = get_movetype(board,color,
					get_first_bitpos(returnmove->fsquare),
					returnmove->piece,returnmove->tsquare);
	moves[i].targets &= ~(returnmove->tsquare);
	return 1;
      }
    }
    (*order)++;
  }
  return 0;
}

int get_movetype(struct board *board, int color, int boardpos, int piecetype, bitboard target) {
  if (piecetype == PAWN)
    return get_pawnmove_movetype(board,color,boardpos,target);
  else if (piecetype == KING)
    return get_kingmove_movetype(board,color,target);
  else
    return get_othermove_movetype(board,color,target);
}

/*int attackers(struct board *board, int color, bitboard target) {
  int piecetype, boardpos;
  bitboard pieces;
  int number = 0;
  extern bitboard square[64];
  //extern int g1;
  bitboard temp;
  int i;

  if (a1) {
    printf("color = %d, target = %d:\n",color,get_first_bitpos(target));
    showboard(board);
  }
  for (piecetype = 0; piecetype < 6; piecetype++) {
    pieces = board->piece[color][piecetype];
    /* Go through all the pieces for the given piecetype. /
    while (pieces != 0) {
      boardpos = get_first_bitpos(pieces);
      if (piecetype == PAWN) {
	number += bitcount(target & generate_pawnmoves(board,color,boardpos));
      } else if (piecetype == KNIGHT) {
	number += bitcount(target & generate_knight_moves(board,color,boardpos));
      } else if (piecetype == BISHOP) {
	number += bitcount(target & (generate_NEdiag_moves(board,color,boardpos)
				     | generate_NWdiag_moves(board,color,boardpos)));
      } else if (piecetype == ROOK) {
	number += bitcount(target & (generate_horizontal_moves(board,color,boardpos)
				      | generate_vertical_moves(board,color,boardpos)));
      } else if (piecetype == QUEEN) {
	number += bitcount(target & (generate_horizontal_moves(board,color,boardpos)
				      | generate_vertical_moves(board,color,boardpos)
				      | generate_NEdiag_moves(board,color,boardpos)
				      | generate_NWdiag_moves(board,color,boardpos)));
      } else if (piecetype == KING) {
	number += bitcount(target & generate_kingmoves(board,color,boardpos));
	if (a1) {
	  printf("\nKingmoves: ");
	  temp = generate_kingmoves(board,color,boardpos);
	  for (i = 63; i >= 0; i--) {
	    if (temp & square[i])
	      printf("1");
	    else
	      printf("0");
	  }
	  printf("\n");
	}
      }
      pieces &= ~square[boardpos];
    }
  }
  return number;
}*/

/* This function returns the number of pieces defending a certain square. */
int get_number_of_defenders(struct board *board, int color, bitboard target) {
  int piecetype, boardpos;
  bitboard pieces;
  extern bitboard square[64];
  int occupancy;
  extern struct attack attack;
  extern int rotate0toNE[64];
  extern int rotate0toNW[64];
  extern int rotate0to90[64];
  extern int ones[9];
  extern int diagNE_start[64];
  extern int diagNE_length[64];
  extern int diagNW_start[64];
  extern int diagNW_length[64];
  int number = 0;

  for (piecetype = 0; piecetype < 6; piecetype++) {
    pieces = board->piece[color][piecetype];
    /* Go through all the pieces for the given piece type. */
    while (pieces != 0) {
      boardpos = get_first_bitpos(pieces);

      if (piecetype == PAWN) {
	number += bitcount(attack.pawn[color][boardpos] & target);
      } else if (piecetype == KNIGHT) {
	number += bitcount(attack.knight[boardpos] & target);
      } else if (piecetype == BISHOP) {
	occupancy = (board->rotNE_pieces[WHITE] | board->rotNE_pieces[BLACK])
	  >> (rotate0toNE[diagNE_start[boardpos]]) & ones[diagNE_length[boardpos]];
	number += bitcount(attack.sliderNE[boardpos][occupancy] & target);
	occupancy = (board->rotNW_pieces[WHITE] | board->rotNW_pieces[BLACK])
	  >> (rotate0toNW[diagNW_start[boardpos]]) & ones[diagNW_length[boardpos]];
	number += bitcount(attack.sliderNW[boardpos][occupancy] & target);
      } else if (piecetype == ROOK) {
	occupancy = ((board->all_pieces[WHITE]
		      | board->all_pieces[BLACK]) >> ((boardpos/8)*8)) & 255;
	number += bitcount(attack.hslider[boardpos][occupancy] & target);
	occupancy = ((board->rot90_pieces[WHITE] | board->rot90_pieces[BLACK])
		     >> (rotate0to90[boardpos]/8)*8) & 255;
	number += bitcount(attack.vslider[boardpos][occupancy] & target);
      } else if (piecetype == QUEEN) {
	occupancy = ((board->all_pieces[WHITE]
		      | board->all_pieces[BLACK]) >> ((boardpos/8)*8)) & 255;
	number += bitcount(attack.hslider[boardpos][occupancy] & target);
	occupancy = ((board->rot90_pieces[WHITE] | board->rot90_pieces[BLACK])
		     >> (rotate0to90[boardpos]/8)*8) & 255;
	number += bitcount(attack.vslider[boardpos][occupancy] & target);
	occupancy = (board->rotNE_pieces[WHITE] | board->rotNE_pieces[BLACK])
	  >> (rotate0toNE[diagNE_start[boardpos]]) & ones[diagNE_length[boardpos]];
	number += bitcount(attack.sliderNE[boardpos][occupancy] & target);
	occupancy = (board->rotNW_pieces[WHITE] | board->rotNW_pieces[BLACK])
	  >> (rotate0toNW[diagNW_start[boardpos]]) & ones[diagNW_length[boardpos]];
	number += bitcount(attack.sliderNW[boardpos][occupancy] & target);
      } else if (piecetype == KING) {
	number += bitcount(attack.king[boardpos] & target);
      }
      pieces &= ~square[boardpos];
    }
  }
  return number;
}

/* This function returns the squares that a player is defending, and returns
   the squares in a bitboard. Note the slight difference between defending
   and attacking. Pieces of the same color cannot attack each other,
   however they can defend each other. A piece can also defend a square
   that's occupied by a piece of opposite color. */
bitboard get_defending_squares(struct board *board, int color) {
  int piecetype, boardpos;
  bitboard pieces, targets = 0;
  extern bitboard square[64];
  //extern struct attack attack;

  int occupancy;
  extern struct attack attack;
  extern int rotate0toNE[64];
  extern int rotate0toNW[64];
  extern int rotate0to90[64];
  extern int ones[9];
  extern int diagNE_start[64];
  extern int diagNE_length[64];
  extern int diagNW_start[64];
  extern int diagNW_length[64];

  for (piecetype = 0; piecetype < 6; piecetype++) {
    pieces = board->piece[color][piecetype];
    /* Go through all the pieces for the given piece type. */
    while (pieces != 0) {
      boardpos = get_first_bitpos(pieces);

      if (piecetype == PAWN) {
	//targets |= generate_pawnmoves(board,color,boardpos);
	targets |= attack.pawn[color][boardpos];
      } else if (piecetype == KNIGHT) {
	//targets |= generate_knight_moves(board,color,boardpos);
	targets |= attack.knight[boardpos];
      } else if (piecetype == BISHOP) {
	//targets |= generate_NEdiag_moves(board,color,boardpos)
	//| generate_NWdiag_moves(board,color,boardpos);
	occupancy = (board->rotNE_pieces[WHITE] | board->rotNE_pieces[BLACK])
	  >> (rotate0toNE[diagNE_start[boardpos]]) & ones[diagNE_length[boardpos]];
	targets |= attack.sliderNE[boardpos][occupancy];
	occupancy = (board->rotNW_pieces[WHITE] | board->rotNW_pieces[BLACK])
	  >> (rotate0toNW[diagNW_start[boardpos]]) & ones[diagNW_length[boardpos]];
	targets |= attack.sliderNW[boardpos][occupancy];
      } else if (piecetype == ROOK) {
	//targets |= generate_horizontal_moves(board,color,boardpos)
	//| generate_vertical_moves(board,color,boardpos);
	occupancy = ((board->all_pieces[WHITE]
		      | board->all_pieces[BLACK]) >> ((boardpos/8)*8)) & 255;
	targets |= attack.hslider[boardpos][occupancy];
	occupancy = ((board->rot90_pieces[WHITE] | board->rot90_pieces[BLACK])
		     >> (rotate0to90[boardpos]/8)*8) & 255;
	targets |= attack.vslider[boardpos][occupancy];
      } else if (piecetype == QUEEN) {
	//targets |= generate_horizontal_moves(board,color,boardpos)
	//| generate_vertical_moves(board,color,boardpos)
	//| generate_NEdiag_moves(board,color,boardpos)
	//| generate_NWdiag_moves(board,color,boardpos);
	occupancy = ((board->all_pieces[WHITE]
		      | board->all_pieces[BLACK]) >> ((boardpos/8)*8)) & 255;
	targets |= attack.hslider[boardpos][occupancy];
	occupancy = ((board->rot90_pieces[WHITE] | board->rot90_pieces[BLACK])
		     >> (rotate0to90[boardpos]/8)*8) & 255;
	targets |= attack.vslider[boardpos][occupancy];
	occupancy = (board->rotNE_pieces[WHITE] | board->rotNE_pieces[BLACK])
	  >> (rotate0toNE[diagNE_start[boardpos]]) & ones[diagNE_length[boardpos]];
	targets |= attack.sliderNE[boardpos][occupancy];
	occupancy = (board->rotNW_pieces[WHITE] | board->rotNW_pieces[BLACK])
	  >> (rotate0toNW[diagNW_start[boardpos]]) & ones[diagNW_length[boardpos]];
	targets |= attack.sliderNW[boardpos][occupancy];
      } else if (piecetype == KING) {
	//targets |= generate_kingmoves(board,color,boardpos);
	targets |= attack.king[boardpos];
      }
      pieces &= ~square[boardpos];
    }
  }
  return targets;
}

/* This function returns all pseudo-legal moves in a given position.
   Pseudo-legal move generation means that no checking is done to see
   if the move places it's own king in check. That has to be checked
   elsewhere.
     This function returns 0 on no error, and -1 on error, which is if
   the opposite king can be taken.
     There is at most 16 pieces of one color, so struct moves *moves needs
   to have room for 16 entries, and no more. */
int generate_moves(struct board *board, int color, struct moves *moves, int *movables) {
  int piecetype, boardpos;
  bitboard pieces;
  int oppcolor = color;
  extern bitboard square[64];

  switch_colors(&oppcolor);
  *movables = 0;

  for (piecetype = 0; piecetype < 6; piecetype++) {
    pieces = board->piece[color][piecetype];
    /* Go through all the pieces for the given piece type. */
    while (pieces != 0) {
      boardpos = get_first_bitpos(pieces);

      if (piecetype == PAWN) {
	moves[*movables].targets =
	  generate_pawnmoves(board,color,boardpos);
      } else if (piecetype == KNIGHT) {
	moves[*movables].targets = generate_knight_moves(board,color,boardpos);
      } else if (piecetype == BISHOP) {
	moves[*movables].targets = generate_NEdiag_moves(board,color,boardpos)
	  | generate_NWdiag_moves(board,color,boardpos);
      } else if (piecetype == ROOK) {
	moves[*movables].targets =
	  generate_horizontal_moves(board,color,boardpos)
	  | generate_vertical_moves(board,color,boardpos);
      } else if (piecetype == QUEEN) {
	moves[*movables].targets =
	  generate_horizontal_moves(board,color,boardpos)
	  | generate_vertical_moves(board,color,boardpos)
	  | generate_NEdiag_moves(board,color,boardpos)
	  | generate_NWdiag_moves(board,color,boardpos);
      } else if (piecetype == KING) {
	moves[*movables].targets = generate_kingmoves(board,color,boardpos);
      }

      if (moves[*movables].targets & board->piece[oppcolor][KING])
	return -1;
      /* Only add this piece if it can go somewhere. */
      if (moves[*movables].targets != 0) {
	moves[*movables].source = square[boardpos];
	moves[*movables].piece = piecetype;
	(*movables)++;
      }
      pieces = pieces & ~square[boardpos];
    }
  }

  return 0;
}

