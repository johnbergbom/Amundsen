#ifndef _BITBOARDS_
#define _BITBOARDS_

typedef long long int int64;
typedef int64 bitboard;

#define LONG_CASTLING_OK 1
#define SHORT_CASTLING_OK 2
#define CASTLED 4

struct board {
  /* piece: 2 colors, black or white, and then 6 types of pieces
     of each color */
  bitboard piece[2][6];

  bitboard all_pieces[2];
  bitboard rot90_pieces[2];   //pieces that are rotated 90 degrees
  bitboard rotNE_pieces[2];   //board that is rotated to northeast (a1-h8 diag)
  bitboard rotNW_pieces[2];   //board that is rotated to northwest (h1-a8 diag)

  int castling_status[2];     //describes castling status (see #define-clause above)
  int passant;                //indicates if passant move is possible
  int captures[2];            //used for determining at what depth a piece is captured
  int moves_left_to_draw;     //used to implement the 50-move-rule
  int64 zobrist_key;          //used for the transposition table     //transposition
};

/* The attackstruct is a database of bitboards representing the
   squares attacked by a certain piece on a certain square. */
struct attack {
  /* Piece color is irrelevant except for pawns which move in
     opposite directions. */
  bitboard pawn[2][64];
  bitboard hslider[64][256];
  bitboard vslider[64][256];

  /* Attack bitboards for diagonals in the a1-h8 direction. */
  bitboard sliderNE[64][256];

  /* Attack bitboards for diagonals in the a8-h1 direction. */
  bitboard sliderNW[64][256];

  bitboard knight[64];
  bitboard king[64];
};

#define NORMAL_MOVE 1
#define CAPTURE_MOVE 2
#define CASTLING_MOVE 4
#define PASSANT_MOVE 8
#define QUEEN_PROMOTION_MOVE 16
#define ROOK_PROMOTION_MOVE 32
#define BISHOP_PROMOTION_MOVE 64
#define KNIGHT_PROMOTION_MOVE 128
//#define PROMOTION_MOVE (QUEEN_PROMOTION_MOVE | ROOK_PROMOTION_MOVE | BISHOP_PROMOTION_MOVE | KNIGHT_PROMOTION_MOVE)
#define PROMOTION_MOVE 240

struct move {
  bitboard fsquare;   //from square
  bitboard tsquare;   //to square
  int piece;          //which kind of piece made the move?
  int type;           //type of move (see #define-clause above)
  int value;          //how good is the move?
};

void set_bitboards();

/* Initializes the board to the starting position. */
void set_board(struct board *board);

/* This function returns the number of bits that are set in an int64. */
int bitcount(int64 n);

/* This function returns the lowest set one bit of a number. */
#define getlsb(w)    ((w) & (~(w) + 1))

/* This function returns the number of the first set bit in an int64.
   The search is done from LSB to MSB. */
int get_first_bitpos(int64 n);

/* This function returns the position of the first bit that is set.
   We search from LSB to MSB. -1 is returned if no bit is set. */
int fbit(int64 bitpattern);


#endif       //_BITBOARDS_








