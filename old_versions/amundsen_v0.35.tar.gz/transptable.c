#include "transptable.h"
#include "bitboards.h"
#include "parse.h"
#include "alfabeta.h"
#include <stdlib.h>

int64 CHANGE_COLOR;

struct hashentry *table;
int64 zobrist[6][2][64];
int64 zobrist_castling[2][5];
int64 zobrist_passant[64];
unsigned char sequence;

//Statistics for entire search
int rhits = 0;    //hits that return a score
int mhits = 0;    //hits that return a move
int misses = 0;
int probes = 0;

//Statistics for quiescence search
int q_rhits = 0;    //hits that return a score
int q_mhits = 0;    //hits that return a move
int q_misses = 0;
int q_probes = 0;

int use_hash;

int64 rand64() {
  return rand() ^ ((int64) rand() << 15) ^ ((int64) rand() << 30)
    ^ ((int64) rand() << 45) ^ ((int64) rand() << 60);
}

void turn_on_hash() {
  use_hash = 1;
}

void turn_off_hash() {
  use_hash = 0;
}

void init_transptable() {
  int i, j, k;

  table = (struct hashentry *) malloc(NBR_ENTRIES*sizeof(struct hashentry));
  sequence = 255;
  clear_hashtable();
  turn_on_hash();
  for (i = 0; i < 6; i++)
    for (j = 0; j < 2; j++)
      for (k = 0; k < 64; k++)
	zobrist[i][j][k] = rand64();
  zobrist_castling[WHITE][0] = rand64();
  zobrist_castling[WHITE][LONG_CASTLING_OK] = rand64();
  zobrist_castling[WHITE][SHORT_CASTLING_OK] = rand64();
  zobrist_castling[WHITE][LONG_CASTLING_OK | SHORT_CASTLING_OK] = rand64();
  zobrist_castling[WHITE][CASTLED] = rand64();
  zobrist_castling[BLACK][0] = rand64();
  zobrist_castling[BLACK][LONG_CASTLING_OK] = rand64();
  zobrist_castling[BLACK][SHORT_CASTLING_OK] = rand64();
  zobrist_castling[BLACK][LONG_CASTLING_OK | SHORT_CASTLING_OK] = rand64();
  zobrist_castling[BLACK][CASTLED] = rand64();
  for (i = 0; i < 64; i++)
    zobrist_passant[i] = rand64();
  CHANGE_COLOR = rand64();
  j = NBR_ENTRIES*sizeof(struct hashentry);
  printf("size of hashtable = %d kb\n",j/1024);
}

int64 get_zobrist_key_for_board(struct board *board, int color_to_move) {
  int64 zobrist_key = 0;
  bitboard pieces;
  extern bitboard square[64];
  int i, j, square_nbr;

  for (i = 0; i < 2; i++) {
    for (j = 0; j < 6; j++) {
      pieces = board->piece[i][j];
      while (pieces != 0) {
	square_nbr = get_first_bitpos(pieces);
	zobrist_key ^= zobrist[j][i][square_nbr];
	pieces &= ~square[square_nbr];
      }
    }
  }
  zobrist_key ^= zobrist_castling[WHITE][board->castling_status[WHITE]];
  zobrist_key ^= zobrist_castling[BLACK][board->castling_status[BLACK]];
  zobrist_key ^= zobrist_passant[board->passant];
  return zobrist_key;
}

void clear_hashtable() {
  int i;

  if (sequence < 255)
    sequence++;
  else {
    sequence = 1;
    for (i = 0; i < NBR_ENTRIES; i++) {
      table[i].lock = 0;
      table[i].sequence = 0;
    }
  }
}

/* The argument can't be a normal int64, because that could give us
   a negative hash key. So we have to use unsigned. */
int get_hashkey(unsigned long long int zobrist_key) {
  return (zobrist_key & ((1<<NBR_BITS)-1));
}

int probe_hash(char depth, struct board *board, struct move *move,
	       int *alpha, int *beta, int *retval, char quiescence) {
  extern bitboard square[64];
  struct hashentry *entry;
  extern int re_search;
  extern int prev_alpha;
  extern int prev_beta;

  probes++;
  if (quiescence)
    q_probes++;
  entry = &(table[get_hashkey(board->zobrist_key)]);
  if (entry->lock == board->zobrist_key) {
    /* Only take the hash value if it's at the same depth, or deeper than
       the current depth, or if it is in quiescence search return the hash
       value no matter what the depth is. */
    if (((!quiescence) && (entry->depth >= depth) && ((entry->status & QUIESCENCE) == 0))
	|| (quiescence && (entry->status & QUIESCENCE))) {
      rhits++;
      if (quiescence)
	q_rhits++;

      /* If the aspiration search failed, then we can't trust values that are
	 outside of the original search window. If however we are outside the
	 alpha-beta bounds but on the "right" side (the side that didn't get
	 expanded) a cutoff should be safe. (?) */
      if (re_search) {
	/*if ((entry->status & EXACT)
	    && (prev_alpha < entry->value && entry->value < prev_beta))
	    return entry->value;*/
	if ((entry->status & EXACT)
	    && ((prev_alpha <= entry->value && entry->value <= prev_beta)
		|| (entry->value <= (*alpha) && (*alpha) == prev_alpha)
		|| (entry->value >= (*beta) && (*beta) == prev_beta)))
		return entry->value;
	/*if (entry->status & ALPHA
	    && prev_alpha < entry->value && entry->value < prev_beta) {
	  *retval = entry->value;
	  *beta = min(*beta,*retval);
	  }*/
	if (entry->status & ALPHA) {
	  if (entry->value <= (*alpha) && (*alpha) == prev_alpha)
	    return entry->value;
	  else if (prev_alpha <= entry->value && entry->value <= prev_beta) {
	    *retval = entry->value;
	    *beta = min(*beta,*retval);
	  }
	}
	/*if (entry->status & BETA
	    && prev_alpha < entry->value && entry->value < prev_beta) {
	  *retval = entry->value;
	  *alpha = max(*alpha,*retval);
	  }*/
	if (entry->status & BETA) {
	  if (entry->value >= (*beta) && (*beta) == prev_beta)
	    return entry->value;
	  else if (prev_alpha <= entry->value && entry->value <= prev_beta) {
	    *retval = entry->value;
	    *alpha = max(*alpha,*retval);
	  }
	}
      } else {
	if (entry->status & EXACT)
	  return entry->value;
	if (entry->status & ALPHA) {
	  if (entry->value <= (*alpha)) {
	    return entry->value;
	  } else {
	    *retval = entry->value;
	    *beta = min(*beta,*retval);
	  }
	}
	if (entry->status & BETA) {
	  if (entry->value >= (*beta))
	    return entry->value;
	  else {
	    *retval = entry->value;
	    *alpha = max(*alpha,*retval);
	  }
	}
      }
      rhits--;
      if (quiescence)
	q_rhits--;
    }
    if (entry->status & BEST_MOVE) {
      mhits++;
      if (quiescence)
	q_mhits++;
      (*move).fsquare = square[entry->bestmove_fsquare];
      (*move).tsquare = square[entry->bestmove_tsquare];
      return HASH_MOVE;
    }
  }
  misses++;
  if (quiescence)
    q_misses++;
  return UNKNOWN;
}

void record_hash(char depth, struct board *board, struct move move,
		 char is_best_move, int value, char flag, char quiescence) {
  struct hashentry *entry;

  entry = &(table[get_hashkey(board->zobrist_key)]);
  /* Only replace if same depth or deeper, or if the element pertains to
     an ancient search, or if it is quiescence we should always replace. */
  if (((!quiescence) && ((depth >= entry->depth) || (sequence > entry->sequence))) || quiescence) {
    entry->lock = board->zobrist_key;
    entry->status = 0;
    if (is_best_move) {
      entry->status |= BEST_MOVE;
      entry->bestmove_fsquare = get_first_bitpos(move.fsquare);
      entry->bestmove_tsquare = get_first_bitpos(move.tsquare);
    } else
      entry->status &= ~BEST_MOVE;
    if (quiescence)
      entry->status |= QUIESCENCE;
    entry->value = value;
    entry->depth = depth;
    entry->status |= flag;
    entry->sequence = sequence;
  }
}

