#ifndef _TRANSPTABLE_
#define _TRANSPTABLE_

#include "bitboards.h"

/* 18 bits in the hashtable is 262144 entries. */
#define NBR_BITS 19
//#define NBR_BITS 8
#define NBR_ENTRIES (1<<NBR_BITS)

#define UNKNOWN 2000000
#define HASH_MOVE 2000001

#define BEST_MOVE 1
#define EXACT 4
#define ALPHA 8
#define BETA 16
#define QUIESCENCE 32

struct hashentry {
  int64 lock;
  int value;
  char depth;
  unsigned char sequence;
  char status;
  char bestmove_fsquare;
  char bestmove_tsquare;
};

int64 rand64();
void turn_on_hash();
void turn_off_hash();
void init_transptable();
int64 get_zobrist_key_for_board(struct board *board, int color_to_move);
void clear_hashtable();
int probe_hash(char depth, struct board *board, struct move *move,
	       int *alpha, int *beta, int *retval, char quiescence);
void record_hash(char depth, struct board *board, struct move move,
		 char is_best_move, int value, char flag, char quiescence);

#endif      //_TRANSPTABLE_
