#ifndef _DIVERSE_
#define _DIVERSE_

#define DEBUGLOGFILE "log.debug"
#define RESULTLOGFILE "log.result"
#define MYSELF "Amundsen"

#define PAWN 0
#define KNIGHT 1
#define BISHOP 2
#define ROOK 3
#define QUEEN 4
#define KING 5

#define EMPTY 7

#define VAL_PAWN 100
#define VAL_KNIGHT 300
#define VAL_BISHOP 300
#define VAL_ROOK 500
#define VAL_QUEEN 900
#define VAL_KING 10000

void switch_colors(int *color);

void debuglog(char *text);
//void resultlog(int status, int color, int white, int black);

#endif      //_DIVERSE_






