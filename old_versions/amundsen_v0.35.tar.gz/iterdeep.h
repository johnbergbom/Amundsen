#ifndef _ITERDEEP_
#define _ITERDEEP_

#include "bitboards.h"
#include "diverse.h"

#define VALWINDOW (VAL_PAWN/2)
#define SECOND_ATTEMPT_VALWINDOW (VAL_PAWN)
#define MAX_ITERATIONS 40

void iterative_deepening_aspiration_search(struct board *board,
					   int color, int movenumber,
					   struct move *movelist, int mcount);

#endif        //_ITERDEEP_

