#include "display.h"
#include <stdio.h>
#include "symboler.h"
#include "bitboards.h"
//#include "diverse.h"
#include "parse.h"
#include "alfabeta.h"

char getPieceLetter(int piece) {
  switch(piece) {
    case PAWN : return 'p';
                break;
    case ROOK : return 'R';
                break;
    case KNIGHT : return 'N';
                  break;
    case BISHOP : return 'B';
                  break;
    case QUEEN : return 'Q';
                 break;
    case KING : return 'K';
                break;
    case EMPTY : return ' ';
                 break;
  }
  return '?';
}

void showboard(struct board *board) {
  int rad = 0, kol = 0;
  int temp[64];
  int i, square_nbr;
  int64 pieces;
  extern bitboard square[64];

  for (kol = 0; kol < 64; kol++)
    temp[kol] = EMPTY;

  for (i = 0; i < 6; i++) {
    pieces = board->piece[WHITE][i];
    while (pieces != 0) {
      square_nbr = get_first_bitpos(pieces);
      if (i == PAWN)
	temp[square_nbr] = PAWN;
      else if (i == ROOK)
	temp[square_nbr] = ROOK;
      else if (i == KNIGHT)
	temp[square_nbr] = KNIGHT;
      else if (i == BISHOP)
	temp[square_nbr] = BISHOP;
      else if (i == QUEEN)
	temp[square_nbr] = QUEEN;
      else if (i == KING)
	temp[square_nbr] = KING;
      pieces = pieces & ~square[square_nbr];
    }
  }

  for (i = 0; i < 6; i++) {
    pieces = board->piece[BLACK][i];
    while (pieces != 0) {
      square_nbr = get_first_bitpos(pieces);
      if (i == PAWN)
	temp[square_nbr] = PAWN;
      else if (i == ROOK)
	temp[square_nbr] = ROOK;
      else if (i == KNIGHT)
	temp[square_nbr] = KNIGHT;
      else if (i == BISHOP)
	temp[square_nbr] = BISHOP;
      else if (i == QUEEN)
	temp[square_nbr] = QUEEN;
      else if (i == KING)
	temp[square_nbr] = KING;
      pieces = pieces & ~square[square_nbr];
    }
  }

  printf("  ---------------------------------\n");
  for (rad = 0; rad < 8; rad++) {
    printf("%d ",8 - rad);
    for (kol = 0; kol < 8; kol++) {
      printf("|");
      //if (temp[rad*8 + kol] > 0)
      //INVERT;
      if (board->piece[WHITE][temp[rad*8+kol]] & square[rad*8+kol])
	INVERT;
      printf(" %c ",getPieceLetter(temp[rad*8 + kol]));
      NORMAL;
    }
    printf("|\n");
    if (rad < 7)
      printf("  |---+---+---+---+---+---+---+---|\n");
  }
  printf("  ---------------------------------\n");
  printf("    A   B   C   D   E   F   G   H\n");
}

void showsettings(int *white, int *black, int *vemstur, int *started) {
  //int i;

  printf("Vit     : ");
  if (*white == COMPUTER)
    printf("dator\n");
  else
    printf("m�nniska\n");
  printf("Svart   : ");
  if (*black == COMPUTER)
    printf("dator\n");
  else
    printf("m�nniska\n");
  printf("Vems tur: ");
  if (*vemstur == WHITE)
    printf("vit\n");
  else
    printf("svart\n");
  printf("Algoritm: ");
    printf("alfa-beta besk�rning (t�nker %.1f drag fram�t)\n",(double)THINKFORWARD/2);
  if (!*started)
    printf("\nParti ej startat.\n");
}

void showhelp() {
  printf("\nCommand:    Meaning:\n\n");
  printf("show         Draw the board\n");
  printf("start        Start a new game\n");
  //printf("tanke      Skriv ut hur datorn t�nkte\n");
  printf("hist         Show move history\n");
  printf("set          Show settings\n");
  printf("enginewhite  Computer plays white\n");
  printf("humanwhite   Human plays white (default)\n");
  printf("engineblack  Computer plays black (default)\n");
  printf("humanblack   Human plays black\n");
  printf("xboard       enter xboard-mode\n\n");

  printf("?            Show help\n");
  printf("help         Show help\n");
  printf("quit         Quit the program\n\n");

  printf("If you make a move, it should be written in the form\n");
  printf("e2e4 for normal moves, and a7a8[q|r|b|n] for pawn promotions.\n");
}


