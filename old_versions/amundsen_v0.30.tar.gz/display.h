#ifndef _DISPLAY_
#define _DISPLAY_

#include "bitboards.h"

char getPieceLetter(int piece);

void showboard(struct board *board);

void showsettings(int *white, int *black, int *vemstur, int *started);

void showhelp();

#endif      //_DISPLAY_
