#include "iterdeep.h"
#include <stdio.h>
#include "diverse.h"
#include "alfabeta.h"
#include "genmoves.h"
#include "timectrl.h"
#include "moves.h"
#include "parse.h"

/* If post is set, then we will send output of the progress of the search
   to xboard. */
int post = 0;

void iterative_deepening_aspiration_search(struct board *board,
					   int color, int movenumber,
					   struct move *movelist, int mcount) {
  //struct move *movelist;
  struct move *bestmove;
  struct move *validmoves;
  struct board newpos;
  //int mcount = 0;
  int bestvalue, b;
  struct move returnmove;
  int alpha = -INFTY, beta = INFTY;
  int valmax = -INFTY;
  int org_color = color;
  int i, j = 0;
  char *dragstr;
  int prunetype;
  int nbr_moves = 0;
  int piecetype, boardpos, oppmovables = 0;
  bitboard pieces;
  //struct moves moves[16];
  struct moves oppmoves[16];
  int oppcolor = color;
  extern bitboard square[64];
  extern bitboard *killers;
  extern int xboard_mode;
  int depth;
  int branchfact;
  int nbrmoves1, nbrmoves2;
  int attempt_nbr;
  //extern int sequence;     //TRANSPOSITION
  //extern int lagge;
  char *str;
  //extern int R;  //reduction factor for null-move pruning

  //*mcount = 0;
  switch_colors(&oppcolor);

  /* We reserve space for killers up to ply == depth, and that's allright,
     because we don't use killer moves in the quiescence search. */
  killers = (bitboard *) calloc(MAX_ITERATIONS,sizeof(bitboard)); //calloc clears mem

  /* Calculate the average branching factor of searching the tree. */
  nbr_moves = mcount;
  nbrmoves1 = nbr_moves;   //one's own moves
  /* We will also calculate the opponent's moves. */
  if (generate_moves_ny(board,oppcolor,oppmoves,&oppmovables) != 0) {
    /* The opponent could take our king, and when the move generation
       function discovers that, it quits immediately, without generating
       the rest of the moves. Therefore we don't know the opponent's
       branching factor, and therefore we set the branching factor to
       the number of moves oneself can do. */
    branchfact = nbrmoves1;
  } else {
    /* Count the number of possible moves for the opponent. */
    nbrmoves2 = 0;
    for (i = 0; i < oppmovables; i++)
      nbrmoves2 += bitcount(oppmoves[i].targets);
    branchfact = (nbrmoves1 + nbrmoves2) / 2;
  }
  printf("Branch factor = %d\n",branchfact);

  /* Go through the moves in the movelist and play them by calling
     alphabeta. Go deeper and deeper iteratively. */
  depth = 2;
  //while (depth <= maxdepth) {
  attempt_nbr = 1;
  while (1) {
  //while (depth <= 2) {
    /* valmax has to be cleared (=-INFTY) for each new turn */
    valmax = -INFTY;
    /* Vary the reduction factor for null-move pruning. The best value seems
       to be R = 2, but then we don't get any pruning for depth's below 6.
       And then for really deep searches we set R = 3.
       Another possibility is to dynamically change R inside the alfabeta-
       function, but it seems to better to keep it constant in alfabeta.
       Otherwise we would get R = 0 and R = 1 even when the original depth
       is very deep, and that will give us a larger tree. */
    /*if (depth == 4)
      R = 5;    //0
    else if (depth == 5)
      R = 1;
    else if (depth < 10)
      R = 2;
    else
    R = 3;*/

    for (mcount = 0; mcount < nbr_moves; mcount++) {
      /* Test code for printing out the moves the engine is processing. */
      dragstr = (char *) malloc(20*sizeof(char));
      move2str(color,movelist[mcount],dragstr);
      //printf("        move %s",dragstr);
      free(dragstr);
      
      makemove(board,&newpos,color,movelist[mcount],depth);
      movelist[mcount].value = alphabeta(&newpos,color,org_color,MIN,alpha,beta,depth-1,depth,1);
      if (movelist[mcount].value != KINGTAKEN) {
	valmax = max(movelist[mcount].value,valmax);
      }
      //printf(" (r: %d)\n",movelist[mcount].value);
      
      /* Clear the killer moves so they don't get too clogged up with
	 stale killers. */
      for (i = 0; i < MAX_ITERATIONS; i++)
	killers[i] = 0;
    }

    /* If we failed high, we set alpha to -INFTY, and keep beta the same.
       If we failed low, we set beta to INFTY, and keep alpha the same.
       This is so we won't keep failing high,low,high,low,... on the
       re-search. I have not done any extensive analysis of this.
       Re-searches seem to be faster most of the time if we don't strech
       out the window to infinity right away. First we try a smaller opening
       by using the variable attempt_nbr. */
    if (valmax <= alpha) {
      if (attempt_nbr == 1) {
	attempt_nbr++;
	alpha = valmax - SECOND_ATTEMPT_VALWINDOW;
      } else {
	alpha = -INFTY;
	attempt_nbr = 1;
      }
      printf("R-alpha\n");
    } else if (valmax >= beta) {
      if (attempt_nbr == 1) {
	attempt_nbr++;
	beta = valmax + SECOND_ATTEMPT_VALWINDOW;
      } else {
	beta = INFTY;
	attempt_nbr = 1;
      }
      printf("R-beta\n");
    } else {
      alpha = valmax - VALWINDOW;
      beta = valmax + VALWINDOW;
      if (post) {   //then send output to xboard
	printf("%d %d 0 0 ",depth,valmax);
	str = (char *) malloc(100*sizeof(char));
	for (i = 0; i < nbr_moves; i++)
	  if (movelist[i].value == valmax) {
	    move2str(color,movelist[i],str);
	    printf("%s ",str);
	  }
	free(str);
	printf("\n");
      }
      if (time_is_up(movenumber,branchfact))
	break;
      /* If there will be a draw, then we don't need to keep searching
	 any deeper. */
      if (board->moves_left_to_draw - depth <= 0 && valmax == 0)
	break;
      /* If we find a quick mate, then we don't need to bother searching
	 deeper. */
      if ((valmax < (-INFTY + 150)) || (valmax > (INFTY - 150)))
	break;
      if (depth == MAX_ITERATIONS)
	break;
      depth++;
      attempt_nbr = 1;
    }
  }
  //sequence++;     //TRANSPOSITION
  //lagge--;

  if (depth >= MAX_ITERATIONS)
    debuglog("WE REACHED MAXIMUM ITERATIONS!");

  /* These are only used in the search, and they should be cleared before
     next search. */
  board->captures[WHITE] = 0;
  board->captures[BLACK] = 0;

  //if (!xboard_mode)
    printf("Ply = %d\n",depth);

  free(killers);
  //free(movelist);
  //free(validmoves);
  //free(str);
  //return returnmove;
  //return movelist;
}
