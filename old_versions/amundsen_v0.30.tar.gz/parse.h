#ifndef _PARSE_
#define _PARSE_

#include "diverse.h"
#include "bitboards.h"

/* We initiate histpos to 6, to allow searching for draws according
   to the 3-move repetition rule, already from the start. Then we don't
   need to treat the first few moves as a separate case. */
#define HISTPOS_INIT 0

#define HUMAN 1
#define COMPUTER 2
#define WHITE 0
#define BLACK 1
#define BOOKSIZE 3144

void computer_make_move(struct board **board, int *vemstur, int *started);

int parsemove(char *input, struct board **board, int *vemstur, int *started);

void parse();

#endif      //_PARSE_
