#include "alfabeta.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include "moves.h"
#include "genmoves.h"
#include "eval.h"
#include "transptable.h"
#include "slump.h"
#include "parse.h"

int lagge = 0;
int lagge_int = 0;
int lagge_int2 = 0;
int lagge_int3 = 0;
int lagge_int4 = 0;

/* killers keep track of the moves that cause a cutoff at each level
   of the search. The killer move implementation is very simple, namely
   every time a cutoff has occurred at a certain node, the killer bitboard
   for the particular depth is OR:ed with the target square. */
bitboard *killers;

/* R = reduction factor for the null-move search. */
//int R = 2;

/* if zugswang is set, then no null-move pruning will be used. */
int zugswang = 0;

int max(int a, int b) {
  if (a > b)
    return a;
  else
    return b;
}

int min(int a, int b) {
  if (a > b)
    return b;
  else
    return a;
}

int quiescence(struct board *board, int color, int org_color, int nodetype, int alpha, int beta, bitboard tsquare) {
  struct board newpos;
  int retval;
  int q_val;
  int piece_nbr = 0;
  //int oppcolor = color;
  int piecetype;
  bitboard pieces, typetargets, target;
  int boardpos, movables = 0;
  struct moves moves[16];
  extern bitboard square[64];
  struct move move;
  char *dragstr;

  switch_colors(&color);

  if (generate_moves_ny(board,color,moves,&movables) != 0)
    return KINGTAKEN;

  if (nodetype == MAX) {
    /* We init retval to the static score of the position. Then the engine
       will take whatever is best of continuing the capture line, or to
       accept the static score of the position. */
    retval = eval(&org_color,board);
    piece_nbr = 0;
    /* Go through all movable pieces. */
    while (piece_nbr < movables) {
      typetargets = moves[piece_nbr].targets & tsquare; //only moves to tsquare
      while (typetargets != 0) {
	target = getlsb(typetargets);
	move.fsquare = moves[piece_nbr].source;
	move.tsquare = target;
	move.piece = moves[piece_nbr].piece;
	move.type = get_movetype(board,color,get_first_bitpos(moves[piece_nbr].source),moves[piece_nbr].piece,target);

	/* Test code for printing out the moves the engine is processing. */
	/*dragstr = (char *) malloc(20*sizeof(char));
	move2str(board,color,move,dragstr);
	if (lagge_int3 && (strncmp(dragstr,"h8g8",4) == 0))
	  lagge_int4 = 1;
	else
	  lagge_int4 = 0;
	if (lagge_int3)
	  fprintf(stderr,"        move %s",dragstr);
	  free(dragstr);*/

	makemove(board,&newpos,color,move,0);
	q_val = quiescence(&newpos,color,org_color,MIN,alpha,beta,tsquare);
	//if (lagge_int3)
	//printf(" (%d)\n",q_val);
	if (q_val != KINGTAKEN) {
	  retval = max(retval,q_val);
	  alpha = max(alpha,retval);
	  if (retval >= beta) {
	    //if (lagge_int4)
	    //printf("DFFFFFFFFFFFFF");
	    //lagge_int4 = 0;
	    return retval;
	  }
	}
	typetargets = typetargets & ~target;
      }
      piece_nbr++;
    }
    /* We get here when we have gone through all the capture moves, and
       when none of them were good enough to merit a cutoff. */
    return retval;
  } else {   //nodetype == MIN
    /* We init retval to the static score of the position. Then the engine
       will take whatever is best of continuing the capture line, or to
       accept the static score of the position. */
    retval = eval(&org_color,board);
    piece_nbr = 0;
    /* Go through all movable pieces. */
    while (piece_nbr < movables) {
      typetargets = moves[piece_nbr].targets & tsquare; //only moves to tsquare
      while (typetargets != 0) {
	target = getlsb(typetargets);
	move.fsquare = moves[piece_nbr].source;
	move.tsquare = target;
	move.piece = moves[piece_nbr].piece;
	move.type = get_movetype(board,color,get_first_bitpos(moves[piece_nbr].source),moves[piece_nbr].piece,target);

	/* Test code for printing out the moves the engine is processing. */
	//dragstr = (char *) malloc(20*sizeof(char));
	//move2str(board,color,move,dragstr);
	/*if (lagge_int3 && (strncmp(dragstr,"h8g8",4) == 0))
	  lagge_int4 = 1;
	else
	lagge_int4 = 0;*/
	//if (lagge_int4)
	//fprintf(stderr,"          move %s",dragstr);
	//free(dragstr);

	makemove(board,&newpos,color,move,0);
	q_val = quiescence(&newpos,color,org_color,MAX,alpha,beta,tsquare);
	//if (lagge_int4)
	//printf(" (%d)\n",q_val);
	if (q_val != KINGTAKEN) {
	  retval = min(retval,q_val);
	  beta = min(beta,retval);
	  if (retval <= alpha)
	    return retval;
	}
	typetargets = typetargets & ~target;
      }
      piece_nbr++;
    }
    /* We get here when we have gone through all the capture moves, and
       when none of them were good enough to merit a cutoff. */
    return retval;
  }

  /* We get here if no quiescence moves are found, i.e. no moves to the
     destination tsquare. That is, at the end of the series of captures. */
  //if (lagge_int4)
  //printf("fyran: %d",eval(&org_color,board));
  //return eval(&org_color,board);

  /* We should never get to this code. */
  printf("ERROR IN QUIESCENCE!!!\n");
}

int alphabeta(struct board *board, int color, int org_color, int nodetype, int alpha, int beta, int depth, int org_depth, int null_ok) {
  struct board newpos;
  int retval;
  int a_val;
  int piece_nbr = 0;
  int oppcolor = color;
  int opp_piece;
  extern int pieceval[6];
  int prunetype = 0;
  struct moves moves[16];
  int movables = 0;
  int piecetype = 0;
  bitboard pieces, typetargets, target;
  int boardpos;
  extern bitboard square[64];
  struct move move;
  char *dragstr;
  int R; //reduction factor for the null-move search
  int extension = 0;

  switch_colors(&color);

  //if (depth < 0)
  //printf("LATTAHAGGI = %d\n",depth);
  if (board->moves_left_to_draw == 0)
    return 0;

  //TRANSPOSITION:
  /*if ((retval = probe_hash(depth,board,alpha,beta)) != UNKNOWN) {
    //color = color;    //dummy
    return retval;
    }*/

  if (depth <= 0) {
    retval = eval(&org_color,board);
    //record_hash(depth,board,retval,EXACT);     //TRANSPOSITION
    return retval;
  } else {
    if (nodetype == MAX) {
      /* Null-move pruning. */
      //if (!zugswang && !in_check(board,color) && null_ok && ((depth-1-R) > 0)) {
      if (!in_check(board,color)) {
	if (!zugswang && null_ok && (depth > 0)) {
	  /*if (depth == 1 || depth == 2)
	    R = 0;
	  else if (depth == 3)
	    R = 1;
	  else if (depth < 8)
	    R = 2;
	  else
	  R = 3;*/
	  R = 2;

	  make_nullmove(board,&newpos,oppcolor);
	  null_ok = 0;
	  /* Notice that we call alphabeta with color instead of oppcolor.
	     That's because the color switch is done at the top of the
	     alphabeta-function. */
	  a_val = alphabeta(&newpos,color,org_color,MIN,alpha,beta,
			    depth-1-R,org_depth,null_ok);
	  if (a_val >= beta) {
	    /* I don't know what is best to return here - a_val or beta? */
	    //retval = eval(&org_color,board);
	    //retval = beta;
	    retval = a_val;
	    //record_hash(depth,board,retval,BETA);     //TRANSPOSITION
	    return retval;
	  } else if (a_val > alpha)
	    alpha = a_val;
	  null_ok = 1;
	}
      } else {
	/* If we are in check, then it's a more dangerous position, and
	   then we don't allow null-move pruning farther down this branch. */
	//null_ok = 0;   //is this necessary???
	extension = 1;
      }

      if (generate_moves_ny(board,color,moves,&movables) != 0)
	return KINGTAKEN;

      retval = -INFTY;
      /* Go through the different prunetypes. The prunetypes make sure the moves
         are tried in a (pretty) good order. See genmoves.h */
      while (prunetype < NBR_PRUNETYPES) {
	piece_nbr = 0;
	/* Go through all movable pieces. */
	while (piece_nbr < movables) {
	  /* Prune the targets to get a good move ordering. */
	  typetargets = get_pruned_targets(moves[piece_nbr].targets,prunetype,
					   killers[depth],board,color);
	  /* Go through the targets one at a time. */
	  while (typetargets != 0) {
	    target = getlsb(typetargets);
	    move.fsquare = moves[piece_nbr].source;
	    move.tsquare = target;
	    move.piece = moves[piece_nbr].piece;
	    move.type = get_movetype(board,color,
				     get_first_bitpos(moves[piece_nbr].source),
				     moves[piece_nbr].piece,target);

	/* Test code for printing out the moves the engine is processing. */
	    /*dragstr = (char *) malloc(20*sizeof(char));
	move2str(board,color,move,dragstr);
	if (lagge_int && depth == 4 && (strncmp(dragstr,"b7c6",4) == 0))
	  lagge_int2 = 1;
	else
	lagge_int2 = 0;
	if (lagge_int && depth == 3) {
	  fprintf(stderr,"    move %s",dragstr);
	  temp = 1;
	  //printf("(a=%d,b=%d)",alpha,beta);
	  //alpha = -INFTY;
	  //beta = INFTY;
	} else
	  temp = 0;
	if (temp2)
	  fprintf(stderr,"  Move %s",dragstr);
	  free(dragstr);*/




	    makemove(board,&newpos,color,move,depth);

	    /* If this move is the last one in the search, and the move is a
	       capture, then quiescence search should be done, otherwise we
	       do alphabeta. */
	    if ((depth-1 == 0) && (move.type & CAPTURE_MOVE)) {
	      /* If move is a capture, then figure out what piece it's taking. */
	      if (move.type & PASSANT_MOVE)
		opp_piece = PAWN;
	      else
		for (opp_piece = 0; opp_piece < 6; opp_piece++) {
		  if (board->piece[oppcolor][opp_piece] & move.tsquare)
		    break;
		}
	      /* If a lower valued piece takes a better one, we don't care about
		 quiescence search. */
	      if (pieceval[opp_piece] > pieceval[move.piece])
		a_val = alphabeta(&newpos,color,org_color,MIN,alpha,beta,
				  depth-1+extension,org_depth,null_ok);
	      else
		a_val = quiescence(&newpos,color,org_color,MIN,alpha,beta,
				   move.tsquare);
	    } else
	      a_val = alphabeta(&newpos,color,org_color,MIN,alpha,beta,
				depth-1+extension,org_depth,null_ok);

	    /*if (lagge_int && depth == 3 && temp)
	      printf(" (d4: %d)\n",a_val);
	    if (temp2)
	    printf(" (d3: %d)\n",a_val);*/
	    if (a_val != KINGTAKEN) {
	      retval = max(retval,a_val);
	      alpha = max(alpha,retval);
	      if (retval >= beta) {
		/* Here we got a cutoff, so we'll add this move as a killer. */
		killers[depth] = killers[depth] | move.tsquare;
		//lagge_int2 = 0;
		/*if (temp2)
		  printf(" (d2_ret: %d)\n",retval);*/
		//if (depth == 3) {
		//record_hash(depth+extension,board,retval,BETA);     //TRANSPOSITION
		  //printf("Stored:\n");
		  //showboard(board);
		  /*if ((retval = probe_hash(depth,board,alpha,beta)) != UNKNOWN)
		    printf("retval = %d\n",retval);
		  else
		    printf("retval = UNKNOWN\n");
		    exit(0);*/
		  //}
		return retval;
	      }
	    }
	    typetargets = typetargets & ~target;
	  }
	  piece_nbr++;
	}
	prunetype++;
      }
      /* If we get here, and retval == -INFTY, it means all possible moves
         from this position leads to a check position. If we are already in
         check, then it's mate. If we're not in check, then it's stalemate. */
      if (retval == -INFTY) {
	if (in_check(board,color))
	  /* Return retval+1 instead of retval. That's because it's only
	     at the deepest level we should do this test. Otherwise this
	     could happen: Let's say at a deeper node we discovered a mate,
	     which means retval is -INFTY when we reach this code. But that
	     might be for a few moves ahead of us (deeper in the search tree).
	     And at the CURRENT position (at THIS level in the tree, we are
	     not in check, and then we would falsely return 0 instead of
	     -INFTY. So therefore, if we return retval+1 at the checkmate
	     level, then we won't reach this code at a shallower level.
	     We also add the +(100-depth), to give shallower mates a worse
	     value than mates deeper down in the tree. */
	  retval = retval + 1 + (100-depth);     //check mate
	else
	  retval = 0;         //stalemate
      }
      //record_hash(depth+extension,board,retval,BETA);     //TRANSPOSITION
      return retval;
    } else {   //nodetype == MIN
      /* Null-move pruning. Don't do null-move search at the first MIN-level.
	 (That's why we have (depth < org_depth-1)) */
      //if (!zugswang && !in_check(board,color) && null_ok && ((depth-1-R) > 0) && (depth < org_depth-1)) {
      //if (!in_check(board,color) && null_ok && (depth > 3) && (depth < org_depth-1)) {
      if (!in_check(board,color)) {
	if (!zugswang && null_ok && (depth > 0) && (depth < org_depth-1)) {
	  /*if (depth == 1 || depth == 2)
	    R = 0;
	  else if (depth == 3)
	    R = 1;
	  else if (depth < 8)
	    R = 2;
	  else
	  R = 3;*/
	  R = 2;

	  make_nullmove(board,&newpos,oppcolor);
	  null_ok = 0;
	  /* Notice that we call alphabeta with color instead of oppcolor.
	     That's because the color switch is done at the top of the
	     alphabeta-function. */
	  a_val = alphabeta(&newpos,color,org_color,MAX,alpha,beta,
			    depth-1-R,org_depth,null_ok);
	  if (a_val <= alpha) {
	    /* I don't know what is best to return here - a_val or alpha? */
	    //retval = eval(&org_color,board);
	    //retval = alpha;
	    retval = a_val;
	    //record_hash(depth,board,retval,ALPHA);     //TRANSPOSITION
	    return retval;
	  } else if (a_val < beta)
	    beta = a_val;
	  null_ok = 1;
	}
      } else {
	/* If we are in check, then it's a more dangerous position, and
	   then we don't allow null-move pruning farther down this branch. */
	//null_ok = 0;
	extension = 1;
      }

      if (generate_moves_ny(board,color,moves,&movables) != 0)
	return KINGTAKEN;

      retval = INFTY;
      /* Go through the different prunetypes. The prunetypes make sure the moves
	 are tried in a (pretty) good order. See genmoves.h */
      while (prunetype < NBR_PRUNETYPES) {
	piece_nbr = 0;
        /* Go through all movable pieces. */
        while (piece_nbr < movables) {
          /* Prune the targets to get a good move ordering. */
          typetargets = get_pruned_targets(moves[piece_nbr].targets,prunetype,
					   killers[depth],board,color);
          /* Go through the targets one at a time. */
          while (typetargets != 0) {
            target = getlsb(typetargets);
            move.fsquare = moves[piece_nbr].source;
            move.tsquare = target;
            move.piece = moves[piece_nbr].piece;
	    move.type = get_movetype(board,color,
				     get_first_bitpos(moves[piece_nbr].source),
				     moves[piece_nbr].piece,target);


	/* Test code for printing out the moves the engine is processing. */
	    /*dragstr = (char *) malloc(20*sizeof(char));
	move2str(board,color,move,dragstr);
	if (lagge && depth == 1 && (strncmp(dragstr,"d1c2",4) == 0)) {
	  lagge_int = 1;
	} else {
	  lagge_int = 0;
	}
	if (lagge && depth == 1)
	  fprintf(stderr,"  move %s",dragstr);

	if (lagge_int2 && (strncmp(dragstr,"a8g8",4) == 0))
	  lagge_int3 = 1;
	else
	lagge_int3 = 0;
	if (temp3)
	fprintf(stderr,"      move %s (type = %d) ",dragstr,move.type);
	  free(dragstr);*/



            makemove(board,&newpos,color,move,depth);
	    if (lagge_int)
	      showboard(newpos);

            /* If this move is the last one in the search, and the move is a
               capture, then quiescence search should be done, otherwise we
	       do alphabeta. */
	    if ((depth-1 == 0) && (move.type & CAPTURE_MOVE)) {
	      /* If move is a capture, then figure out what piece it's taking. */
	      if (move.type & PASSANT_MOVE)
		opp_piece = PAWN;
	      else
		for (opp_piece = 0; opp_piece < 6; opp_piece++) {
		  if (board->piece[oppcolor][opp_piece] & move.tsquare)
		    break;
		}
	      /* If a lower valued piece takes a better one, we don't care about
		 quiescence search. */
	      if (pieceval[opp_piece] > pieceval[move.piece]) {
		a_val = alphabeta(&newpos,color,org_color,MAX,alpha,beta,
				  depth-1+extension,org_depth,null_ok);
	      } else {
		a_val = quiescence(&newpos,color,org_color,MAX,alpha,beta,
				   move.tsquare);
	      }
	    } else {
	      a_val = alphabeta(&newpos,color,org_color,MAX,alpha,beta,
				depth-1+extension,org_depth,null_ok);
	    }

	    /*if (lagge && depth == 1)
	      printf(" (d1: %d)\n",a_val);
	    if (temp3)
	      printf(" (t3-1: %d)\n",a_val);*/
	    if (a_val != KINGTAKEN) {
	      retval = min(retval,a_val);
	      beta = min(beta,retval);
	      if (retval <= alpha) {
                /* Here we got a cutoff, so we'll add this move as a killer. */
		killers[depth] = killers[depth] | move.tsquare;
		//if (depth == 3)
		//lagge_int = 0;
		/*if (lagge_int2 && depth == 1)
		  printf(" (d1_ret: %d)\n",retval);*/
		//if (depth == 3)
		//record_hash(depth+extension,board,retval,ALPHA);     //TRANSPOSITION
		return retval;
	      }
	    }
	    typetargets = typetargets & ~target;
	  }
	  piece_nbr++;
	}
	prunetype++;
      }
      /* If we get here, and retval == INFTY, it means all possible moves
         from this position leads to a check position. If we are already in
         check, then it's mate. If we're not in check, then it's stalemate. */
      if (retval == INFTY) {
	if (in_check(board,color)) {
	  /* Return retval-1 instead of retval. That's because it's only
	     at the deepest level we should do this test. Otherwise this
	     could happen: Let's say at a deeper node we discovered a mate,
	     which means retval is INFTY when we reach this code. But that
	     might be for a few moves ahead of us (deeper in the search tree).
	     And at the CURRENT position (at THIS level in the tree, we are
	     not in check, and then we would falsely return 0 instead of
	     INFTY. So therefore, if we return retval-1 at the checkmate
	     level, then we won't reach this code at a shallower level.
	     We also add the -(100-depth), to give shallower mates a higher
	     value than mates deeper down in the tree. */
	  retval = retval - 1 - (100-depth);     //check mate
	} else {
	  retval = 0;         //stalemate
	}
      }
      //record_hash(depth+extension,board,retval,ALPHA);     //TRANSPOSITION
      return retval;
    }
  }
  fprintf(stderr,"HIT BORDE VI V�L ALDRIG KOMMA???\n");
  debuglog("HIT BORDE VI V�L ALDRIG KOMMA???");
  return retval;
}

void thinkalphabeta(struct board *board, int color, int depth,
		    struct move *movelist, int mcount) {
  //struct move *movelist;
  //struct move *bestmove;
  //struct move *validmoves;
  struct board newpos;
  //int mcount = 0;
  //int bestvalue, b;
  //struct move returnmove;
  int alpha = -INFTY, beta = INFTY;
  int org_color = color;
  int i;
  char *dragstr;
  //int prunetype;
  int nbr_moves = 0;
  //bitboard pieces, typetargets, target;
  //struct moves moves[16];
  //extern bitboard square[64];
  //extern int sequence;     //TRANSPOSITION
  //extern int hits;     //TRANSPOSITION

  //hits = 0;     //TRANSPOSITION

  //*mcount = 0;
  /* We reserve space for killers up to ply == depth, and that's allright,
     because we don't use killer moves in the quiescence search. */
  killers = (bitboard *) calloc(depth,sizeof(bitboard)); //calloc clears memory

  /* Vary the reduction factor for null-move pruning. The best value seems
     to be R = 2, but then we don't get any pruning for depth's below 6.
     And then for really deep searches we set R = 3.
       Another possibility is to dynamically change R inside the alfabeta-
     function, but it seems to better to keep it constant in alfabeta.
     Otherwise we would get R = 0 and R = 1 even when the original depth
     is very deep, and that will give us a larger tree. */
  /*  if (depth == 4)
    R = 0;
  else if (depth == 5)
    R = 1;
  else if (depth < 10)
    R = 2;
  else
  R = 3;*/

  nbr_moves = mcount;
  for (mcount = 0; mcount < nbr_moves; mcount++) {
    /* Test code for printing out the moves the engine is processing. */
    dragstr = (char *) malloc(20*sizeof(char));
    move2str(color,movelist[mcount],dragstr);
    /*if (strncmp(dragstr,"h8g8",4) == 0) {
      lagge = 1;
      } else
      lagge = 0;*/
    //if (lagge)
    fprintf(stderr,"drag %s",dragstr);
    free(dragstr);
    
    makemove(board,&newpos,color,movelist[mcount],depth);
    movelist[mcount].value = alphabeta(&newpos,color,org_color,MIN,alpha,beta,depth-1,depth,1);
    //if (lagge)
    printf(" (r: %d)\n",movelist[mcount].value);
    /* Clear the killer moves so they don't get too clogged up with
       stale killers. */
    for (i = 0; i < depth; i++)
      killers[i] = 0;
  }
  //sequence++;     //TRANSPOSITION
  
  /* These are only used in the search, and they should be cleared before
     next search. */
  board->captures[WHITE] = 0;
  board->captures[BLACK] = 0;

  free(killers);
  //free(movelist);
  //return movelist;

  //free(validmoves);

  //return returnmove;
}
