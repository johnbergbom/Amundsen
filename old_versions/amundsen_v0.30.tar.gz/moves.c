#include "moves.h"
#include "genmoves.h"
#include "parse.h"
#include <stdio.h>
#include <stdlib.h>

extern int xboard_mode;

/* This method returns true(=1) if the king in the specified color is
   threatened. Else false(=0).*/
int in_check(struct board *board, int color) {
  int64 pieces, targets;
  int oppcolor = color;
  int piecetype, boardpos;
  extern bitboard square[64];
  extern struct attack attack;

  switch_colors(&oppcolor);

  /* Generate moves for the opponent and see if ones own king can be taken.
     But we can't generate those moves by calling generate_moves(), because
     that function generates moves for the king, and the generation of
     kingmoves is dependant on the function, so that would give us an
     infinite recursive loop. So here we generate the kingmoves "by hand".
     We don't generate castling moves (dependent on this function), but
     that's alright, because a castling move can never take the opposite
     king.
       But the king can't take it's opponent king anyway, you might argue?
     Yes, but we need to check that too, because otherwise game_ended()
     would say that a game is not ended in a mating position, if the mated
     king can escape a check by going to a square that is controlled by
     the opposite king. */

  for (piecetype = 0; piecetype < 6; piecetype++) {
    pieces = board->piece[oppcolor][piecetype];
    while (pieces != 0) {
      boardpos = get_first_bitpos(pieces);
      if (piecetype == PAWN) {
	targets = generate_pawnmoves(board,oppcolor,boardpos);
      } else if (piecetype == ROOK) {
	targets = generate_horizontal_moves(board,oppcolor,boardpos)
	  | generate_vertical_moves(board,oppcolor,boardpos);
      } else if (piecetype == KNIGHT) {
	targets = generate_knight_moves(board,oppcolor,boardpos);
      } else if (piecetype == BISHOP) {
	targets = generate_NEdiag_moves(board,oppcolor,boardpos)
	  | generate_NWdiag_moves(board,oppcolor,boardpos);
      } else if (piecetype == QUEEN) {
	targets = generate_horizontal_moves(board,oppcolor,boardpos)
	  | generate_vertical_moves(board,oppcolor,boardpos)
	  | generate_NEdiag_moves(board,oppcolor,boardpos)
	  | generate_NWdiag_moves(board,oppcolor,boardpos);
      } else {   //piecetype == KING
	targets = attack.king[boardpos] & (~board->all_pieces[oppcolor]);
      }

      if (targets & board->piece[color][KING])
	return 1;
      pieces = pieces & ~square[boardpos];
    }
  }
  /* If we get here, then that means we found no moves that were threatening
     the king. */
  return 0;
}

/* This function returns 1 if the move is legal, and 0 if it's illegal. */
int legal_move(struct move move_to_check, struct board *board, int color) {
  struct moves moves[16];
  int movables, piece_nbr;
  bitboard target;
  struct move move;
  struct board newpos;
  //char *str;
  //char *str2;

  /* Make a list of all the possible pseudo-moves in this position,
     and see if move_to_check is in the list. If it is, then make
     the move, and see if the move will get oneself into check.
     If one gets in check, then the move is illegal, otherwise it's legal. */

  /* This program only generates queen promotions, and no minor promotions.
     So if the opponent tries to make a minor promotion, there will be no
     match between move_to_check and any of the moves in the generated
     movelist. A way to solve that problem is to check if the opponent's
     move is a promotion. If it is, then we set move_to_check.type
     to QUEEN_PROMOTION_MOVE, and then we can have our match. */
  if (move_to_check.type & PROMOTION_MOVE) {
    move_to_check.type = move_to_check.type & (~PROMOTION_MOVE);
    move_to_check.type = move_to_check.type | QUEEN_PROMOTION_MOVE;
  }

  if (generate_moves_ny(board,color,moves,&movables) != 0) {
    /* If we get here, it means that the last move by the opponent
       left him in check, which is illegal. */
    debuglog("ERROR! ILLEGAL POSITION!");
    printf("ERROR! ILLEGAL POSITION!\n");
    exit(1);
  }

  piece_nbr = 0;
  while (piece_nbr < movables) {
    while (moves[piece_nbr].targets != 0) {
      target = getlsb(moves[piece_nbr].targets);
      move.fsquare = moves[piece_nbr].source;
      move.tsquare = target;
      move.piece = moves[piece_nbr].piece;
      move.type = get_movetype(board,color,
			       get_first_bitpos(moves[piece_nbr].source),
			       moves[piece_nbr].piece,target);
      /* move.value is something we don't know about until after a search,
         so we don't compare the move.value */
      if ((move.fsquare == move_to_check.fsquare)
	  && (move.tsquare == move_to_check.tsquare)
	  && (move.piece == move_to_check.piece)
	  && (move.type == move_to_check.type)) {
	makemove(board,&newpos,color,move,0);
	if (!in_check(&newpos,color)) {
	  return 1;     //Now we know that the move is legal.
	} else
	  return 0;     //illegal move
      }
      moves[piece_nbr].targets = moves[piece_nbr].targets & ~target;
    }
    piece_nbr++;
  }
  /* If we get here, it means that move_to_check was not in the movelist,
     and is therefore illegal. */
  return 0;
}

/* Denna funktion omvandlar en str�ng till ett struct drag-objekt. Om str�ngen
   �r felaktig returneras move.value = -99. */
struct move str2move(char *vilket_drag, struct board *board, int color) {
  struct move move;
  int frow, fcol, trow, tcol;
  char *str;
  extern bitboard square[64];
  extern bitboard pawn_lastrow[2];
  extern struct attack attack;
  int oppcolor = color;
  int i, movetype;

  switch_colors(&oppcolor);

  if (strlen(vilket_drag) != 4 && strlen(vilket_drag) != 5) {
    move.value = -99;
    return move;
  }

  frow = '8' - vilket_drag[1];
  fcol = vilket_drag[0] - 'a';
  trow = '8' - vilket_drag[3];
  tcol = vilket_drag[2] - 'a';
  move.fsquare = square[frow*8 + fcol];
  move.tsquare = square[trow*8 + tcol];

  /* Denna test beh�vs eftersom det inte r�cker att kolla om
     strlen(vilket_drag) != 7, ty man kan ju skriva in tex.
     str�ngen "hhhhhhh", som ocks� har 7 tecken. */
  if ((frow > 7) || (frow < 0) ||
      (fcol > 7) || (fcol < 0) ||
      (trow > 7) || (trow < 0) ||
      (tcol > 7) || (tcol < 0)) {
    move.value = -99;
    return move;
  }

  /* Find out what kind of piece made this move. */
  for (i = 0; i < 6; i++)
    if (board->piece[color][i] & move.fsquare)
      move.piece = i;

  /* Find out if this move was a capture or a normal move. */
  movetype = NORMAL_MOVE;
  if (board->all_pieces[oppcolor] & move.tsquare)
    movetype = CAPTURE_MOVE;

  /* Find out if the move is a passant move. First check if a pawn
     makes the move. */
  if (move.piece == PAWN) {
    /* Then check if the pawn is making an attack, and if the attack goes
       towards a square that is not occupied by an enemy piece. */
    if ((attack.pawn[color][frow*8+fcol] & move.tsquare)
	&& !(board->all_pieces[oppcolor] & move.tsquare))
      movetype = CAPTURE_MOVE | PASSANT_MOVE;
  }

  /* Find out if the move is a castling move. */
  if (move.piece == KING) {
    if (color == WHITE) {
      if ((move.fsquare & square[60]) &&
	  ((move.tsquare & square[58]) || (move.tsquare & square[62])))
	movetype = CASTLING_MOVE;
    } else {     //color == BLACK
      if ((move.fsquare & square[4]) &&
	  ((move.tsquare & square[2]) || (move.tsquare & square[6])))
	movetype = CASTLING_MOVE;
    }
  }
  move.type = movetype;

  /* If the move is a pawn that advances to the last row, then find out
     what kind of promotion it is. */
  if ((move.piece == PAWN) && (move.tsquare & pawn_lastrow[color])) {
    if (strlen(vilket_drag) == 5) {
      switch(vilket_drag[4]) {
      case 'r' : move.type = move.type | ROOK_PROMOTION_MOVE;     break;
      case 'q' : move.type = move.type | QUEEN_PROMOTION_MOVE;     break;
      case 'n' : move.type = move.type | KNIGHT_PROMOTION_MOVE;     break;
      case 'b' : move.type = move.type | BISHOP_PROMOTION_MOVE;     break;
      default : if (!xboard_mode)
	          printf("Invalid piece!\n");
                else {
		  str = (char *) malloc(100*sizeof(char));
		  sprintf(str,"Error (invalid piece): %s",vilket_drag);
		  printf("%s\n",str);
		  debuglog(str);
		  free(str);
		}
                move.value = -99;
		return move;
      }
    } else {
      if (!xboard_mode)
	printf("Invalid move format!\n");
      else {
	str = (char *) malloc(100*sizeof(char));
	sprintf(str,"Error (invalid move format): %s",vilket_drag);
	printf("%s\n",str);
	debuglog(str);
	free(str);
      }
      move.value = -99;
      return move;
    }
  }

  return move;
}

void move2str(int color, struct move move, char *str) {
  extern bitboard pawn_lastrow[2];
  int square, row, col;

  square = get_first_bitpos(move.fsquare);
  row = square / 8;
  col = square % 8;
  str[1] = '8' - row;
  str[0] = col + 'a';
  square = get_first_bitpos(move.tsquare);
  row = square / 8;
  col = square % 8;
  str[3] = '8' - row;
  str[2] = col + 'a';
  str[4] = '\0';
  /* If the move is a pawn that advances to the last row, then find out
     what kind of promotion it is. */
  //if (move.fsquare & board->piece[color][PAWN] && move.tsquare & pawn_lastrow[color]) {
  if ((move.piece == PAWN) && (move.tsquare & pawn_lastrow[color])) {
    if (move.type & QUEEN_PROMOTION_MOVE)
      str[4] = 'q';
    else if (move.type & ROOK_PROMOTION_MOVE)
      str[4] = 'r';
    else if (move.type & KNIGHT_PROMOTION_MOVE)
      str[4] = 'n';
    else if (move.type & BISHOP_PROMOTION_MOVE)
      str[4] = 'b';
    else {
      printf("ERROR, wrong kind of promotion!!!\n");
      debuglog("ERROR, wrong kind of promotion!!!");
      exit(1);
    }
    str[5] = '\0';
  }
}

void make_nullmove(struct board *oldboard, struct board *newboard, int color) {
  *newboard = *oldboard;
  
  /* Nedanst�ende kod f�r hantering av zobrist-keys f�r nullmoves kanske
     ej �r korrekt? I alfabeta anropar man denna funktion med "fel" f�rg,
     pga. att switch_colors g�rs h�gst upp i funktionen.
       Skulle man helt enkelt h�r kunna g�ra:
     newboard->zobrist_key ^= rand64(); ???
     Ty vid ett nullmove borde v�l samma position helst inte redan finnas i
     hashtabellen, eftersom samma st�llning men med motspelaren vid draget
     ej borde ha samma positionsv�rde. */
  //if (color == BLACK)     //TRANSPOSITION
  //newboard->zobrist_key ^= BLACK_TO_MOVE;     //TRANSPOSITION
}

void makemove(struct board *oldboard, struct board *newboard, int color, struct move move, int depth) {
  int oppcolor = color;
  int j;
  bitboard rookfsquare, rooktsquare;
  extern bitboard square[64];
  extern int rotate0to90[64];
  extern int rotate0toNE[64];
  extern int rotate0toNW[64];
  extern int promotion_piece[129];
  //extern int64 zobrist[6][2][64];     //TRANSPOSITION
  //extern int64 zobrist_castling[2][5];     //TRANSPOSITION
  //extern int64 BLACK_TO_MOVE;     //TRANSPOSITION
  extern bitboard pawn_start[2];
  extern bitboard pawn_passantrow[2];

  switch_colors(&oppcolor);
  *newboard = *oldboard;

  newboard->passant = 0;
  //if (color == BLACK)     //TRANSPOSITION
  //newboard->zobrist_key ^= BLACK_TO_MOVE;     //TRANSPOSITION
  //newboard->zobrist_key ^= square[oldboard->passant];     //TRANSPOSITION

  /* Check if the move is a capture. If it is, then we have to clear
     the bitboard of the taken piece. */
  if (move.type & CAPTURE_MOVE) {
    /* A shallow (=early) capture is worth more than a deeper one. */
    newboard->captures[color] += depth;
    newboard->moves_left_to_draw = 100;
    /* If it's a passant capture, then we have to remove the taken piece in
       a different way than for a normal capture. */
    if (move.type & PASSANT_MOVE) {
      if (color == WHITE) {
	newboard->piece[oppcolor][PAWN] = newboard->piece[oppcolor][PAWN] & (~(move.tsquare << 8));
	newboard->all_pieces[oppcolor] = newboard->all_pieces[oppcolor] & (~(move.tsquare << 8));
	newboard->rot90_pieces[oppcolor] = newboard->rot90_pieces[oppcolor]
	  & ~(square[rotate0to90[get_first_bitpos(move.tsquare << 8)]]);
	newboard->rotNE_pieces[oppcolor] = newboard->rotNE_pieces[oppcolor]
	  & ~(square[rotate0toNE[get_first_bitpos(move.tsquare << 8)]]);
	newboard->rotNW_pieces[oppcolor] = newboard->rotNW_pieces[oppcolor]
	  & ~(square[rotate0toNW[get_first_bitpos(move.tsquare << 8)]]);
	//newboard->zobrist_key ^= zobrist[PAWN][oppcolor][get_first_bitpos(move.tsquare << 8)];     //TRANSPOSITION
      } else {   //color == BLACK
	newboard->piece[oppcolor][PAWN] = newboard->piece[oppcolor][PAWN] & (~(move.tsquare >> 8));
	newboard->all_pieces[oppcolor] = newboard->all_pieces[oppcolor] & (~(move.tsquare >> 8));
	newboard->rot90_pieces[oppcolor] = newboard->rot90_pieces[oppcolor]
	  & ~(square[rotate0to90[get_first_bitpos(move.tsquare >> 8)]]);
	newboard->rotNE_pieces[oppcolor] = newboard->rotNE_pieces[oppcolor]
	  & ~(square[rotate0toNE[get_first_bitpos(move.tsquare >> 8)]]);
	newboard->rotNW_pieces[oppcolor] = newboard->rotNW_pieces[oppcolor]
	  & ~(square[rotate0toNW[get_first_bitpos(move.tsquare >> 8)]]);
	//newboard->zobrist_key ^= zobrist[PAWN][oppcolor][get_first_bitpos(move.tsquare >> 8)];     //TRANSPOSITION
      }
    } else {   //normal capture (not passant)
      newboard->all_pieces[oppcolor] = newboard->all_pieces[oppcolor] & (~move.tsquare);
      newboard->rot90_pieces[oppcolor] = newboard->rot90_pieces[oppcolor]
	& ~(square[rotate0to90[get_first_bitpos(move.tsquare)]]);
      newboard->rotNE_pieces[oppcolor] = newboard->rotNE_pieces[oppcolor]
	& ~(square[rotate0toNE[get_first_bitpos(move.tsquare)]]);
      newboard->rotNW_pieces[oppcolor] = newboard->rotNW_pieces[oppcolor]
	& ~(square[rotate0toNW[get_first_bitpos(move.tsquare)]]);
      for (j = 0; j < 6; j++)
	if (newboard->piece[oppcolor][j] & move.tsquare) {
	  newboard->piece[oppcolor][j] = newboard->piece[oppcolor][j] & (~move.tsquare);
	  /* If a rook is taken, the opponent's castling rights must be
	     adjusted accordingly. */
	  if (j == ROOK) {
	    //newboard->zobrist_key ^= zobrist_castling[oppcolor][newboard->castling_status[oppcolor]];     //TRANSPOSITION
	    if (color == WHITE) {
	      if (get_first_bitpos(move.tsquare) == 0)
		newboard->castling_status[oppcolor] &= ~LONG_CASTLING_OK;
	      else if (get_first_bitpos(move.tsquare) == 7)
		newboard->castling_status[oppcolor] &= ~SHORT_CASTLING_OK;
	    } else {   //color == BLACK
	      if (get_first_bitpos(move.tsquare) == 56)
		newboard->castling_status[oppcolor] &= ~LONG_CASTLING_OK;
	      else if (get_first_bitpos(move.tsquare) == 63)
		newboard->castling_status[oppcolor] &= ~SHORT_CASTLING_OK;
	    }
	    //newboard->zobrist_key ^= zobrist_castling[oppcolor][newboard->castling_status[oppcolor]];     //TRANSPOSITION
	  }
	  //newboard->zobrist_key ^= zobrist[j][oppcolor][get_first_bitpos(move.tsquare)];     //TRANSPOSITION
	  break;
	}
    }
  } else if (move.piece == PAWN) {   //not a capture move, but a pawn move
    newboard->moves_left_to_draw = 100;
    if ((move.fsquare & pawn_start[color]) && (move.tsquare & pawn_passantrow[color])) {
      if (color == WHITE)
	newboard->passant = get_first_bitpos(move.fsquare >> 8);
      else
	newboard->passant = get_first_bitpos(move.fsquare << 8);
    }
  } else  //not a capture, and not a pawn move
    newboard->moves_left_to_draw = newboard->moves_left_to_draw - 1;
  //newboard->zobrist_key ^= square[newboard->passant];     //TRANSPOSITION

  /* Update the bitboard for the piece that made the move. */
  newboard->piece[color][move.piece] = newboard->piece[color][move.piece] & (~move.fsquare);
  //newboard->zobrist_key ^= zobrist[move.piece][color][get_first_bitpos(move.fsquare)];     //TRANSPOSITION
  if (move.type & PROMOTION_MOVE) {
    newboard->piece[color][promotion_piece[move.type & PROMOTION_MOVE]]
      |= move.tsquare;
    //newboard->zobrist_key ^= zobrist[promotion_piece[move.type & PROMOTION_MOVE]][color][get_first_bitpos(move.tsquare)];     //TRANSPOSITION

    /*if (move.type & QUEEN_PROMOTION_MOVE)
      newboard->piece[color][QUEEN] =
	newboard->piece[color][QUEEN] | move.tsquare;
    else if (move.type & ROOK_PROMOTION_MOVE)
      newboard->piece[color][ROOK] =
	newboard->piece[color][ROOK] | move.tsquare;
    else if (move.type & BISHOP_PROMOTION_MOVE)
      newboard->piece[color][BISHOP] =
	newboard->piece[color][BISHOP] | move.tsquare;
    else if (move.type & KNIGHT_PROMOTION_MOVE)
      newboard->piece[color][KNIGHT] =
      newboard->piece[color][KNIGHT] | move.tsquare;*/

    /* An early promotion is worth more than a deeper one, so in case of
       promotion, we increase the value of the capture-flag with the value
       of depth. But if the move is a capture move, then the captures-flag
       has already gotten a higher value, so then we don't update it again. */
    if (!(move.type & CAPTURE_MOVE))
      newboard->captures[color] += depth;

  } else {
    newboard->piece[color][move.piece] =
      newboard->piece[color][move.piece] | move.tsquare;
    //newboard->zobrist_key ^= zobrist[move.piece][color][get_first_bitpos(move.tsquare)];     //TRANSPOSITION
  }

  /* Update the all_pieces bitboard and the rotated bitboards. */
  newboard->all_pieces[color] = newboard->all_pieces[color] & (~move.fsquare);
  newboard->all_pieces[color] = newboard->all_pieces[color] | move.tsquare;
  newboard->rot90_pieces[color] = newboard->rot90_pieces[color]
    & ~(square[rotate0to90[get_first_bitpos(move.fsquare)]]);
  newboard->rot90_pieces[color] = newboard->rot90_pieces[color]
    | square[rotate0to90[get_first_bitpos(move.tsquare)]];
  newboard->rotNE_pieces[color] = newboard->rotNE_pieces[color]
    & ~(square[rotate0toNE[get_first_bitpos(move.fsquare)]]);
  newboard->rotNE_pieces[color] = newboard->rotNE_pieces[color]
    | square[rotate0toNE[get_first_bitpos(move.tsquare)]];
  newboard->rotNW_pieces[color] = newboard->rotNW_pieces[color]
    & ~(square[rotate0toNW[get_first_bitpos(move.fsquare)]]);
  newboard->rotNW_pieces[color] = newboard->rotNW_pieces[color]
    | square[rotate0toNW[get_first_bitpos(move.tsquare)]];

  /* Update the castling flags. */
  //newboard->zobrist_key ^= zobrist_castling[color][newboard->castling_status[color]];     //TRANSPOSITION
  if (move.piece == ROOK) {
    if (color == WHITE) {
      if (move.fsquare & square[56])
	newboard->castling_status[color] =
	  newboard->castling_status[color] & ~LONG_CASTLING_OK;
      else if (move.fsquare & square[63])
	newboard->castling_status[color] =
	  newboard->castling_status[color] & ~SHORT_CASTLING_OK;
    } else {    //color == BLACK
      if (move.fsquare & square[0])
	newboard->castling_status[color] =
	  newboard->castling_status[color] & ~LONG_CASTLING_OK;
      else if (move.fsquare & square[7])
	newboard->castling_status[color] =
	  newboard->castling_status[color] & ~SHORT_CASTLING_OK;
    }
  } else if (move.piece == KING)
    newboard->castling_status[color] = newboard->castling_status[color]
      & ~(SHORT_CASTLING_OK | LONG_CASTLING_OK);
  //newboard->zobrist_key ^= zobrist_castling[color][newboard->castling_status[color]];     //TRANSPOSITION

  if (move.type & CASTLING_MOVE) {
    /* check if short castling. */
    if ((move.tsquare & square[6]) || (move.tsquare & square[62])) {
      rookfsquare = move.tsquare << 1;
      rooktsquare = move.tsquare >> 1;
    } else {   //long castling
      rookfsquare = move.tsquare >> 2;
      rooktsquare = move.tsquare << 1;
    }
    //newboard->zobrist_key ^= zobrist[ROOK][color][get_first_bitpos(rookfsquare)];     //TRANSPOSITION
    //newboard->zobrist_key ^= zobrist[ROOK][color][get_first_bitpos(rooktsquare)];     //TRANSPOSITION
    newboard->piece[color][ROOK] = newboard->piece[color][ROOK] & (~rookfsquare);
    newboard->piece[color][ROOK] = newboard->piece[color][ROOK] | rooktsquare;
    newboard->all_pieces[color] = newboard->all_pieces[color] & (~rookfsquare);
    newboard->all_pieces[color] = newboard->all_pieces[color] | rooktsquare;
    newboard->rot90_pieces[color] = newboard->rot90_pieces[color]
      & ~(square[rotate0to90[get_first_bitpos(rookfsquare)]]);
    newboard->rot90_pieces[color] = newboard->rot90_pieces[color]
      | square[rotate0to90[get_first_bitpos(rooktsquare)]];
    newboard->rotNE_pieces[color] = newboard->rotNE_pieces[color]
      & ~(square[rotate0toNE[get_first_bitpos(rookfsquare)]]);
    newboard->rotNE_pieces[color] = newboard->rotNE_pieces[color]
      | square[rotate0toNE[get_first_bitpos(rooktsquare)]];
    newboard->rotNW_pieces[color] = newboard->rotNW_pieces[color]
      & ~(square[rotate0toNW[get_first_bitpos(rookfsquare)]]);
    newboard->rotNW_pieces[color] = newboard->rotNW_pieces[color]
      | square[rotate0toNW[get_first_bitpos(rooktsquare)]];
    newboard->castling_status[color] = CASTLED;
  }
}


