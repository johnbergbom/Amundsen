#ifndef _TIMECTRL_
#define _TIMECTRL_

/* The program supports three types of time controls:
   TIMECTRL_NEWTIME plays a certain number of moves, and then
   additional time is obtained.
   TIMECTRL_INC has a base time and in addition to that, it has a
   certain amount of time for each move, and the time that is not
   used up is accumulated for later use.
   TIMECTRL_NOINC has a base time, and no additional time per move,
   and it doesn't get additional time after a certain number of moves. */
#define TIMECTRL_NEWTIME 1
#define TIMECTRL_INC 2
#define TIMECTRL_NOINC 3

void showtime(int engine_color);
void start_own_clock();
void start_opp_clock();
void stop_own_clock();
void stop_opp_clock();
int time_is_up(int movenumber, int branching_factor);

#endif         //_TIMECTRL_
