#include "transptable.h"
#include "bitboards.h"
//#include "diverse.h"
#include "parse.h"
#include <stdlib.h>

//#define NBR_ENTRIES 500000
#define NBR_ENTRIES 300000
//int64 WHITE_TO_MOVE;
int64 BLACK_TO_MOVE;

struct hashentry {
  int64 lock;
  struct move bestmove;
  int value;
  int depth;
  int flag;
  int sequence;
};

struct hashentry *table;
int64 zobrist[6][2][64];
int64 zobrist_castling[2][5];
int64 zobrist_passant[64];
int sequence = 1;
int hits = 0;

int64 rand64() {
  return rand() ^ ((int64) rand() << 15) ^ ((int64) rand() << 30)
    ^ ((int64) rand() << 45) ^ ((int64) rand() << 60);
}

void init_transptable() {
  int i, j, k;

  table = (struct hashentry *) malloc(NBR_ENTRIES*sizeof(struct hashentry));
  for (i = 0; i < NBR_ENTRIES; i++) {
    table[i].lock = 0;
    table[i].sequence = 0;
  }
  for (i = 0; i < 6; i++)
    for (j = 0; j < 2; j++)
      for (k = 0; k < 64; k++)
	zobrist[i][j][k] = rand64();
  zobrist_castling[WHITE][0] = rand64();
  zobrist_castling[WHITE][LONG_CASTLING_OK] = rand64();
  zobrist_castling[WHITE][SHORT_CASTLING_OK] = rand64();
  zobrist_castling[WHITE][LONG_CASTLING_OK | SHORT_CASTLING_OK] = rand64();
  zobrist_castling[WHITE][CASTLED] = rand64();
  zobrist_castling[BLACK][0] = rand64();
  zobrist_castling[BLACK][LONG_CASTLING_OK] = rand64();
  zobrist_castling[BLACK][SHORT_CASTLING_OK] = rand64();
  zobrist_castling[BLACK][LONG_CASTLING_OK | SHORT_CASTLING_OK] = rand64();
  zobrist_castling[BLACK][CASTLED] = rand64();
  for (i = 0; i < 64; i++)
    zobrist_passant[i] = rand64();
  //WHITE_TO_MOVE = rand64();
  BLACK_TO_MOVE = rand64();
  j = NBR_ENTRIES*sizeof(struct hashentry);
  printf("size of hashtable = %d kb\n",j/1024);
}

int64 get_zobrist_key_for_board(struct board *board, int color_to_move) {
  int64 zobrist_key = 0;
  bitboard pieces;
  extern bitboard square[64];
  int i, j, square_nbr;

  for (i = 0; i < 2; i++) {
    for (j = 0; j < 6; j++) {
      pieces = board->piece[i][j];
      while (pieces != 0) {
	square_nbr = get_first_bitpos(pieces);
	zobrist_key ^= zobrist[j][i][square_nbr];
	pieces &= ~square[square_nbr];
      }
    }
  }
  /*if (color_to_move == WHITE)
    zobrist_key = zobrist_key ^ WHITE_TO_MOVE;
  else
  zobrist_key = zobrist_key ^ BLACK_TO_MOVE;*/
  if (color_to_move == BLACK)
    zobrist_key ^= BLACK_TO_MOVE;
  zobrist_key ^= zobrist_castling[WHITE][board->castling_status[WHITE]];
  zobrist_key ^= zobrist_castling[BLACK][board->castling_status[BLACK]];
  zobrist_key ^= zobrist_passant[board->passant];
  return zobrist_key;
}

/* The argument can't be a normal int64, because that could give us
   a negative hash key. So we have to use unsigned. */
int get_hashkey(unsigned long long int zobrist_key) {
  return (zobrist_key % NBR_ENTRIES);
}

int probe_hash(int depth, struct board *board, int alpha, int beta) {
  struct hashentry *entry;

//TRANSPOSITION:
//  entry = &(table[get_hashkey(board->zobrist_key)]);
//  if (entry->lock == board->zobrist_key) {
//    /* Only take the hash value if it's at the same depth, or deeper than
//       the current depth. (remember that deepest level has depth == 0,
//       that's why we write <=, and not >=) */
//    //if ((entry->depth + (sequence - entry->sequence)*2) <= depth) {
//    //if (entry->depth <= depth) {
//    /* Only take the hash value if it's at the same depth, or deeper than
//       the current depth. */
//    if (entry->depth >= depth) {
//      hits++;
//      if (entry->flag == EXACT)
//	return entry->value;
//      if ((entry->flag == ALPHA) && (entry->value <= alpha))
//	return entry->value;
//      if ((entry->flag == BETA) && (entry->value >= beta))
//	return entry->value;
//      hits--;
//    }
//  }
  return UNKNOWN;
}

void record_hash(int depth, struct board *board, int value, int flag) {
  struct hashentry *entry;

//TRANSPOSITION:
//  entry = &(table[get_hashkey(board->zobrist_key)]);
//  /* Only replace if same depth or deeper, or if the element pertains to
//     an ancient search.  */
//  //if (depth <= entry->depth || sequence > entry->sequence) {
//  //if (depth <= (entry->depth + (sequence - entry->sequence)*2)) {
//  if ((depth >= entry->depth) || (sequence > entry->sequence)) {
//    entry->lock = board->zobrist_key;
//    entry->value = value;
//    entry->depth = depth;
//    entry->flag = flag;
//    entry->sequence = sequence;
//  }
}


