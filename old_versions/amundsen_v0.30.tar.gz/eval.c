#include "eval.h"
#include "parse.h"
#include "bitboards.h"

/* If endgame == 0 there is no special endgame. Otherwise the number tells us
   what kind of endgame we are dealing with. See eval.h for endgame types. */
int endgame;

/* If ahead == 1, then one color has more material than the other one, then
   it's good for the color that is ahead to exchange pieces. The variable
   ahead keeps track of this. */
int ahead;

void eval_pawn_structure(struct board *board, int *wval, int *bval) {
  int i, num;
  extern bitboard col_bitboard[8];
  extern bitboard adj_cols[8];
  bitboard pawn_col[2][8];
  extern int row_nbr[64];

  for (i = 0; i < 8; i++) {
    pawn_col[WHITE][i] = board->piece[WHITE][PAWN] & col_bitboard[i];
    pawn_col[BLACK][i] = board->piece[BLACK][PAWN] & col_bitboard[i];
  }

  /* Tempor�r, f�r att f� den att rensa bort lite b�nder. */
  /*if (bitcount(board->piece[WHITE][PAWN]) > 6)
    *wval -= 1;
  if (bitcount(board->piece[BLACK][PAWN]) > 6)
  *bval += 1;*/

  /* Check for doubled pawns. Each doubled pawn is worth 25% less than
     a normal pawn. */
  for (i = 0; i < 8; i++) {
    num = bitcount(pawn_col[WHITE][i]);
    if (num > 1)
      *wval -= num*VAL_PAWN*0.25;
  }
  for (i = 0; i < 8; i++) {
    num = bitcount(pawn_col[BLACK][i]);
    if (num > 1)
      *bval -= num*VAL_PAWN*0.25;
  }

  /* Check for passed pawns. Doubled passed pawns are each worth as much as
     as normal pawn. Then we also add 2 centipawn's value times the row
     to which the pawn has advanced. */
  for (i = 0; i < 8; i++) {
    num = bitcount(pawn_col[WHITE][i]);
    if (num > 0)
      if (((board->piece[BLACK][PAWN]) & (adj_cols[i])) == 0)
	*wval += num*VAL_PAWN*0.25
	  + VAL_PAWN*row_nbr[get_first_bitpos(pawn_col[WHITE][i])]*0.02;
  }
  for (i = 0; i < 8; i++) {
    num = bitcount(pawn_col[BLACK][i]);
    if (num > 0)
      if (((board->piece[WHITE][PAWN]) & (adj_cols[i])) == 0)
	*bval += num*VAL_PAWN*0.25
	  + VAL_PAWN*(7-row_nbr[get_first_bitpos(pawn_col[BLACK][i])])*0.02;
  }

  /* Check for isolated pawns. Each isolated pawn is worth 25% less than a
     normal pawn. Two doubled isolated pawns will then be worth as much as
     one good pawn. */
  /*for (i = 0; i < 8; i++) {
    num = bitcount(pawn_col[WHITE][i]);
    if (num > 0)
      if (((board->piece[WHITE][PAWN] & ~pawn_col[WHITE][i])
	   & (adj_cols[i])) == 0)
	*wval -= num*VAL_PAWN*0.25;
  }
  for (i = 0; i < 8; i++) {
    num = bitcount(pawn_col[BLACK][i]);
    if (num > 0)
      if (((board->piece[BLACK][PAWN] & ~pawn_col[BLACK][i])
	   & (adj_cols[i])) == 0)
	*bval -= num*VAL_PAWN*0.25;
	}*/
}

void eval_piece_placement(struct board *board, int *wval, int *bval) {
  bitboard pieces, piece;
  extern int dist_to_corn[64];
  extern bitboard pawn_start[2];
  extern bitboard pawn_lastrow[2];

  /* Knights should be standing close to the middle. */
  pieces = board->piece[WHITE][KNIGHT];
  while (pieces != 0) {
    piece = getlsb(pieces);
    *wval += dist_to_corn[get_first_bitpos(piece)];
    pieces &= ~piece;
  }
  pieces = board->piece[BLACK][KNIGHT];
  while (pieces != 0) {
    piece = getlsb(pieces);
    *bval += dist_to_corn[get_first_bitpos(piece)];
    pieces &= ~piece;
  }

  /* Bishops should not be sitting on the back row. */
  pieces = board->piece[WHITE][BISHOP];
  while (pieces != 0) {
    piece = getlsb(pieces);
    if (piece & pawn_lastrow[BLACK])
      *wval -= 1;
    pieces &= ~piece;
  }
  pieces = board->piece[BLACK][BISHOP];
  while (pieces != 0) {
    piece = getlsb(pieces);
    if (piece & pawn_lastrow[WHITE])
      *bval -= 1;
    pieces &= ~piece;
  }

  /* Encourage 7th rank attacks by rooks. */
  pieces = board->piece[WHITE][ROOK];
  while (pieces != 0) {
    piece = getlsb(pieces);
    if (piece & pawn_start[BLACK])
      *wval += 5;
    pieces &= ~piece;
  }
  pieces = board->piece[BLACK][ROOK];
  while (pieces != 0) {
    piece = getlsb(pieces);
    if (piece & pawn_start[WHITE])
      *bval += 5;
    pieces &= ~piece;
  }

  /* If the enemy queen is off the board, or if the opponent only has a few
     pieces left, then the king can move out of his shelter. Otherwise he
     should stay home. */
  /*if (board->piece[1-color][QUEEN] != 0 && ()) {
    //bestraffa en "modig kung"
    }*/
}

/* This function returns a value for how good a position is. A high value
   for the player at move means he is well off in the game. */
int eval(int *color, struct board *board) {
  int wvalue = 0, bvalue = 0;
  extern int dist_to_side[64];
  extern int dist_to_corn[64];

  /* Check the material balance. */
  wvalue += bitcount(board->piece[WHITE][PAWN])*VAL_PAWN;
  wvalue += bitcount(board->piece[WHITE][ROOK])*VAL_ROOK;
  wvalue += bitcount(board->piece[WHITE][KNIGHT])*VAL_KNIGHT;
  wvalue += bitcount(board->piece[WHITE][BISHOP])*VAL_BISHOP;
  wvalue += bitcount(board->piece[WHITE][QUEEN])*VAL_QUEEN;
  wvalue += bitcount(board->piece[WHITE][KING])*VAL_KING;
  bvalue += bitcount(board->piece[BLACK][PAWN])*VAL_PAWN;
  bvalue += bitcount(board->piece[BLACK][ROOK])*VAL_ROOK;
  bvalue += bitcount(board->piece[BLACK][KNIGHT])*VAL_KNIGHT;
  bvalue += bitcount(board->piece[BLACK][BISHOP])*VAL_BISHOP;
  bvalue += bitcount(board->piece[BLACK][QUEEN])*VAL_QUEEN;
  bvalue += bitcount(board->piece[BLACK][KING])*VAL_KING;

  /* Add the capture-values to make shallower captures (or promotions)
     to be worth a little bit more than deeper captures/promotions. This
     can be good if for example the engine detects that the loss of a pawn
     is inevitable to the maximum search depth. However beyond the horizon
     of the search it might turn out that it's indeed possible to save the
     pawn, and therefore we should try to keep it for as long as possible.
     Another use of this is if for example the engine has the possibility
     to promote a pawn to a queen. Then it needs some encouragement to do
     it soon, rather than waiting. */
  wvalue += board->captures[WHITE];
  bvalue += board->captures[BLACK];

  /* Add incentive to castle. */
  if (board->castling_status[WHITE] & CASTLED)
    wvalue += 50;
  else if (board->castling_status[WHITE]
	   & (LONG_CASTLING_OK | SHORT_CASTLING_OK))
    wvalue += 10;
  else
    wvalue -= 50;
  if (board->castling_status[BLACK] & CASTLED)
    bvalue += 50;
  else if (board->castling_status[BLACK]
	   & (LONG_CASTLING_OK | SHORT_CASTLING_OK))
    bvalue += 10;
  else
    bvalue -= 50;

  eval_piece_placement(board,&wvalue,&bvalue);
  eval_pawn_structure(board,&wvalue,&bvalue);

  if (endgame) {
    if (endgame == KRK || endgame == KQK) {
      int wsquare, bsquare;
      wsquare = get_first_bitpos(board->piece[WHITE][KING]);
      bsquare = get_first_bitpos(board->piece[BLACK][KING]);

      /* In KRK and KQK the color who is having the advantage should try
       to force the enemy king to the side, and to come close with his king. */

      if (bitcount(board->all_pieces[WHITE]) > 1) {    //white is ahead
	wvalue -= dist_to_side[bsquare]*10;
	wvalue -= 2*(abs(wsquare%8-bsquare%8) + abs(wsquare/8-bsquare/8));
	wvalue -= dist_to_corn[bsquare];
	wvalue += dist_to_side[wsquare];
      } else {   //black is ahead
	bvalue -= dist_to_side[wsquare]*10;
	bvalue -= 2*(abs(wsquare%8-bsquare%8) + abs(wsquare/8-bsquare/8));
	bvalue -= dist_to_corn[wsquare];
	bvalue += dist_to_side[bsquare];
      }
    }
  }

  if (*color == WHITE) {
    return (wvalue - bvalue);
  } else {   //black's turn, invert the value
    return bvalue - wvalue;
  }
}

