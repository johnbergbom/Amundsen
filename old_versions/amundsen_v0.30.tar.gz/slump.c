#include "slump.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

/* Denna funktion initierar ett fr� f�r slumptalsgenerering. Fr�et tas fr�n
   systemklockan. */
void init_random_seed() {
  time_t *t;
  char *str;

  t = (time_t *) malloc(1*sizeof(time_t));
  if (time(t) == -1)
    perror("Kunde inte f� tiden");
  else {
    str = (char *) malloc(100*sizeof(char));
    sprintf(str,"Random seed: %d\n",*t);
    debuglog(str);
    free(str);
    //srand(*t);
    srand(400);
    //srand(1063324603);
  }
  free(t);
}

/* Denna funktion returnerar ett tal som ligger mellan noll och high. */
int get_random_number(int high) {
  return (int) ((high+1)*(rand()/(RAND_MAX+1.0)));
}

