#ifndef _TRANSPTABLE_
#define _TRANSPTABLE_

#include "bitboards.h"

#define UNKNOWN 2000000
#define EXACT 0
#define ALPHA 1
#define BETA 2

void init_transptable();
int64 get_zobrist_key_for_board(struct board *board, int color_to_move);
int probe_hash(int depth, struct board *board, int alpha, int beta);
void record_hash(int depth, struct board *board, int value, int flag);

#endif      //_TRANSPTABLE_
