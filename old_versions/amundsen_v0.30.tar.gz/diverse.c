#include "diverse.h"
#include <stdio.h>
#include "parse.h"

void switch_colors(int *color) {
  if (*color == WHITE)
    *color = BLACK;
  else
    *color = WHITE;
}

void debuglog(char *text) {
  FILE *fp;
  char *filnamn = DEBUGLOGFILE;

  fp = fopen(filnamn,"a");
  if (fp == NULL)
    fprintf(stderr,"Could not open %s\n",DEBUGLOGFILE);
  fprintf(fp,"%s\n",text);
  fclose(fp);
}

