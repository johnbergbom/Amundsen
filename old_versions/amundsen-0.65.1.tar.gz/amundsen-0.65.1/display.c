#include "display.h"
#include <stdio.h>
#include "bitboards.h"
//#include "misc.h"
#include "parse.h"
#include "alfabeta.h"

extern bitboard square[64];

char getPieceLetter(int piece) {
  switch(piece) {
    case PAWN : return 'p';
                break;
    case KNIGHT : return 'N';
                  break;
    case BISHOP : return 'B';
                  break;
    case ROOK : return 'R';
                break;
    case QUEEN : return 'Q';
                 break;
    case KING : return 'K';
                break;
    case EMPTY : return ' ';
                 break;
  }
  return '?';
}

void showboard(struct board *board) {
  int rad = 0, kol = 0;
  int temp[64];
  int i, square_nbr;
  int64 pieces;

  for (kol = 0; kol < 64; kol++)
    temp[kol] = EMPTY;

  for (i = 0; i < 6; i++) {
    pieces = board->piece[WHITE][i];
    while (pieces != 0) {
      square_nbr = get_first_bitpos(pieces);
      temp[square_nbr] = i;
      pieces = pieces & ~square[square_nbr];
    }
  }

  for (i = 0; i < 6; i++) {
    pieces = board->piece[BLACK][i];
    while (pieces != 0) {
      square_nbr = get_first_bitpos(pieces);
      temp[square_nbr] = i;
      pieces = pieces & ~square[square_nbr];
    }
  }

  printf("  ---------------------------------\n");
  for (rad = 0; rad < 8; rad++) {
    printf("%d ",8 - rad);
    for (kol = 0; kol < 8; kol++) {
      printf("|");
      if (board->piece[WHITE][temp[rad*8+kol]] & square[rad*8+kol])
	INVERT;
      printf(" %c ",getPieceLetter(temp[rad*8 + kol]));
      NORMAL;
    }
    printf("|\n");
    if (rad < 7)
      printf("  |---+---+---+---+---+---+---+---|\n");
  }
  printf("  ---------------------------------\n");
  printf("    A   B   C   D   E   F   G   H\n");
}

#ifndef AM_DEBUG
void showsettings(struct board *board, int white, int black, int started) {
#else
void showsettings(struct board *board, int white, int black, int started, int gamelog) {
#endif
  printf("White     : ");
  if (white == COMPUTER)
    printf("engine\n");
  else
    printf("human\n");
  printf("Black   : ");
  if (black == COMPUTER)
    printf("engine\n");
  else
    printf("human\n");
  printf("Whose turn: ");
  if (board->color_at_move == WHITE)
    printf("white\n");
  else
    printf("black\n");
#ifdef AM_DEBUG
  if (gamelog)
    printf("Games are logged.");
  else
    printf("Games are not logged.");
#endif
  if (!started)
    printf("\nGame not started.\n");
}

void showhelp(int mode) {
#ifdef AM_DEBUG
  if (mode == DEBUG_MODE) {
    printf("\nCommand:    Meaning:\n\n");
    printf("show         Draw the board\n");
    printf("gamelog      Turn on logging of games\n");
    printf("nogamelog    Turn off logging of games\n");
    printf("set          Show settings\n");
    printf("?            Show help\n");
    printf("help         Show help\n");
    printf("debexit      Exit from debugging mode\n\n");
  } else
#endif
  {
    printf("\nCommand:                 Meaning:\n\n");
    printf("show                      Draw the board\n");
    printf("start                     Start a new game\n");
    printf("hist                      Show move history\n");
    printf("set                       Show settings\n");
    printf("testsuite filename.epd    Play a testsuite\n");
    printf("perft depth               Run perft to a specified depth\n");
    printf("play [-d depth] [-t time] Let the engine play a move from the current position\n");
    printf("setboard FEN              Set up a position according to a FEN string.\n");
    printf("enginewhite               Computer plays white\n");
    printf("humanwhite                Human plays white (default)\n");
    printf("engineblack               Computer plays black (default)\n");
    printf("humanblack                Human plays black\n");
#ifdef AM_DEBUG
    printf("debug                     Enter debug mode\n\n");
#endif
    printf("xboard                    Enter xboard mode\n\n");
    
    printf("?                         Show help\n");
    printf("help                      Show help\n");
    printf("quit                      Quit the program\n\n");
    
    printf("If you make a move, it should be written in the form\n");
    printf("e2e4 for normal moves, and a7a8[q|r|b|n] for pawn promotions.\n");
  }
}
