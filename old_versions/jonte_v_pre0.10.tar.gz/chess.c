#include <stdio.h>
#include "diverse.h"
#include "slump.h"

extern char *LATTEMINDRAG;
extern char *LATTEMAXDRAG;

int main(int argc, char **argv) {
  int white = HUMAN;     //som default �r vit m�nniska
  int black = COMPUTER;  //som default �r svart dator
  int vemstur = WHITE;   //vit b�rjar ju alltid
  int started = 0;       //�r noll innan ett parti b�rjat

  struct s *spel;

  LATTEMINDRAG = (char *) malloc(20*sizeof(char));
  LATTEMAXDRAG = (char *) malloc(20*sizeof(char));

  setbuf(stdin,NULL);      //set unbuffered input
  setbuf(stdout,NULL);     //set unbuffered output

  debuglog("------------------------------");
  init_random_seed();
  printf("\nThis is Jonte v. pre-0.1\n");
  printf("Copyright (C)2002-2003 John Bergbom\n");
  printf("\nType \'?\' for a list of commands.\n");

  //spel->spelplan = get_test_board();
  //spel->spelplan = get_test_board2();
  //spel->spelplan = get_test_board3();
  //spel->spelplan = get_test_board4();
  //spel = get_test_board5();
  spel = get_new_board();

  parse(&white,&black,&vemstur,&started,spel);
  free(spel);

  return 0;
}




