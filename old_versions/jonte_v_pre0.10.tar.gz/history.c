#include "history.h"
#include "diverse.h"

struct drag *historik;
int initierats = 0;
int histpos = 0;

void add_drag2history(struct drag *draget) {
  if (!initierats) {
    historik = (struct drag *) malloc(MAXDRAG_I_PARTI*2*sizeof(struct drag));
    initierats = 1;
  }

  historik[histpos].fromrow = draget->fromrow;
  historik[histpos].fromcol = draget->fromcol;
  historik[histpos].frompjas = draget->frompjas;
  historik[histpos].torow = draget->torow;
  historik[histpos].tocol = draget->tocol;
  historik[histpos].topjas = draget->topjas;
  historik[histpos].value = draget->value;
  historik[histpos].rockad = draget->rockad;

  histpos++;
  if (histpos > MAXDRAG_I_PARTI - 10)
    printf("Rapportera: Stort parti!\n");
}

/* Denna funktion returnerar draget nummer. Nummer ska vara ett negativt
   tal som betecknar vilket drag tidigare i spelet man vill ha fram,
   j�mf�rt med det just gjorda draget. getmovenumber(-1) returnerar
   det just gjorda draget. */
struct drag getmovenumber(int nummer) {
  return historik[histpos + nummer];
}

void showhistory() {
  char *drag;
  int i;

  if (histpos == 0) {
    printf("Tom draglista.\n");
    return;
  }

  printf("Parti:\n");
  drag = (char *) malloc(20*sizeof(char));
  for (i = 0; i < histpos; i++) {
    drag2str(historik[i],drag);
    if (i % 2 == 0)
      printf("%d: ",i/2+1);
    printf("%s",drag);
    if (i % 2 == 0)
      printf("  ");
    else
      printf("\n");
  }
  free(drag);
}

