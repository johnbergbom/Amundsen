#include "kung.h"

/* Denna funktion returnerar en lista p� alla drag kungen kan
   g�ra. Sista positionen i listan �r -99. */
struct drag *drag_kung(struct s *spel, int rad, int kol, int vemstur) {
  struct drag *draglista;
  int i = 0;
  int pjas;

  draglista = (struct drag *) malloc((MAX_KING_MOVE+1)*sizeof(struct drag));
  pjas = spel->spelplan[rad][kol];

  if (insert(spel->spelplan,rad-1,kol,vemstur))
    initdrag(&draglista[i++],rad,kol,rad-1,kol,pjas);
  if (insert(spel->spelplan,rad-1,kol+1,vemstur))
    initdrag(&draglista[i++],rad,kol,rad-1,kol+1,pjas);
  if (insert(spel->spelplan,rad,kol+1,vemstur))
    initdrag(&draglista[i++],rad,kol,rad,kol+1,pjas);
  if (insert(spel->spelplan,rad+1,kol+1,vemstur))
    initdrag(&draglista[i++],rad,kol,rad+1,kol+1,pjas);
  if (insert(spel->spelplan,rad+1,kol,vemstur))
    initdrag(&draglista[i++],rad,kol,rad+1,kol,pjas);
  if (insert(spel->spelplan,rad+1,kol-1,vemstur))
    initdrag(&draglista[i++],rad,kol,rad+1,kol-1,pjas);
  if (insert(spel->spelplan,rad,kol-1,vemstur))
    initdrag(&draglista[i++],rad,kol,rad,kol-1,pjas);
  if (insert(spel->spelplan,rad-1,kol-1,vemstur))
    initdrag(&draglista[i++],rad,kol,rad-1,kol-1,pjas);

  if (vemstur == WHITE) {
    if (!spel->vitrockerat) {
      if (!spel->vitkingmoved) {
	if ((!spel->vitHtornmoved) && (spel->spelplan[7][5] == EMPTY)
            && (spel->spelplan[7][6] == EMPTY)) {
	  initdrag(&draglista[i],rad,kol,rad,kol+2,pjas);  //kort rockad
	  draglista[i++].rockad = KORT_ROCKAD;
	}
	if ((!spel->vitAtornmoved) && (spel->spelplan[7][3] == EMPTY)
            && (spel->spelplan[7][2] == EMPTY) && (spel->spelplan[7][1] == EMPTY)) {
	  initdrag(&draglista[i],rad,kol,rad,kol-2,pjas);   //lang rockad
	  draglista[i++].rockad = LANG_ROCKAD;
	}
      }
    }
  } else {
    if (!spel->svartrockerat) {
      if (!spel->svartkingmoved) {
	if ((!spel->svartHtornmoved) && (spel->spelplan[0][5] == EMPTY)
            && (spel->spelplan[0][6] == EMPTY)) {
	  initdrag(&draglista[i],rad,kol,rad,kol+2,pjas);  //kort rockad
	  draglista[i++].rockad = KORT_ROCKAD;
	}
	if ((!spel->svartAtornmoved) && (spel->spelplan[0][3] == EMPTY)
            && (spel->spelplan[0][2] == EMPTY) && (spel->spelplan[0][1] == EMPTY)) {
	  initdrag(&draglista[i],rad,kol,rad,kol-2,pjas);   //lang rockad
	  draglista[i++].rockad = LANG_ROCKAD;
	}
      }
    }
  }

  draglista[i].fromrow = -99;
  return draglista;
}
