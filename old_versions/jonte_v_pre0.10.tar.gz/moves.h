#ifndef _MOVES_
#define _MOVES_

#include "diverse.h"

/*Denna funktion satter som default topjas == frompjas, och rockad == 0. Det
  eftersom detta galler i 99% av fallen. Vid bondeforvandling eller rockad
  far man sjalv satta ratt varde efter att man anropat denna funktion. */
void initdrag(struct drag *drag, int frad, int fkol, int trad, int tkol, int pjas);

/* Denna funktion omvandlar en str�ng till ett struct drag-objekt. Om str�ngen
   �r felaktig returneras -99. */
struct drag str2drag(char *vilket_drag, struct s *spel, int vemstur);

/* Denna funktion omvandlar ett drag till en str�ng. */
void drag2str(struct drag draget, char *vilket_drag);

void undomove(struct s *spel, struct drag *vilket_drag, struct s *oldflags, int oldsquare);

void makemove(struct s *spel, struct drag *vilket_drag, struct s *saved_flags);

#endif      //_MOVES_
