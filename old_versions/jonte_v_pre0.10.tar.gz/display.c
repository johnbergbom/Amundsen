#include "display.h"
#include "symboler.h"
//#include "netdiverse.h"

//extern int clientcount;
//extern int speed;
//extern struct clients *clientlist;

void printmoves(struct drag *draglista) {
  int i = 0;
  char *dragstr;

  dragstr = (char *) malloc(20*sizeof(char));
  while (draglista[i].fromrow != -99) {
    drag2str(draglista[i],dragstr);
    printf("%s\n",dragstr);
    i++;
  }
  free(dragstr);
}

char getPjasBokstav(int pjas) {
  switch(abs(pjas)) {
    case WHITE_PAWN : return PAWN_LETTER;
                      break;
    case WHITE_ROOK : return ROOK_LETTER;
                      break;
    case WHITE_KNIGHT : return KNIGHT_LETTER;
                        break;
    case WHITE_BISHOP : return BISHOP_LETTER;
                        break;
    case WHITE_QUEEN : return QUEEN_LETTER;
                       break;
    case WHITE_KING : return KING_LETTER;
                      break;
    case EMPTY : return EMPTY_LETTER;
                 break;
  }
  return '?';
}

void print_table(int **spelplan) {
  int rad = 0, kol = 0;
  //CLRSCR;
  //GOTOXY(0,0);
  printf("  ---------------------------------\n");
  for (rad = 0; rad < 8; rad++) {
    printf("%d ",8 - rad);
    for (kol = 0; kol < 8; kol++) {
      printf("|");
      if (spelplan[rad][kol] > 0)
	INVERT;
      printf(" %c ",getPjasBokstav(spelplan[rad][kol]));
      //printf(" %d ",spelplan[rad][kol]);
      NORMAL;
    }
    printf("|\n");
    if (rad < 7)
      printf("  |---+---+---+---+---+---+---+---|\n");
  }
  printf("  ---------------------------------\n");
  printf("    A   B   C   D   E   F   G   H\n");
}


void showsettings(int *white, int *black, int *vemstur, int *started) {
  int i;

  printf("Vit     : ");
  if (*white == COMPUTER)
    printf("dator\n");
  else
    printf("m�nniska\n");
  printf("Svart   : ");
  if (*black == COMPUTER)
    printf("dator\n");
  else
    printf("m�nniska\n");
  printf("Vems tur: ");
  if (*vemstur == WHITE)
    printf("vit\n");
  else
    printf("svart\n");
  printf("Algoritm: ");
  if (STRATEGY == RANDOM)
    printf("slumpm�ssigt drag\n");
  else if (STRATEGY == MINMAX)
    printf("minmax (t�nker %.1f drag fram�t)\n",(double)THINKFORWARD/2);
  else if (STRATEGY == ALPHABETA)
    printf("alfa-beta besk�rning (t�nker %.1f drag fram�t)\n",(double)THINKFORWARD/2);
  else
    printf("ERROR\n");
  /*printf("\nServer: hastighet = %d\n",speed);
  printf("\nKlienter:\n");
  if (clientcount == 0) {
    printf("inga\n");
  } else {
    for (i = 0; i < clientcount; i++) {
      printf("%s (hastighet = %d)\n",clientlist[i].hostname,clientlist[i].speed);
    }
    }*/
  if (!*started)
    printf("\nParti ej startat.\n");
}

void showhelp() {
  printf("\nKommando:    Betydelse:\n\n");
  printf("visa         Rita upp spelplanen\n");
  printf("starta       Starta ett nytt parti\n");
  //printf("tanke        Skriv ut hur datorn t�nkte\n");
  printf("hist         Visa draghistorik\n");
  printf("inst         Visa inst�llningar\n");
  printf("vitdator     Datorn spelar de vita pj�serna\n");
  printf("vitman       Du spelar sj�lv de vita pj�serna (f�rvalt)\n");
  printf("svartdator   Datorn spelar de svarta pj�serna (f�rvalt)\n");
  printf("svartman     Du spelar sj�lv de svarta pj�serna\n");
  printf("xboard       xboard-l�ge\n\n");
  //printf("(Notera att datorn kan spela mot sig sj�lv, eller\n");
  //printf(" om man s� vill, tv� m�nniskor mot varandra.)\n\n");

  printf("?            Visa hj�lp\n");
  printf("hj�lp        Visa hj�lp\n");
  printf("avsluta      Avsluta programmet\n\n");

  printf("Om du g�r ett drag, ska det skrivas p� formen\n");
  printf("e2e4 f�r vanliga drag, och a7a8q f�r bondef�rvandling.\n");
}


