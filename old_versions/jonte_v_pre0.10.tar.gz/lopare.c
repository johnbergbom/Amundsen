#include "lopare.h"

#include "diverse.h"

/* Denna funktion returnerar en lista p� alla drag en viss l�pare kan
   g�ra. Sista positionen i listan �r -99. */
struct drag *drag_lopare(int **spelplan, int rad, int kol) {
  int i = 0;
  struct drag *draglista;
  int t_rad, t_kol;
  int quit_loop;

  /*+1 f�r att rymma -99 p� slutet*/
  draglista = (struct drag *) malloc((MAX_BISHOP_MOVE+1)*sizeof(struct drag));
  if (spelplan[rad][kol] == WHITE_BISHOP) {

    /* Kolla hur m�nga steg "sydv�st" han kan g�. */
    t_rad = rad + 1;
    t_kol = kol - 1;
    quit_loop = 0;
    while ((t_rad < 8) && (t_kol > -1) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_BISHOP);
      } else if (spelplan[t_rad][t_kol] < 0) {   //om svart pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_BISHOP);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] > 0) {     //om vit pj�s
	quit_loop = 1;
      }
      t_rad++;
      t_kol--;
    }

    /* Kolla hur m�nga steg "nordost" han kan g�. */
    t_rad = rad - 1;
    t_kol = kol + 1;
    quit_loop = 0;
    while ((t_rad > -1) && (t_kol < 8) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_BISHOP);
      } else if (spelplan[t_rad][t_kol] < 0) {   //om svart pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_BISHOP);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] > 0) {     //om vit pj�s
	quit_loop = 1;
      }
      t_rad--;
      t_kol++;
    }

    /* Kolla hur m�nga steg �t "nordv�st" han kan g�. */
    t_rad = rad - 1;
    t_kol = kol - 1;
    quit_loop = 0;
    while ((t_kol > -1) && (t_rad > -1) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_BISHOP);
      } else if (spelplan[t_rad][t_kol] < 0) {   //om svart pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_BISHOP);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] > 0) {     //om vit pj�s
	quit_loop = 1;
      }
      t_rad--;
      t_kol--;
    }

    /* Kolla hur m�nga steg �t "sydv�st" han kan g�. */
    t_rad = rad + 1;
    t_kol = kol + 1;
    quit_loop = 0;
    while ((t_kol < 8) && (t_rad < 8) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_BISHOP);
      } else if (spelplan[t_rad][t_kol] < 0) {   //om svart pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_BISHOP);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] > 0) {     //om vit pj�s
	quit_loop = 1;
      }
      t_rad++;
      t_kol++;
    }
  } else if (spelplan[rad][kol] == BLACK_BISHOP) {

    /* Kolla hur m�nga steg "sydv�st" han kan g�. */
    t_rad = rad + 1;
    t_kol = kol - 1;
    quit_loop = 0;
    while ((t_rad < 8) && (t_kol > -1) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_BISHOP);
      } else if (spelplan[t_rad][t_kol] > 0) {   //om vit pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_BISHOP);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] < 0) {     //om svart pj�s
	quit_loop = 1;
      }
      t_rad++;
      t_kol--;
    }

    /* Kolla hur m�nga steg "nordost" han kan g�. */
    t_rad = rad - 1;
    t_kol = kol + 1;
    quit_loop = 0;
    while ((t_rad > -1) && (t_kol < 8) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_BISHOP);
      } else if (spelplan[t_rad][t_kol] > 0) {   //om vit pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_BISHOP);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] < 0) {     //om svart pj�s
	quit_loop = 1;
      }
      t_rad--;
      t_kol++;
    }

    /* Kolla hur m�nga steg �t "nordv�st" han kan g�. */
    t_rad = rad - 1;
    t_kol = kol - 1;
    quit_loop = 0;
    while ((t_kol > -1) && (t_rad > -1) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_BISHOP);
      } else if (spelplan[t_rad][t_kol] > 0) {   //om vit pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_BISHOP);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] < 0) {     //om svart pj�s
	quit_loop = 1;
      }
      t_rad--;
      t_kol--;
    }

    /* Kolla hur m�nga steg �t "sydv�st" han kan g�. */
    t_rad = rad + 1;
    t_kol = kol + 1;
    quit_loop = 0;
    while ((t_kol < 8) && (t_rad < 8) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_BISHOP);
      } else if (spelplan[t_rad][t_kol] > 0) {   //om vit pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_BISHOP);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] < 0) {     //om svart pj�s
	quit_loop = 1;
      }
      t_rad++;
      t_kol++;
    }
  } else {
    //g�r ingenting, det var inte en l�pare som stod p� rutan
  }
  draglista[i].fromrow = -99;
  return draglista;
}



/* Kollar om en l�pare kan g� fr�n en ruta till en annan, enligt
   reglerna f�r l�parens f�rflyttning. Vi tar ej h�nsyn till
   om tex. en schack om�jligg�r draget, utan vi tittar endast
   p� reglerna f�r pj�sens f�rflyttning. NOTERA: color �r f�rgen
   p� motst�ndarens pj�ser. Denna funktion anropas fr�n
   check_opponentschack() i makelist.c
     Vi kollar inte vad som finns p� spelplan[torow][tocol],
   och f�r �vrigt f�rv�ntas spelplan[fromrow][fromcol] vara tom. */
int bishopmovevalid(int **spelplan, int fromrow, int fromcol, int torow, int tocol) {
  int i, j;

  if (fromrow - torow == fromcol - tocol) {   //Nordv�st
    j = 0;
    for (i = fromcol; i > tocol; i--) {
      if (spelplan[fromrow - j][fromcol - j] != EMPTY)
	return 0;
      j++;
    }
    return 1;
  } else if (fromrow - torow == tocol - fromcol) {   //Nordost
    j = 0;
    for (i = fromcol; i < tocol; i++) {
      if (spelplan[fromrow - j][fromcol + j] != EMPTY)
	return 0;
      j++;
    }
    return 1;
  } else if (torow - fromrow == fromcol - tocol) {   //Sydv�st
    j = 0;
    for (i = fromcol; i > tocol; i--) {
      if (spelplan[fromrow + j][fromcol - j] != EMPTY)
	return 0;
      j++;
    }
    return 1;
  } else if (torow - fromrow == tocol - fromcol) {   //Sydost
    j = 0;
    for (i = fromcol; i < tocol; i++) {
      if (spelplan[fromrow + j][fromcol + j] != EMPTY)
	return 0;
      j++;
    }
    return 1;
  }

  return 0;
}





