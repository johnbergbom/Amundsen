#include "bonde.h"

void bondeforvandling(struct drag *draglista, int *i, int frad, int fkol, int trad, int tkol, int color) {
  if (color == WHITE) {
    initdrag(&draglista[*i],frad,fkol,trad,tkol,WHITE_PAWN);
    draglista[(*i)++].topjas = WHITE_QUEEN;
    initdrag(&draglista[*i],frad,fkol,trad,tkol,WHITE_PAWN);
    draglista[(*i)++].topjas = WHITE_ROOK;
    initdrag(&draglista[*i],frad,fkol,trad,tkol,WHITE_PAWN);
    draglista[(*i)++].topjas = WHITE_KNIGHT;
    initdrag(&draglista[*i],frad,fkol,trad,tkol,WHITE_PAWN);
    draglista[(*i)++].topjas = WHITE_BISHOP;
  } else {
    initdrag(&draglista[*i],frad,fkol,trad,tkol,BLACK_PAWN);
    draglista[(*i)++].topjas = BLACK_QUEEN;
    initdrag(&draglista[*i],frad,fkol,trad,tkol,BLACK_PAWN);
    draglista[(*i)++].topjas = BLACK_ROOK;
    initdrag(&draglista[*i],frad,fkol,trad,tkol,BLACK_PAWN);
    draglista[(*i)++].topjas = BLACK_KNIGHT;
    initdrag(&draglista[*i],frad,fkol,trad,tkol,BLACK_PAWN);
    draglista[(*i)++].topjas = BLACK_BISHOP;
  }
}

/* Denna funktion returnerar en lista p� alla drag en viss bonde kan
   g�ra. Sista positionen i listan �r -99. */
struct drag *drag_bonde(int **spelplan, int rad, int kol) {
  int i = 0;
  struct drag *draglista;

  /*+1 f�r att rymma -99 p� slutet*/
  draglista = (struct drag *) malloc((MAX_PAWN_MOVE+1)*sizeof(struct drag));
  if ((rad >= 0) && (rad <= 7) && (kol >= 0) && (kol <= 7)) {
    if (spelplan[rad][kol] == WHITE_PAWN) {
      if (rad - 1 >= 0) {
	if (spelplan[rad-1][kol] == EMPTY) {
	  //kan g� ett steg fram�t
	  if (rad - 1 == 0)  //bondeforvandling
	    bondeforvandling(draglista,&i,rad,kol,rad-1,kol,WHITE);
	  else
	    initdrag(&draglista[i++],rad,kol,rad-1,kol,WHITE_PAWN);
	  if ((rad == 6) && (spelplan[rad-2][kol] == EMPTY)) {
	    //kan g� tv� steg fram�t eftersom den st�r i sin utg�ngsposition
	    initdrag(&draglista[i++],rad,kol,rad-2,kol,WHITE_PAWN);
	  }
	}
	if (kol - 1 >= 0) {
	  if (spelplan[rad-1][kol-1] < 0) {
	    //kan ta en motspelare
	    if (rad - 1 == 0)  //bondeforvandling
	      bondeforvandling(draglista,&i,rad,kol,rad-1,kol-1,WHITE);
	    else
	      initdrag(&draglista[i++],rad,kol,rad-1,kol-1,WHITE_PAWN);
	  }
	}
	if (kol + 1 <= 7) {
	  if (spelplan[rad-1][kol+1] < 0) {
	    //kan ta en motspelare
	    if (rad - 1 == 0)   //bondeforvandling
	      bondeforvandling(draglista,&i,rad,kol,rad-1,kol+1,WHITE);
	    else
	      initdrag(&draglista[i++],rad,kol,rad-1,kol+1,WHITE_PAWN);
	  }
	}
      }
      /* KOM IH�G ATT FIXA S� ATT DEN �VEN KLARAR AV EN PASSANT.
	 EVENTUELLT KAN DETTA G�RAS GENOM ATT MAN ANROPAR EN
	 HISTORY-FUNKTION SOM RETURNERAR F�RRA DRAGET. OM
	 MOTST�NDARENS F�RRA DRAG VAR ATT FLYTTA SIN BONDE S�
	 ATT DEN ST�R TILL H�GER ELLER V�NSTER OM VITS BONDE,
	 KAN VIT G�RA EN PASSANT. */
    } else if (spelplan[rad][kol] == BLACK_PAWN) {
      if (rad + 1 <= 7) {
	if (spelplan[rad+1][kol] == EMPTY) {
	  //kan g� ett steg fram�t
	  if (rad + 1 == 7)   //bondeforvandling
	    bondeforvandling(draglista,&i,rad,kol,rad+1,kol,BLACK);
	  else
	    initdrag(&draglista[i++],rad,kol,rad+1,kol,BLACK_PAWN);
	  if ((rad == 1) && (spelplan[rad+2][kol] == EMPTY)) {
	    //kan g� tv� steg fram�t eftersom den st�r i sin utg�ngsposition
	    initdrag(&draglista[i++],rad,kol,rad+2,kol,BLACK_PAWN);
	  }
	}
	if (kol - 1 >= 0) {
	  if (spelplan[rad+1][kol-1] > 0) {
	    //kan ta en motspelare
	    if (rad + 1 == 7)   //bondeforvandling
	      bondeforvandling(draglista,&i,rad,kol,rad+1,kol-1,BLACK);
	    else
	      initdrag(&draglista[i++],rad,kol,rad+1,kol-1,BLACK_PAWN);
	  }
	}
	if (kol + 1 <= 7) {
	  if (spelplan[rad+1][kol+1] > 0) {
	    //kan ta en motspelare
	    if (rad + 1 == 7)   //bondeforvandling
	      bondeforvandling(draglista,&i,rad,kol,rad+1,kol+1,BLACK);
	    else
	      initdrag(&draglista[i++],rad,kol,rad+1,kol+1,BLACK_PAWN);
	  }
	}
      }
      /* KOM IH�G ATT FIXA S� ATT DEN �VEN KLARAR AV EN PASSANT.
	 EVENTUELLT KAN DETTA G�RAS GENOM ATT MAN ANROPAR EN
	 HISTORY-FUNKTION SOM RETURNERAR F�RRA DRAGET. OM
	 MOTST�NDARENS F�RRA DRAG VAR ATT FLYTTA SIN BONDE S�
	 ATT DEN ST�R TILL H�GER ELLER V�NSTER OM VITS BONDE,
	 KAN VIT G�RA EN PASSANT. */
    } else {
      //g�r ingenting, det var inte en bonde som stod p� rutan
    }
  }
  draglista[i].fromrow = -99;
  return draglista;
}


/* Kollar om en bonde kan g� fr�n en ruta till en annan, enligt
   reglerna f�r bondens f�rflyttning. Vi tar ej h�nsyn till
   om tex. en schack om�jligg�r draget, utan vi tittar endast
   p� reglerna f�r pj�sens f�rflyttning. NOTERA: color �r f�rgen
   p� motst�ndarens pj�ser. Denna funktion anropas fr�n
   check_opponentschack() i makelist.c */
int pawnmovevalid(int fromrow, int fromcol, int torow, int tocol, int color) {
  if (color == WHITE) {    //svart bonde!!
    if (fromrow + 1 == torow && fromcol - 1 == tocol)
      return 1;
    else if (fromrow + 1 == torow && fromcol + 1 == tocol)
      return 1;
  } else {                 //vit bonde!!
    if (fromrow - 1 == torow && fromcol - 1 == tocol)
      return 1;
    else if (fromrow - 1 == torow && fromcol + 1 == tocol)
      return 1;
  }

  return 0;
}

