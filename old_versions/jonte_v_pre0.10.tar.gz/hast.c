#include "hast.h"

#include "diverse.h"

int insert(int **spelplan,int rad, int kol, int vemstur) {
  if ((rad >= 0) && (rad < 8) && (kol >= 0) && (kol < 8)) {
    if (spelplan[rad][kol] == EMPTY)
      return 1;
    else {
      if (((vemstur == WHITE) && (spelplan[rad][kol] < 0))
	  || ((vemstur == BLACK) && (spelplan[rad][kol] > 0)))
	return 1;
      else
	return 0;
    }
  } else
    return 0;
}

/* Denna funktion returnerar en lista p� alla drag en viss h�st kan
   g�ra. Sista positionen i listan �r -99. */
struct drag *drag_hast(int **spelplan, int rad, int kol, int vemstur) {
  struct drag *draglista;
  int i = 0;
  int pjas;
  
  draglista = (struct drag *) malloc((MAX_KNIGHT_MOVE+1)*sizeof(struct drag));
  pjas = spelplan[rad][kol];
  
  if (insert(spelplan,rad-2,kol+1,vemstur))
    initdrag(&draglista[i++],rad,kol,rad-2,kol+1,pjas);
  if (insert(spelplan,rad-1,kol+2,vemstur))
    initdrag(&draglista[i++],rad,kol,rad-1,kol+2,pjas);
  if (insert(spelplan,rad+1,kol+2,vemstur))
    initdrag(&draglista[i++],rad,kol,rad+1,kol+2,pjas);
  if (insert(spelplan,rad+2,kol+1,vemstur))
    initdrag(&draglista[i++],rad,kol,rad+2,kol+1,pjas);
  if (insert(spelplan,rad+2,kol-1,vemstur))
    initdrag(&draglista[i++],rad,kol,rad+2,kol-1,pjas);
  if (insert(spelplan,rad+1,kol-2,vemstur))
    initdrag(&draglista[i++],rad,kol,rad+1,kol-2,pjas);
  if (insert(spelplan,rad-1,kol-2,vemstur))
    initdrag(&draglista[i++],rad,kol,rad-1,kol-2,pjas);
  if (insert(spelplan,rad-2,kol-1,vemstur))
    initdrag(&draglista[i++],rad,kol,rad-2,kol-1,pjas);

  draglista[i].fromrow = -99;
  return draglista;
}


/* Kollar om en h�st kan g� fr�n en ruta till en annan, enligt
   reglerna f�r h�stens f�rflyttning. Vi tar ej h�nsyn till
   om tex. en schack om�jligg�r draget, utan vi tittar endast
   p� reglerna f�r pj�sens f�rflyttning. */
int knightmovevalid(int fromrow, int fromcol, int torow, int tocol) {
  if (fromrow - 2 == torow && fromcol + 1 == tocol)
    return 1;
  else if (fromrow - 1 == torow && fromcol + 2 == tocol)
    return 1;
  else if (fromrow + 1 == torow && fromcol + 2 == tocol)
    return 1;
  else if (fromrow + 2 == torow && fromcol + 1 == tocol)
    return 1;
  else if (fromrow + 2 == torow && fromcol - 1 == tocol)
    return 1;
  else if (fromrow + 1 == torow && fromcol - 2 == tocol)
    return 1;
  else if (fromrow - 1 == torow && fromcol - 2 == tocol)
    return 1;
  else if (fromrow - 2 == torow && fromcol - 1 == tocol)
    return 1;

  return 0;
}




