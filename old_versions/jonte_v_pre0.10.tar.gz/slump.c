#include "slump.h"
#include <stdlib.h>
#include <sys/time.h>

/* Denna funktion initierar ett fr� f�r slumptalsgenerering. Fr�et tas fr�n
   systemklockan. */
void init_random_seed() {
  time_t *t;

  t = (time_t *) malloc(1*sizeof(time_t));
  if (time(t) == -1)
    perror("Kunde inte f� tiden");
  else {
    //srand(*t);
    srand(400);
  }
  free(t);
}

/* Denna funktion returnerar ett tal som ligger mellan noll och high. */
int get_random_number(int high) {
  return (int) ((high+1)*(rand()/(RAND_MAX+1.0)));
}

