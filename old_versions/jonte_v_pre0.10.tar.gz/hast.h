#ifndef _HAST_
#define _HAST_

int insert(int **spelplan,int rad, int kol, int vemstur);

/* Denna funktion returnerar en lista p� alla drag en viss h�st kan
   g�ra. Sista positionen i listan �r -99. */
struct drag *drag_hast(int **spelplan, int rad, int kol, int vemstur);

/* Kollar om en h�st kan g� fr�n en ruta till en annan, enligt
   reglerna f�r h�stens f�rflyttning. Vi tar ej h�nsyn till
   om tex. en schack om�jligg�r draget, utan vi tittar endast
   p� reglerna f�r pj�sens f�rflyttning. */
int knightmovevalid(int fromrow, int fromcol, int torow, int tocol);

#endif     //_HAST_
