#include "genmoves.h"
#include <stdlib.h>
#include <stdio.h>
#include "moves.h"
#include "bonde.h"
#include "torn.h"
#include "hast.h"
#include "lopare.h"
#include "dam.h"
#include "kung.h"

/* Denna funktion reallokerar en listas storlek i minnet. */
int change_list_size(struct drag **lista, int new_size) {
  struct drag *ny_lista;

  if((ny_lista = (struct drag *) realloc(*lista,(new_size + 1)*sizeof(struct drag))) == NULL) {
    perror("Realloc failed");
    exit(1);
  } else
    *lista = ny_lista;
  
  return new_size;
}

int nbr_of_moves(struct drag *lista) {
  int i = 0;
  while (lista[i].fromrow != -99) {
    i++;
  }
  return i;
}

/* Denna funktion returnerar true eller false beroende p� om pj�sen
   �r av samma f�rg som farg. */
int samecolor(int pjas, int farg) {
  if ((farg == WHITE && pjas > 0) || (farg == BLACK && pjas < 0))
    return 1;
  else
    return 0;
}

/* Denna funktion returnerar true om pj�sen pjas_att_kolla �r en
   likadan pj�s som ABS_pjas, fast i motsatt f�rg som farg. Annars
   returnas false. */
int oppositecolor(int pjas_att_kolla, int ABS_pjas, int farg) {
  if ((farg == WHITE) && (pjas_att_kolla > 0))
    return 0;
  if ((farg == BLACK) && (pjas_att_kolla < 0))
    return 0;

  if (abs(pjas_att_kolla) == ABS_pjas)
    return 1;
  else
    return 0;
}

/* Denna funktion returnerar true (=1) om kungen st�r i schack,
   och false (=0) annars. Argumenten kungrad och kungkol indikerar
   var p� spelplanen kungen st�r. */
int i_schack(int **spelplan, int kungrad, int kungkol) {
  int rad, kol;
  int kingcolor;

  if (spelplan[kungrad][kungkol] > 0)
    kingcolor = WHITE;
  else
    kingcolor = BLACK;

  /*Kolla om hot finns fr�n "nordv�st"*/
  rad = kungrad - 1;
  kol = kungkol - 1;
  while ((rad >= 0) && (kol >= 0)) {
    if ((oppositecolor(spelplan[rad][kol],ABS_BISHOP,kingcolor))
	|| (oppositecolor(spelplan[rad][kol],ABS_QUEEN,kingcolor))) {
      return 1;
    } else if (spelplan[rad][kol] != EMPTY) {
      break;
    }
    rad--;
    kol--;
  }
  
  /*Kolla om hot finns fr�n "nordost"*/
  rad = kungrad - 1;
  kol = kungkol + 1;
  while ((rad >= 0) && (kol <= 7)) {
    if ((oppositecolor(spelplan[rad][kol],ABS_BISHOP,kingcolor))
	|| (oppositecolor(spelplan[rad][kol],ABS_QUEEN,kingcolor))) {
      return 1;
    } else if (spelplan[rad][kol] != EMPTY) {
      break;
    }
    rad--;
    kol++;
  }
  
  /*Kolla om hot finns fr�n "sydv�st"*/
  rad = kungrad + 1;
  kol = kungkol - 1;
  while ((rad <= 7) && (kol >= 0)) {
    if ((oppositecolor(spelplan[rad][kol],ABS_BISHOP,kingcolor))
	|| (oppositecolor(spelplan[rad][kol],ABS_QUEEN,kingcolor))) {
      return 1;
    } else if (spelplan[rad][kol] != EMPTY) {
      break;
    }
    rad++;
    kol--;
  }
  
  /*Kolla om hot finns fr�n "sydost"*/
  rad = kungrad + 1;
  kol = kungkol + 1;
  while ((rad <= 7) && (kol <= 7)) {
    if ((oppositecolor(spelplan[rad][kol],ABS_BISHOP,kingcolor))
	|| (oppositecolor(spelplan[rad][kol],ABS_QUEEN,kingcolor))) {
      return 1;
    } else if (spelplan[rad][kol] != EMPTY) {
      break;
    }
    rad++;
    kol++;
  }
  
  /*Kolla om hot finns fr�n "norr"*/
  rad = kungrad - 1;
  kol = kungkol;
  while (rad >= 0) {
    if ((oppositecolor(spelplan[rad][kol],ABS_ROOK,kingcolor))
	|| (oppositecolor(spelplan[rad][kol],ABS_QUEEN,kingcolor))) {
      return 1;
    } else if (spelplan[rad][kol] != EMPTY) {
      break;
    }
    rad--;
  }
  
  /*Kolla om hot finns fr�n "s�der"*/
  rad = kungrad + 1;
  kol = kungkol;
  while (rad <= 7) {
    if ((oppositecolor(spelplan[rad][kol],ABS_ROOK,kingcolor))
	|| (oppositecolor(spelplan[rad][kol],ABS_QUEEN,kingcolor))) {
      return 1;
    } else if (spelplan[rad][kol] != EMPTY) {
      break;
    }
    rad++;
  }
  
  /*Kolla om hot finns fr�n "v�ster"*/
  rad = kungrad;
  kol = kungkol - 1;
  while (kol >= 0) {
    if ((oppositecolor(spelplan[rad][kol],ABS_ROOK,kingcolor))
	|| (oppositecolor(spelplan[rad][kol],ABS_QUEEN,kingcolor))) {
      return 1;
    } else if (spelplan[rad][kol] != EMPTY) {
      break;
    }
    kol--;
  }
  
  /*Kolla om hot finns fr�n "�ster"*/
  rad = kungrad;
  kol = kungkol + 1;
  while (kol <= 7) {
    if ((oppositecolor(spelplan[rad][kol],ABS_ROOK,kingcolor))
	|| (oppositecolor(spelplan[rad][kol],ABS_QUEEN,kingcolor))) {
      return 1;
    } else if (spelplan[rad][kol] != EMPTY) {
      break;
    }
    kol++;
  }
  
  /*Kolla om fientliga b�nder kan ta kungen*/
  if (kingcolor == WHITE) {
    if (kungrad > 1) {
      if (kungkol > 0) {
	if (oppositecolor(spelplan[kungrad-1][kungkol-1],ABS_PAWN,kingcolor)) {
	  return 1;
	}
      }
      if (kungkol < 7) {
	if (oppositecolor(spelplan[kungrad-1][kungkol+1],ABS_PAWN,kingcolor)) {
	  return 1;
	}
      }
    }
  } else {
    if (kungrad < 6) {
      if (kungkol > 0) {
	if (oppositecolor(spelplan[kungrad+1][kungkol-1],ABS_PAWN,kingcolor)) {
	  return 1;
	}
      }
      if (kungkol < 7) {
	if (oppositecolor(spelplan[kungrad+1][kungkol+1],ABS_PAWN,kingcolor)) {
	  return 1;
	}
      }
    }
  }
  
  /*Kolla om fientlig h�st finns tv� steg framf�r
    och ett �t v�nster/h�ger*/
  rad = kungrad;
  kol = kungkol;
  if (rad > 1) {
    if (kol > 0) {
      if (oppositecolor(spelplan[kungrad-2][kungkol-1],ABS_KNIGHT,kingcolor)) {
	return 1;
      }
    }
    if (kol < 7) {
      if (oppositecolor(spelplan[kungrad-2][kungkol+1],ABS_KNIGHT,kingcolor)) {
	return 1;
      }
    }
  }
  
  /*Kolla om fientlig h�st finns tv� steg bakom
    och ett �t v�nster/h�ger*/
  if (rad < 6) {
    if (kol > 0) {
      if (oppositecolor(spelplan[kungrad+2][kungkol-1],ABS_KNIGHT,kingcolor)) {
	return 1;
      }
    }
    if (kol < 7) {
      if (oppositecolor(spelplan[kungrad+2][kungkol+1],ABS_KNIGHT,kingcolor)) {
	return 1;
      }
    }
  }
  
  /*Kolla om fientlig h�st finns ett steg framf�r
    och tv� �t v�nster/h�ger*/
  if (rad > 0) {
    if (kol > 1) {
      if (oppositecolor(spelplan[kungrad-1][kungkol-2],ABS_KNIGHT,kingcolor)) {
	return 1;
      }
    }
    if (kol < 6) {
      if (oppositecolor(spelplan[kungrad-1][kungkol+2],ABS_KNIGHT,kingcolor)) {
	return 1;
      }
    }
  }
  
  /*Kolla om fientlig h�st finns ett steg bakom
    och tv� �t v�nster/h�ger*/
  if (rad < 7) {
    if (kol > 1) {
      if (oppositecolor(spelplan[kungrad+1][kungkol-2],ABS_KNIGHT,kingcolor)) {
	return 1;
      }
    }
    if (kol < 6) {
      if (oppositecolor(spelplan[kungrad+1][kungkol+2],ABS_KNIGHT,kingcolor)) {
	return 1;
      }
    }
  }
  
  /*Kolla s� att inte kungen st�r bredvid fiendens kung.*/
  if ((rad > 0) && (oppositecolor(spelplan[kungrad-1][kungkol],ABS_KING,kingcolor))) {
    return 1;
  }
  if ((rad < 7) && (oppositecolor(spelplan[kungrad+1][kungkol],ABS_KING,kingcolor))) {
    return 1;
  }
  if ((kol > 0) && (oppositecolor(spelplan[kungrad][kungkol-1],ABS_KING,kingcolor))) {
    return 1;
  }
  if ((kol < 7) && (oppositecolor(spelplan[kungrad][kungkol+1],ABS_KING,kingcolor))) {
    return 1;
  }
  if ((rad > 0) && (kol > 0) &&
      (oppositecolor(spelplan[kungrad-1][kungkol-1],ABS_KING,kingcolor))) {
    return 1;
  }
  if ((rad > 0) && (kol < 7) &&
      (oppositecolor(spelplan[kungrad-1][kungkol+1],ABS_KING,kingcolor))) {
    return 1;
  }
  if ((rad < 7) && (kol > 0) &&
      (oppositecolor(spelplan[kungrad+1][kungkol-1],ABS_KING,kingcolor))) {
    return 1;
  }
  if ((rad < 7) && (kol < 7) &&
      (oppositecolor(spelplan[kungrad+1][kungkol+1],ABS_KING,kingcolor))) {
    return 1;
  }
  
  return 0;
}

/* Denna metod returnerar kungens position. */
void findking(int **spelplan, int color, int *kungrad, int *kungkol) {
  int rad, kol;

  for (rad = 0; rad < 8; rad++) {
    for (kol = 0; kol < 8; kol++) {
      if (color == WHITE) {
	if (spelplan[rad][kol] == WHITE_KING) {
	  *kungrad = rad;
	  *kungkol = kol;
	  return;
	}
      } else if (spelplan[rad][kol] == BLACK_KING) {
	*kungrad = rad;
	*kungkol = kol;
	return;
      }
    }
  }
  fprintf(stderr,"Error, hittar inte kungen!");
  //print_table(spelplan);
  exit(0);
}

/* Denna funktion returnerar en lista p� alla drag alla pj�ser
   f�r spelare med f�rg color kan g�ra. Sista positionen i
   listan �r -99.
     Ifall n�got av dragen kan ta motst�ndarens kung,
   returneras 0, annars 1. */
int generate_moves(struct s *spel, int *color) {
  int i = 0;
  struct drag *return_lista, *templista;
  int rad, kol;
  int antal_drag;
  int listsize;
  int counter;
  int retval;
  int kungrad, kungkol;
  int cap = 0;
  int notcap = 0;

  /*g�r plats f�r fyrtio drag initialt i listan
    (+1 f�r att rymma -99 p� slutet)*/
  listsize = 40;
  return_lista = (struct drag *) malloc((listsize+1)*sizeof(struct drag));
  
  for (rad = 0; rad < 8; rad++) {
    for (kol = 0; kol < 8; kol++) {
      if (samecolor(spel->spelplan[rad][kol],*color)) {
	switch(abs(spel->spelplan[rad][kol])) {
	case ABS_PAWN : templista = drag_bonde(spel->spelplan,rad,kol);
         	          antal_drag = nbr_of_moves(templista);
			  /* i-variabeln �r positionen i return_listan d�r
			     n�sta drag skall s�ttas in, vilket �r samma
			     sak som antalet drag som satts in (g�nger tv�).
			     (listsize - i) �r allts� antalet lediga platser
			     i listan. */
			  if (antal_drag > (listsize - i))
			    listsize=change_list_size(&return_lista,
			      listsize + antal_drag);
			  for (counter = 0; counter < antal_drag; counter++) {
			    return_lista[i] = templista[counter];
			    i++;
			  }
			  free(templista);
			  break;
	case ABS_ROOK : templista = drag_torn(spel->spelplan,rad,kol);
	                  antal_drag = nbr_of_moves(templista);
			  if (antal_drag > (listsize - i))
			    listsize=change_list_size(&return_lista,
						      listsize + antal_drag);
			  for (counter = 0; counter < antal_drag; counter++) {
			    return_lista[i] = templista[counter];
			    i++;
			  }
			  free(templista);
			  break;
	case ABS_KNIGHT : templista = drag_hast(spel->spelplan,rad,kol,*color);
	                    antal_drag = nbr_of_moves(templista);
			    if (antal_drag > (listsize - i))
			      listsize=change_list_size(&return_lista,
							listsize+antal_drag);
			    for (counter = 0; counter < antal_drag; counter++){
			      return_lista[i] = templista[counter];
			      i++;
			    }
			    free(templista);
			    break;
	case ABS_BISHOP : templista = drag_lopare(spel->spelplan,rad,kol);
         	            antal_drag = nbr_of_moves(templista);
			    if (antal_drag > (listsize - i))
			      listsize=change_list_size(&return_lista,
							listsize + antal_drag);
			    for (counter = 0; counter < antal_drag; counter++){
			      return_lista[i] = templista[counter];
			      i++;
			    }
			    free(templista);
			    break;
	case ABS_QUEEN : templista = drag_dam(spel->spelplan,rad,kol);
         	           antal_drag = nbr_of_moves(templista);
			   if (antal_drag > (listsize - i))
			     listsize=change_list_size(&return_lista,
						       listsize + antal_drag);
			   for (counter = 0; counter < antal_drag; counter++) {
			     return_lista[i] = templista[counter];
			     i++;
			   }
			   free(templista);
			   break;
	case ABS_KING :   templista = drag_kung(spel,rad,kol,*color);
	                  antal_drag = nbr_of_moves(templista);
			  if (antal_drag > (listsize - i))
			    listsize=change_list_size(&return_lista,
						      listsize + antal_drag);
			  for (counter = 0; counter < antal_drag; counter++) {
			    return_lista[i] = templista[counter];
			    i++;
			  }
			  free(templista);
			  break;
	}
      }
    }
  }

  return_lista[i].fromrow = -99;

  /* Kolla om n�got av dragen kan ta motst�ndarens kung. */
  if (*color == WHITE)
    findking(spel->spelplan,BLACK,&kungrad,&kungkol);
  else
    findking(spel->spelplan,WHITE,&kungrad,&kungkol);
  antal_drag = i;
  retval = 1;
  for (i = 0; i < antal_drag; i++)
    if (return_lista[i].torow == kungrad && return_lista[i].tocol == kungkol)
      retval = 0;

  /* Sort the list so capture moves come first. That will hopefully
     cause quick cutoffs in the alphabeta search. */
  /*  templista = (struct drag *) malloc((antal_drag+1)*sizeof(struct drag));
  for (i = 0; i < antal_drag; i++) {
    if (spel->spelplan[return_lista[i].torow][return_lista[i].tocol] != EMPTY)
      return_lista[cap++] = return_lista[i];
    else
      templista[notcap++] = return_lista[i];
  }
  for (i = 0; i < notcap; i++)
    return_lista[i+cap] = templista[i];
    free(templista);*/

  spel->draglista = return_lista;
  return retval;
}

