#ifndef _DISPLAY_
#define _DISPLAY_

#include "diverse.h"

void printmoves(struct drag *draglista);

char getPjasBokstav(int pjas);

void print_table(int **spelplan);

void showsettings(int *white, int *black, int *vemstur, int *started);

void showhelp();

#endif      //_DISPLAY_
