#include "moves.h"

extern int xboard_mode;

/*Denna funktion satter som default topjas == frompjas, och rockad == 0. Det
  eftersom detta galler i 99% av fallen. Vid bondeforvandling eller rockad
  far man sjalv satta ratt varde efter att man anropat denna funktion. */
void initdrag(struct drag *drag, int frad, int fkol, int trad, int tkol, int pjas) {
  drag->fromrow = frad;
  drag->fromcol = fkol;
  drag->frompjas = pjas;
  drag->torow = trad;
  drag->tocol = tkol;
  drag->topjas = pjas;
  drag->value = 0;
  drag->rockad = 0;
  drag->i_schack = 0;
}

/* Denna funktion omvandlar en str�ng till ett struct drag-objekt. Om str�ngen
   �r felaktig returneras -99. */
struct drag str2drag(char *vilket_drag, struct s *spel, int vemstur) {
  struct drag draget;
  int kungrad, kungkol;
  struct s *next_spel;
  //struct s *make_move(struct s *, struct drag *);
  //void findking(int **,int,int *,int *);
  char *str;

  draget.fromrow = '8' - vilket_drag[1];
  draget.fromcol = vilket_drag[0] - 'a';
  draget.torow = '8' - vilket_drag[3];
  draget.tocol = vilket_drag[2] - 'a';

  /* Denna test beh�vs eftersom det inte r�cker att kolla om
     strlen(vilket_drag) != 7, ty man kan ju skriva in tex.
     str�ngen "hhhhhhh", som ocks� har 7 tecken. */
  if ((draget.fromrow > 7) || (draget.fromrow < 0) ||
      (draget.fromcol > 7) || (draget.fromcol < 0) ||
      (draget.torow > 7) || (draget.torow < 0) ||
      (draget.tocol > 7) || (draget.tocol < 0)) {
    draget.fromrow = -99;
    return draget;
  }

  draget.frompjas = spel->spelplan[draget.fromrow][draget.fromcol];
  draget.topjas = draget.frompjas;
  if (strlen(vilket_drag) == 5) {
    if (draget.frompjas > 0) {  //vit pjas
      switch(vilket_drag[4]) {
      case 'r' : draget.topjas = WHITE_ROOK;     break;
      case 'q' : draget.topjas = WHITE_QUEEN;     break;
      case 'n' : draget.topjas = WHITE_KNIGHT;     break;
      case 'b' : draget.topjas = WHITE_BISHOP;     break;
      default : if (!xboard_mode)
	          printf("Invalid piece!\n");
                else {
		  str = (char *) malloc(30*sizeof(char));
		  sprintf(str,"Invalid piece = %s",vilket_drag);
		  debuglog(str);
		  free(str);
		}
                draget.fromrow = -99;
		return draget;
      }
    } else {
      switch(vilket_drag[4]) {
      case 'r' : draget.topjas = BLACK_ROOK;     break;
      case 'q' : draget.topjas = BLACK_QUEEN;     break;
      case 'n' : draget.topjas = BLACK_KNIGHT;     break;
      case 'b' : draget.topjas = BLACK_BISHOP;     break;
      default : if (!xboard_mode)
	          printf("Invalid piece!\n");
                else {
		  str = (char *) malloc(30*sizeof(char));
		  sprintf(str,"Invalid piece = %s",vilket_drag);
		  debuglog(str);
		  free(str);
		}
                draget.fromrow = -99;
		return draget;
      }
    }
  }

  /*Kolla om rockad*/
  draget.rockad = 0;
  if (abs(draget.frompjas) == ABS_KING) {
    if (draget.tocol - draget.fromcol == 2) { //flyttat 2 steg med kung!
      if (draget.frompjas > 0) {    //vit pjas
	/* Gor en liten test...*/
	if ((draget.fromrow == 7) && (draget.fromcol == 4)
	    && (spel->spelplan[7][7] == WHITE_ROOK))
	  draget.rockad = KORT_ROCKAD;
      } else {       //svart pjas
	/* Gor en liten test...*/
	if ((draget.fromrow == 0) && (draget.fromcol == 4)
	    && (spel->spelplan[0][7] == BLACK_ROOK))
	  draget.rockad = KORT_ROCKAD;
      }
    } else if (draget.fromcol - draget.tocol == 2) { //flyttat 2 steg med kung!
      if (draget.frompjas > 0) {    //vit pjas
	/* Gor en liten test...*/
	if ((draget.fromrow == 7) && (draget.fromcol == 4)
	    && (spel->spelplan[7][0] == WHITE_ROOK))
	  draget.rockad = LANG_ROCKAD;
      } else {       //svart pjas
	/* Gor en liten test...*/
	if ((draget.fromrow == 0) && (draget.fromcol == 4)
	    && (spel->spelplan[0][0] == BLACK_ROOK))
	  draget.rockad = LANG_ROCKAD;
      }
    }
  }

  /* Kolla om motst�ndaren st�lls i schack n�r detta drag g�rs. */
  /*  if (vemstur == WHITE)
    findking(spel->spelplan,BLACK,&kungrad,&kungkol);
  else
    findking(spel->spelplan,WHITE,&kungrad,&kungkol);
  next_spel = make_move(spel,&draget);
  draget.i_schack = in_chess_fullcheck(next_spel->spelplan,kungrad,kungkol);
  freespel(next_spel);*/

  return draget;
}

/* Denna funktion omvandlar ett drag till en str�ng. */
void drag2str(struct drag draget, char *vilket_drag) {
  vilket_drag[1] = '8' - draget.fromrow;
  vilket_drag[0] = draget.fromcol + 'a';
  vilket_drag[3] = '8' - draget.torow;
  vilket_drag[2] = draget.tocol + 'a';

  if (draget.frompjas != draget.topjas) {
    switch(abs(draget.topjas)) {
      case ABS_ROOK : vilket_drag[4] = 'r';     break;
      case ABS_QUEEN : vilket_drag[4] = 'q';     break;
      case ABS_KNIGHT : vilket_drag[4] = 'n';     break;
      case ABS_BISHOP : vilket_drag[4] = 'b';     break;
    }
    vilket_drag[5] = '\0';
  } else
    vilket_drag[4] = '\0';
}

void undomove(struct s *spel, struct drag *vilket_drag, struct s *oldflags, int oldsquare) {
  *spel = *oldflags;
  spel->spelplan[vilket_drag->fromrow][vilket_drag->fromcol] = vilket_drag->frompjas;
  spel->spelplan[vilket_drag->torow][vilket_drag->tocol] = oldsquare;

  if (vilket_drag->rockad) {
    if (vilket_drag->rockad == KORT_ROCKAD) {
      if (vilket_drag->frompjas > 0) {    //vit pj�s
	spel->spelplan[7][7] = WHITE_ROOK;
	spel->spelplan[7][5] = EMPTY;
      } else {    //svart pj�s
	spel->spelplan[0][7] = BLACK_ROOK;
	spel->spelplan[0][5] = EMPTY;
      }
    } else {     //l�ng rockad
      if (vilket_drag->frompjas > 0) {    //vit pj�s
	spel->spelplan[7][0] = WHITE_ROOK;
	spel->spelplan[7][3] = EMPTY;
      } else {    //svart pj�s
	spel->spelplan[0][0] = BLACK_ROOK;
	spel->spelplan[0][3] = EMPTY;
      }
    }
  }
}

void makemove(struct s *spel, struct drag *vilket_drag, struct s *saved_flags) {
  *saved_flags = *spel;

  spel->evalboard = spel->evalboard
    - getPjasValue(spel->spelplan[vilket_drag->torow][vilket_drag->tocol]);
  if (vilket_drag->frompjas != vilket_drag->topjas)
    spel->evalboard = spel->evalboard
      - (getPjasValue(vilket_drag->frompjas) - getPjasValue(vilket_drag->topjas));

  //typ_av_pjas = vilket_drag->topjas;
  spel->spelplan[vilket_drag->fromrow][vilket_drag->fromcol] = EMPTY;
  spel->spelplan[vilket_drag->torow][vilket_drag->tocol] = vilket_drag->topjas;

  /* Uppdatera rockeringsinformationen. */
  if (vilket_drag->frompjas == WHITE_KING)
    spel->vitkingmoved = 1;
  if ((vilket_drag->frompjas == WHITE_ROOK) && (vilket_drag->fromrow == 7)
      && (vilket_drag->fromcol == 0))
    spel->vitAtornmoved = 1;
  if ((vilket_drag->frompjas == WHITE_ROOK) && (vilket_drag->fromrow == 7)
      && (vilket_drag->fromcol == 7))
    spel->vitHtornmoved = 1;

  if (vilket_drag->frompjas == BLACK_KING)
    spel->svartkingmoved = 1;
  if ((vilket_drag->frompjas == BLACK_ROOK) && (vilket_drag->fromrow == 0)
      && (vilket_drag->fromcol == 0))
    spel->svartAtornmoved = 1;
  if ((vilket_drag->frompjas == BLACK_ROOK) && (vilket_drag->fromrow == 0)
      && (vilket_drag->fromcol == 7))
    spel->svartHtornmoved = 1;

  if (vilket_drag->rockad) {
    if (vilket_drag->rockad == KORT_ROCKAD) {
      if (vilket_drag->frompjas > 0) {   //vit pjas
        /* Make a little test...*/
        if ((vilket_drag->fromrow == 7) && (vilket_drag->fromcol == 4)
            && (spel->spelplan[7][7] == WHITE_ROOK)) {
	  spel->spelplan[7][7] = EMPTY;
	  spel->spelplan[7][5] = WHITE_ROOK;
	  spel->vitrockerat = KORT_ROCKAD;
	  spel->vitkingmoved = 1;
	  spel->vitHtornmoved = 1;
	}
      } else {    //svart pjas
        /* Make a little test...*/
        if ((vilket_drag->fromrow == 0) && (vilket_drag->fromcol == 4)
            && (spel->spelplan[0][7] == BLACK_ROOK)) {
	  spel->spelplan[0][7] = EMPTY;
	  spel->spelplan[0][5] = BLACK_ROOK;
	  spel->svartrockerat = KORT_ROCKAD;
	  spel->svartkingmoved = 1;
	  spel->svartHtornmoved = 1;
	}
      }
    } else {    //lang rockad
      if (vilket_drag->frompjas > 0) {   //vit pjas
        /* Make a little test...*/
        if ((vilket_drag->fromrow == 7) && (vilket_drag->fromcol == 4)
            && (spel->spelplan[7][0] == WHITE_ROOK)) {
	  spel->spelplan[7][0] = EMPTY;
	  spel->spelplan[7][3] = WHITE_ROOK;
	  spel->vitrockerat = LANG_ROCKAD;
	  spel->vitkingmoved = 1;
	  spel->vitAtornmoved = 1;
        }
      } else {    //svart pjas
        /* Make a little test...*/
        if ((vilket_drag->fromrow == 0) && (vilket_drag->fromcol == 4)
            && (spel->spelplan[0][0] == BLACK_ROOK)) {
	  spel->spelplan[0][0] = EMPTY;
	  spel->spelplan[0][3] = BLACK_ROOK;
	  spel->svartrockerat = LANG_ROCKAD;
	  spel->svartkingmoved = 1;
	  spel->svartAtornmoved = 1;
        }
      }
    }
  }
}

