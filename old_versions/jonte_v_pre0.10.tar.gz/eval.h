#ifndef _EVAL_
#define _EVAL_

#include "diverse.h"

int getPjasValue(int pjas);

/* Denna funktion returnerar ett v�rde f�r hur bra en viss st�llning �r.
   H�gt v�rde f�r den spelare som �r vid draget inneb�r att han ligger
   bra till i spelet. */
int eval(int *vemstur, struct s *spel);

/* Denna funktion returnerar ett v�rde f�r hur bra en viss st�llning �r.
   Om returv�rdet �r positivt, ligger vit b�ttre till �n svart, och om
   returv�rdet �r negativt, ligger svart b�ttre till �n vit. */
int eval_abs(int **spelplan);

#endif    //_EVAL_
