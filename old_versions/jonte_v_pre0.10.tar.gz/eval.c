#include "eval.h"

int getPjasValue(int pjas) {
  switch(pjas) {
    case WHITE_PAWN : return 1;
                      break;
    case WHITE_ROOK : return 5;
                      break;
    case WHITE_KNIGHT : return 3;
                      break;
    case WHITE_BISHOP : return 3;
                      break;
    case WHITE_QUEEN : return 9;
                      break;
    case WHITE_KING : return 1;
                      break;
    case BLACK_PAWN : return -1;
                      break;
    case BLACK_ROOK : return -5;
                      break;
    case BLACK_KNIGHT : return -3;
                      break;
    case BLACK_BISHOP : return -3;
                      break;
    case BLACK_QUEEN : return -9;
                      break;
    case BLACK_KING : return -1;
                      break;
    case EMPTY : return 0;
                      break;
  }
  return -99;
}

/* Denna funktion returnerar ett v�rde f�r hur bra en viss st�llning �r.
   H�gt v�rde f�r den spelare som �r vid draget inneb�r att han ligger
   bra till i spelet. */
int eval(int *vemstur, struct s *spel) {
  int rad, kol, value = 0;
  struct drag *draglista;
  int antal_drag;
  int *oppositecolor;
  int kungrad, kungkol;
  void switch_colors(int *color);

  /* Check if the opponent is checkmated. */
  /*
  *oppositecolor = *vemstur;
  switch_colors(oppositecolor);
  draglista = skapa_lista(spelplan,oppositecolor);
  antal_drag = nbr_of_moves(draglista);
  free(draglista);
  if (antal_drag == 0) {
    findking(spelplan,*oppositecolor,&kungrad,&kungkol);
    if (in_chess(spelplan,kungrad,kungkol))
      return RLIM_INFINITY;
  }
  */
  
  /*  if (*vemstur == WHITE) {
    for (rad = 0; rad < 8; rad++) {
      for (kol = 0; kol < 8; kol++) {
        value += getPjasValue(spelplan[rad][kol]);
      }
    }
  } else {
    for (rad = 0; rad < 8; rad++) {
      for (kol = 0; kol < 8; kol++) {
        value -= getPjasValue(spelplan[rad][kol]);
      }
    }
    }*/

  if (*vemstur == WHITE) {
    value = spel->evalboard;
  } else {   //svarts tur, invertera v�rdet
    if (spel->evalboard > 0)
      value = -(spel->evalboard);
    else
      value = abs(spel->evalboard);
  }
  return value;
}

/* Denna funktion returnerar ett v�rde f�r hur bra en viss st�llning �r.
   Om returv�rdet �r positivt, ligger vit b�ttre till �n svart, och om
   returv�rdet �r negativt, ligger svart b�ttre till �n vit. */
int eval_abs(int **spelplan) {
  int rad, kol, value = 0;

  for (rad = 0; rad < 8; rad++) {
    for (kol = 0; kol < 8; kol++) {
      value += getPjasValue(spelplan[rad][kol]);
    }
  }
  return value;
}




