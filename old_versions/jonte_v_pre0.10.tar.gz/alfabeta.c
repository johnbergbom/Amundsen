#include "alfabeta.h"
#include <stdio.h>
#include <sys/resource.h>
#include "moves.h"
//#include "history.h"
//#include "netdiverse.h"
//#include "serialization.h"

#define KINGTAKEN 500000

extern int xboard_mode;
int lagge = 0;
int lagge_int = 0;

int max(int a, int b) {
  if (a > b)
    return a;
  else
    return b;
}

int min(int a, int b) {
  if (a > b)
    return b;
  else
    return a;
}

int quiescence(struct s *spel, int vemstur, int org_color, int nodetype, int alpha, int beta, int tillrad, int tillkol) {
  struct s saved_flags;
  int oldsquare;
  int retval;
  int q_val;
  int i = 0;
  int qmoves = 0;

  //saved_flags = (struct s *) malloc(1*sizeof(struct s));
  if (nodetype == MAX) {
    retval = -INFTY;
    if (generate_moves(spel,&vemstur)) {
      switch_colors(&vemstur);
      while (spel->draglista[i].fromrow != -99) {
	/* G�r bara de drag som sl�r i samma ruta. */
	if (spel->draglista[i].torow == tillrad
	    && spel->draglista[i].tocol == tillkol) {
	  /* Om s�mre pj�s sl�r en b�ttre avslutar vi quiescence-search,
	     annars forts�tter vi. */
	  if (abs(getPjasValue(spel->spelplan[tillrad][tillkol]))
	      > abs(getPjasValue(spel->draglista[i].topjas)))
	    q_val = eval(&org_color,spel);
	  else {
	    oldsquare = spel->spelplan[tillrad][tillkol];
	    makemove(spel,&(spel->draglista[i]),&saved_flags);
	    q_val = quiescence(spel,vemstur,org_color,MIN,alpha,beta,tillrad,tillkol);
	    undomove(spel,&(saved_flags.draglista[i]),&saved_flags,oldsquare);
	  }
	  if (q_val != KINGTAKEN) {
	    qmoves++;
	    retval = max(retval,q_val);
	    alpha = max(alpha,retval);
	    if (retval >= beta)
	      break;
	  }
	}
	i++;
      }
    } else
      retval = KINGTAKEN;
    free(spel->draglista);
  } else {   //nodetype == MIN
    retval = INFTY;
    if (generate_moves(spel,&vemstur)) {
      switch_colors(&vemstur);
      while (spel->draglista[i].fromrow != -99) {
	/* G�r bara de drag som sl�r i samma ruta. */
	if (spel->draglista[i].torow == tillrad
	    && spel->draglista[i].tocol == tillkol) {
	  /* Om s�mre pj�s sl�r en b�ttre avslutar vi quiescence-search,
	     annars forts�tter vi. */
	  if (abs(getPjasValue(spel->spelplan[tillrad][tillkol]))
	      > abs(getPjasValue(spel->draglista[i].topjas)))
	    q_val = eval(&org_color,spel);
	  else {
	    oldsquare = spel->spelplan[tillrad][tillkol];
	    makemove(spel,&(spel->draglista[i]),&saved_flags);
	    q_val = quiescence(spel,vemstur,org_color,MAX,alpha,beta,tillrad,tillkol);
	    undomove(spel,&(saved_flags.draglista[i]),&saved_flags,oldsquare);
	  }
	  if (q_val != KINGTAKEN) {
	    qmoves++;
	    retval = min(retval,q_val);
	    beta = min(beta,retval);
	    if (retval <= alpha)
	      break;
	  }
	}
	i++;
      }
    } else
      retval = KINGTAKEN;
    free(spel->draglista);
  }

  if (!qmoves)
    retval = eval(&org_color,spel);
  //free(saved_flags);
  return retval;
}

int alphabeta(struct s *spel, int vemstur, int org_color, int nodetype, int alpha, int beta, int depth) {
  struct s saved_flags;
  int oldsquare;
  int retval;
  int a_val;
  int i = 0;
  int torow, tocol;

  //saved_flags = (struct s *) malloc(1*sizeof(struct s));
  if (depth == 0) {
    retval = eval(&org_color,spel);
  } else if (nodetype == MAX) {
    retval = -INFTY;
    if (generate_moves(spel,&vemstur)) {
      switch_colors(&vemstur);
      while (spel->draglista[i].fromrow != -99) {
	torow = spel->draglista[i].torow;
	tocol = spel->draglista[i].tocol;
	oldsquare = spel->spelplan[torow][tocol];
	makemove(spel,&(spel->draglista[i]),&saved_flags);
	/* Om detta drag blir det sista draget i s�kningen, och draget
	   sl�r en motst�ndarpj�s, s� skall quiescence-s�kningen k�ras,
	   annars vanlig alphabeta. */
	if (depth-1 == 0 && oldsquare != EMPTY)
	  /* Om s�mre pj�s sl�r en b�ttre bryr vi oss inte om
	     quiescence-s�kning. */
	  if (abs(getPjasValue(oldsquare))
	      > abs(getPjasValue(spel->draglista[i].topjas)))
	    a_val = alphabeta(spel,vemstur,org_color,MIN,alpha,beta,depth-1);
	  else
	    a_val = quiescence(spel,vemstur,org_color,MIN,alpha,beta,torow,tocol);
	else
	  a_val = alphabeta(spel,vemstur,org_color,MIN,alpha,beta,depth-1);
	undomove(spel,&(saved_flags.draglista[i]),&saved_flags,oldsquare);
	if (a_val != KINGTAKEN) {
	  retval = max(retval,a_val);
	  alpha = max(alpha,retval);
	  if (retval >= beta)
	    break;
	}
	i++;
      }
    } else
      retval = KINGTAKEN;
    free(spel->draglista);
  } else {   //nodetype == MIN
    retval = INFTY;
    if (generate_moves(spel,&vemstur)) {
      switch_colors(&vemstur);
      while (spel->draglista[i].fromrow != -99) {
	torow = spel->draglista[i].torow;
	tocol = spel->draglista[i].tocol;
	oldsquare = spel->spelplan[torow][tocol];
	makemove(spel,&(spel->draglista[i]),&saved_flags);
	/* Om detta drag blir det sista draget i s�kningen, och draget
	   sl�r en motst�ndarpj�s, s� skall quiescence-s�kningen k�ras,
	   annars vanlig alphabeta. */
	if (depth-1 == 0 && oldsquare != EMPTY)
	  /* Om s�mre pj�s sl�r en b�ttre bryr vi oss inte om
	     quiescence-s�kning. */
	  if (abs(getPjasValue(oldsquare))
	      > abs(getPjasValue(spel->draglista[i].topjas)))
	    a_val = alphabeta(spel,vemstur,org_color,MAX,alpha,beta,depth-1);
	  else
	    a_val = quiescence(spel,vemstur,org_color,MAX,alpha,beta,torow,tocol);
	else
	  a_val = alphabeta(spel,vemstur,org_color,MAX,alpha,beta,depth-1);
	undomove(spel,&(saved_flags.draglista[i]),&saved_flags,oldsquare);
	if (a_val != KINGTAKEN) {
	  retval = min(retval,a_val);
	  beta = min(beta,retval);
	  if (retval <= alpha)
	    break;
	}
	i++;
      }
    } else
      retval = KINGTAKEN;
    free(spel->draglista);
  }
  //free(saved_flags);
  return retval;
}


/* Anropa denna funktion f�r att anv�nda alfabeta-besk�rningsalgoritmen.
   Funktionen returnerar det b�sta draget. Om det finns klienter
   uppkopplade kommer dessa att anropas, s� att arbetsb�rdan f�rdelas. */
struct drag thinkalphabeta(struct s *spel, int vemstur, int depth) {
  struct drag *bestmove;
  struct drag *validmoves;
  int bestvalue, b;
  struct s saved_flags;
  int oldsquare;
  struct drag returdrag;
  int antal_drag;
  int alpha = -INFTY, beta = INFTY;
  int org_color = vemstur;
  int i = 0, j = 0;
  int a_val;

  //saved_flags = (struct s *) malloc(1*sizeof(struct s));
  generate_moves(spel,&vemstur);
  switch_colors(&vemstur);
  while (spel->draglista[i].fromrow != -99) {
    oldsquare = spel->spelplan[spel->draglista[i].torow][spel->draglista[i].tocol];
    makemove(spel,&(spel->draglista[i]),&saved_flags);
    a_val = alphabeta(spel,vemstur,org_color,MIN,alpha,beta,depth-1);
    undomove(spel,&(saved_flags.draglista[i]),&saved_flags,oldsquare);
    if (a_val == KINGTAKEN) {
      //draget spel->draglista[i] �r ogiltigt, st�ller kungen i schack
      spel->draglista[i].fromrow = -99;
    }
    spel->draglista[i].value = a_val;
    i++;
  }
  antal_drag = i;

  /* Remove all invalid moves from the list. (The invalid ones are flagged
     with drag.fromrow == -99, see above) */
  validmoves = (struct drag *) malloc(antal_drag * sizeof(struct drag));
  for (i = 0; i < antal_drag; i++)
    if (spel->draglista[i].fromrow != -99)
      validmoves[j++] = spel->draglista[i];
  antal_drag = j;

  if (j > 0) {
    /* Put the best moves in the array bestmove, and chose a random best move.
       (Provided there are several moves which are equally good.) */
    bestmove = (struct drag *) malloc(antal_drag * sizeof(struct drag));
    bestvalue = validmoves[0].value;
    b = 0;
    for (i = 0; i < antal_drag; i++) {
      if (validmoves[i].value >= bestvalue) {
	if (validmoves[i].value > bestvalue)
	  b = 0;
	bestvalue = validmoves[i].value;
	bestmove[b++] = validmoves[i];
      }
    }
    returdrag = bestmove[get_random_number(b-1)];
    free(bestmove);
  } else
    returdrag = spel->draglista[0];   //fromrow == -99

  if (!xboard_mode)
    printf("Value = %d\n",returdrag.value);

  free(spel->draglista);
  free(validmoves);
  //free(saved_flags);
  return returdrag;
}

