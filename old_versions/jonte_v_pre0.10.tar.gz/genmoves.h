#ifndef _GENMOVES_
#define _GENMOVES_

#include "diverse.h"

/* Denna funktion reallokerar en listas storlek i minnet. */
int change_list_size(struct drag **lista, int new_size);

int nbr_of_moves(struct drag *lista);

/* Denna funktion returnerar true eller false beroende p� om pj�sen
   �r av samma f�rg som farg. */
int samecolor(int pjas, int farg);

/* Denna funktion returnerar true om pj�sen pjas_att_kolla �r en
   likadan pj�s som ABS_pjas, fast i motsatt f�rg som farg. Annars
   returnas false. */
int oppositecolor(int pjas_att_kolla, int ABS_pjas, int farg);

/* Denna funktion returnerar true (=1) om kungen st�r i schack,
   och false (=0) annars. Argumenten kungrad och kungkol indikerar
   var p� spelplanen kungen st�r. */
int i_schack(int **spelplan, int kungrad, int kungkol);

/* Denna metod returnerar kungens position. */
void findking(int **spelplan, int color, int *kungrad, int *kungkol);

/* Denna funktion returnerar en lista p� alla drag alla pj�ser
   f�r spelare med f�rg color kan g�ra. Sista positionen i
   listan �r -99.
     Ifall n�got av dragen kan ta motst�ndarens kung,
   returneras 0, annars 1. */
int generate_moves(struct s *spel, int *color);

#endif      //_GENMOVES_
