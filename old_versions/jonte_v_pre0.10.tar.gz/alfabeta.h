#ifndef _ALFABETA_
#define _ALFABETA_

#include "diverse.h"

#define SAMRE_SLAR_BATTRE 1
#define LIKA_SLAR_LIKA 2
#define BATTRE_SLAR_SAMRE 3

int max(int a, int b);

int min(int a, int b);

int quiescence(struct s *spel, int vemstur, int org_color, int nodetype, int alpha, int beta, int tillrad, int tillkol);

int alphabeta(struct s *spel, int vemstur, int org_color, int nodetype, int alpha, int beta, int depth);

/* Anropa denna funktion f�r att anv�nda alfabeta-besk�rningsalgoritmen.
   Funktionen returnerar det b�sta draget. Om det finns klienter
   uppkopplade kommer dessa att anropas, s� att arbetsb�rdan f�rdelas. */
struct drag thinkalphabeta(struct s *spel, int vemstur, int nbr_moves_ahead);

#endif       //_ALFABETA_
