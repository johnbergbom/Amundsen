#include "parse.h"
#include <stdio.h>
#include <signal.h>
//#include <unistd.h>
#include "alfabeta.h"
//#include "history.h"
#include "moves.h"

extern int histpos;
extern int xboard_mode;

void computer_make_move(struct s *spel, int *vemstur, int *started) {
  struct drag drag;
  //struct drag *draglista;
  int antal_drag;
  int kungrad, kungkol;
  struct s *saved_flags;
  char *str;
  char *dragstr;

  saved_flags = (struct s *) malloc(1*sizeof(struct s));
  dragstr = (char *) malloc(20*sizeof(char));
  str = (char *) malloc(50*sizeof(char));
  drag = thinkalphabeta(spel,*vemstur,THINKFORWARD);

  if (drag.fromrow == -99) {  /* Inga giltiga drag fanns. */
    findking(spel->spelplan,*vemstur,&kungrad,&kungkol);
    if (i_schack(spel->spelplan,kungrad,kungkol)) {
      if (!xboard_mode) {
	printf("Schack och matt! ");
	if (*vemstur == WHITE)
	  printf("Svart vann!\n");
	else
	  printf("Vit vann!\n");
	printf("Partiet avslutas.\n");
      } else {
	if (*vemstur == WHITE) {
	  printf("0-1 {Black mates}\n");
	  sprintf(str,"output sent = 0-1 {Black mates}");
	  debuglog(str);
	  debuglog("Black won");
	} else {
	  printf("1-0 {White mates}\n");
	  sprintf(str,"output sent = 1-0 {White mates}");
	  debuglog(str);
	  debuglog("White won");
	}
      }
    } else {
      if (!xboard_mode) {
	printf("Patt! Kan inte g� n�gonstans. Det blev remi.\n");
	printf("Partiet avslutas.\n");
      } else {
	printf("1/2-1/2 {Stalemate}\n");
	sprintf(str,"output sent = 1/2-1/2 {Stalemate}");
	debuglog(str);
	debuglog("Stalemate (Patt)");
      }
    }
    *started = 0;
  } else {
    add_drag2history(&drag);
    makemove(spel,&drag,saved_flags);
    if (!xboard_mode)
      print_table(spel->spelplan);
    else {
      drag2str(drag,dragstr);
      printf("move %s\n",dragstr);
      sprintf(str,"output sent = move %s",dragstr);
      debuglog(str);
    }
    if (*vemstur == WHITE)
      *vemstur = BLACK;
    else
      *vemstur = WHITE;
  
    if (drag.value == INFTY) {
      if (!xboard_mode) {
	printf("Schack och matt! ");
	if (*vemstur == WHITE)
	  printf("Svart vann!\n");
	else
	  printf("Vit vann!\n");
	printf("Partiet avslutas.\n");
      } else {
	if (*vemstur == WHITE) {
	  printf("0-1 {Black mates}\n");
	  sprintf(str,"output sent = 0-1 {Black mates}");
	  debuglog(str);
	  debuglog("Black won");
	} else {
	  printf("1-0 {White mates}\n");
	  sprintf(str,"output sent = 1-0 {White mates}");
	  debuglog(str);
	  debuglog("White won");
	}
      }
      *started = 0;
    }
  }

  free(str);
  free(dragstr);
  free(saved_flags);
  return;
}

/* Returns false(=0) on error, and true(=1) if no error. */
int parsemove(char *input, struct s *spel, int *vemstur, int *started) {
  struct s *saved_flags;
  struct drag drag;
  char *str;
  char *dragstr;
  int returnval = 0;
  int oldsquare;

  saved_flags = (struct s *) malloc(1*sizeof(struct s));

  /*  drag = str2drag(input,spel,*vemstur);
  printf("F�re:\n");
  print_table(spel->spelplan);
  oldsquare = spel->spelplan[drag.torow][drag.tocol];
  makemove(spel,&drag,saved_flags);
  printf("Efter:\n");
  print_table(spel->spelplan);
  undomove(spel,&drag,saved_flags,oldsquare);
  printf("�terst�llning:\n");
  print_table(spel->spelplan);
  exit(0);*/



  str = (char *) malloc(50*sizeof(char));
  drag = str2drag(input,spel,*vemstur);
  if (drag.fromrow != -99) {
    if (!*started && !xboard_mode)
      printf("Du har inte startat n�got parti.\n");
    else {
      debuglog(input);
      add_drag2history(&drag);
      makemove(spel,&drag,saved_flags);
      if (!xboard_mode)
	print_table(spel->spelplan);
      if (*vemstur == WHITE)
	*vemstur = BLACK;
      else
	*vemstur = WHITE;
      /* If xboard_mode is on and *started = 0, then we will make the
         move, but not start thinking until xboard sends a go. This
         is done by returning a 0.*/
      if (*started)
	returnval = 1;
    }
  } else {
    if (!xboard_mode)
      printf("Kommando kunde ej tolkas. Tryck '?' f�r hj�lp.\n");
    else {
      sprintf(str,"unknown input received = \"%s\"",input);
      debuglog(str);
    }
  }
  free(str);
  free(saved_flags);
  return returnval;
}

void parse(int *white, int *black, int *vemstur, int *started,
	   struct s *spel) {
  char *input;
  //struct s *old_spel;
  //struct drag drag;
  int run = 1;
  //void visa_tanke(struct s *, int *);
  char *str;

  input = (char *) malloc(100*sizeof(char));
  str = (char *) malloc(100*sizeof(char));

  while (run) {
    if (!xboard_mode)
      fprintf(stderr,">");
    //scanf("%s",input);
    //read(0,input,20);
    fgets(input,100,stdin);   //reads a whole line
    input[strlen(input)-1] = '\0';   //remove trailing newline
    //sprintf(str,"input received = \"%s\"",input);
    //debuglog(str);
    //fprintf(stderr,"input = \"%s\"\n",input);

    if (xboard_mode) {
      if (strcmp(input,"new") == 0) {
	spel = get_new_board();
	*vemstur = WHITE;
	*white = HUMAN;
	*black = COMPUTER;
	*started = 1;
	histpos = 0;   //nollst�ll draghistoriken
	debuglog("new");
      } else if (strcmp(input,"random") == 0) {
	//do nothing, we always use random evaluation
	debuglog("random");
      } else if (strcmp(input,"force") == 0) {
	*started = 0;
	debuglog("force");
      } else if (strncmp(input,"level",5) == 0) {
	//do nothing, the enginge doesn't support timing
	debuglog("level");
      } else if (strncmp(input,"time",4) == 0) {
	//do nothing, the enginge doesn't support timing
	debuglog("time");
      } else if (strncmp(input,"otim",4) == 0) {
	//do nothing, the enginge doesn't support timing
	debuglog("otime");
      } else if (strncmp(input,"result",6) == 0) {
	debuglog("result");
      } else if (strcmp(input,"hard") == 0) {
	//do nothing, the enginge doesn't support pondering
	debuglog("hard");
      } else if (strcmp(input,"dumpa") == 0) {
	//Used for debugging purposes
	debuglog("dumpa");
	print_table(spel->spelplan);
      } else if (strcmp(input,"quit") == 0) {
	*started = 0;
	run = 0;
	debuglog("quit");
      } else if (strcmp(input,"white") == 0) {
	*vemstur = WHITE;
	*white = HUMAN;
	*black = COMPUTER;
	debuglog("white");
      } else if (strcmp(input,"black") == 0) {
	*vemstur = BLACK;
	*white = COMPUTER;
	*black = HUMAN;
	debuglog("black");
      } else if (strcmp(input,"go") == 0) {
	*started = 1;
	if (*vemstur == WHITE) {
	  *white = COMPUTER;
	  *black = HUMAN;
	} else {
	  *black = COMPUTER;
	  *white = HUMAN;
	}
	debuglog("go");
	computer_make_move(spel,vemstur,started);
      }else {
	if (parsemove(input,spel,vemstur,started))
	  computer_make_move(spel,vemstur,started);
      }
    }else {
      if (strcmp(input,"xboard") == 0) {
	xboard_mode = 1;
	printf("\n");   //xboard wants a newline here
	signal(SIGINT,SIG_IGN);  //ignore SIGINT
	debuglog("xboard");
      } else if (strcmp(input,"hist") == 0)
	showhistory();
      else if (strcmp(input,"avsluta") == 0)
	run = 0;
      else if ((strcmp(input,"hj�lp") == 0) || (strcmp(input,"?") == 0))
	showhelp();
      else if (strcmp(input,"visa") == 0)
	print_table(spel->spelplan);
      else if (strcmp(input,"vitdator") == 0)
	*white = COMPUTER;
      else if (strcmp(input,"vitman") == 0)
	*white = HUMAN;
      else if (strcmp(input,"svartdator") == 0)
	*black = COMPUTER;
      else if ((strcmp(input,"svartman") == 0) || (strcmp(input,"neger") == 0))
	*black = HUMAN;
      else if (strcmp(input,"starta") == 0) {
	if (*started != 1) {
	  *started = 1;
	  histpos = 0;   //nollst�ll draghistoriken
	  if (*white == COMPUTER)
	    computer_make_move(spel,vemstur,started);
	}
      } else if (strcmp(input,"inst") == 0)
	showsettings(white,black,vemstur,started);
      else {
	if (parsemove(input,spel,vemstur,started))
	  computer_make_move(spel,vemstur,started);
      }
    }
  }
  free(input);
  free(str);
}













