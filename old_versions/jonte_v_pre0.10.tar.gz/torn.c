#include "torn.h"

#include "diverse.h"

/* Denna funktion returnerar en lista p� alla drag ett visst torn kan
   g�ra. Sista positionen i listan �r -99. */
struct drag *drag_torn(int **spelplan, int rad, int kol) {
  int i = 0;
  struct drag *draglista;
  int t_rad, t_kol;
  int quit_loop;

  /*+1 f�r att rymma -99 p� slutet*/
  draglista = (struct drag *) malloc((MAX_ROOK_MOVE+1)*sizeof(struct drag));
  if (spelplan[rad][kol] == WHITE_ROOK) {

    /* Kolla hur m�nga steg "ned�t" han kan g�. */
    t_rad = rad + 1;
    t_kol = kol;
    quit_loop = 0;
    while ((t_rad < 8) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_ROOK);
      } else if (spelplan[t_rad][t_kol] < 0) {   //om svart pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_ROOK);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] > 0) {     //om vit pj�s
	quit_loop = 1;
      }
      t_rad++;
    }

    /* Kolla hur m�nga steg "upp�t" han kan g�. */
    t_rad = rad - 1;
    t_kol = kol;
    quit_loop = 0;
    while ((t_rad > -1) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_ROOK);
      } else if (spelplan[t_rad][t_kol] < 0) {   //om svart pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_ROOK);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] > 0) {     //om vit pj�s
	quit_loop = 1;
      }
      t_rad--;
    }

    /* Kolla hur m�nga steg �t "h�ger" han kan g�. */
    t_rad = rad;
    t_kol = kol + 1;
    quit_loop = 0;
    while ((t_kol < 8) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_ROOK);
      } else if (spelplan[t_rad][t_kol] < 0) {   //om svart pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_ROOK);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] > 0) {     //om vit pj�s
	quit_loop = 1;
      }
      t_kol++;
    }

    /* Kolla hur m�nga steg �t "v�nster" han kan g�. */
    t_rad = rad;
    t_kol = kol - 1;
    quit_loop = 0;
    while ((t_kol > -1) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_ROOK);
      } else if (spelplan[t_rad][t_kol] < 0) {   //om svart pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_ROOK);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] > 0) {     //om vit pj�s
	quit_loop = 1;
      }
      t_kol--;
    }
  } else if (spelplan[rad][kol] == BLACK_ROOK) {

    /* Kolla hur m�nga steg "upp�t" han kan g�. */
    t_rad = rad + 1;
    t_kol = kol;
    quit_loop = 0;
    while ((t_rad < 8) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_ROOK);
      } else if (spelplan[t_rad][t_kol] > 0) {   //om vit pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_ROOK);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] < 0) {     //om svart pj�s
	quit_loop = 1;
      }
      t_rad++;
    }

    /* Kolla hur m�nga steg "ned�t" han kan g�. */
    t_rad = rad - 1;
    t_kol = kol;
    quit_loop = 0;
    while ((t_rad > -1) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_ROOK);
      } else if (spelplan[t_rad][t_kol] > 0) {   //om vit pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_ROOK);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] < 0) {     //om svart pj�s
	quit_loop = 1;
      }
      t_rad--;
    }

    /* Kolla hur m�nga steg �t "h�ger" han kan g�. */
    t_rad = rad;
    t_kol = kol + 1;
    quit_loop = 0;
    while ((t_kol < 8) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_ROOK);
      } else if (spelplan[t_rad][t_kol] > 0) {   //om vit pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_ROOK);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] < 0) {     //om svart pj�s
	quit_loop = 1;
      }
      t_kol++;
    }

    /* Kolla hur m�nga steg �t "v�nster" han kan g�. */
    t_rad = rad;
    t_kol = kol - 1;
    quit_loop = 0;
    while ((t_kol > -1) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_ROOK);
      } else if (spelplan[t_rad][t_kol] > 0) {   //om vit pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_ROOK);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] < 0) {     //om svart pj�s
	quit_loop = 1;
      }
      t_kol--;
    }
  } else {
    //g�r ingenting, det var inte ett torn som stod p� rutan
  }
  draglista[i].fromrow = -99;
  return draglista;
}




/* Kollar om ett torn kan g� fr�n en ruta till en annan, enligt
   reglerna f�r tornets f�rflyttning. Vi tar ej h�nsyn till
   om tex. en schack om�jligg�r draget, utan vi tittar endast
   p� reglerna f�r pj�sens f�rflyttning. NOTERA: color �r f�rgen
   p� motst�ndarens pj�ser. Denna funktion anropas fr�n
   check_opponentschack() i makelist.c
     Vi kollar inte vad som finns p� spelplan[torow][tocol],
   och f�r �vrigt f�rv�ntas spelplan[fromrow][fromcol] vara tom. */
int rookmovevalid(int **spelplan, int fromrow, int fromcol, int torow, int tocol) {
  int i, j;

  if (fromrow == torow) {                     //Samma rad
    if (fromcol < tocol) {
      for (i = fromcol; i < tocol; i++) {
	if (spelplan[fromrow][i] != EMPTY)
	  return 0;
      }
      return 1;
    } else {
      for (i = fromcol; i > tocol; i--) {
	if (spelplan[fromrow][i] != EMPTY)
	  return 0;
      }
      return 1;
    }
  } else if (fromcol == tocol) {              //Samma kolumn
    if (fromrow < torow) {
      for (i = fromrow; i < torow; i++) {
	if (spelplan[i][fromcol] != EMPTY)
	  return 0;
      }
      return 1;
    } else {
      for (i = fromrow; i > torow; i--) {
	if (spelplan[i][fromcol] != EMPTY)
	  return 0;
      }
      return 1;
    }
  }

  return 0;
}





