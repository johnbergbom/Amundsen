#ifndef _LOPARE_
#define _LOPARE_

/* Denna funktion returnerar en lista p� alla drag en viss l�pare kan
   g�ra. Sista positionen i listan �r -99. */
struct drag *drag_lopare(int **spelplan, int rad, int kol);

/* Kollar om en l�pare kan g� fr�n en ruta till en annan, enligt
   reglerna f�r l�parens f�rflyttning. Vi tar ej h�nsyn till
   om tex. en schack om�jligg�r draget, utan vi tittar endast
   p� reglerna f�r pj�sens f�rflyttning. NOTERA: color �r f�rgen
   p� motst�ndarens pj�ser. Denna funktion anropas fr�n
   check_opponentschack() i makelist.c
     Vi kollar inte vad som finns p� spelplan[torow][tocol],
   och f�r �vrigt f�rv�ntas spelplan[fromrow][fromcol] vara tom. */
int bishopmovevalid(int **spelplan, int fromrow, int fromcol, int torow, int tocol);

#endif      //_LOPARE_
