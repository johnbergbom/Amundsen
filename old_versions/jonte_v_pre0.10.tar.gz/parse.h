#ifndef _PARSE_
#define _PARSE_

#include "diverse.h"

void computer_make_move(struct s *spel, int *vemstur, int *started);

int parsemove(char *input, struct s *spel, int *vemstur, int *started);

void parse(int *white, int *black, int *vemstur, int *started,
	   struct s *spel);

#endif      //_PARSE_
