#ifndef _KUNG_
#define _KUNG_

#include "diverse.h"

/* Denna funktion returnerar en lista p� alla drag kungen kan
   g�ra. Sista positionen i listan �r -99. */
struct drag *drag_kung(struct s *spel, int rad, int kol, int vemstur);

#endif       //_KUNG_
