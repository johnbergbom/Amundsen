#include "dam.h"

#include "diverse.h"

/* Denna funktion returnerar en lista p� alla drag damen kan
   g�ra. Sista positionen i listan �r -99. */
struct drag *drag_dam(int **spelplan, int rad, int kol) {
  int i = 0;
  struct drag *draglista;
  int t_rad, t_kol;
  int quit_loop;

  /*+1 f�r att rymma -99 p� slutet*/
  draglista = (struct drag *) malloc((MAX_QUEEN_MOVE+1)*sizeof(struct drag));
  if (spelplan[rad][kol] == WHITE_QUEEN) {

    /* Kolla hur m�nga steg "ned�t" hon kan g�. */
    t_rad = rad + 1;
    t_kol = kol;
    quit_loop = 0;
    while ((t_rad < 8) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_QUEEN);
      } else if (spelplan[t_rad][t_kol] < 0) {   //om svart pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_QUEEN);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] > 0) {     //om vit pj�s
	quit_loop = 1;
      }
      t_rad++;
    }

    /* Kolla hur m�nga steg "upp�t" hon kan g�. */
    t_rad = rad - 1;
    t_kol = kol;
    quit_loop = 0;
    while ((t_rad > -1) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_QUEEN);
      } else if (spelplan[t_rad][t_kol] < 0) {   //om svart pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_QUEEN);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] > 0) {     //om vit pj�s
	quit_loop = 1;
      }
      t_rad--;
    }

    /* Kolla hur m�nga steg �t "h�ger" hon kan g�. */
    t_rad = rad;
    t_kol = kol + 1;
    quit_loop = 0;
    while ((t_kol < 8) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_QUEEN);
      } else if (spelplan[t_rad][t_kol] < 0) {   //om svart pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_QUEEN);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] > 0) {     //om vit pj�s
	quit_loop = 1;
      }
      t_kol++;
    }

    /* Kolla hur m�nga steg �t "v�nster" hon kan g�. */
    t_rad = rad;
    t_kol = kol - 1;
    quit_loop = 0;
    while ((t_kol > -1) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_QUEEN);
      } else if (spelplan[t_rad][t_kol] < 0) {   //om svart pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_QUEEN);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] > 0) {     //om vit pj�s
	quit_loop = 1;
      }
      t_kol--;
    }

    /* Kolla hur m�nga steg "sydv�st" hon kan g�. */
    t_rad = rad + 1;
    t_kol = kol - 1;
    quit_loop = 0;
    while ((t_rad < 8) && (t_kol > -1) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_QUEEN);
      } else if (spelplan[t_rad][t_kol] < 0) {   //om svart pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_QUEEN);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] > 0) {     //om vit pj�s
	quit_loop = 1;
      }
      t_rad++;
      t_kol--;
    }

    /* Kolla hur m�nga steg "nordost" hon kan g�. */
    t_rad = rad - 1;
    t_kol = kol + 1;
    quit_loop = 0;
    while ((t_rad > -1) && (t_kol < 8) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_QUEEN);
      } else if (spelplan[t_rad][t_kol] < 0) {   //om svart pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_QUEEN);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] > 0) {     //om vit pj�s
	quit_loop = 1;
      }
      t_rad--;
      t_kol++;
    }

    /* Kolla hur m�nga steg �t "nordv�st" hon kan g�. */
    t_rad = rad - 1;
    t_kol = kol - 1;
    quit_loop = 0;
    while ((t_kol > -1) && (t_rad > -1) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_QUEEN);
      } else if (spelplan[t_rad][t_kol] < 0) {   //om svart pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_QUEEN);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] > 0) {     //om vit pj�s
	quit_loop = 1;
      }
      t_rad--;
      t_kol--;
    }

    /* Kolla hur m�nga steg �t "sydv�st" hon kan g�. */
    t_rad = rad + 1;
    t_kol = kol + 1;
    quit_loop = 0;
    while ((t_kol < 8) && (t_rad < 8) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_QUEEN);
      } else if (spelplan[t_rad][t_kol] < 0) {   //om svart pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,WHITE_QUEEN);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] > 0) {     //om vit pj�s
	quit_loop = 1;
      }
      t_rad++;
      t_kol++;
    }

  } else if (spelplan[rad][kol] == BLACK_QUEEN) {

    /* Kolla hur m�nga steg "upp�t" hon kan g�. */
    t_rad = rad + 1;
    t_kol = kol;
    quit_loop = 0;
    while ((t_rad < 8) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_QUEEN);
      } else if (spelplan[t_rad][t_kol] > 0) {   //om vit pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_QUEEN);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] < 0) {     //om svart pj�s
	quit_loop = 1;
      }
      t_rad++;
    }

    /* Kolla hur m�nga steg "ned�t" hon kan g�. */
    t_rad = rad - 1;
    t_kol = kol;
    quit_loop = 0;
    while ((t_rad > -1) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_QUEEN);
      } else if (spelplan[t_rad][t_kol] > 0) {   //om vit pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_QUEEN);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] < 0) {     //om svart pj�s
	quit_loop = 1;
      }
      t_rad--;
    }

    /* Kolla hur m�nga steg �t "h�ger" hon kan g�. */
    t_rad = rad;
    t_kol = kol + 1;
    quit_loop = 0;
    while ((t_kol < 8) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_QUEEN);
      } else if (spelplan[t_rad][t_kol] > 0) {   //om vit pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_QUEEN);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] < 0) {     //om svart pj�s
	quit_loop = 1;
      }
      t_kol++;
    }

    /* Kolla hur m�nga steg �t "v�nster" hon kan g�. */
    t_rad = rad;
    t_kol = kol - 1;
    quit_loop = 0;
    while ((t_kol > -1) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_QUEEN);
      } else if (spelplan[t_rad][t_kol] > 0) {   //om vit pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_QUEEN);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] < 0) {     //om svart pj�s
	quit_loop = 1;
      }
      t_kol--;
    }

    /* Kolla hur m�nga steg "sydv�st" hon kan g�. */
    t_rad = rad + 1;
    t_kol = kol - 1;
    quit_loop = 0;
    while ((t_rad < 8) && (t_kol > -1) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_QUEEN);
      } else if (spelplan[t_rad][t_kol] > 0) {   //om vit pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_QUEEN);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] < 0) {     //om svart pj�s
	quit_loop = 1;
      }
      t_rad++;
      t_kol--;
    }

    /* Kolla hur m�nga steg "nordost" hon kan g�. */
    t_rad = rad - 1;
    t_kol = kol + 1;
    quit_loop = 0;
    while ((t_rad > -1) && (t_kol < 8) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_QUEEN);
      } else if (spelplan[t_rad][t_kol] > 0) {   //om vit pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_QUEEN);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] < 0) {     //om svart pj�s
	quit_loop = 1;
      }
      t_rad--;
      t_kol++;
    }

    /* Kolla hur m�nga steg �t "nordv�st" hon kan g�. */
    t_rad = rad - 1;
    t_kol = kol - 1;
    quit_loop = 0;
    while ((t_kol > -1) && (t_rad > -1) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_QUEEN);
      } else if (spelplan[t_rad][t_kol] > 0) {   //om vit pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_QUEEN);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] < 0) {     //om svart pj�s
	quit_loop = 1;
      }
      t_rad--;
      t_kol--;
    }

    /* Kolla hur m�nga steg �t "sydv�st" hon kan g�. */
    t_rad = rad + 1;
    t_kol = kol + 1;
    quit_loop = 0;
    while ((t_kol < 8) && (t_rad < 8) && (!quit_loop)) {
      if (spelplan[t_rad][t_kol] == EMPTY) {
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_QUEEN);
      } else if (spelplan[t_rad][t_kol] > 0) {   //om vit pj�s
	initdrag(&draglista[i++],rad,kol,t_rad,t_kol,BLACK_QUEEN);
	quit_loop = 1;
      } else if (spelplan[t_rad][t_kol] < 0) {     //om svart pj�s
	quit_loop = 1;
      }
      t_rad++;
      t_kol++;
    }

  } else {
    //g�r ingenting, det var inte en dam som stod p� rutan
  }
  draglista[i].fromrow = -99;
  return draglista;
}


/* Kollar om en dam kan g� fr�n en ruta till en annan, enligt
   reglerna f�r damens f�rflyttning. Vi tar ej h�nsyn till
   om tex. en schack om�jligg�r draget, utan vi tittar endast
   p� reglerna f�r pj�sens f�rflyttning. NOTERA: color �r f�rgen
   p� motst�ndarens pj�ser. Denna funktion anropas fr�n
   check_opponentschack() i makelist.c
     Vi kollar inte vad som finns p� spelplan[torow][tocol],
   och f�r �vrigt f�rv�ntas spelplan[fromrow][fromcol] vara tom. */
int queenmovevalid(int **spelplan, int fromrow, int fromcol, int torow, int tocol) {
  int i, j;

  if (fromrow == torow) {                     //Samma rad
    if (fromcol < tocol) {
      for (i = fromcol; i < tocol; i++) {
	if (spelplan[fromrow][i] != EMPTY)
	  return 0;
      }
      return 1;
    } else {
      for (i = fromcol; i > tocol; i--) {
	if (spelplan[fromrow][i] != EMPTY)
	  return 0;
      }
      return 1;
    }
  } else if (fromcol == tocol) {              //Samma kolumn
    if (fromrow < torow) {
      for (i = fromrow; i < torow; i++) {
	if (spelplan[i][fromcol] != EMPTY)
	  return 0;
      }
      return 1;
    } else {
      for (i = fromrow; i > torow; i--) {
	if (spelplan[i][fromcol] != EMPTY)
	  return 0;
      }
      return 1;
    }
  } else if (fromrow - torow == fromcol - tocol) {   //Nordv�st
    j = 0;
    for (i = fromcol; i > tocol; i--) {
      if (spelplan[fromrow - j][fromcol - j] != EMPTY)
	return 0;
      j++;
    }
    return 1;
  } else if (fromrow - torow == tocol - fromcol) {   //Nordost
    j = 0;
    for (i = fromcol; i < tocol; i++) {
      if (spelplan[fromrow - j][fromcol + j] != EMPTY)
	return 0;
      j++;
    }
    return 1;
  } else if (torow - fromrow == fromcol - tocol) {   //Sydv�st
    j = 0;
    for (i = fromcol; i > tocol; i--) {
      if (spelplan[fromrow + j][fromcol - j] != EMPTY)
	return 0;
      j++;
    }
    return 1;
  } else if (torow - fromrow == tocol - fromcol) {   //Sydost
    j = 0;
    for (i = fromcol; i < tocol; i++) {
      if (spelplan[fromrow + j][fromcol + j] != EMPTY)
	return 0;
      j++;
    }
    return 1;
  }

  return 0;
}




