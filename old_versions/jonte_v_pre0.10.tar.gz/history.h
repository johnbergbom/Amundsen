#ifndef _HISTORY_
#define _HISTORY_

#include "diverse.h"

#define MAXDRAG_I_PARTI 200

void add_drag2history(struct drag *draget);

/* Denna funktion returnerar draget nummer. Nummer ska vara ett negativt
   tal som betecknar vilket drag tidigare i spelet man vill ha fram,
   j�mf�rt med det just gjorda draget. getmovenumber(-1) returnerar
   det just gjorda draget. */
struct drag getmovenumber(int nummer);

void showhistory();

#endif     //_HISTORY_
