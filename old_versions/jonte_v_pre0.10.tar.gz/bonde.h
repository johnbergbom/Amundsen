#ifndef _BONDE_
#define _BONDE_

#include "diverse.h"

void bondeforvandling(struct drag *draglista, int *i, int frad, int fkol, int trad, int tkol, int color);

/* Denna funktion returnerar en lista p� alla drag en viss bonde kan
   g�ra. Sista positionen i listan �r -99. */
struct drag *drag_bonde(int **spelplan, int rad, int kol);

/* Kollar om en bonde kan g� fr�n en ruta till en annan, enligt
   reglerna f�r bondens f�rflyttning. Vi tar ej h�nsyn till
   om tex. en schack om�jligg�r draget, utan vi tittar endast
   p� reglerna f�r pj�sens f�rflyttning. NOTERA: color �r f�rgen
   p� motst�ndarens pj�ser. Denna funktion anropas fr�n
   check_opponentschack() i makelist.c */
int pawnmovevalid(int fromrow, int fromcol, int torow, int tocol, int color);

#endif      //_BONDE_
