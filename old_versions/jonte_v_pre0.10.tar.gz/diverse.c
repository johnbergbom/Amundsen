#include "diverse.h"
#include <stdio.h>

int LATTEVAARA = -99;
char *LATTEMINDRAG;
char *LATTEMAXDRAG;
int MINELLERMAX = 0;
int xboard_mode = 0;

/* OBS! Funktionen kor inte free pa spel->draglista! */
void freespel(struct s *spel) {
  int i;

  for (i = 0; i < 8; i++)
    free(spel->spelplan[i]);
  free(spel->spelplan);
  //free(spel->draglista);
  free(spel);
}

void switch_colors(int *color) {
  if (*color == WHITE)
    *color = BLACK;
  else
    *color = WHITE;
}

void debuglog(char *text) {
  FILE *fp;
  char *filnamn = DEBUGLOGFILE;

  fp = fopen(filnamn,"a");
  if (fp == NULL)
    fprintf(stderr,"Could not open %s\n",DEBUGLOGFILE);
  fprintf(fp,"%s\n",text);
  fclose(fp);
}

struct s *get_new_board() {
  int **board;
  int i, rad, kol;
  struct s *spel;

  spel = (struct s *) malloc(1*sizeof(struct s));
  board = (int **) malloc(8*sizeof(int *));
  for (i = 0; i < 8; i++)
    board[i] = (int *) malloc(8*sizeof(int));

  board[0][0] = BLACK_ROOK;
  board[0][1] = BLACK_KNIGHT;
  board[0][2] = BLACK_BISHOP;
  board[0][3] = BLACK_QUEEN;
  board[0][4] = BLACK_KING;
  board[0][5] = BLACK_BISHOP;
  board[0][6] = BLACK_KNIGHT;
  board[0][7] = BLACK_ROOK;
  for (kol = 0; kol < 8; kol++)
    board[1][kol] = BLACK_PAWN;
  for (rad = 2; rad < 6; rad++) {
    for (kol = 0; kol < 8; kol++) {
      board[rad][kol] = EMPTY;
    }
  }
  for (kol = 0; kol < 8; kol++)
    board[6][kol] = WHITE_PAWN;
  board[7][0] = WHITE_ROOK;
  board[7][1] = WHITE_KNIGHT;
  board[7][2] = WHITE_BISHOP;
  board[7][3] = WHITE_QUEEN;
  board[7][4] = WHITE_KING;
  board[7][5] = WHITE_BISHOP;
  board[7][6] = WHITE_KNIGHT;
  board[7][7] = WHITE_ROOK;

  spel->spelplan = board;
  spel->evalboard = eval_abs(spel->spelplan);
  if (board[7][0] != WHITE_ROOK)
    spel->vitAtornmoved = 1;
  if (board[7][7] != WHITE_ROOK)
    spel->vitHtornmoved = 1;
  if (board[7][4] != WHITE_KING)
    spel->vitkingmoved = 1;
  if (spel->vitAtornmoved || spel->vitHtornmoved || spel->vitkingmoved)
    spel->vitrockerat = 1;
  if (board[0][0] != BLACK_ROOK)
    spel->svartAtornmoved = 1;
  if (board[0][7] != BLACK_ROOK)
    spel->svartHtornmoved = 1;
  if (board[0][4] != BLACK_KING)
    spel->svartkingmoved = 1;
  if (spel->svartAtornmoved || spel->svartHtornmoved || spel->svartkingmoved)
    spel->svartrockerat = 1;

  return spel;
}

int **get_test_board() {
  int **spelplan;
  int i, rad, kol;

  spelplan = (int **) malloc(8*sizeof(int *));
  for (i = 0; i < 8; i++)
    spelplan[i] = (int *) malloc(8*sizeof(int));

  for (rad = 0; rad < 8; rad++) {
    for (kol = 0; kol < 8; kol++) {
      spelplan[rad][kol] = EMPTY;
    }
  }

  spelplan[0][1] = BLACK_QUEEN;
  spelplan[0][6] = BLACK_KING;
  spelplan[4][0] = BLACK_KNIGHT;
  spelplan[5][3] = WHITE_KNIGHT;
  spelplan[6][1] = WHITE_PAWN;
  spelplan[7][2] = WHITE_QUEEN;
  spelplan[7][6] = WHITE_KING;

  return spelplan;
}

int **get_test_board2() {
  int **spelplan;
  int i, rad, kol;

  spelplan = (int **) malloc(8*sizeof(int *));
  for (i = 0; i < 8; i++)
    spelplan[i] = (int *) malloc(8*sizeof(int));

  for (rad = 0; rad < 8; rad++) {
    for (kol = 0; kol < 8; kol++) {
      spelplan[rad][kol] = EMPTY;
    }
  }

  spelplan[0][1] = BLACK_QUEEN;
  spelplan[0][6] = BLACK_KING;
  spelplan[1][1] = BLACK_ROOK;
  spelplan[5][3] = WHITE_KNIGHT;
  spelplan[6][1] = WHITE_KNIGHT;
  spelplan[6][2] = WHITE_QUEEN;
  spelplan[7][6] = WHITE_KING;

  return spelplan;
}


int **get_test_board3() {
  int **spelplan;
  int i, rad, kol;

  spelplan = (int **) malloc(8*sizeof(int *));
  for (i = 0; i < 8; i++)
    spelplan[i] = (int *) malloc(8*sizeof(int));

  spelplan[0][0] = BLACK_ROOK;
  spelplan[0][1] = BLACK_KNIGHT;
  spelplan[0][2] = BLACK_BISHOP;
  spelplan[0][3] = BLACK_QUEEN;
  spelplan[0][4] = BLACK_KING;
  spelplan[0][5] = BLACK_BISHOP;
  spelplan[0][6] = BLACK_KNIGHT;
  spelplan[0][7] = BLACK_ROOK;
  for (kol = 0; kol < 8; kol++)
    spelplan[1][kol] = BLACK_PAWN;
  for (rad = 2; rad < 6; rad++) {
    for (kol = 0; kol < 8; kol++) {
      spelplan[rad][kol] = EMPTY;
    }
  }
  for (kol = 0; kol < 8; kol++)
    spelplan[6][kol] = WHITE_PAWN;
  spelplan[7][0] = WHITE_ROOK;
  spelplan[7][1] = WHITE_KNIGHT;
  spelplan[7][2] = WHITE_BISHOP;
  spelplan[7][3] = WHITE_QUEEN;
  spelplan[7][4] = WHITE_KING;
  spelplan[7][5] = WHITE_BISHOP;
  spelplan[7][6] = WHITE_KNIGHT;
  spelplan[7][7] = WHITE_ROOK;

  spelplan[1][3] = EMPTY;
  spelplan[2][3] = BLACK_PAWN;
  spelplan[4][4] = WHITE_PAWN;
  spelplan[6][4] = EMPTY;

  return spelplan;
}


int **get_test_board4() {
  int **spelplan;
  int i, rad, kol;

  spelplan = (int **) malloc(8*sizeof(int *));
  for (i = 0; i < 8; i++)
    spelplan[i] = (int *) malloc(8*sizeof(int));

  spelplan[0][0] = BLACK_ROOK;
  spelplan[0][1] = BLACK_KNIGHT;
  spelplan[0][2] = BLACK_BISHOP;
  spelplan[0][3] = BLACK_QUEEN;
  spelplan[0][4] = BLACK_KING;
  spelplan[0][5] = BLACK_BISHOP;
  spelplan[0][6] = BLACK_KNIGHT;
  spelplan[0][7] = BLACK_ROOK;
  for (kol = 0; kol < 8; kol++)
    spelplan[1][kol] = BLACK_PAWN;
  for (rad = 2; rad < 6; rad++) {
    for (kol = 0; kol < 8; kol++) {
      spelplan[rad][kol] = EMPTY;
    }
  }
  for (kol = 0; kol < 8; kol++)
    spelplan[6][kol] = WHITE_PAWN;
  spelplan[7][0] = WHITE_ROOK;
  spelplan[7][1] = WHITE_KNIGHT;
  spelplan[7][2] = WHITE_BISHOP;
  spelplan[7][3] = WHITE_QUEEN;
  spelplan[7][4] = WHITE_KING;
  spelplan[7][5] = WHITE_BISHOP;
  spelplan[7][6] = WHITE_KNIGHT;
  spelplan[7][7] = WHITE_ROOK;

  spelplan[0][0] = EMPTY;
  spelplan[0][3] = EMPTY;
  spelplan[1][0] = EMPTY;
  spelplan[1][1] = EMPTY;
  spelplan[1][2] = EMPTY;
  spelplan[1][4] = EMPTY;
  spelplan[2][1] = BLACK_PAWN;
  spelplan[2][5] = BLACK_QUEEN;
  spelplan[3][3] = BLACK_PAWN;
  spelplan[3][5] = BLACK_ROOK;
  spelplan[4][0] = BLACK_PAWN;

  //spelplan[3][1] = WHITE_KNIGHT;
  spelplan[6][3] = WHITE_QUEEN;
  spelplan[4][5] = WHITE_BISHOP;
  //spelplan[5][5] = WHITE_KNIGHT;
  //spelplan[6][3] = EMPTY;
  spelplan[6][4] = WHITE_BISHOP;
  spelplan[7][1] = EMPTY;
  spelplan[7][2] = EMPTY;
  spelplan[7][3] = EMPTY;
  spelplan[7][4] = WHITE_ROOK;
  spelplan[7][5] = EMPTY;
  spelplan[7][6] = WHITE_KING;
  spelplan[7][7] = EMPTY;

  spelplan[1][3] = EMPTY;
  spelplan[0][2] = EMPTY;
  //spelplan[7][7] = EMPTY;
  //spelplan[7][7] = EMPTY;

  return spelplan;
}

struct s *get_test_board5() {
  int **board;
  int i, rad, kol;
  struct s *spel;

  spel = (struct s *) malloc(1*sizeof(struct s));

  board = (int **) malloc(8*sizeof(int *));
  for (i = 0; i < 8; i++)
    board[i] = (int *) malloc(8*sizeof(int));

  for (rad = 0; rad < 8; rad++) {
    for (kol = 0; kol < 8; kol++) {
      board[rad][kol] = EMPTY;
    }
  }

  board[0][1] = BLACK_KNIGHT;
  board[1][1] = WHITE_BISHOP;
  board[1][2] = BLACK_PAWN;
  board[1][7] = BLACK_KING;
  board[2][0] = BLACK_PAWN;
  board[4][7] = BLACK_PAWN;
  board[5][2] = WHITE_PAWN;
  board[6][0] = WHITE_PAWN;
  board[6][5] = WHITE_PAWN;
  board[6][6] = WHITE_PAWN;
  board[6][7] = WHITE_PAWN;
  board[7][3] = WHITE_ROOK;
  board[7][4] = WHITE_ROOK;
  board[7][6] = WHITE_KING;

  spel->spelplan = board;
  spel->evalboard = eval_abs(spel->spelplan);
  if (board[7][0] != WHITE_ROOK)
    spel->vitAtornmoved = 1;
  if (board[7][7] != WHITE_ROOK)
    spel->vitHtornmoved = 1;
  if (board[7][4] != WHITE_KING)
    spel->vitkingmoved = 1;
  if (spel->vitAtornmoved || spel->vitHtornmoved || spel->vitkingmoved)
    spel->vitrockerat = 1;
  if (board[0][0] != BLACK_ROOK)
    spel->svartAtornmoved = 1;
  if (board[0][7] != BLACK_ROOK)
    spel->svartHtornmoved = 1;
  if (board[0][4] != BLACK_KING)
    spel->svartkingmoved = 1;
  if (spel->svartAtornmoved || spel->svartHtornmoved || spel->svartkingmoved)
    spel->svartrockerat = 1;

  return spel;
}

