#ifndef _EVAL_
#define _EVAL_

#include "bitboards.h"

#define KRK 1
#define KQK 2
#define UNKNOWN_ENDGAME 3

void eval_pawn_structure(struct board *board, int *wval, int *bval);
void eval_piece_placement(struct board *board, int *wval, int *bval);

/* This function returns a value for how good a position is. A high value
   for the player at move means he is well off in the game. */
int eval(int *color, struct board *board);

#endif    //_EVAL_
