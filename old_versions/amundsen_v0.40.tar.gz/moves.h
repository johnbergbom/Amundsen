#ifndef _MOVES_
#define _MOVES_

#include "misc.h"
#include "bitboards.h"

/* This method returns true(=1) if the king in the specified color is
   threatened. Else false(=0).*/
int in_check(struct board *board, int color);

/* This function returns 1 if the move is legal, and 0 if it's illegal. */
int legal_move(struct move move_to_check, struct board *board, int color);

/* This function converts a string to a struct move-object. If the string
   is not a correct move, then move.value will be set to -99. */
void str2move(char *vilket_drag, struct board *board, int vemstur, struct move *move);

void move2str(int color, struct move move, char *str);

void make_nullmove(struct board *oldboard, struct board *newboard);

void makemove(struct board *oldboard, struct board *newboard, int color, struct move move, int depth);

#endif      //_MOVES_
