#ifndef _PARSE_
#define _PARSE_

#include "misc.h"
#include "bitboards.h"

#define HUMAN 1
#define COMPUTER 2
#define WHITE 0
#define BLACK 1
#define BOOKSIZE 3144

int change_list_size(struct move **list, int new_size);
void move2history(struct move *move);
int game_ended(struct board *brd, int color_to_move);
void preanalysis(struct board *brd, int color, struct move **movelist,
		 int *mcount);
void postanalysis(struct board *brd, struct move **movelist,
		  int mcount, int color, struct move *move);
int bookmove(int l_histpos, int *in_book, struct board *l_board,
	     int color, struct move *move);
void computer_make_move(struct board **board, int *vemstur, int *started);

int parsemove(char *input, struct board **board, int *vemstur, int *started);

void parse(void);

#endif      //_PARSE_
