#ifndef _TIMECTRL_
#define _TIMECTRL_

/* The program supports three types of time controls:
   TIMECTRL_NEWTIME plays a certain number of moves, and then
   additional time is obtained.
   TIMECTRL_INC has a base time and in addition to that, it has a
   certain amount of time for each move, and the time that is not
   used up is accumulated for later use.
   TIMECTRL_NOINC has a base time, and no additional time per move,
   and it doesn't get additional time after a certain number of moves. */
#define TIMECTRL_NEWTIME 1
#define TIMECTRL_INC 2
#define TIMECTRL_NOINC 3

/* On some platforms there seems to be problems with calling the
   ftime-function. Then gettimeofday can be used instead. */
#define FTIME 0
#define GETTIMEOFDAY 1
#define GETTIME GETTIMEOFDAY

void showtime(int engine_color);
int get_checkpoint_time(void);
void start_own_clock(void);
void start_opp_clock(void);
void stop_own_clock(void);
void stop_opp_clock(void);
int time_elapsed(int checkpoint);
int time_is_up(int movenumber, int branching_factor);

#endif         //_TIMECTRL_
