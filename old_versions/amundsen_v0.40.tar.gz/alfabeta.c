#include "alfabeta.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include "moves.h"
#include "genmoves.h"
#include "eval.h"
#include "hash.h"
#include "slump.h"
#include "parse.h"
#include "display.h"

/* R = reduction factor for the null-move search. */
#define R 2

int visited_nodes;       //total number (quiescence + normal search)
int quiescence_nodes;
int cutoffs = 0;             //count the number of cutoffs
int cutoffs_first = 0;

/* Killers keep track of the moves that cause a cutoff at each level
   of the search. */
struct killers **killers;

/* if zugswang is set, then no null-move pruning will be used. */
int zugswang = 0;


int lagge;
int lagge2;
//int lagge3;

int max(int a, int b) {
  if (a > b)
    return a;
  else
    return b;
}

int min(int a, int b) {
  if (a > b)
    return b;
  else
    return a;
}

/* Don't use the hashtable in the quiescence search. It's probably better to
   save the hashtable for the upper parts of the search tree. */
int quiescence(struct board *board, int color, int org_color, int nodetype, int alpha, int beta, bitboard tsquare) {
  struct board newpos;
  int retval;
  int q_val;
  int movables = 0;
  struct moves moves[16];
  struct move move;
  int order = 0;
  int hashval = 0;
  struct move hashmove;
  //extern int use_hash;
  int org_alpha = alpha, org_beta = beta;

  switch_colors(&color);

  if (generate_moves(board,color,moves,&movables) != 0)
    return KINGTAKEN;

  visited_nodes++;
  quiescence_nodes++;
  retval = (nodetype == MAX) ? -INFTY : INFTY;

  //if (use_hash) {
    hashval = probe_hash(0,board,&hashmove,&alpha,&beta,&retval,1);
    if (hashval != UNKNOWN && hashval != HASH_MOVE)
      return hashval;
    //}

  if (nodetype == MAX) {
    /* We init retval to the static score of the position. Then the engine
       will take whatever is best of continuing the capture line, or to
       accept the static score of the position. However if the hashprobe gave
       an even better value we will use that instead. */
    retval = max(eval(&org_color,board),retval);
    if (retval >= beta) {
      record_hash(0,board,move,0,retval,BETA,1);
      return retval;
    } else
      alpha = max(alpha,retval);
    while(get_next_quiet_move(board,color,moves,movables,&hashval,&hashmove,&move,&order,tsquare)) {
      makemove(board,&newpos,color,move,0);
      q_val = quiescence(&newpos,color,org_color,MIN,alpha,beta,tsquare);
      if (q_val != KINGTAKEN) {
	retval = max(retval,q_val);
	alpha = max(alpha,retval);
	if (retval >= beta) {
	  record_hash(0,board,move,1,retval,BETA,1);
	  return retval;
	}
      }
    }
    /* We get here when we have gone through all the capture moves, and
       when none of them were good enough to merit a cutoff. */
    //record_hash(0,board,move,0,retval,BETA,1);
    record_hash(0,board,move,0,retval,(retval < org_alpha )? ALPHA : EXACT,1);
    //record_hash(0,board,move,0,alpha,(retval < org_alpha )? ALPHA : EXACT,1);
    return retval;
  } else {   //nodetype == MIN
    /* We init retval to the static score of the position. Then the engine
       will take whatever is best of continuing the capture line, or to
       accept the static score of the position. However if the hashprobe gave
       an even better value we will use that instead. */
    retval = min(eval(&org_color,board),retval);
    if (retval <= alpha) {
      record_hash(0,board,move,0,retval,ALPHA,1);
      return retval;
    } else
      beta = min(beta,retval);
    while(get_next_quiet_move(board,color,moves,movables,&hashval,&hashmove,&move,&order,tsquare)) {
      makemove(board,&newpos,color,move,0);
      q_val = quiescence(&newpos,color,org_color,MAX,alpha,beta,tsquare);
      if (q_val != KINGTAKEN) {
	retval = min(retval,q_val);
	beta = min(beta,retval);
	if (retval <= alpha) {
	  record_hash(0,board,move,1,retval,ALPHA,1);
	  return retval;
	}
      }
    }
    /* We get here when we have gone through all the capture moves, and
       when none of them were good enough to merit a cutoff. */
    //record_hash(0,board,move,0,retval,ALPHA,1);
    record_hash(0,board,move,0,retval,(retval > org_beta)? BETA : EXACT,1);
    //record_hash(0,board,move,0,beta,(retval > org_beta)? BETA : EXACT,1);
    return retval;
  }
}

int alphabeta(struct board *board, int color, int org_color, int nodetype, int alpha, int beta, int depth, int org_depth, int null_ok) {
  struct board newpos;
  int retval;
  int a_val;
  struct moves moves[16];
  int movables = 0;
  struct move move;
  int extension = 0;
  int hashval = 0;
  struct move hashmove;
  int best;
  int order = 0;
  int cutcount = 0;
  char *dragstr;
  int org_alpha = alpha, org_beta = beta;
  int n1;
  int m1;
  int temp;

  switch_colors(&color);
  retval = (nodetype == MAX) ? -INFTY : INFTY;
  visited_nodes++;

  //if (use_hash) {
    hashval = probe_hash((char)depth,board,&hashmove,&alpha,&beta,&retval,0);
    if (hashval != UNKNOWN && hashval != HASH_MOVE)
      return hashval;
    //}
  
  /* Generate the moves, so we detect whether the position is legal or not.
     Otherwise an invalid position can be null move pruned, or if the depth
     is zero a value can be returned. */
  if (generate_moves(board,color,moves,&movables) != 0)
    return KINGTAKEN;
  /* We can't test move_left_to_draw until after we have generated
     the moves, to see if this is an illegal position. Because otherwise
     it might happen that a zero is returned for an illegal position
     instead of KINGTAKEN. And that can lead to making an illegal move
     when we are getting close to draw by the 50-move rule. */
  if (board->moves_left_to_draw <= 0)
    return 0;

  if (depth <= 0) {
    retval = eval(&org_color,board);
    record_hash(0,board,move,0,retval,EXACT,0);
    return retval;
  } else {
    if (nodetype == MAX) {
      if (lagge2 && depth == 1)
	m1 = 1;
      else
	m1 = 0;
      /* Null-move pruning. */
      if (!in_check(board,color)) {
	if (!zugswang && null_ok && (depth > 0)) {
	  make_nullmove(board,&newpos);
	  /* Notice that we call alphabeta with color instead of oppcolor.
	     That's because the color switch is done at the top of the
	     alphabeta-function. */
	  /* Search with a minimal window around beta. Values outside of the
	     minimal window are invalid. We record values above beta in the
	     transposition table, since they are outside of the sought
	     range, and therefore doesn't need to be correct. However we
	     do not record values below beta, since we will probably want to
	     have correct values in that interval later on in the search.
	     The best move will always be recorded though, no matter where
	     in the search we are. */
	  //nullmove = 1;
	  //null_high = INFTY;
	  //null_low = beta - 1;
	  a_val = alphabeta(&newpos,color,org_color,MIN,beta-1,beta,
			    depth-1-R,org_depth,0);
	  //nullmove = 0;
	  if (a_val >= beta) {
	    retval = a_val;
	    record_hash((char)depth,board,move,0,retval,BETA,0);
	    return retval;
	  }
	}
      } else
	extension = 1;

      while (get_next_move(board,color,moves,movables,&hashval,&hashmove,killers[depth],&move,&order,org_depth,depth)) {
	cutcount++;
	/* Test code for printing out the moves the engine is processing. */
	dragstr = (char *) malloc(20*sizeof(char));
	move2str(color,move,dragstr);
	/*if (m1 && strcmp(dragstr,"f6d5") == 0) {
	  temp = 1;
	  lagge3 = 1;
	} else {
	  temp = 0;
	  lagge3 = 0;
	  }*/
	if (m1)
	  printf("    move %s(%d,%d,e=%d) ",dragstr,alpha,beta,extension);
	free(dragstr);
	makemove(board,&newpos,color,move,depth);
	
	if (depth-1+extension <= 0) {
	  a_val = quiescence(&newpos,color,org_color,MIN,alpha,beta,
			     move.tsquare);
	} else {
	  a_val = alphabeta(&newpos,color,org_color,MIN,alpha,beta,
			    depth-1+extension,org_depth,1);
	}
	
	if (m1)
	  printf("%d\n",a_val);
	if (a_val != KINGTAKEN) {
	  retval = max(retval,a_val);
	  alpha = max(alpha,retval);
	  if (retval >= beta) {
	    cutoffs++;
	    if (cutcount == 1)
	      cutoffs_first++;
	    /* Here we got a cutoff, so we'll add this move as a killer.
	       Replace the best killer. (Not the worst one, because then
	       we don't get any rotation.) */
	    best = 0;
	    /*for (i = 1; i < NBR_KILLERS; i++)
	      if (killers[depth][i].value > killers[depth][best].value)
	      best = i;*/
	    killers[depth][best].fsquare = move.fsquare;
	    killers[depth][best].tsquare = move.tsquare;
	    killers[depth][best].value = retval;
	    record_hash((char) (depth+extension),board,move,1,retval,BETA,0);
	    return retval;
	  }
	}
      }
      /* If we get here, and retval == -INFTY, it means all possible moves
         from this position leads to a check position. If we are already in
         check, then it's mate. If we're not in check, then it's stalemate. */
      if (retval == -INFTY) {
	if (in_check(board,color))
	  /* Return retval+1 instead of retval. That's because it's only
	     at the deepest level we should do this test. Otherwise this
	     could happen: Let's say at a deeper node we discovered a mate,
	     which means retval is -INFTY when we reach this code. But that
	     might be for a few moves ahead of us (deeper in the search tree).
	     And at the CURRENT position (at THIS level in the tree, we are
	     not in check, and then we would falsely return 0 instead of
	     -INFTY. So therefore, if we return retval+1 at the checkmate
	     level, then we won't reach this code at a shallower level.
	     We also add the +(100-depth), to give shallower mates a worse
	     value than mates deeper down in the tree. */
	  retval = retval + 1 + (100-depth);     //check mate
	else
	  retval = 0;         //stalemate
      }
      //record_hash((char) (depth+extension),board,move,0,retval,BETA,0);
      record_hash((char) (depth+extension),board,move,0,retval,(retval < org_alpha )? ALPHA : EXACT,0);
      //record_hash((char) (depth+extension),board,move,0,alpha,(retval < org_alpha )? ALPHA : EXACT,0);
      //printf("M");
      return retval;
    } else {   //nodetype == MIN
      if (lagge && depth == 2)
	n1 = 1;
      else
	n1 = 0;
      /* Null-move pruning. Don't do null-move search at the first MIN-level.
	 (That's why we have (depth < org_depth-1)) */
      if (!in_check(board,color)) {
	if (!zugswang && null_ok && (depth > 0) && (depth < org_depth-1)) {
	  //if (!zugswang && null_ok && (depth > 0)) {
	  make_nullmove(board,&newpos);
	  /* Notice that we call alphabeta with color instead of oppcolor.
	     That's because the color switch is done at the top of the
	     alphabeta-function. */
	  /* Search with a minimal window around alpha. Values outside of the
	     minimal window are invalid. We record values below alpha in the
	     transposition table, since they are outside of the sought
	     range, and therefore doesn't need to be correct. However we
	     do not record values above alpha, since we will probably want to
	     have correct values in that interval later on in the search.
	     The best move will always be recorded though, no matter where
	     in the search we are. */
	  //nullmove = 1;
	  //null_low = -INFTY;
	  //null_high = alpha + 1;
	  a_val = alphabeta(&newpos,color,org_color,MAX,alpha,alpha+1,
			    depth-1-R,org_depth,0);
	  //nullmove = 0;
	  if (a_val <= alpha) {
	    retval = a_val;
	    record_hash((char)depth,board,move,0,retval,ALPHA,0);
	    return retval;
	  }
	}
      } else
	extension = 1;

      while (get_next_move(board,color,moves,movables,&hashval,&hashmove,killers[depth],&move,&order,org_depth,depth)) {
	cutcount++;
	/* Test code for printing out the moves the engine is processing. */
	dragstr = (char *) malloc(20*sizeof(char));
	move2str(color,move,dragstr);
	if (lagge && strcmp(dragstr,"d4d5") == 0) {
	  temp = 1;
	  lagge2 = 1;
	} else {
	  temp = 0;
	  lagge2 = 0;
	}
	if (temp)
	  printf("  move %s(%d,%d,e=%d) ",dragstr,alpha,beta,extension);
	free(dragstr);

	makemove(board,&newpos,color,move,depth);

	if (depth-1+extension <= 0) {
	  a_val = quiescence(&newpos,color,org_color,MAX,alpha,beta,
			     move.tsquare);
	} else {
	  a_val = alphabeta(&newpos,color,org_color,MAX,alpha,beta,
			    depth-1+extension,org_depth,1);
	}

	if (temp)
	  printf("%d\n",a_val);
	if (a_val != KINGTAKEN) {
	  retval = min(retval,a_val);
	  beta = min(beta,retval);
	  if (retval <= alpha) {
	    cutoffs++;
	    if (cutcount == 1)
	      cutoffs_first++;
	    /* Here we got a cutoff, so we'll add this move as a killer.
	       Replace the best killer. (Not the worst one, because then
	       we don't get any rotation.) */
	    best = 0;
	    /*for (i = 1; i < NBR_KILLERS; i++)
	      if (killers[depth][i].value < killers[depth][best].value)
	      best = i;*/
	    killers[depth][best].fsquare = move.fsquare;
	    killers[depth][best].tsquare = move.tsquare;
	    killers[depth][best].value = retval;
	    record_hash((char) (depth+extension),board,move,1,retval,ALPHA,0);
	    return retval;
	  }
	}
      }
      /* If we get here, and retval == INFTY, it means all possible moves
         from this position leads to a check position. If we are already in
         check, then it's mate. If we're not in check, then it's stalemate. */
      if (retval == INFTY) {
	if (in_check(board,color)) {
	  /* Return retval-1 instead of retval. That's because it's only
	     at the deepest level we should do this test. Otherwise this
	     could happen: Let's say at a deeper node we discovered a mate,
	     which means retval is INFTY when we reach this code. But that
	     might be for a few moves ahead of us (deeper in the search tree).
	     And at the CURRENT position (at THIS level in the tree, we are
	     not in check, and then we would falsely return 0 instead of
	     INFTY. So therefore, if we return retval-1 at the checkmate
	     level, then we won't reach this code at a shallower level.
	     We also add the -(100-depth), to give shallower mates a higher
	     value than mates deeper down in the tree. */
	  retval = retval - 1 - (100-depth);     //check mate
	} else {
	  retval = 0;         //stalemate
	}
      }
      //record_hash((char) (depth+extension),board,move,0,retval,ALPHA,0);
      record_hash((depth+extension),board,move,0,retval,(retval > org_beta)? BETA : EXACT,0);
      //record_hash((char) (depth+extension),board,move,0,beta,(retval > org_beta)? BETA : EXACT,0);
      //printf("m");
      return retval;
    }
  }
}

