#include "timectrl.h"
#if GETTIME == GETTIMEOFDAY
  #include <sys/time.h>
  #include <unistd.h>
#else
  #include <sys/timeb.h>
#endif
#include "misc.h"
#include "parse.h"
#include <stdio.h>

/* own_time and opp_time measures the clocks of the engine and the opponent
   respectively, measured in milliseconds. */
int own_time;
int opp_time;
int own_checkpoint_time;
int opp_checkpoint_time;

/* Default timectrl is TIMECTRL_NEWTIME, which is what xboard uses
   by default, when you don't run in ICS-mode. */
int timectrl = TIMECTRL_NEWTIME;
int moves_per_timecontrol;
int base;
int increment;

void showtime(int engine_color) {
  if (engine_color == WHITE)
    printf("White: %d:%d, Black: %d:%d\n",
	   ((own_time - time_elapsed(own_checkpoint_time))/1000)/60,
	   ((own_time - time_elapsed(own_checkpoint_time))/1000)%60,
	   ((opp_time - time_elapsed(opp_checkpoint_time))/1000)/60,
	   ((opp_time - time_elapsed(opp_checkpoint_time))/1000)%60);
  else
    printf("White: %d:%d, Black: %d:%d\n",
	   ((opp_time - time_elapsed(opp_checkpoint_time))/1000)/60,
	   ((opp_time - time_elapsed(opp_checkpoint_time))/1000)%60,
	   ((own_time - time_elapsed(own_checkpoint_time))/1000)/60,
	   ((own_time - time_elapsed(own_checkpoint_time))/1000)%60);
}

int get_checkpoint_time() {
  #if GETTIME == GETTIMEOFDAY
    struct timeval tval;
    struct timezone tzone;

    if (gettimeofday(&tval,&tzone) != 0) {
      perror("Error with getting the time.");
      debuglog("Error with getting the time.");
      exit(0);
    } else
      return tval.tv_sec * 1000 + tval.tv_usec / 1000;
  #else
    struct timeb tp;

    ftime(&tp);
    return tp.time * 1000 + tp.millitm;
  #endif
}

void start_own_clock() {
  own_checkpoint_time = get_checkpoint_time();
}

void start_opp_clock() {
  opp_checkpoint_time = get_checkpoint_time();
}

void stop_own_clock() {
  own_time = own_time - time_elapsed(own_checkpoint_time);
  own_checkpoint_time = -1;
}

void stop_opp_clock() {
  opp_time = opp_time - time_elapsed(opp_checkpoint_time);
  opp_checkpoint_time = -1;
}

int time_elapsed(int checkpoint) {
  #if GETTIME == GETTIMEOFDAY
    struct timeval tval;
    struct timezone tzone;
    int currtime;

    if (checkpoint == -1)
      return 0;

    if (gettimeofday(&tval,&tzone) != 0) {
      perror("Error with getting the time.");
      debuglog("Error with getting the time.");
      exit(0);
    } else {
      currtime =  tval.tv_sec * 1000 + tval.tv_usec / 1000;
      return currtime - checkpoint;
    }
  #else
    struct timeb tp;
    int currtime;

    if (checkpoint == -1)
      return 0;

    ftime(&tp);
    currtime = tp.time * 1000 + tp.millitm;
    return currtime - checkpoint;
  #endif
}

/* This function returns 1 if the engine has to stop thinking, and
   0 if it can continue. It is used by the iterative_deepening-function
   to determine how deep to search. movenumber is actually the number of
   the current "half-move". (move = white's move and black's move,
   "half-move" = movement of one piece (white's or black's) In other
   words movenumber describes how far in the game we have gotten, in
   terms of white's moves + black's moves. branching_factor determines
   how many moves can be made in average from the current position. And
   that in turn determines how quickly the search tree will grow very
   large. */
int time_is_up(int movenumber, int branching_factor) {
  int time_per_move;

  if (timectrl == TIMECTRL_NEWTIME) {
    int whichmove, seconds_one_should_have;
    whichmove = (movenumber%(moves_per_timecontrol*2))/2;
    seconds_one_should_have = base - whichmove*base/moves_per_timecontrol;
    time_per_move = base/moves_per_timecontrol + (own_time - seconds_one_should_have);
    /* If time per move is less than 0, which can happen if some preceding
       move took a lot longer than expected, then we make sure the engine
       will still get at least some time to think. */
    if (time_per_move < 0) {
      if ((base/moves_per_timecontrol)/2 < own_time)
	time_per_move = (base/moves_per_timecontrol)/2;
      else
	time_per_move = own_time/10;
    }
  } else if (timectrl == TIMECTRL_INC) {
    time_per_move = increment + own_time - base;
    /* If time per move is less than 0, which can happen if some preceding
       move took a lot longer than expected, then we make sure the engine
       will still get at least some time to think. */
    if (time_per_move < 0) {
      if (increment/2 < own_time)
	time_per_move = increment/2;
      else
	time_per_move = own_time/10;
    }
  } else {    //timectrl == TIMECTRL_NOINC
    /* We divide the initial time in 40 slices. For the first 20 moves we
       use up one of those slices. Then we cut up the remaining time in 30
       slices, and for the next 10 moves we use up one of those slices.
       Then, between move number 30 and 40, we cut up the remaining time in
       20 slices, and use one of those slices for each move. Then, after
       move number 30 we use one tenth of the remaining time for each move. */
    if (movenumber/2 <= 20) {
      //time_per_move = own_time / (40 - movenumber/2);
      time_per_move = base/40;
    } else if (movenumber/2 <= 30) {
      //time_per_move = own_time / (50 - movenumber/2);
      time_per_move = base/30;
    } else if (movenumber/2 <= 40) {
      //time_per_move = own_time / (50 - movenumber/2);
      time_per_move = base/20;
    } else {
      time_per_move = own_time / 10;
    }
    /* If one has more time left than one's opponent, then it's okay
       to think longer. */
    /*if (own_time > 2*opp_time)
      time_per_move = own_time/10;
    else if (own_time > opp_time)
      time_per_move = own_time/20;
    else
    time_per_move = own_time/40;*/
  }
  //time_per_move = 15000;
  //printf("time_per_move = %d\n",time_per_move);
  //printf("time_elapsed = %d\n\n",time_elapsed(own_checkpoint_time));

  /* We multiply the elapsed time by the branching factor to get a good
     idea of how long time an extra ply of search will take. */
  //if (time_elapsed(own_checkpoint_time)*branching_factor >= time_per_move)
  /* It turns out that the increase in re-search time between one level and
     one level deeper, doesn't increase as fast as the branching factor.
     I dont't understand why. But anyway, that's why I divide the branching
     factor by three. */
  if (time_elapsed(own_checkpoint_time)*branching_factor/3 >= time_per_move)
    return 1;
  else
    return 0;
  /*if (time_elapsed(own_checkpoint_time) >= time_per_move)
    return 1;
  else
  return 0;*/
}
