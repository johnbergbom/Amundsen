#include "iterdeep.h"
#include <stdio.h>
#include <stdlib.h>
#include "misc.h"
#include "alfabeta.h"
#include "genmoves.h"
#include "timectrl.h"
#include "moves.h"
#include "parse.h"
#include "hash.h"

/* If post is set, then we will send output of the progress of the search
   to xboard. */
int post = 0;

/* The variable re_search is used to notify the probing of the transposition
   table that the aspiration window failed, and that transposition table
   values outside of the original window are invalid. The variables
   prev_alpha and prev_beta respectively are used to tell the probing of the
   transposition table what the previous bounds were. */
//int re_search, prev_alpha, prev_beta;

/* The variables searches and search_depth are used for getting statistics
   about the average search depth. */
int searches = 0;
int search_depth = 0;


extern int lagge;
extern struct killers **killers;
extern int xboard_mode;


/* This function determines if an aspiration re-search has do be done, and if
   so, what the alpha/beta bounds dhould be. Altogether there are eight
   different states, where state zero means that no re-search is necessary. */
int next_state(int val, int *alpha, int *beta, int *org_alpha, int *org_beta,
	       int *state, int *re_searches) {
  if (*state == 1) {
    if (val <= *alpha) {
      *state = 2;
      printf("Failed low ");
      prepare_research(*alpha+1,INFTY);
    } else if (val >= *beta) {
      *state = 5;
      printf("Failed high ");
      prepare_research(-INFTY,*beta-1);
    } else
      *state = 0;
  } else if (*state == 2) {
    if (val <= *alpha) {
      *state = 3;
      printf("Failed low ");
      prepare_research(*alpha+1,INFTY);
    } else if (val >= *beta) {
      *state = 7;
      printf("Failed high ");
      prepare_research(-INFTY,*beta-1);
    } else
      *state = 0;
  } else if (*state == 3) {
    if (val >= *beta) {
      *state = 4;
      printf("Failed high ");
      prepare_research(-INFTY,*beta-1);
    } else
      *state = 0;
  } else if (*state == 4) {
    *state = 0;
  } else if (*state == 5) {
    if (val <= *alpha) {
      *state = 7;
      printf("Failed low ");
      prepare_research(*alpha+1,INFTY);
    } else if (val >= *beta) {
      *state = 6;
      printf("Failed high ");
      prepare_research(-INFTY,*beta-1);
    } else
      *state = 0;
  } else if (*state == 6) {
    if (val <= *alpha) {
      *state = 4;
      printf("Failed low ");
      prepare_research(*alpha+1,INFTY);
    } else
      *state = 0;
  } else if (*state == 7) {
    if (val <= *alpha) {
      printf("Failed low ");
      *state = 3;
      prepare_research(*alpha+1,INFTY);
    } else if (val >= *beta) {
      *state = 6;
      printf("Failed high ");
      prepare_research(-INFTY,*beta-1);
    } else
      *state = 0;
  } /*else {
    printf("ERROR IN PROGRAM, ILLEGAL STATE IN ASPIRATION SEARCH!\n");
    exit(1);
    }*/

  if (*state != 0) {
    printf("(state => %d)\n",*state);
    (*re_searches)++;
  }

  /* If there have been several re-searches the search window is made
     bigger than it would otherwise be. */
  if (*state == 0) {
    *org_alpha = *alpha = val - VALWINDOW - 15*(*re_searches);
    *org_beta = *beta = val + VALWINDOW + 15*(*re_searches);
  } else if (*state == 2) {
    *beta = *alpha + 1;
    *alpha = val - SECOND_ATTEMPT_VALWINDOW - 20*(*re_searches);
  } else if (*state == 3) {
    *alpha = -INFTY;
    //beta stays the same
  } else if (*state == 4) {
    *alpha = -INFTY;
    *beta = INFTY;
  } else if (*state == 5) {
    *alpha = *beta - 1;
    *beta = val + SECOND_ATTEMPT_VALWINDOW + 20*(*re_searches);
  } else if (*state == 6) {
    //alpha stays the same
    *beta = *beta = INFTY;
  } else if (*state == 7) {
    *alpha = min(*alpha,*org_alpha);
    *beta = max(*beta,*org_beta);
  } /*else {
    printf("ERROR IN PROGRAM, ILLEGAL STATE IN ASPIRATION SEARCH!\n");
    exit(1);
    }*/
  return *state;
}


void iterative_deepening_aspiration_search(struct board *board,
					   int color, int movenumber,
					   struct move *movelist, int mcount) {
  struct board newpos;
  int alpha = -INFTY, beta = INFTY;
  int valmax = -INFTY;
  int org_color = color;
  int i;
  int nbr_moves = 0;
  int oppmovables = 0;
  struct moves oppmoves[16];
  int oppcolor = color;
  int depth;
  int branchfact;
  int nbrmoves1, nbrmoves2;
  int attempt_nbr;
  char *str;
  char *dragstr;
  int org_alpha, org_beta;
  int *searched_list;
  int best;
  int order;
  int fail;
  int state = 1;
  int re_searches = 0;
  int legal_moves;
  struct move *temp_movelist;
  //int out_of_time = 0;

  switch_colors(&oppcolor);

  searched_list = (int *) malloc(mcount*sizeof(int));

  /* If a search or re-search takes too long we want to quit the search
     before arriving at a value within the alpha/beta bounds. This is
     done by using a temporary movelist, which is copied to the real
     movelist only after a search within the bounds. Thereby we know that
     the real movelist will always contain usable moves, so it can be
     returned to the caller at any time (i.e. when time is up) */
  temp_movelist = (struct move *) malloc(mcount * sizeof(struct move));
  for (i = 0; i < mcount; i++)
    temp_movelist[i] = movelist[i];

  /*for (i = 0; i < mcount; i++)
    if ((bitboard)temp_movelist[i].fsquare != (bitboard) movelist[i].fsquare
	|| (bitboard)temp_movelist[i].tsquare != (bitboard) movelist[i].tsquare
	|| temp_movelist[i].piece != movelist[i].piece
	|| temp_movelist[i].type != movelist[i].type
	|| temp_movelist[i].value != movelist[i].value) {
      printf("OLIKA!!!!!!!!!!!!!!!!\n");
      exit(1);
      }*/

  /* We reserve space for killers up to ply == depth, and that's allright,
     because we don't use killer moves in the quiescence search. */
  killers = (struct killers **) calloc(MAX_ITERATIONS,sizeof(struct killers *));
  for (i = 0; i < MAX_ITERATIONS; i++)
    killers[i] = (struct killers *) calloc(NBR_KILLERS,sizeof(struct killers));

  /* Calculate the average branching factor of searching the tree. */
  nbr_moves = mcount;
  nbrmoves1 = nbr_moves;   //one's own moves
  /* We will also calculate the opponent's moves. */
  if (generate_moves(board,oppcolor,oppmoves,&oppmovables) != 0) {
    /* The opponent could take our king, and when the move generation
       function discovers that, it quits immediately, without generating
       the rest of the moves. Therefore we don't know the opponent's
       branching factor, and therefore we set the branching factor to
       the number of moves oneself can do. */
    branchfact = nbrmoves1;
  } else {
    /* Count the number of possible moves for the opponent. */
    nbrmoves2 = 0;
    for (i = 0; i < oppmovables; i++)
      nbrmoves2 += bitcount(oppmoves[i].targets);
    branchfact = (nbrmoves1 + nbrmoves2) / 2;
  }
  printf("Branch factor = %d\n",branchfact);

  /* Go through the moves in the movelist and play them by calling
     alphabeta. Go deeper and deeper iteratively. */
  depth = 2;
  attempt_nbr = 1;
  //re_search = 0;
  org_alpha = alpha;
  org_beta = beta;
  while (1) {
    //while (depth <= 3) {
    /* valmax has to be cleared (=-INFTY) for each new turn */
    valmax = -INFTY;
    /* Unset the searched moves before each new turn. */
    for (i = 0; i < nbr_moves; i++)
      searched_list[i] = 0;
    order = 0;
    fail = 0;
    legal_moves = 0;
    for (mcount = 0; mcount < nbr_moves && !fail; mcount++) {
      /* Find out a starting value for best. */
      /*best = 0;
      while (searched_list[best] == 1 && best < nbr_moves)
      best++;*/
      /*for (i = 0; i < nbr_moves; i++)
	printf("%d, ",searched_list[i]);
      printf("(b = %d)\n",best);
      printf("values = ");
      for (i = 0; i < nbr_moves; i++)
	printf("%d, ",temp_movelist[i].value);
	printf("\n",best);*/
      /* Pick the best move next. */
      /*for (i = best + 1; i < nbr_moves; i++)
	if (temp_movelist[i].value > temp_movelist[best].value && searched_list[i] == 0)
	  best = i;
      if (best >= nbr_moves) {
	printf("best >= nbr_moves!+n");
	exit(0);
	}*/
      best = get_next_root_move(board,color,temp_movelist,nbr_moves,&order,
				searched_list);
      if (best == -1) {
	printf("best == -1\n");
	exit(0);
      }
				  
      //printf("(best = %d)",best);
      /* Test code for printing out the moves the engine is processing. */
      dragstr = (char *) malloc(20*sizeof(char));
      move2str(color,temp_movelist[best],dragstr);
      //if (depth == 3 && strcmp(dragstr,"a7a5") == 0) {
      if (strcmp(dragstr,"d4b5") == 0 || strcmp(dragstr,"d4c6") == 0) {
	lagge = 1;
      } else
	lagge = 0;
      lagge = 0;
      if (lagge)
	printf("move %s(%d,%d) ",dragstr,alpha,beta);
      free(dragstr);

      makemove(board,&newpos,color,temp_movelist[best],depth);
      temp_movelist[best].value = alphabeta(&newpos,color,org_color,MIN,alpha,beta,depth-1,depth,1);
      //temp_movelist[mcount].value = alphabeta(&newpos,color,org_color,MIN,-INFTY,INFTY,depth-1,depth,1);
      if (temp_movelist[best].value != KINGTAKEN) {
	valmax = max(temp_movelist[best].value,valmax);
	//alpha = max(alpha,valmax);
	legal_moves++;
      }
      searched_list[best] = 1;
      if (lagge)
	printf("%d (capture = %d, order = %d)\n",temp_movelist[best].value,temp_movelist[best].type & CAPTURE_MOVE ? 1 : 0,order);
      //printf("%d\n",temp_movelist[best].value);
      /*if (depth > 2 && time_is_up(movenumber,branchfact))
	//if (time_is_up(movenumber,branchfact) && depth >= 7)
	out_of_time = 1;*/
      if (valmax >= beta)
	fail = 1;
    }
    fail = 0;

    if (next_state(valmax,&alpha,&beta,&org_alpha,&org_beta,
		   &state,&re_searches) == 0) {
      printf("depth = %d\n",depth);
      //re_search = 0;
      if (post) {   //then send output to xboard
	printf("%d %d 0 0 ",depth,valmax);
	str = (char *) malloc(100*sizeof(char));
	for (i = 0; i < nbr_moves; i++)
	  if (temp_movelist[i].value == valmax) {
	    move2str(color,temp_movelist[i],str);
	    printf("%s ",str);
	  }
	free(str);
	printf("\n");
      }
      /* Copy the temporary movelist into the list that will be returned. */
      for (i = 0; i < nbr_moves; i++)
	movelist[i] = temp_movelist[i];
      if (time_is_up(movenumber,branchfact))
	//if (time_is_up(movenumber,branchfact) && depth >= 7)
	break;
      /* If there will be a draw, then we don't need to keep searching
	 any deeper. */
      if (board->moves_left_to_draw - depth <= 0 && valmax == 0)
	break;
      /* If we find a quick mate, then we don't need to bother searching
	 deeper. */
      if ((valmax < (-INFTY + 150)) || (valmax > (INFTY - 150)))
	break;
      /* If there is just one legal move we don't need to search deeper. */
      if (legal_moves < 2)
	break;
      if (depth == MAX_ITERATIONS)
	break;
      depth++;
      attempt_nbr = 1;
      state = 1;
    } /*else if (depth > 2 && time_is_up(movenumber,branchfact))
      / * We don't check the time unless depth > 2 to make sure the movelist
	 contains some usable moves. (Otherwise it might be so that it's
	 only the temporary movelist that contains usable moves.) /
      //if (time_is_up(movenumber,branchfact) && depth >= 7)
      break;*/
  }
  clear_hashtable();
  searches++;
  search_depth += depth;

  if (depth >= MAX_ITERATIONS)
    debuglog("WE REACHED MAXIMUM ITERATIONS!");

  /* These are only used in the search, and they should be cleared before
     next search. */
  board->captures[WHITE] = 0;
  board->captures[BLACK] = 0;

  printf("Ply = %d\n",depth);

  for (i = 0; i < MAX_ITERATIONS; i++)
    free(killers[i]);
  free(killers);
  free(temp_movelist);
  free(searched_list);
}
