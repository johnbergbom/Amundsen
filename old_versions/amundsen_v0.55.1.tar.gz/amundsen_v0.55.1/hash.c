#include "hash.h"
#include "bitboards.h"
#include "parse.h"
#include "alfabeta.h"
#include <stdlib.h>
#include <stdio.h>
#include "makemove.h"
#include "misc.h"
#include "slump.h"

int64 CHANGE_COLOR;

struct refutation_entry *ref_table;
struct transposition_entry *transp_table;
struct pawn_entry *pawn_table;
int64 zobrist[6][2][64];
int64 zobrist_castling[2][5];
int64 zobrist_passant[64];
unsigned char sequence;
extern bitboard square[64];
extern int abort_search;

//Statistics for pawn search
int pawn_hits = 0;
int pawn_misses = 0;
int pawn_probes = 0;

/* In the postanalysis phase, if there is several best moves (with the same
   value), we pick the move that gives the best outcome after just 2 plies.
   The idea is to pick a move with a quick outcome rather than a gain farther
   away. In order to check that, we need to turn off probing of the
   transposition table, which is done by calling turn_off_hash(), which in
   turn sets the variable hash_probing to zero. */
int hash_probing = 1;

void turn_on_hash() {
  hash_probing = 1;
}

void turn_off_hash() {
  hash_probing = 0;
}

void init_hashtables() {
  int i, j, k;

  ref_table = (struct refutation_entry *) malloc(REFUTATION_NBR_ENTRIES*sizeof(struct refutation_entry));
  transp_table = (struct transposition_entry *) malloc(TRANSP_NBR_ENTRIES*sizeof(struct transposition_entry));
  pawn_table = (struct pawn_entry *) malloc(PAWN_HASH_SIZE*sizeof(struct pawn_entry));
  sequence = 255;
  clear_hashtable();
  turn_on_hash();
  for (i = 0; i < TRANSP_NBR_ENTRIES; i++)
    transp_table[i].repetitions = 0;
  for (i = 0; i < 6; i++)
    for (j = 0; j < 2; j++)
      for (k = 0; k < 64; k++)
	zobrist[i][j][k] = rand64();
  zobrist_castling[WHITE][0] = rand64();
  zobrist_castling[WHITE][LONG_CASTLING_OK] = rand64();
  zobrist_castling[WHITE][SHORT_CASTLING_OK] = rand64();
  zobrist_castling[WHITE][LONG_CASTLING_OK | SHORT_CASTLING_OK] = rand64();
  zobrist_castling[WHITE][CASTLED] = rand64();
  zobrist_castling[BLACK][0] = rand64();
  zobrist_castling[BLACK][LONG_CASTLING_OK] = rand64();
  zobrist_castling[BLACK][SHORT_CASTLING_OK] = rand64();
  zobrist_castling[BLACK][LONG_CASTLING_OK | SHORT_CASTLING_OK] = rand64();
  zobrist_castling[BLACK][CASTLED] = rand64();
  for (i = 0; i < 64; i++)
    zobrist_passant[i] = rand64();
  CHANGE_COLOR = rand64();
  j = REFUTATION_NBR_ENTRIES*sizeof(struct refutation_entry);
  printf("size of refutation table = %d kb\n",j/1024);
  j = TRANSP_NBR_ENTRIES*sizeof(struct transposition_entry);
  printf("size of transposition table = %d kb\n",j/1024);
  j = PAWN_HASH_SIZE*sizeof(struct pawn_entry);
  printf("size of pawn hashtable = %d kb\n",j/1024);
}

int64 get_zobrist_key_for_board(struct board *board) {
  int64 zobrist_key = 0;
  bitboard pieces;
  int i, j, square_nbr;

  for (i = 0; i < 2; i++) {
    for (j = 0; j < 6; j++) {
      pieces = board->piece[i][j];
      while (pieces != 0) {
	square_nbr = get_first_bitpos(pieces);
	zobrist_key ^= zobrist[j][i][square_nbr];
	pieces &= ~square[square_nbr];
      }
    }
  }
  zobrist_key ^= zobrist_castling[WHITE][(int)board->castling_status[WHITE]];
  zobrist_key ^= zobrist_castling[BLACK][(int)board->castling_status[BLACK]];
  zobrist_key ^= zobrist_passant[(int)board->passant];
  return zobrist_key;
}

int64 get_zobrist_pawn_key_for_board(struct board *board) {
  int64 zobrist_key = 0;
  bitboard pieces;
  int i, square_nbr;

  for (i = 0; i < 2; i++) {
    pieces = board->piece[i][PAWN];
    while (pieces != 0) {
      square_nbr = get_first_bitpos(pieces);
      zobrist_key ^= zobrist[PAWN][i][square_nbr];
      pieces &= ~square[square_nbr];
    }
  }
  return zobrist_key;
}

void clear_hashtable() {
  int i;

  if (sequence < 255)
    sequence++;
  else {
    sequence = 1;
    for (i = 0; i < REFUTATION_NBR_ENTRIES; i++) {
      ref_table[i].lock = 0;
      ref_table[i].sequence = 0;
    }
  }
}

/* Call this function after every non-reversible move that is
   actually played on the board. It closes all open positions, that
   is it sets the repetition counter to zero. */
void non_reversible_move() {
  int i;

  for (i = 0; i < TRANSP_NBR_ENTRIES; i++) {
    transp_table[i].repetitions = 0;
  }
}

/* Call this method after playing an actual move on the board. It
   updates the repetition counter for the position in question. */
void new_position_on_board(struct board *board) {
  struct transposition_entry *entry;

  entry = &(transp_table[get_hashkey((unsigned long long int) board->zobrist_key,(long long int) TRANSP_NBR_ENTRIES)]);
  if (entry->lock == board->zobrist_key) {
    (entry->repetitions)++;
  } else if (entry->repetitions > 0) {
    /* Already open position, don't overwrite. In this case
       repetitions won't be detected, but hopefully we don't
       get here too often. */
    //infolog("Already open position in game tree.");
  } else {
    /* Hash miss, closed position. Now the position should be opened
       (=detected as a repetition) */
    entry->lock = board->zobrist_key;
    entry->repetitions = 1;
  }
}

/* After an aspiration search that returned a value outside of the
   alpha-beta bound, the values in the hash tables cannot be used.
   However the best moves can always be used. This function takes care
   of preparing the hash tables for an aspiration re-search. */
void prepare_research(int safe_low, int safe_high) {
  int i;

  for (i = 0; i < REFUTATION_NBR_ENTRIES; i++) {
    if (ref_table[i].value < safe_low || ref_table[i].value > safe_high)
      ref_table[i].status |= MOVE_ONLY;
  }
  for (i = 0; i < TRANSP_NBR_ENTRIES; i++) {
    if (transp_table[i].value < safe_low || transp_table[i].value > safe_high)
      transp_table[i].status |= MOVE_ONLY;
  }
}

/* This function returns the number of repetitions for the board. */
int get_repetitions(struct board *board) {
  struct transposition_entry *entry;

  entry = &(transp_table[get_hashkey((unsigned long long int) board->zobrist_key,(long long int) TRANSP_NBR_ENTRIES)]);
  if (entry->lock == board->zobrist_key)
    return entry->repetitions;
  return 0;
}

/* The argument can't be a normal int64, because that could give us
   a negative hash key. So we have to use unsigned. */
int get_hashkey(unsigned long long int zobrist_key, long long int hash_size) {
  return (zobrist_key & (hash_size-1));
}

int probe_pawn_hash(struct board *board, struct pawn_entry *pawn_struct) {
  struct pawn_entry *entry;

  pawn_probes++;
  entry = &(pawn_table[get_hashkey((unsigned long long int) board->zobrist_pawn_key,(long long int) PAWN_HASH_SIZE)]);
  if (entry->lock == board->zobrist_pawn_key) {
    pawn_hits++;
    *pawn_struct = *entry;
    return 0;
  } else {
    pawn_misses++;
    return UNKNOWN;
  }
}

int probe_refutation(int depth, struct board *board, struct move *move,
		     int *alpha, int *beta, int *retval) {
  struct refutation_entry *entry;

  if (hash_probing) {
    entry = &(ref_table[get_hashkey((unsigned long long int) board->zobrist_key,(long long int) REFUTATION_NBR_ENTRIES)]);
    if (entry->lock == board->zobrist_key) {
      /* Only take the hash value if it's at the same depth, or deeper than
	 the current depth. */
      if (entry->depth >= ((char)depth)) {
	if (!(entry->status & MOVE_ONLY)) {
	    if (entry->status & EXACT)
	      return entry->value;
	    if (entry->status & ALPHA) {
	      if (entry->value <= (*alpha)) {
		return entry->value;
	      } else {
		*retval = entry->value;
		*beta = min(*beta,*retval);
	      }
	    }
	    if (entry->status & BETA) {
	      if (entry->value >= (*beta))
		return entry->value;
	      else {
		*retval = entry->value;
		*alpha = max(*alpha,*retval);
	      }
	    }
	}
      }
      if (entry->status == 0)
	return UNKNOWN;
      (*move).fsquare = square[(int) entry->bestmove_fsquare];
      (*move).tsquare = square[(int) entry->bestmove_tsquare];
      return HASH_MOVE;
    }
  }
  return UNKNOWN;
}

int probe_transposition(int depth, struct board *board, struct move *move,
			int *alpha, int *beta, int *retval) {
  struct transposition_entry *entry;

  if (hash_probing) {
    entry = &(transp_table[get_hashkey((unsigned long long int) board->zobrist_key,(long long int) TRANSP_NBR_ENTRIES)]);
    if (entry->lock == board->zobrist_key) {
      if (entry->repetitions > 1) {
	return draw_score();    //draw if same position is repeated 3 times
      }
      /* Don't take the hash value if the node is opened, because the
	 true value of a node is set when it's closed, so nothing is
	 known for an open node, other than that the position has
	 occurred before. */
      if (entry->repetitions == 0) {
	/* Only take the hash value if it's at the same depth, or deeper than
	   the current depth. */
	if (entry->depth >= ((char)depth)) {
	  if (!(entry->status & MOVE_ONLY)) {
	    if (entry->status & EXACT)
	      return entry->value;
	    if (entry->status & ALPHA) {
	      if (entry->value <= (*alpha)) {
		/* TODO: Find out if crafty returns alpha here (seemed like it). */
		return entry->value;
	      } else {
		*retval = min(*retval,entry->value);
		*beta = min(*beta,entry->value);
	      }
	    }
	    if (entry->status & BETA) {
	      if (entry->value >= (*beta)) {
		return entry->value;
	      } else {
		*retval = max(*retval,entry->value);
		*alpha = max(*alpha,entry->value);
	      }
	    }
	  }
	}
	(entry->repetitions)++;   //increase the number of repetitions
	if (entry->status & BEST_MOVE) {
	  (*move).fsquare = square[(int) entry->bestmove_fsquare];
	  (*move).tsquare = square[(int) entry->bestmove_tsquare];
	  return HASH_MOVE;
	}
      } else {
	(entry->repetitions)++;
      }
    } else if (entry->repetitions > 0) {
      /* Already open position, don't overwrite. Rather return a hash miss.
	 In this case repetitions aren't detected, but hopefully we don't
	 get here too often. */
      return UNKNOWN;
    } else {
      /* Hash miss, closed position. Now the position should be opened
	 (=detected as a repetition) */
      entry->lock = board->zobrist_key;
      entry->repetitions = 1;
    }
  }
  return UNKNOWN;
}

/*-----------------------------------------------------------------
 | This function returns the hashvalue if the position is in the  |
 | hashtable and is good enough to cause a cutoff if executed, or |
 | else UNKNOWN is returned.                                      |
 -----------------------------------------------------------------*/
int in_hashtable(int64 zobrist_key, int depth, int alpha, int beta) {
  struct transposition_entry *t_entry;
  struct refutation_entry *r_entry;

  if (hash_probing) {
    t_entry = &(transp_table[get_hashkey((unsigned long long int) zobrist_key,(long long int) TRANSP_NBR_ENTRIES)]);
    if (t_entry->lock == zobrist_key) {
      if (t_entry->repetitions > 1)
	return draw_score();    //draw if same position is repeated 3 times
      if (t_entry->repetitions == 0) {
	if (t_entry->depth >= ((char)depth)) {
	  if (!(t_entry->status & MOVE_ONLY)) {
	    if (t_entry->status & EXACT)
	      return t_entry->value;
	    if ((t_entry->status & ALPHA) && (t_entry->value <= alpha))
	      return t_entry->value;
	    if ((t_entry->status & BETA) && (t_entry->value >= beta))
	      return t_entry->value;
	  }
	}
      }
    }

    r_entry = &(ref_table[get_hashkey((unsigned long long int) zobrist_key,(long long int) REFUTATION_NBR_ENTRIES)]);
    if (r_entry->lock == zobrist_key) {
      if (r_entry->depth >= ((char)depth)) {
	if (!(r_entry->status & MOVE_ONLY)) {
	    if (r_entry->status & EXACT)
	      return r_entry->value;
	    if ((r_entry->status & ALPHA) && (r_entry->value <= alpha))
	      return r_entry->value;
	    if ((r_entry->status & BETA) && (r_entry->value >= beta))
	      return r_entry->value;
	}
      }
    }
  }
  return UNKNOWN;
}

void record_pawn_hash(struct board *board, struct pawn_entry *pawn_struct) {
  struct pawn_entry *entry;

  entry = &(pawn_table[get_hashkey((unsigned long long int) board->zobrist_pawn_key,(long long int) PAWN_HASH_SIZE)]);
  pawn_struct->lock = board->zobrist_pawn_key;
  *entry = *pawn_struct;
}

void record_refutation(int depth, struct board *board, struct move *move,
		       int flag) {
  struct refutation_entry *entry;

  /* Don't record the hashvalue if it's an aborted search. */
  if (hash_probing && !abort_search) {
    entry = &(ref_table[get_hashkey((unsigned long long int) board->zobrist_key,(long long int) REFUTATION_NBR_ENTRIES)]);
    /* Only replace if same depth or deeper, or if the element pertains to
       an ancient search or if status == 0 */
    if ((((char)depth) >= entry->depth) || (sequence > entry->sequence)
	|| (entry->status == 0)) {
      entry->lock = board->zobrist_key;
      entry->bestmove_fsquare = get_first_bitpos(move->fsquare);
      entry->bestmove_tsquare = get_first_bitpos(move->tsquare);
      entry->status = 0;
      entry->status |= (char) flag;
      /* If it's a mating score, then don't store the mating value in the
	 hash directly, since the exact value depends on which depth the
	 mate was found. Rather store a bound. */
      if (move->value <= (-INFTY + 150)) {
	if (flag & BETA) {
	  entry->status = 0;
	} else {
	  entry->value = -INFTY + 150;
	  entry->status |= ALPHA;
	  entry->status &= ~BETA;
	  entry->status &= ~EXACT;
	}
      } else if (move->value >= (INFTY - 150)) {
	if (flag & ALPHA) {
	  entry->status = 0;
	} else {
	  entry->value = INFTY - 150;
	  entry->status |= BETA;
	  entry->status &= ~ALPHA;
	  entry->status &= ~EXACT;
	}
      } else
	entry->value = move->value;
      entry->depth = (char) depth;
      entry->sequence = sequence;
    }
  }
}

char get_refutation_status(struct board *board) {
  struct refutation_entry *entry;

  if (hash_probing) {
    entry = &(ref_table[get_hashkey((unsigned long long int) board->zobrist_key,(long long int) REFUTATION_NBR_ENTRIES)]);
    if (entry->lock == board->zobrist_key)
      return entry->status;
    printf("STATUS NOT FOUND!\n");
    exit(1);
  }
  return 0;
}

char get_refutation_depth(struct board *board) {
  struct refutation_entry *entry;

  if (hash_probing) {
    entry = &(ref_table[get_hashkey((unsigned long long int) board->zobrist_key,(long long int) REFUTATION_NBR_ENTRIES)]);
    if (entry->lock == board->zobrist_key)
      return entry->depth;
    printf("DEPTH NOT FOUND!\n");
    exit(1);
  }
  return 0;
}

void close_transposition(int depth, struct board *board, struct move *move,
			 int is_best_move, int flag) {
  struct transposition_entry *entry;

  if (hash_probing) {
    entry = &(transp_table[get_hashkey((unsigned long long int) board->zobrist_key,(long long int) TRANSP_NBR_ENTRIES)]);
    /* Always replace. */
    if (entry->lock != board->zobrist_key) {
      return;
    }
    if (is_best_move) {
      entry->status = BEST_MOVE;
      entry->bestmove_fsquare = get_first_bitpos(move->fsquare);
      entry->bestmove_tsquare = get_first_bitpos(move->tsquare);
    } else
      entry->status = 0;
    entry->status |= (char) flag;
    if (flag == 0)
      entry->status = 0;
    /* If it's a mating score, then don't store the mating value in the
       hash directly, since the exact value depends on which depth the
       mate was found. Rather store a bound. */
    if (move->value <= (-INFTY + 150)) {
      if (flag & BETA) {
	entry->status = 0;
      } else {
	entry->value = -INFTY + 150;
	entry->status |= ALPHA;
	entry->status &= ~BETA;
	entry->status &= ~EXACT;
      }
    } else if (move->value >= (INFTY - 150)) {
      if (flag & ALPHA) {
	entry->status = 0;
      } else {
	entry->value = INFTY - 150;
	entry->status |= BETA;
	entry->status &= ~ALPHA;
	entry->status &= ~EXACT;
      }
    } else
      entry->value = move->value;
    entry->depth = (char) depth;
    (entry->repetitions)--;        //decrease the numer of repetitions
    /* If it's an aborted search, then make the entry unusable by setting
       the status to zero, because in this case we don't know what value
       the node should have. */
    if (abort_search)
      entry->status = 0;
  }
}

