#ifndef _ALFABETA_
#define _ALFABETA_

#include "misc.h"
#include "bitboards.h"

#define INFTY 1000000
#define KINGTAKEN 500000
#define MAXNODE 1
#define MINNODE 2

#undef max
int max(int a, int b);
#undef min
int min(int a, int b);

int quiescence(struct board *board, int alpha, int beta);

int alphabeta(struct board *board, int alpha, int beta, int depth, int null_ok);

#endif       //_ALFABETA_

