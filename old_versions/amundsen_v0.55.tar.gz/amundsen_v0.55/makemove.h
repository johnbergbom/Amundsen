#ifndef _MAKEMOVE_
#define _MAKEMOVE_

#include "misc.h"
#include "bitboards.h"

void make_nullmove(struct board *oldboard, struct board *newboard);

void makemove(struct board *oldboard, struct board *newboard,
	      struct move move, int depth);

#endif      //_MAKEMOVE_
