/*
 * Copyright (C) 2002 John Bergbom
 */

#include <stdio.h>
#include "misc.h"
#include "slump.h"
#include "bitboards.h"
#include "parse.h"
#include "hash.h"

int main(int argc, char **argv) {
  setbuf(stdin,NULL);      //set unbuffered input
  setbuf(stdout,NULL);     //set unbuffered output

  infolog("------------------------------");
  init_random_seed();
  set_bitboards();
  init_hashtables();
  printf("\nThis is Amundsen v. 0.55\n");
  printf("Copyright (C)2002-2003 John Bergbom\n");
  printf("\nType \'help\' for a list of commands.\n");
  parse();
  return 0;
}




