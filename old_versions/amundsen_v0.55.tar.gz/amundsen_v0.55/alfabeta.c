#include "alfabeta.h"
#include <stdio.h>
#include <stdlib.h>
#ifndef _MSC_VER
#include <sys/resource.h>
#endif
#include "makemove.h"
#include "genmoves.h"
#include "eval.h"
#include "hash.h"
#include "slump.h"
#include "parse.h"
#include "display.h"
#include "timectrl.h"
#include "swap.h"

extern int pieceval[6];
extern bitboard square[64];

int visited_nodes;       //total number (quiescence + normal search)
int quiescence_nodes;
int cutoffs = 0;             //counts the number of cutoffs
int cutoffs_first = 0;
int nullmoves_tried = 0;
int nullmove_cutoffs = 0;

/* Killers keep track of the moves that cause a cutoff at each level
   of the search. */
struct killers **killers;

/* The following variables are used for hash statistics. */
int probes = 0;
int sc_hits = 0;  //a score was returned
int m_hits = 0;   //a move was returned
int b_hits = 0;   //alpha/beta bounds were changed
int misses = 0;

/* We don't do the time checking too often, so we define a macro
   telling how many nodes should be searched before we check if
   there is time left. */
int abort_search;
int NODES_TO_SEARCH_BETWEEN_TIME_CHECKS = 1000;
int node_count_at_last_check = 0;

/* Declare the history moves table. */
int historymovestable[2][64][64];

int max(int a, int b) {
  if (a > b)
    return a;
  else
    return b;
}

int min(int a, int b) {
  if (a > b)
    return b;
  else
    return a;
}

int quiescence(struct board *board, int alpha, int beta) {
  struct board newpos;
  int retval;
  int q_val;
  struct move move; //doesn't need initialization
  int order = 0;
  struct swap_entry swap_list[16];
  int swap_list_count = 0;
  int own_king_check = 0;
  bitboard spec_moves;
  int stat_val;
  int opp_pieces[64];

  if (opp_in_check(board))
    return KINGTAKEN;

  visited_nodes++;
  quiescence_nodes++;

  /* We init retval to the static score of the position. Then the engine
     will take whatever is best of continuing the capture line, or to
     accept the static score of the position. */
  stat_val = retval = eval(board);
  if (retval >= beta)
    return retval;
  else
    alpha = max(alpha,retval);

  own_king_check = in_check(board);
  while (get_next_quiet_move(board,&move,swap_list,&order,
			     &swap_list_count,own_king_check,
			     &spec_moves,stat_val,alpha,opp_pieces)) {
    makemove(board,&newpos,move,0);
    q_val = -quiescence(&newpos,-beta,-alpha);
    if (q_val != -KINGTAKEN) {
      if (own_king_check) {
	/* If we find one legal king move, then don't bother to search
	   any more. */
	return max(retval,q_val);
      }
      retval = max(retval,q_val);
      if (retval >= beta)
	return retval;
      else
	alpha = max(alpha,retval);
    }
  }
  /* We get here when we have gone through all the capture moves, and
     when none of them were good enough to merit a cutoff. */
  if (own_king_check)
    return KINGTAKEN;
  else
    return retval;

}

int alphabeta(struct board *board, int alpha, int beta, int depth, int null_ok) {
  struct board newpos;
  int retval;
  struct moves moves[16];
  int movables = 0;
  struct move move; //doesn't need initialization
  struct move best_move; //doesn't need initialization
  int extension = 0;
  int ref_val, transp_val; //don't need initialization
  struct move refmove; //doesn't need initialization
  struct move transpmove; //doesn't need initialization
  int best = 0;
  int order = 0;
  int cutcount = 0;
  int org_alpha = alpha, org_beta = beta;
  struct swap_entry swap_list[16];
  struct hist_entry hist_list[NBR_HISTMOVES];
  int swap_count = 0;
  int opp_pieces[64];
  int killers_processed = 0;
  int R_adapt;
  bitboard spec_moves;
  int own_king_check = 0;

  best_move.value = retval = -INFTY;
  visited_nodes++;

  /*----------------------------------------
   | Check if there is time left to think. |
   ----------------------------------------*/
  if (abort_search)
    return 0;
  if (visited_nodes - node_count_at_last_check
      >= NODES_TO_SEARCH_BETWEEN_TIME_CHECKS) {
    node_count_at_last_check = visited_nodes;
    if (time_is_up(/*org_depth,*/1)) {
      abort_search = 1;
      return 0;
    }
  }

  /*-------------------------------------------------------------------
   | Probe refutation table and transposition table. First try the    |
   | transposition table since it handles the 3 position repetition,  |
   | so a value of zero is returned in case of excessive repetitions, |
   | rather than something that's in the refutation table.            |
   -------------------------------------------------------------------*/
  probes++;
  transp_val = probe_transposition((char)depth,board,&transpmove,
				   &alpha,&beta,&retval);
  if (transp_val != UNKNOWN && transp_val != HASH_MOVE) {
    sc_hits++;
    return transp_val;
  }
  ref_val = probe_refutation((char)depth,board,&refmove,
			     &alpha,&beta,&retval);
  if (ref_val != UNKNOWN && ref_val != HASH_MOVE) {
    sc_hits++;
    move.value = ref_val;
    close_transposition(get_refutation_depth(board),board,&move,0,
			get_refutation_status(board));
    return ref_val;
  }
  if (transp_val == HASH_MOVE || ref_val == HASH_MOVE)
    m_hits++;
  else if (org_alpha != alpha || org_beta != beta)
    b_hits++;
  else if (transp_val == UNKNOWN && ref_val == UNKNOWN)
    misses++;
  
  
  /*----------------------------
   | Detect illegal positions. |
   ----------------------------*/
  if (opp_in_check(board)) {
    move.value = KINGTAKEN;
    close_transposition((char)depth,board,&move,0,EXACT);
    return KINGTAKEN;
  }

  /*-------------------------------------
   | Check if draw by the 50 move rule. |
   -------------------------------------*/
  if (board->moves_left_to_draw <= 0) {
    move.value = draw_score();
    close_transposition((char)depth,board,&move,0,EXACT);
    return move.value;
  }

  /*-------------------------------------------------------------
   | Very simple internal node recognizer that recognizes draws |
   | due to insufficient material.                              |
   -------------------------------------------------------------*/
  /*if (board->material_pawns[WHITE] == 0 && board->material_pawns[BLACK] == 0
      && ((board->nbr_pieces[WHITE] == 0
	   && board->material_pieces[BLACK] < (VAL_KING + VAL_ROOK))
          || (board->nbr_pieces[BLACK] == 0
	      && board->material_pieces[WHITE] < (VAL_KING + VAL_ROOK)))) {
    move.value = draw_score();
    close_transposition((char)depth,board,&move,0,EXACT);
    return draw_score();
  }*/

  if (depth <= 0) {
    move.value = quiescence(board,alpha,beta);
    close_transposition((char)depth,board,&move,0,EXACT);
    return move.value;
  } else {
    /*---------------------------------------------------------------
     | Do null-move pruning if the king is not in check and if both |
     | players has at least one piece left (otherwise the risk of   |
     | zugzwang is to great).                                       |
     ---------------------------------------------------------------*/
    if (!in_check(board)) {
      if (null_ok && board->nbr_pieces[WHITE] && board->nbr_pieces[BLACK]) {
	make_nullmove(board,&newpos);

	/*---------------------------------------------------------------
	 | Adaptive nullmove search: Use R = 3 in the upper part of the |
	 | search tree except for in the late endgame, or else R = 2.   |
	 ---------------------------------------------------------------*/
	if (depth <= 6 || (depth <= 8 && (board->nbr_pieces[WHITE] < 3
					  || board->nbr_pieces[BLACK] < 3))) {
	  R_adapt = 2;
	} else {
	  R_adapt = 3;
	}
	move.value = -alphabeta(&newpos,-beta,1-beta,depth-1-R_adapt,
				/*org_depth,*/0);
	nullmoves_tried++;

	/*------------------------------------------------------------
	 | If not moving gets the side to move mated, then this is a |
	 | dangerous position, so then let's extend the search. Else |
	 | if the value is greater than beta then cutoff.            |
	 ------------------------------------------------------------*/
	if (move.value < (-INFTY + 200)) {
	  extension = 1;
	} else if (move.value >= beta) {
	  close_transposition((char)depth,board,&move,0,BETA);
	  nullmove_cutoffs++;
	  return move.value;
	}
      }
    } else {
      own_king_check = 1;
      extension = 1;
    }

    while (get_next_move(board,moves,&movables,&ref_val,&refmove,
			 &transp_val,&transpmove,killers[depth],
			 &move,&order,depth,swap_list,
			 &swap_count,opp_pieces,&killers_processed,
			 hist_list,own_king_check,&spec_moves,alpha,beta,
			 extension)) {
      cutcount++;
      makemove(board,&newpos,move,depth);

      if (depth-1+extension <= 0) {
	move.value = -quiescence(&newpos,-beta,-alpha);
      } else {
	move.value = -alphabeta(&newpos,-beta,-alpha,depth-1+extension,1);
      }
      if (move.value == -KINGTAKEN)
	move.value = KINGTAKEN;
	
      if (move.value != KINGTAKEN) {
	if (move.value > retval)
	  best_move = move;
	retval = max(retval,move.value);
	alpha = max(alpha,retval);
	if (retval >= beta) {
	  /* We got a cutoff here, so we'll add this move to the history
	     moves table. */
	  historymovestable[(int)Color][get_first_bitpos(move.fsquare)]
	    [get_first_bitpos(move.tsquare)] += (1 << depth);
	  cutoffs++;
	  if (cutcount == 1)
	    cutoffs_first++;
	  /* Add this move as a killer. Replace the best killer.
	     (Not the worst one, because then we don't get any rotation.) */
	  killers[depth][best].fsquare = move.fsquare;
	  killers[depth][best].tsquare = move.tsquare;
	  killers[depth][best].value = retval;
	  record_refutation((char) (depth+extension),board,&move,BETA);
	  close_transposition((char) (depth+extension),board,&move,1,BETA);
	  return retval;
	}
      }
    }

    /*---------------------------------------------------------------------
     | If we get here, and retval == -INFTY, it means all possible moves  |
     | from this position leads to a check position. If we are already in |
     | check, then it's mate. If we're not in check, then it's stalemate. |
     ---------------------------------------------------------------------*/
    if (retval == -INFTY) {
      if (in_check(board))
	best_move.value = retval + (100-depth); //quick mates are better
      else
	best_move.value = draw_score();         //stalemate
      close_transposition((char) (depth+extension),board,&best_move,
			  0,(retval <= org_alpha) ? ALPHA : EXACT);
    } else {
      if (best_move.value != -INFTY) {
	best_move.value = retval;
	close_transposition((char) (depth+extension),board,&best_move,
			    1,(retval <= org_alpha) ? ALPHA : EXACT);
      } else {
	best_move.value = retval;
	close_transposition((char) (depth+extension),board,&best_move,
			    0,(retval <= org_alpha) ? ALPHA : EXACT);
      }
    }
    return best_move.value;
  }
}

