#include "misc.h"
#include <stdio.h>
#include <stdlib.h>
#include "parse.h"
#include "genmoves.h"
#include "makemove.h"
#include "hash.h"
#include "config.h"

extern bitboard square[64];
extern struct attack attack;

void infolog(const char *text) {
  FILE *fp;
  const char *filename = INFOLOGFILE;

  fp = fopen(filename,"a");
  if (fp == NULL)
    fprintf(stderr,"Could not open %s\n",INFOLOGFILE);
  fprintf(fp,"%s\n",text);
  fclose(fp);
}

/* Prints without a newline at the end. */
void testsuitelog(const char *text) {
  FILE *fp;
  const char *filename = TESTSUITELOGFILE;

  fp = fopen(filename,"a");
  if (fp == NULL)
    fprintf(stderr,"Could not open %s\n",INFOLOGFILE);
  fprintf(fp,"%s",text);
  fclose(fp);
}

#ifdef AM_DEBUG
void debuglog(const char *text) {
  FILE *fp;
  const char *filename = DEBUGLOGFILE;

  fp = fopen(filename,"a");
  if (fp == NULL)
    fprintf(stderr,"Could not open %s\n",DEBUGLOGFILE);
  fprintf(fp,"%s\n",text);
  fclose(fp);
}
#endif

void resultlog(int status, int color, int white, int black) {
  FILE *fp;
  const char *filnamn = RESULTLOGFILE;
  char *str;
  
  str = (char *) malloc(100*sizeof(char));
  if (status == 2) {
    if ((color == WHITE && white == COMPUTER) || (color == BLACK && black == COMPUTER))
      sprintf(str,"%s lost.",PACKAGE_STRING);
    else if ((color == BLACK && white == COMPUTER) || (color == WHITE && black == COMPUTER))
      sprintf(str,"%s won.",PACKAGE_STRING);
  } else if (status == 1) {
    sprintf(str,"1/2-1/2 {Stalemate}");
  } else if (status == 3) {
    sprintf(str,"1/2-1/2 {50 move rule}");
  } else if (status == 4) {
    sprintf(str,"1/2-1/2 {Insufficient material}");
  } else {
    sprintf(str,"1/2-1/2 {Draw by repetition}\n");
  }

  fp = fopen(filnamn,"a");
  if (fp == NULL)
    fprintf(stderr,"Could not open %s\n",RESULTLOGFILE);
  fprintf(fp,"%s\n",str);
  fclose(fp);
  free(str);
}

int draw_score() {
  return 0;
}

/* This function reallocates the size of a list in the memory. */
int change_list_size(struct move **list, int new_size) {
  struct move *new_list;

  if((new_list = (struct move *) realloc(*list,(new_size + 1)*sizeof(struct move))) == NULL) {
    perror("Realloc failed");
    exit(1);
  } else
    *list = new_list;
  
  return new_size;
}

/* This function returns 1 if the move is legal, and 0 if it's illegal. */
int legal_move(struct move move_to_check, struct board *board) {
  struct moves moves[16];
  int movables, piece_nbr;
  bitboard target;
  struct move move;
  struct board newpos;

  /* Make a list of all the possible pseudo-moves in this position,
     and see if move_to_check is in the list. If it is, then make
     the move, and see if the move will get oneself into check.
     If one gets in check, then the move is illegal, otherwise it's legal. */

  /* This program only generates queen promotions, and no minor promotions.
     So if the opponent tries to make a minor promotion, there will be no
     match between move_to_check and any of the moves in the generated
     movelist. A way to solve that problem is to check if the opponent's
     move is a promotion. If it is, then we set move_to_check.type
     to QUEEN_PROMOTION_MOVE, and then we can have our match. */
  if (move_to_check.type & PROMOTION_MOVE) {
    move_to_check.type = move_to_check.type & (~PROMOTION_MOVE);
    move_to_check.type = move_to_check.type | QUEEN_PROMOTION_MOVE;
  }

  generate_moves(board,moves,&movables);

  piece_nbr = 0;
  while (piece_nbr < movables) {
    while (moves[piece_nbr].targets != 0) {
      target = getlsb(moves[piece_nbr].targets);
      move.fsquare = moves[piece_nbr].source;
      move.tsquare = target;
      move.piece = moves[piece_nbr].piece;
      move.type = get_movetype
	(board,get_first_bitpos(moves[piece_nbr].source),
	 moves[piece_nbr].piece,target);
      /* move.value is something we don't know about until after a search,
         so we don't compare the move.value */
      if ((move.fsquare == move_to_check.fsquare)
	  && (move.tsquare == move_to_check.tsquare)
	  && (move.piece == move_to_check.piece)
	  && (move.type == move_to_check.type)) {
	makemove(board,&newpos,move,0);
	newpos.color_at_move = Color;  //make sure we check the own color
	if (!in_check(&newpos)) {
	  return 1;     //Now we know that the move is legal.
	} else
	  return 0;     //illegal move
      }
      moves[piece_nbr].targets &= ~target;
    }
    piece_nbr++;
  }
  /* If we get here, it means that move_to_check was not in the movelist,
     and is therefore illegal. */
  return 0;
}

/* This function returns 0 if game is not ended, 1 if stalemate,
   2 if check mate, 3 if draw by the 50 move rule, 4 if
   insufficient material, and 5 if draw by repetition */
int game_ended(struct board *board) {
  struct moves moves[16];
  int movables, piece_nbr;
  bitboard target;
  struct move move;
  struct board newpos;

  /* If there is no pawns on the board, it could be insufficient material
     left to win the game. */
  if ((board->piece[WHITE][PAWN] == 0) && (board->piece[BLACK][PAWN] == 0)) {
    /* If there is no queens or rooks left on the board, it's possibly
       insufficient material left. */
    if ((board->piece[WHITE][QUEEN] == 0) && (board->piece[WHITE][ROOK] == 0)
	&& (board->piece[BLACK][QUEEN] == 0) && (board->piece[BLACK][ROOK] == 0)) {
      /* If neither player has at least 2 bishops, it could be a draw. */
      if ((bitcount(board->piece[WHITE][BISHOP]) < 2)
	  && (bitcount(board->piece[BLACK][BISHOP]) < 2)) {
	/* If neither player has at least a bishop and a knight, then
	   it's a draw. */
	if (((board->piece[WHITE][BISHOP] == 0)
	     || (board->piece[WHITE][KNIGHT] == 0))
	    && ((board->piece[BLACK][BISHOP] == 0)
		|| (board->piece[BLACK][KNIGHT] == 0))) {
	  return 4;
	}
      }
    }
  }


  /* Basically what we do in this function, is this:
     if (can make move which doesn't place him in check)
       return game is not over;
     else {
       if (in check now)
         return game is lost;
       else
         return stalemate;
     }
  */

  if (generate_moves(board,moves,&movables) != 0) {
    /* If we get here, it means that the last move by the opponent
       left him in check, which is illegal. */
    infolog("ERROR! ILLEGAL POSITION!");
    printf("ERROR! ILLEGAL POSITION!\n");
    exit(1);
  }

  /* Try to make all the moves, and see if the player is still in check. */
  piece_nbr = 0;
  while (piece_nbr < movables) {
    while (moves[piece_nbr].targets != 0) {
      target = getlsb(moves[piece_nbr].targets);
      move.fsquare = moves[piece_nbr].source;
      move.tsquare = target;
      move.piece = moves[piece_nbr].piece;
      move.type = get_movetype
	(board,get_first_bitpos(moves[piece_nbr].source),
	 moves[piece_nbr].piece,target);
      makemove(board,&newpos,move,0);
      newpos.color_at_move = Color;  //make sure we check the own color
      if (!in_check(&newpos)) {
	/* The player has a move that will not place him in check.
	   So the game is not over, unless the 50 move rule or
	   draw by repetition rule apply. */
	if (board->moves_left_to_draw <= 0)
	  return 3;
	else if (get_repetitions(board) > 2)
	  return 5;
	else
	  return 0;
      }
      moves[piece_nbr].targets = moves[piece_nbr].targets & ~target;
    }
    piece_nbr++;
  }
  /* Every move places him in check. The game is over. */
  if (in_check(board))
    return 2;     //the game is lost
  else
    return 1;     //stalemate
}

/* Prints out a move on the screen. */
void printmove(int color, struct move move) {
  char *dragstr;

  dragstr = (char *) malloc(20*sizeof(char));
  move2str(color,move,dragstr);
  printf("move %s\n",dragstr);
  free(dragstr);
}

/* Prints a bitboard nicely. */
void printbitboard(bitboard brd) {
  int i;

  for (i = 0; i < 64; i++) {
    if (brd & square[i])
      printf("1");
    else
      printf("0");
    if (i == 55 || i == 47 || i == 39 || i == 31 || i == 23 || i == 15 || i == 7)
      printf("\n");
  }
  printf("\n");
}
