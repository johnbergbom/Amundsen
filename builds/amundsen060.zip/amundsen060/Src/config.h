#define PACKAGE_STRING "Amundsen v0.60"
#define PACKAGE_NAME "Amundsen"
#define PACKAGE_VERSION "0.60"
