/*
 * Copyright (C) 2002 John Bergbom
 */

#include <stdio.h>
#include "misc.h"
#include "slump.h"
#include "bitboards.h"
#include "parse.h"
#include "hash.h"
//#include "egtbprobe.h" //nalimov
#ifndef _CONFIG_
#define _CONFIG_
#include "config.h"
#endif


int main(int argc, char **argv) {
  setbuf(stdin,NULL);      //set unbuffered input
  setbuf(stdout,NULL);     //set unbuffered output

  infolog("------------------------------");
  init_random_seed();
  set_bitboards();
  init_hashtables();
  printf("\nThis is %s v. %s\n",PACKAGE_NAME,PACKAGE_VERSION);
  printf("Copyright (C)2002-2003 John Bergbom\n");
  //init_nalimov_probing();
  printf("\nType \'help\' for a list of commands.\n");
  parse();
  //end_nalimov_probing();
  return 0;
}




