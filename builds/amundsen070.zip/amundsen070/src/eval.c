#include "eval.h"
#include "parse.h"
#include "bitboards.h"
#include "hash.h"
#include "alfabeta.h"
#include <stdlib.h>

/* If endgame == 0 there is no special endgame. Otherwise the number tells us
   what kind of endgame we are dealing with. See eval.h for endgame types. */
int endgame = 0;

/* Before the search the material values of the pieces and pawns are
   calculated. That way it's possible to see if any pieces or pawns have
   been traded. This is used to encourage piece exchanges when ahead, and
   pawn exchanges when behind. */
int presearch_pieceval[2];
int presearch_pawnval[2];

struct pawn_entry pawn_struct;

extern bitboard col_bitboard[8];
extern bitboard adj_cols_not_self[8];
extern int row_nbr[64];
extern int connected_bits[256];
extern struct defense defense;
extern bitboard possible_pawn_attack[2][64];
extern bitboard right_col[8];
extern bitboard left_col[8];
extern bitboard square[64];
extern int dist_to_corn[64];
extern bitboard pawn_start[2];
extern bitboard pawn_lastrow[2];
extern int dist_to_side[64];
extern bitboard white_squares;
extern bitboard black_squares;
extern bitboard abcd_col;
extern bitboard efgh_col;
extern bitboard abc_col;
extern bitboard fgh_col;
extern bitboard ab_col;
extern bitboard gh_col;
extern int dist_to_square[64][64];
extern struct attack attack;
extern int square2col[64];
extern int square2row[64];
extern bitboard d3d4d5d6;
extern bitboard e3e4e5e6;
extern bitboard pawn_duo[64];
extern bitboard passed_pawn[2][64];

static const int king_reach_early[64] = {
    5,   6,  -2,  -6,  -6,  -2,   6,   5,
   -8, -10, -14, -16, -16, -14, -10,  -8,
  -10, -15, -18, -20, -20, -18, -15, -10,
  -14, -20, -25, -30, -30, -25, -20, -14,
  -14, -20, -25, -30, -30, -25, -20, -14,
  -10, -15, -18, -20, -20, -18, -15, -10,
   -8, -10, -14, -16, -16, -14, -10,  -8,
    5,   6,  -2,  -6,  -6,  -2,   6,   5
};

static const unsigned king_reach_late[64] = {
  3, 5, 5, 5, 5, 5, 5, 3,
  5, 8, 8, 8, 8, 8, 8, 5,
  5, 8, 8, 8, 8, 8, 8, 5,
  5, 8, 8, 8, 8, 8, 8, 5,
  5, 8, 8, 8, 8, 8, 8, 5,
  5, 8, 8, 8, 8, 8, 8, 5,
  5, 8, 8, 8, 8, 8, 8, 5,
  3, 5, 5, 5, 5, 5, 5, 3
};

static const unsigned w_king_reach_endgame_normal[64] = {
  -40, -20, -20, -20, -20, -20, -20, -40,
  -20,  30,  40,  40,  40,  40,  30, -20,
  -20,  30,  60,  60,  60,  60,  30, -20,
  -20,  30,  60,  60,  60,  60,  30, -20,
  -20,  20,  40,  40,  40,  40,  20, -20,
  -20,  20,  20,  20,  20,  20,  20, -20,
  -20,   0,   0,   0,   0,   0,   0, -20,
  -40, -20, -20, -20, -20, -20, -20, -40
};

static const unsigned b_king_reach_endgame_normal[64] = {
  -40, -20, -20, -20, -20, -20, -20, -40,
  -20,   0,   0,   0,   0,   0,   0, -20,
  -20,  20,  20,  20,  20,  20,  20, -20,
  -20,  20,  40,  40,  40,  40,  20, -20,
  -20,  30,  60,  60,  60,  60,  30, -20,
  -20,  30,  60,  60,  60,  60,  30, -20,
  -20,  30,  40,  40,  40,  40,  30, -20,
  -40, -20, -20, -20, -20, -20, -20, -40
};


static const unsigned w_king_reach_endgame_qside[64] = {
  -20, -20, -20, -20, -20, -20, -40, -60,
   40,  40,  40,  40,  20, -20, -40, -60,
   40,  60,  60,  60,  20, -20, -40, -60,
   40,  60,  60,  60,  20, -20, -40, -60,
   40,  40,  40,  40,  20, -20, -40, -60,
   20,  20,  20,  20,  20, -20, -40, -60,
    0,   0,   0,   0,   0, -20, -40, -60,
  -20, -20, -20, -20, -20, -20, -40, -60
};

static const unsigned b_king_reach_endgame_qside[64] = {
  -20, -20, -20, -20, -20, -20, -40, -60,
    0,   0,   0,   0,   0, -20, -40, -60,
   20,  20,  20,  20,  20, -20, -40, -60,
   40,  40,  40,  40,  20, -20, -40, -60,
   40,  60,  60,  60,  20, -20, -40, -60,
   40,  60,  60,  60,  20, -20, -40, -60,
   40,  40,  40,  40,  20, -20, -40, -60,
  -20, -20, -20, -20, -20, -20, -40, -60
};

static const unsigned w_king_reach_endgame_kside[64] = {
  -60, -40, -20, -20, -20, -20, -20, -20,
  -60, -40, -20,  20,  40,  40,  40,  40,
  -60, -40, -20,  20,  60,  60,  60,  40,
  -60, -40, -20,  20,  60,  60,  60,  40,
  -60, -40, -20,  20,  40,  40,  40,  40,
  -60, -40, -20,  20,  20,  20,  20,  20,
  -60, -40, -20,   0,   0,   0,   0,   0,
  -60, -40, -20, -20, -20, -20, -20, -20
};

static const unsigned b_king_reach_endgame_kside[64] = {
  -60, -40, -20, -20, -20, -20, -20, -20,
  -60, -40, -20,   0,   0,   0,   0,   0,
  -60, -40, -20,  20,  20,  20,  20,  20,
  -60, -40, -20,  20,  40,  40,  40,  40,
  -60, -40, -20,  20,  60,  60,  60,  40,
  -60, -40, -20,  20,  60,  60,  60,  40,
  -60, -40, -20,  20,  40,  40,  40,  40,
  -60, -40, -20, -20, -20, -20, -20, -20
};

static const unsigned queen_posval[64] = {
  -20, -20,   0,   0,   0,   0, -20, -20,
  -20,   0,   8,   8,   8,   8,   0, -20,
    0,   8,   8,  12,  12,   8,   8,   0,
    0,   8,  12,  16,  16,  12,   8,   0,
    0,   8,  12,  16,  16,  12,   8,   0,
    0,   8,   8,  12,  12,   8,   8,   0,
  -20,   0,   8,   8,   8,   8,   0, -20,
  -20, -20,   0,   0,   0,   0, -20, -20
};

static const unsigned rook_posval[64] = {
  -10, -6, -2, 2, 2, -2, -6, -10,
  -10, -6, -2, 2, 2, -2, -6, -10,
  -10, -6, -2, 2, 2, -2, -6, -10,
  -10, -6, -2, 2, 2, -2, -6, -10,
  -10, -6, -2, 2, 2, -2, -6, -10,
  -10, -6, -2, 2, 2, -2, -6, -10,
  -10, -6, -2, 2, 2, -2, -6, -10,
  -10, -6, -2, 2, 2, -2, -6, -10
};

static const unsigned bishop_posval[64] = {
  -20, -20, -20, -20, -20, -20, -20, -20,
  -20,   6,   6,   3,   3,   6,   6, -20,
  -20,   6,   8,   6,   6,   8,   6, -20,
  -20,   3,   6,  10,  10,   6,   3, -20,
  -20,   3,   6,  10,  10,   6,   3, -20,
  -20,   6,   8,   6,   6,   8,   6, -20,
  -20,   6,   6,   3,   3,   6,   6, -20,
  -20, -20, -20, -20, -20, -20, -20, -20
};

static const unsigned knight_posval[64] = {
  -60, -30, -30, -30, -30, -30, -30, -60,
  -30, -24, -10, -10, -10, -10, -24, -30,
  -30,  -6,  -6,  -6,  -6,  -6,  -6, -30,
  -30,  -6,  -2,   0,   0,  -2,  -6, -30,
  -30,  -6,  -2,   0,   0,  -2,  -6, -30,
  -30,  -6,  -6,  -6,  -6,  -6,  -6, -30,
  -30, -24, -10, -10, -10, -10, -24, -30,
  -60, -30, -30, -30, -30, -30, -30, -60
};

static const unsigned white_outpost[64] = {
  0, 0,  0,  0,  0,  0, 0, 0,
  0, 0,  0,  0,  0,  0, 0, 0,
  0, 0, 10, 24, 24, 10, 0, 0,
  0, 5, 10, 24, 24, 10, 5, 0,
  0, 5, 10, 20, 20, 10, 5, 0,
  0, 0,  0,  0,  0,  0, 0, 0,
  0, 0,  0,  0,  0,  0, 0, 0,
  0, 0,  0,  0,  0,  0, 0, 0
};

static const unsigned black_outpost[64] = {
  0, 0,  0,  0,  0,  0, 0, 0,
  0, 0,  0,  0,  0,  0, 0, 0,
  0, 0,  0,  0,  0,  0, 0, 0,
  0, 5, 10, 20, 20, 10, 5, 0,
  0, 5, 10, 24, 24, 10, 5, 0,
  0, 0, 10, 24, 24, 10, 0, 0,
  0, 0,  0,  0,  0,  0, 0, 0,
  0, 0,  0,  0,  0,  0, 0, 0
};

static const unsigned pawn_posval[2][64] = {
  {  0,  0,   0,   0,   0,  0,  0,  0,
    40, 40,  40,  40,  40, 40, 40, 40,
    10, 10,  10,  30,  30, 10, 10, 10,
     6,  6,   6,  16,  16,  6,  6,  6,
     3,  3,   3,  13,  13,  3,  3,  3,
     1,  1,   1,  10,  10,  1,  1,  1,
     0,  0,   0, -10, -10,  0,  0,  0,
     0,  0,   0,   0,   0,  0,  0,  0 },
  {  0,  0,   0,   0,   0,  0,  0,  0,
     0,  0,   0, -10, -10,  0,  0,  0,
     1,  1,   1,  10,  10,  1,  1,  1,
     3,  3,   3,  13,  13,  3,  3,  3,
     6,  6,   6,  16,  16,  6,  6,  6,
    10, 10,  10,  30,  30, 10, 10, 10,
    40, 40,  40,  40,  40, 40, 40, 40,
     0,  0,   0,   0,   0,  0,  0,  0 }
};

int isolated_pawn_val[8] = { 8, 20, 40, 60, 70, 80, 80, 80 };
int isolated_pawn_val2[8] = { 4, 10, 16, 24, 24, 24, 24, 24 };
int passed_pawn_val[2][8] = {
  { 0, 150, 120, 72, 48, 20, 12, 0 },
  { 0, 12, 20, 48, 72, 120, 150, 0 }
};
int connected_passed_pawn_val[2][8] = {
  { 0, 200, 100, 40, 20, 10, 0, 0 },
  { 0, 0, 10, 20, 40, 100, 200, 0 }
};
int hidden_passed_pawn_val[2][8] = {
  { 0, 0, 40, 20, 0, 0, 0, 0 },
  { 0, 0, 0, 0, 20, 40, 0, 0 }
};
int blocking_passed_pawn_val[2][8] = {
  { 0, 75, 60, 36, 24, 10, 6, 0 },
  { 0, 6, 10, 24, 36, 60, 75, 0 }
};

/* The first dimension tells the number of open files,
   and the second dimension tells the file in question.
   The value tells the reward. Eg. rook_open_file[2][3] = 26
   tells that if there are 2 open files and the rook is on
   the D file, then the reward is 26. Note that the more
   central the file is the higher the reward, and the fewer
   open files there are the more important it is to control
   one (=higher reward). */
static const unsigned rook_open_file[9][8] = {
  {  0,  0,  0,  0,  0,  0,  0,  0 },
  { 20, 27, 35, 40, 40, 35, 27, 20 },
  { 13, 18, 23, 26, 26, 23, 18, 13 },
  { 10, 13, 17, 20, 20, 17, 13, 10 },
  { 10, 13, 17, 20, 20, 17, 13, 10 },
  { 10, 13, 17, 20, 20, 17, 13, 10 },
  { 10, 13, 17, 20, 20, 17, 13, 10 },
  { 10, 13, 17, 20, 20, 17, 13, 10 },
  { 10, 13, 17, 20, 20, 17, 13, 10 }
};

void eval_pawns(struct board *board, int *wval, int *bval) {
  int i;
  unsigned char connected[2] = { 0, 0 };
  bitboard pawn_col, pieces, temp_bitboard;
  int counter;
  bitboard advanced_white_d_pawns, advanced_white_e_pawns;
  bitboard advanced_black_d_pawns, advanced_black_e_pawns;
  int sq, temp;
  int isolated_pawns_white, isolated_pawns_black;
  int isolated_pawns_white2, isolated_pawns_black2;
  int attackers, defenders, backing_attackers, backing_defenders, weakness;

 if (probe_pawn_hash(board,&pawn_struct) == UNKNOWN) {
    pawn_struct.white_value = pawn_struct.black_value = 0;
    pawn_struct.passed_pawn[0] = pawn_struct.passed_pawn[1]
      = pawn_struct.weak_pawn[0] = pawn_struct.weak_pawn[1]
      = pawn_struct.pawn_hole[0] = pawn_struct.pawn_hole[1]
      = pawn_struct.half_open_file[0] = pawn_struct.half_open_file[1]
      = pawn_struct.open_file = pawn_struct.center
      = isolated_pawns_white = isolated_pawns_black
      = isolated_pawns_white2 = isolated_pawns_black2 = 0;
    
    
    /*---------------------------------------------------------
     | Determine how blocked the center is.                   |
     | 0.) Blocked                                            |
     | 1.) Half-open: One of the front pawns on the D or E    |
     | file has no opposing pawn in front of itself, or the   |
     | front pawns on the D and E files are on the same rank, |
     | or one player has no advanced pawns.                   |
     | 2.) Open: at most one pawn on the D/E files.           |
     ---------------------------------------------------------*/
    if (bitcount((col_bitboard[3] | col_bitboard[4]) &
		 (board->piece[WHITE][PAWN] | board->piece[BLACK][PAWN])) <= 1)
      pawn_struct.center = 2;
    else {
      advanced_white_d_pawns = board->piece[WHITE][PAWN] & d3d4d5d6;
      advanced_white_e_pawns = board->piece[WHITE][PAWN] & e3e4e5e6;
      advanced_black_d_pawns = board->piece[BLACK][PAWN] & d3d4d5d6;
      advanced_black_e_pawns = board->piece[BLACK][PAWN] & e3e4e5e6;
      if (!(((d3d4d5d6 & board->piece[WHITE][PAWN]) >> 8)
	    & board->piece[BLACK][PAWN]) ||
	  !(((e3e4e5e6 & board->piece[WHITE][PAWN]) >> 8)
	    & board->piece[BLACK][PAWN]) ||
	  (advanced_white_d_pawns == 0 && advanced_white_e_pawns == 0) ||
	  (advanced_black_d_pawns == 0 && advanced_black_e_pawns == 0) ||
	  (advanced_white_d_pawns != 0 && advanced_white_e_pawns != 0
	   && square2row[get_first_bitpos(advanced_white_d_pawns)]
	   == square2row[get_first_bitpos(advanced_white_e_pawns)]) ||
	  (advanced_black_d_pawns != 0 && advanced_black_e_pawns != 0
	   && square2row[get_first_bitpos(advanced_black_d_pawns)]
	   == square2row[get_first_bitpos(advanced_black_e_pawns)]))
	pawn_struct.center = 1;
    }

    /*--------------------------------------------------------------------
     | Check for unmoved center pawns that are blocked by an enemy pawn. |
     --------------------------------------------------------------------*/
    if (((board->piece[WHITE][PAWN] & pawn_start[WHITE]) >> 8)
	& board->piece[BLACK][PAWN] & (col_bitboard[3] | col_bitboard[4]))
      pawn_struct.white_value -= 12;
    if (((board->piece[BLACK][PAWN] & pawn_start[BLACK]) << 8)
	& board->piece[WHITE][PAWN] & (col_bitboard[3] | col_bitboard[4]))
      pawn_struct.black_value -= 12;


    /*-----------------------------------------
     | Go through the white pawns one by one. |
     -----------------------------------------*/
    pieces = board->piece[WHITE][PAWN];
    while (pieces != 0) {
      sq = get_first_bitpos(pieces);

      /* Check pawn's placement. */
      pawn_struct.white_value += pawn_posval[WHITE][sq];

      /*-------------------------------------------------------------------
       | Is pawn isolated? If isolated, then don't do weak pawn analysis. |
       -------------------------------------------------------------------*/
      if (!(adj_cols_not_self[square2col[sq]] & board->piece[WHITE][PAWN])) {
	isolated_pawns_white++;
	/* Doubled isolated pawn? */
	if ((temp = bitcount(col_bitboard[square2col[sq]]
			     & board->piece[WHITE][PAWN])) > 1) {
	  if (temp == 2)
	    pawn_struct.white_value -= -10;
	  else
	    pawn_struct.white_value -= -15;
	}
	/* No opponent pawn right in front? */
	if (!((square[sq] >> 8) & board->piece[BLACK][PAWN]))
	  isolated_pawns_white2++;
      } else {
	/*------------------------------------------------------------------
	 | Do weak pawn analysis. If the pawn has an enemy pawn in front   |
	 | of it, or if it has more pawn defenders than pawn attackers,    |
	 | then it's considered strong. If it can get more pawn defenders  |
	 | than pawn attackers either by advancing itself or by advancing  |
	 | some other pawn, then it's considered strong. If the best thing |
	 | that can be achieved is an equal amount of pawn defenders and   |
	 | pawn attackers, then the pawn is possibly weak. In all other    |
	 | cases the pawn is considered weak.                              |
	 ------------------------------------------------------------------*/
	do {
	  weakness = STRONG_PAWN;
	  /* If an opposite colored pawn is in front of the pawn, then
	     the pawn is not weak. */
	  if (get_ray(sq,-8) & board->piece[BLACK][PAWN])
	    break;
	  defenders = bitcount(attack.pawn[BLACK][sq]
			       & board->piece[WHITE][PAWN]);
	  attackers = bitcount(attack.pawn[WHITE][sq]
			       & board->piece[BLACK][PAWN]);
	  if (defenders > attackers)
	    break;
	  else if (defenders == 0 && attackers == 0) {
	    weakness = LITTLE_WEAK_PAWN;
	    break;
	  } else if (defenders == attackers)
	    weakness = POSSIBLY_WEAK_PAWN;
	  else {
	    weakness = WEAK_PAWN;
	    //break;
	  }
	  /* If the pawn can advance forward and the pawn is defended
	     by more pawns than the number of pawns attacking (at the
	     new square), then the pawn is strong. */
	  backing_defenders = bitcount(attack.pawn[BLACK][sq-8]
				       & board->piece[WHITE][PAWN]);
	  backing_attackers = bitcount(attack.pawn[WHITE][sq-8]
				       & board->piece[BLACK][PAWN]);
	  if (backing_defenders >= backing_attackers) {
	    if (weakness == WEAK_PAWN) {
	      weakness = LITTLE_WEAK_PAWN; //weak but can get strong
	      break;
	    } else if (weakness == POSSIBLY_WEAK_PAWN) {
	      weakness = STRONG_PAWN;
	      break;
	    }
	  }
	  if (square2row[sq] == 6
	      && !((board->all_pieces[WHITE] | board->all_pieces[BLACK])
		   & square[sq-16])) {
	    backing_defenders = bitcount(attack.pawn[BLACK][sq-16]
					 & board->piece[WHITE][PAWN]);
	    backing_attackers = bitcount(attack.pawn[WHITE][sq-16]
					 & board->piece[BLACK][PAWN]);
	    if (backing_defenders >= backing_attackers) {
	      if (weakness == WEAK_PAWN) {
		weakness = LITTLE_WEAK_PAWN; //weak but can get strong
		break;
	      } else if (weakness == POSSIBLY_WEAK_PAWN) {
		weakness = STRONG_PAWN;
		break;
	      }
	    }
	  }

	  /* If another pawn can be advanced in order to defend the
	     pawn, then it's a strong pawn. */
	  if (square2col[sq] > 0) {
	    temp_bitboard = col_bitboard[square2col[sq]-1] & board->piece[WHITE][PAWN];
	    if ((square2row[sq] <= 4)
		&& !((board->all_pieces[WHITE] | board->all_pieces[BLACK])
		     & square[sq+7])
		&& (temp_bitboard & square[sq+15])) {
	      backing_defenders = bitcount(attack.pawn[BLACK][sq+7]
					   & board->piece[WHITE][PAWN]);
	      backing_attackers = bitcount(attack.pawn[WHITE][sq+7]
					   & board->piece[BLACK][PAWN]);
	      if (backing_defenders >= backing_attackers) {
		if (backing_defenders + defenders + 1 >
		    backing_attackers + attackers) {
		  if (weakness == WEAK_PAWN) {
		    weakness = LITTLE_WEAK_PAWN; //weak but can get strong
		    break;
		  } else if (weakness == POSSIBLY_WEAK_PAWN) {
		    weakness = STRONG_PAWN;
		    break;
		  }
		}
	      }
	    }
	    if ((square2row[sq] == 3)
		&& !((board->all_pieces[WHITE] | board->all_pieces[BLACK])
		     & (square[sq+7] | square[sq+15]))
		&& (temp_bitboard & square[sq+23])) {
	      backing_defenders = bitcount(attack.pawn[BLACK][sq+7]
					   & board->piece[WHITE][PAWN]);
	      backing_attackers = bitcount(attack.pawn[WHITE][sq+7]
					   & board->piece[BLACK][PAWN]);
	      if (backing_defenders >= backing_attackers) {
		if (backing_defenders + defenders + 1 >
		    backing_attackers + attackers) {
		  if (weakness == WEAK_PAWN) {
		    weakness = LITTLE_WEAK_PAWN; //weak but can get strong
		    break;
		  } else if (weakness == POSSIBLY_WEAK_PAWN) {
		    weakness = STRONG_PAWN;
		    break;
		  }
		}
	      }
	    }
	  }
	  if (square2col[sq] < 7) {
	    temp_bitboard = col_bitboard[square2col[sq]+1] & board->piece[WHITE][PAWN];
	    if ((square2row[sq] <= 4)
		&& !((board->all_pieces[WHITE] | board->all_pieces[BLACK])
		     & square[sq+9])
		&& (temp_bitboard & square[sq+17])) {
	      backing_defenders = bitcount(attack.pawn[BLACK][sq+9]
					   & board->piece[WHITE][PAWN]);
	      backing_attackers = bitcount(attack.pawn[WHITE][sq+9]
					   & board->piece[BLACK][PAWN]);
	      if (backing_defenders >= backing_attackers) {
		if (backing_defenders + defenders + 1 >
		    backing_attackers + attackers) {
		  if (weakness == WEAK_PAWN) {
		    weakness = LITTLE_WEAK_PAWN; //weak but can get strong
		    break;
		  } else if (weakness == POSSIBLY_WEAK_PAWN) {
		    weakness = STRONG_PAWN;
		    break;
		  }
		}
	      }
	    }
	    if ((square2row[sq] == 3)
		&& !((board->all_pieces[WHITE] | board->all_pieces[BLACK])
		     & (square[sq+9] | square[sq+17]))
		&& (temp_bitboard & square[sq+25])) {
	      backing_defenders = bitcount(attack.pawn[BLACK][sq+9]
					   & board->piece[WHITE][PAWN]);
	      backing_attackers = bitcount(attack.pawn[WHITE][sq+9]
					   & board->piece[BLACK][PAWN]);
	      if (backing_defenders >= backing_attackers) {
		if (backing_defenders + defenders + 1 >
		    backing_attackers + attackers) {
		  if (weakness == WEAK_PAWN) {
		    weakness = LITTLE_WEAK_PAWN; //weak but can get strong
		    break;
		  } else if (weakness == POSSIBLY_WEAK_PAWN) {
		    weakness = STRONG_PAWN;
		    break;
		  }
		}
	      }
	    }
	  }
	} while (0);

	/*-------------------------------------------------------------------
	 | Assign a penalty for weak pawns. Assign a greater penalty if the |
	 |  pawn is on a half open file.                                    |
	 -------------------------------------------------------------------*/
	if (weakness != STRONG_PAWN) {
	  if (weakness == LITTLE_WEAK_PAWN || weakness == POSSIBLY_WEAK_PAWN) {
	      if (!(col_bitboard[square2col[sq]] & board->piece[BLACK][PAWN]))
		pawn_struct.white_value -= 6;
	      else
		pawn_struct.white_value -= 3;
	  } else { //WEAK_PAWN
	    if (!(col_bitboard[square2col[sq]] & board->piece[BLACK][PAWN]))
	      pawn_struct.white_value -= 20;
	    else
	      pawn_struct.white_value -= 12;
	    pawn_struct.weak_pawn[WHITE] |= col_bitboard[square2col[sq]];
	    pawn_struct.pawn_hole[WHITE] |= square[sq-8];
	  }
	}

	/* Check for doubled pawns. */
	temp = bitcount(col_bitboard[square2col[sq]]
			& board->piece[WHITE][PAWN]);
	if (temp > 1) {
	  if (temp == 2)
	    pawn_struct.white_value -= 4;
	  else if (temp == 3)
	    pawn_struct.white_value -= 7;
	  else
	    pawn_struct.white_value -= 10;
	}

	/* Check for two pawns side by side. */
	if (pawn_duo[sq] & board->piece[WHITE][PAWN])
	  pawn_struct.white_value += 2;

      }

      /*-----------------------------------------------------------
       | A passed pawn is given an added constant value + a bonus |
       | related to the number of rows it has advanced.           |
       -----------------------------------------------------------*/
      if (!(passed_pawn[WHITE][sq] & board->piece[BLACK][PAWN])) {
	if (get_last_bitpos(col_bitboard[square2col[sq]]
			    & board->piece[WHITE][PAWN]) == sq)
	  pawn_struct.white_value += passed_pawn_val[WHITE][square2row[sq]];
	pawn_struct.passed_pawn[WHITE] |= col_bitboard[square2col[sq]];
	connected[WHITE] |= (1<<(square2col[sq]));

	/* A passed pawn that's blocked by an enemy piece is less valuable. */
	if ((board->all_pieces[BLACK] & ~(board->piece[BLACK][PAWN]))
	    & square[sq-8]) {
	  pawn_struct.white_value -=
	    blocking_passed_pawn_val[WHITE][square2row[sq]];
	}
      } else {
	/*-----------------------------------------------------------------
	 | Ok, so now we know that the pawn isn't a passed pawn, so check |
	 | if it's a "hidden" passed pawn (a pawn that can easily turn    |
	 | in to a passed pawn).                                          |
	 -----------------------------------------------------------------*/
	if (!(passed_pawn[WHITE][sq-8] & board->piece[BLACK][PAWN])
	    && (square2row[sq] < 3)
	    && (square[sq-8] & board->piece[BLACK][PAWN])
	    && (((square2col[sq] < 7)
		 && (square[sq+7] & board->piece[WHITE][PAWN])
		 && !(get_ray(sq+7,-8) & board->piece[BLACK][PAWN])
		 && (square2col[sq] == 6
		     || !(get_ray(sq+6,-8) & board->piece[BLACK][PAWN])))
		|| ((square2col[sq] > 0)
		    && (square[sq+9] & board->piece[WHITE][PAWN])
		    && !(get_ray(sq+9,-8) & board->piece[BLACK][PAWN])
		    && (square2col[sq] == 1
			|| !(get_ray(sq+10,-8) & board->piece[BLACK][PAWN]))))) {
	  pawn_struct.white_value += hidden_passed_pawn_val[WHITE][square2row[sq]];
	}
      }

      pieces &= ~(square[sq]);
    }

    /*-----------------------------------------
     | Go through the black pawns one by one. |
     -----------------------------------------*/
    pieces = board->piece[BLACK][PAWN];
    while (pieces != 0) {
      sq = get_first_bitpos(pieces);

      /* Check pawn's placement. */
      pawn_struct.black_value += pawn_posval[BLACK][sq];

      /*-------------------------------------------------------------------
       | Is pawn isolated? If isolated, then don't do weak pawn analysis. |
       -------------------------------------------------------------------*/
      if (!(adj_cols_not_self[square2col[sq]] & board->piece[BLACK][PAWN])) {
	isolated_pawns_black++;
	/* Doubled isolated pawn? */
	if ((temp = bitcount(col_bitboard[square2col[sq]]
			     & board->piece[BLACK][PAWN])) > 1) {
	  if (temp == 2)
	    pawn_struct.black_value -= -10;
	  else
	    pawn_struct.black_value -= -15;
	}
	/* No opponent pawn right in front? TODO: Crafty har h�r snarare koll
	   av ifall det finns n�gon motst�ndarbonde framf�r p� samma kolumn
	   (dvs. get_ray() snarare �n square[]. */
	if (!((square[sq] >> 8) & board->piece[WHITE][PAWN]))
	  isolated_pawns_black2++;
      } else {
	/*------------------------------------------------------------------
	 | Do weak pawn analysis. If the pawn has an enemy pawn in front   |
	 | of it, or if it has more pawn defenders than pawn attackers,    |
	 | then it's considered strong. If it can get more pawn defenders  |
	 | than pawn attackers either by advancing itself or by advancing  |
	 | some other pawn, then it's considered strong. If the best thing |
	 | that can be achieved is an equal amount of pawn defenders and   |
	 | pawn attackers, then the pawn is possibly weak. In all other    |
	 | cases the pawn is considered weak.                              |
	 ------------------------------------------------------------------*/
	do {
	  weakness = STRONG_PAWN;
	  /* If an opposite colored pawn is in front of the pawn, then
	     the pawn is not weak. */
	  if (get_ray(sq,8) & board->piece[WHITE][PAWN])
	    break;
	  defenders = bitcount(attack.pawn[WHITE][sq]
			       & board->piece[BLACK][PAWN]);
	  attackers = bitcount(attack.pawn[BLACK][sq]
			       & board->piece[WHITE][PAWN]);
	  if (defenders > attackers)
	    break;
	  else if (defenders == 0 && attackers == 0) {
	    weakness = LITTLE_WEAK_PAWN;
	    break;
	  } else if (defenders == attackers)
	    weakness = POSSIBLY_WEAK_PAWN;
	  else {
	    weakness = WEAK_PAWN;
	    //break;
	  }
	  /* If the pawn can advance forward and the pawn is defended
	     by more pawns than the number of pawns attacking (at the
	     new square), then the pawn is strong. */
	  backing_defenders = bitcount(attack.pawn[WHITE][sq+8]
				       & board->piece[BLACK][PAWN]);
	  backing_attackers = bitcount(attack.pawn[BLACK][sq+8]
				       & board->piece[WHITE][PAWN]);
	  if (backing_defenders >= backing_attackers) {
	    if (weakness == WEAK_PAWN) {
	      weakness = LITTLE_WEAK_PAWN; //weak but can get strong
	      break;
	    } else if (weakness == POSSIBLY_WEAK_PAWN) {
	      weakness = STRONG_PAWN;
	      break;
	    }
	  }
	  if (square2row[sq] == 1
	      && !((board->all_pieces[WHITE] | board->all_pieces[BLACK])
		   & square[sq+16])) {
	    backing_defenders = bitcount(attack.pawn[WHITE][sq+16]
					 & board->piece[BLACK][PAWN]);
	    backing_attackers = bitcount(attack.pawn[BLACK][sq+16]
					 & board->piece[WHITE][PAWN]);
	    if (backing_defenders >= backing_attackers) {
	      if (weakness == WEAK_PAWN) {
		weakness = LITTLE_WEAK_PAWN; //weak but can get strong
		break;
	      } else if (weakness == POSSIBLY_WEAK_PAWN) {
		weakness = STRONG_PAWN;
		break;
	      }
	    }
	  }

	  /* If another pawn can be advanced in order to defend the
	     pawn, then it's a strong pawn. */
	  if (square2col[sq] > 0) {
	    temp_bitboard = col_bitboard[square2col[sq]-1] & board->piece[BLACK][PAWN];
	    if ((square2row[sq] >= 3)
		&& !((board->all_pieces[WHITE] | board->all_pieces[BLACK])
		     & square[sq-9])
		&& (temp_bitboard & square[sq-17])) {
	      backing_defenders = bitcount(attack.pawn[WHITE][sq-9]
					   & board->piece[BLACK][PAWN]);
	      backing_attackers = bitcount(attack.pawn[BLACK][sq-9]
					   & board->piece[WHITE][PAWN]);
	      if (backing_defenders >= backing_attackers) {
		if (backing_defenders + defenders + 1 >
		    backing_attackers + attackers) {
		  if (weakness == WEAK_PAWN) {
		    weakness = LITTLE_WEAK_PAWN; //weak but can get strong
		    break;
		  } else if (weakness == POSSIBLY_WEAK_PAWN) {
		    weakness = STRONG_PAWN;
		    break;
		  }
		}
	      }
	    }
	    if ((square2row[sq] == 4)
		&& !((board->all_pieces[WHITE] | board->all_pieces[BLACK])
		     & (square[sq-9] | square[sq-17]))
		&& (temp_bitboard & square[sq-25])) {
	      backing_defenders = bitcount(attack.pawn[WHITE][sq-9]
					   & board->piece[BLACK][PAWN]);
	      backing_attackers = bitcount(attack.pawn[BLACK][sq-9]
					   & board->piece[WHITE][PAWN]);
	      if (backing_defenders >= backing_attackers) {
		if (backing_defenders + defenders + 1 >
		    backing_attackers + attackers) {
		  if (weakness == WEAK_PAWN) {
		    weakness = LITTLE_WEAK_PAWN; //weak but can get strong
		    break;
		  } else if (weakness == POSSIBLY_WEAK_PAWN) {
		    weakness = STRONG_PAWN;
		    break;
		  }
		}
	      }
	    }
	  }
	  if (square2col[sq] < 7) {
	    temp_bitboard = col_bitboard[square2col[sq]+1] & board->piece[BLACK][PAWN];
	    if ((square2row[sq] >= 3)
		&& !((board->all_pieces[WHITE] | board->all_pieces[BLACK])
		     & square[sq-7])
		&& (temp_bitboard & square[sq-15])) {
	      backing_defenders = bitcount(attack.pawn[WHITE][sq-7]
					   & board->piece[BLACK][PAWN]);
	      backing_attackers = bitcount(attack.pawn[BLACK][sq-7]
					   & board->piece[WHITE][PAWN]);
	      if (backing_defenders >= backing_attackers) {
		if (backing_defenders + defenders + 1 >
		    backing_attackers + attackers) {
		  if (weakness == WEAK_PAWN) {
		    weakness = LITTLE_WEAK_PAWN; //weak but can get strong
		    break;
		  } else if (weakness == POSSIBLY_WEAK_PAWN) {
		    weakness = STRONG_PAWN;
		    break;
		  }
		}
	      }
	    }
	    if ((square2row[sq] == 4)
		&& !((board->all_pieces[WHITE] | board->all_pieces[BLACK])
		     & (square[sq-7] | square[sq-15]))
		&& (temp_bitboard & square[sq-23])) {
	      backing_defenders = bitcount(attack.pawn[WHITE][sq-7]
					   & board->piece[BLACK][PAWN]);
	      backing_attackers = bitcount(attack.pawn[BLACK][sq-7]
					   & board->piece[WHITE][PAWN]);
	      if (backing_defenders >= backing_attackers) {
		if (backing_defenders + defenders + 1 >
		    backing_attackers + attackers) {
		  if (weakness == WEAK_PAWN) {
		    weakness = LITTLE_WEAK_PAWN; //weak but can get strong
		    break;
		  } else if (weakness == POSSIBLY_WEAK_PAWN) {
		    weakness = STRONG_PAWN;
		    break;
		  }
		}
	      }
	    }
	  }
	} while (0);

	/*-------------------------------------------------------------------
	 | Assign a penalty for weak pawns. Assign a greater penalty if the |
	 |  pawn is on a half open file.                                    |
	 -------------------------------------------------------------------*/
	if (weakness != STRONG_PAWN) {
	  if (weakness == LITTLE_WEAK_PAWN || weakness == POSSIBLY_WEAK_PAWN) {
	      if (!(col_bitboard[square2col[sq]] & board->piece[WHITE][PAWN]))
		pawn_struct.black_value -= 6;
	      else
		pawn_struct.black_value -= 3;
	  } else { //WEAK_PAWN
	    if (!(col_bitboard[square2col[sq]] & board->piece[WHITE][PAWN]))
	      pawn_struct.black_value -= 20;
	    else
	      pawn_struct.black_value -= 12;
	    pawn_struct.weak_pawn[BLACK] |= col_bitboard[square2col[sq]];
	    pawn_struct.pawn_hole[BLACK] |= square[sq+8];
	  }
	}

	/* Check for doubled pawns. */
	temp = bitcount(col_bitboard[square2col[sq]]
			& board->piece[WHITE][PAWN]);
	if (temp > 1) {
	  if (temp == 2)
	    pawn_struct.white_value -= 4;
	  else if (temp == 3)
	    pawn_struct.white_value -= 7;
	  else
	    pawn_struct.white_value -= 10;
	}

	/* Check for two pawns side by side. */
	if (pawn_duo[sq] & board->piece[WHITE][PAWN])
	  pawn_struct.white_value += 2;

      }

      /*-----------------------------------------------------------
       | A passed pawn is given an added constant value + a bonus |
       | related to the number of rows it has advanced.           |
       -----------------------------------------------------------*/
      if (!(passed_pawn[BLACK][sq] & board->piece[WHITE][PAWN])) {
	if (get_first_bitpos(col_bitboard[square2col[sq]]
			     & board->piece[BLACK][PAWN]) == sq)
	  pawn_struct.black_value += passed_pawn_val[BLACK][square2row[sq]];
	pawn_struct.passed_pawn[BLACK] |= col_bitboard[square2col[sq]];
	connected[BLACK] |= (1<<(square2col[sq]));

	/* A passed pawn that's blocked by an enemy piece is less valuable. */
	if ((board->all_pieces[WHITE] & ~(board->piece[WHITE][PAWN]))
	    & square[sq+8]) {
	  pawn_struct.black_value -=
	    blocking_passed_pawn_val[BLACK][square2row[sq]];
	}
      } else {
	/*-----------------------------------------------------------------
	 | Ok, so now we know that the pawn isn't a passed pawn, so check |
	 | if it's a "hidden" passed pawn (a pawn that can easily turn    |
	 | in to a passed pawn).                                          |
	 -----------------------------------------------------------------*/
	if (!(passed_pawn[BLACK][sq+8] & board->piece[WHITE][PAWN])
	    && (square2row[sq] > 4)
	    && (square[sq+8] & board->piece[WHITE][PAWN])
	    && (((square2col[sq] < 7)
		 && (square[sq-9] & board->piece[BLACK][PAWN])
		 && !(get_ray(sq-9,8) & board->piece[WHITE][PAWN])
		 && (square2col[sq] == 6
		     || !(get_ray(sq-10,8) & board->piece[WHITE][PAWN])))
		|| ((square2col[sq] > 0)
		    && (square[sq-7] & board->piece[BLACK][PAWN])
		    && !(get_ray(sq-7,8) & board->piece[WHITE][PAWN])
		    && (square2col[sq] == 1
			|| !(get_ray(sq-6,8) & board->piece[WHITE][PAWN]))))) {
	  pawn_struct.black_value += hidden_passed_pawn_val[BLACK][square2row[sq]];
	}
      }

      pieces &= ~(square[sq]);
    }

    /* Now give a non-linear penalty for isolated pawns. */
    if (isolated_pawns_white > 0) {
      pawn_struct.white_value -= isolated_pawn_val[isolated_pawns_white];
      if (isolated_pawns_white2 > 0) {
	pawn_struct.white_value -= isolated_pawn_val2[isolated_pawns_white2];
      }
    }
    if (isolated_pawns_black > 0) {
      pawn_struct.black_value -= isolated_pawn_val[isolated_pawns_black];
      if (isolated_pawns_black2 > 0) {
	pawn_struct.black_value -= isolated_pawn_val2[isolated_pawns_black2];
      }
    }

    /*----------------------------------------------
     | Check openings in the pawn chain for white. |
     ----------------------------------------------*/
    counter = 0;
    for (i = 0; i < 8; i++) {
      pawn_col = board->piece[WHITE][PAWN] & col_bitboard[i];
      if (pawn_col == 0) {
	counter++;
	if (board->piece[BLACK][PAWN] & col_bitboard[i]) {
	  pawn_struct.half_open_file[WHITE] |= col_bitboard[i];
	} else
	  pawn_struct.open_file |= col_bitboard[i];
      }
    }
    /*-----------------------------------------
     | It's bad to have no open files at all. |
     -----------------------------------------*/
    if (counter == 0)
      pawn_struct.white_value -= 20;

    /*----------------------------------------------
     | Check openings in the pawn chain for black. |
     ----------------------------------------------*/
    counter = 0;
    for (i = 0; i < 8; i++) {
      pawn_col = board->piece[BLACK][PAWN] & col_bitboard[i];
      if (pawn_col == 0) {
	counter++;
	if (board->piece[WHITE][PAWN] & col_bitboard[i]) {
	  pawn_struct.half_open_file[BLACK] |= col_bitboard[i];
	}
      }
    }
    /*-----------------------------------------
     | It's bad to have no open files at all. |
     -----------------------------------------*/
    if (counter == 0)
      pawn_struct.black_value -= 20;


    /*--------------------------------------------------
     | Give a higher value for connected passed pawns. |
     --------------------------------------------------*/
    //TODO: The following if clause can possibly be replaced with:
    //if (connected_bits[connected[WHITE]]) {
    if (bitcount(connected[WHITE]) > 1) {
      if (bitcount(connected[WHITE] & (128+64)) == 2) {
	pawn_struct.white_value += connected_passed_pawn_val[WHITE]
	  [maxval(square2row[get_last_bitpos(col_bitboard[7] & board->piece[WHITE][PAWN])],
		  square2row[get_last_bitpos(col_bitboard[6] & board->piece[WHITE][PAWN])])];
      }
      if (bitcount(connected[WHITE] & (64+32)) == 2) {
	pawn_struct.white_value += connected_passed_pawn_val[WHITE]
	  [maxval(square2row[get_last_bitpos(col_bitboard[6] & board->piece[WHITE][PAWN])],
		  square2row[get_last_bitpos(col_bitboard[5] & board->piece[WHITE][PAWN])])];
      }
      if (bitcount(connected[WHITE] & (32+16)) == 2) {
	pawn_struct.white_value += connected_passed_pawn_val[WHITE]
	  [maxval(square2row[get_last_bitpos(col_bitboard[5] & board->piece[WHITE][PAWN])],
		  square2row[get_last_bitpos(col_bitboard[4] & board->piece[WHITE][PAWN])])];
      }
      if (bitcount(connected[WHITE] & (16+8)) == 2) {
	pawn_struct.white_value += connected_passed_pawn_val[WHITE]
	  [maxval(square2row[get_last_bitpos(col_bitboard[4] & board->piece[WHITE][PAWN])],
		  square2row[get_last_bitpos(col_bitboard[3] & board->piece[WHITE][PAWN])])];
      }
      if (bitcount(connected[WHITE] & (8+4)) == 2) {
	pawn_struct.white_value += connected_passed_pawn_val[WHITE]
	  [maxval(square2row[get_last_bitpos(col_bitboard[3] & board->piece[WHITE][PAWN])],
		  square2row[get_last_bitpos(col_bitboard[2] & board->piece[WHITE][PAWN])])];
      }
      if (bitcount(connected[WHITE] & (4+2)) == 2) {
	pawn_struct.white_value += connected_passed_pawn_val[WHITE]
	  [maxval(square2row[get_last_bitpos(col_bitboard[2] & board->piece[WHITE][PAWN])],
		  square2row[get_last_bitpos(col_bitboard[1] & board->piece[WHITE][PAWN])])];
      }
      if (bitcount(connected[WHITE] & (2+1)) == 2) {
	pawn_struct.white_value += connected_passed_pawn_val[WHITE]
	  [maxval(square2row[get_last_bitpos(col_bitboard[1] & board->piece[WHITE][PAWN])],
		  square2row[get_last_bitpos(col_bitboard[0] & board->piece[WHITE][PAWN])])];
      }
    }

    //TODO: The following if clause can possibly be replaced with:
    //if (connected_bits[connected[BLACK]]) {
    if (bitcount(connected[BLACK]) > 1) {
      if (bitcount(connected[BLACK] & (128+64)) == 2) {
	pawn_struct.black_value += connected_passed_pawn_val[BLACK]
	  [minval(square2row[get_first_bitpos(col_bitboard[7] & board->piece[BLACK][PAWN])],
		  square2row[get_first_bitpos(col_bitboard[6] & board->piece[BLACK][PAWN])])];
      }
      if (bitcount(connected[BLACK] & (64+32)) == 2) {
	pawn_struct.black_value += connected_passed_pawn_val[BLACK]
	  [minval(square2row[get_first_bitpos(col_bitboard[6] & board->piece[BLACK][PAWN])],
		  square2row[get_first_bitpos(col_bitboard[5] & board->piece[BLACK][PAWN])])];
      }
      if (bitcount(connected[BLACK] & (32+16)) == 2) {
	pawn_struct.black_value += connected_passed_pawn_val[BLACK]
	  [minval(square2row[get_first_bitpos(col_bitboard[5] & board->piece[BLACK][PAWN])],
		  square2row[get_first_bitpos(col_bitboard[4] & board->piece[BLACK][PAWN])])];
      }
      if (bitcount(connected[BLACK] & (16+8)) == 2) {
	pawn_struct.black_value += connected_passed_pawn_val[BLACK]
	  [minval(square2row[get_first_bitpos(col_bitboard[4] & board->piece[BLACK][PAWN])],
		  square2row[get_first_bitpos(col_bitboard[3] & board->piece[BLACK][PAWN])])];
      }
      if (bitcount(connected[BLACK] & (8+4)) == 2) {
	pawn_struct.black_value += connected_passed_pawn_val[BLACK]
	  [minval(square2row[get_first_bitpos(col_bitboard[3] & board->piece[BLACK][PAWN])],
		  square2row[get_first_bitpos(col_bitboard[2] & board->piece[BLACK][PAWN])])];
      }
      if (bitcount(connected[BLACK] & (4+2)) == 2) {
	pawn_struct.black_value += connected_passed_pawn_val[BLACK]
	  [minval(square2row[get_first_bitpos(col_bitboard[2] & board->piece[BLACK][PAWN])],
		  square2row[get_first_bitpos(col_bitboard[1] & board->piece[BLACK][PAWN])])];
      }
      if (bitcount(connected[BLACK] & (2+1)) == 2) {
	pawn_struct.black_value += connected_passed_pawn_val[BLACK]
	  [minval(square2row[get_first_bitpos(col_bitboard[1] & board->piece[BLACK][PAWN])],
		  square2row[get_first_bitpos(col_bitboard[0] & board->piece[BLACK][PAWN])])];
      }
    }


    /*---------------------------------------------------
     | Record the pawn structure in the pawn hashtable. |
     ---------------------------------------------------*/
    record_pawn_hash(board,&pawn_struct);

  }

  *wval += pawn_struct.white_value;
  *bval += pawn_struct.black_value;
}

/*-----------------------
 | Evaluate the rooks. |
 -----------------------*/
void eval_rooks(struct board *board, int *wval, int *bval) {
  bitboard pieces;
  char saved_color;
  int nbr_open_files, sq;

  nbr_open_files = bitcount(pawn_struct.open_file & pawn_start[BLACK]);
  saved_color = Color;

  /*---------------------------------
   | Iterate through white's rooks. |
   ---------------------------------*/
  board->color_at_move = WHITE; //needed because generate_horizontal_moves used
  pieces = board->piece[WHITE][ROOK];
  while (pieces) {
    sq = get_first_bitpos(pieces);
    pieces &= ~(square[sq]);

    /* Check rook's placement. */
    *wval += rook_posval[sq];

    /*-----------------------------------------------------------------
     | Check if the rooks are behind a passed pawn and the pawn is    |
     | the only pawn on the file. Give a greater reward if it's a     |
     | passed pawn of own color, but also a little reward if the rook |
     | stands behind a passed pawn of enemy color.                    |
     -----------------------------------------------------------------*/
    if (square[sq] & pawn_struct.passed_pawn[WHITE]
	&& bitcount(board->piece[WHITE][PAWN]
		    & col_bitboard[square2col[sq]]
		    & pawn_struct.passed_pawn[WHITE]) == 1) {
      if (square2row[sq] >
	  square2row[get_first_bitpos(board->piece[WHITE][PAWN]
				      & col_bitboard[square2col[sq]]
				      & pawn_struct.passed_pawn[WHITE])]) {
	*wval += 24;
      }
    }
    if (square[sq] & pawn_struct.passed_pawn[BLACK]
	&& bitcount(board->piece[BLACK][PAWN]
		    & col_bitboard[square2col[sq]]
		    & pawn_struct.passed_pawn[BLACK]) == 1) {
      if (square2row[sq] <
	  square2row[get_last_bitpos(board->piece[BLACK][PAWN]
				     & col_bitboard[square2col[sq]]
				     & pawn_struct.passed_pawn[BLACK])])
	*wval += 5;
    }

    /*-------------------------------------------------------------------
     | If a rook is on the 7th rank and the opponent either has pawns   |
     | there, or else has the king trapped on the 8th rank, then that's |
     | rewarded, and if in addition to that there is more than one      |
     | rook on the 7th rank, then that's also rewarded.                 |
     -------------------------------------------------------------------*/
    if (square[sq] & pawn_start[BLACK]
	&& ((board->piece[BLACK][KING] & pawn_lastrow[WHITE])
	    || (board->piece[BLACK][PAWN] & pawn_start[BLACK]))) {
      *wval += 24;
      if (bitcount(board->piece[WHITE][ROOK] & pawn_start[BLACK]) > 1)
	*wval += 10;
    }

    /*------------------------------------------------------------------
     | If a weak pawn is on a half open file, then it's good to attack |
     | the weak pawn with a rook.                                      |
     ------------------------------------------------------------------*/
    if ((square[sq] & pawn_struct.weak_pawn[BLACK])
	&& (square[sq] & pawn_struct.half_open_file[WHITE])) {
      if (square2row[sq] >
	  square2row[get_last_bitpos(board->piece[BLACK][PAWN]
				     & col_bitboard[square2col[sq]])]) {
	*wval += 15;
      }
    }

    /*-------------------------------------------------------------
     | It's good to place rooks in open files. If the rook is not |
     | on an open file, but there are open files on the board,    |
     | then penalize the rook if it cannot reach any open file in |
     | one move. Give some points if the rook is on a half open   |
     | file (a file where there are no pawns of one's own color). |
     -------------------------------------------------------------*/
    if (square[sq] & pawn_struct.open_file)
      *wval += rook_open_file[nbr_open_files][square2col[sq]];
    else {
      if (pawn_struct.open_file) {
	if ((generate_horizontal_moves(board,sq)
	     & pawn_struct.open_file) == 0)
	  *wval -= 16;
      }
      if (square[sq] & pawn_struct.half_open_file[WHITE])
	*wval += 10;
    }
  }

  /*---------------------------------
   | Iterate through black's rooks. |
   ---------------------------------*/
  board->color_at_move = BLACK; //needed because generate_horizontal_moves used
  pieces = board->piece[BLACK][ROOK];
  while (pieces) {
    sq = get_first_bitpos(pieces);
    pieces &= ~(square[sq]);

    /* Check rook's placement. */
    *bval += rook_posval[sq];

    /*-----------------------------------------------------------------
     | Check if the rooks are behind a passed pawn and the pawn is    |
     | the only pawn on the file. Give a greater reward if it's a     |
     | passed pawn of own color, but also a little reward if the rook |
     | stands behind a passed pawn of enemy color.                    |
     -----------------------------------------------------------------*/
    if (square[sq] & pawn_struct.passed_pawn[BLACK]
	&& bitcount(board->piece[BLACK][PAWN]
		    & col_bitboard[square2col[sq]]
		    & pawn_struct.passed_pawn[BLACK]) == 1) {
      if (square2row[sq] <
	  square2row[get_last_bitpos(board->piece[BLACK][PAWN]
				     & col_bitboard[square2col[sq]]
				     & pawn_struct.passed_pawn[BLACK])])
	*bval += 24;
    }
    if (square[sq] & pawn_struct.passed_pawn[WHITE]
	&& bitcount(board->piece[WHITE][PAWN]
		    & col_bitboard[square2col[sq]]
		    & pawn_struct.passed_pawn[WHITE]) == 1) {
      if (square2row[sq] >
	  square2row[get_first_bitpos(board->piece[WHITE][PAWN]
				      & col_bitboard[square2col[sq]]
				      & pawn_struct.passed_pawn[WHITE])])
	*bval += 5;
    }

    /*-------------------------------------------------------------------
     | If a rook is on the 7th rank and the opponent either has pawns   |
     | there, or else has the king trapped on the 8th rank, then that's |
     | rewarded, and if in addition to that there is more than one      |
     | rook on the 7th rank, then that's also rewarded.                 |
     -------------------------------------------------------------------*/
    if (square[sq] & pawn_start[WHITE]
	&& ((board->piece[WHITE][KING] & pawn_lastrow[BLACK])
	    || (board->piece[WHITE][PAWN] & pawn_start[WHITE]))) {
      *bval += 24;
      if (bitcount(board->piece[BLACK][ROOK] & pawn_start[WHITE]) > 1)
	*bval += 10;
    }

    /*------------------------------------------------------------------
     | If a weak pawn is on a half open file, then it's good to attack |
     | the weak pawn with a rook.                                      |
     ------------------------------------------------------------------*/
    if ((square[sq] & pawn_struct.weak_pawn[WHITE])
	&& (square[sq] & pawn_struct.half_open_file[BLACK])) {
      if (square2row[sq] <
	  square2row[get_first_bitpos(board->piece[WHITE][PAWN]
				      & col_bitboard[square2col[sq]])]) {
	*bval += 15;
      }
    }

    /*-------------------------------------------------------------
     | It's good to place rooks in open files. If the rook is not |
     | on an open file, but there are open files on the board,    |
     | then penalize the rook if it cannot reach any open file in |
     | one move. Give some points if the rook is on a half open   |
     | file (a file where there are no pawns of one's own color). |
     -------------------------------------------------------------*/
    if (square[sq] & pawn_struct.open_file)
      *bval += rook_open_file[nbr_open_files][square2col[sq]];
    else {
      if (pawn_struct.open_file) {
	if ((generate_horizontal_moves(board,sq)
	     & pawn_struct.open_file) == 0)
	  *bval -= 16;
      }
      if (square[sq] & pawn_struct.half_open_file[BLACK])
	*bval += 10;
    }
  }
  board->color_at_move = saved_color;
}

/*-----------------------
 | Evaluate the queens. |
 -----------------------*/
void eval_queens(struct board *board, int *wval, int *bval) {
  bitboard pieces, piece;
  int sq;

  /*---------------------------------
   | Check white queen's placement. |
   ---------------------------------*/
  pieces = board->piece[WHITE][QUEEN];
  while (pieces) {
    sq = get_first_bitpos(pieces);
    pieces &= ~(square[sq]);
    *wval += queen_posval[sq];
  }

  /*---------------------------------
   | Check black queen's placement. |
   ---------------------------------*/
  pieces = board->piece[BLACK][QUEEN];
  while (pieces) {
    sq = get_first_bitpos(pieces);
    pieces &= ~(square[sq]);
    *bval += queen_posval[sq];
  }

  /*-----------------------------------------------------
   | 7th rank attacks by rook and queen is very strong. |
   -----------------------------------------------------*/
  if (board->piece[WHITE][QUEEN] & pawn_start[BLACK]
      && board->piece[WHITE][ROOK] & pawn_start[BLACK])
    *wval += 50;
  if (board->piece[BLACK][QUEEN] & pawn_start[WHITE]
      && board->piece[BLACK][ROOK] & pawn_start[WHITE])
    *bval += 50;

  /*----------------------------------------------
   | Give penalty for when the queen is offside. |
   ----------------------------------------------*/
  if (bitcount(board->piece[WHITE][PAWN]) > 4) {
    pieces = board->piece[WHITE][QUEEN];
    while (pieces != 0) {
      piece = getlsb(pieces);
      if ((piece & ab_col && board->piece[BLACK][KING] & gh_col)
	  || (piece & gh_col && board->piece[BLACK][KING] & ab_col))
	*wval -= 30;
      pieces &= ~piece;
    }
  }
  if (bitcount(board->piece[BLACK][PAWN]) > 4) {
    pieces = board->piece[BLACK][QUEEN];
    while (pieces != 0) {
      piece = getlsb(pieces);
      if ((piece & ab_col && board->piece[WHITE][KING] & gh_col)
	  || (piece & gh_col && board->piece[WHITE][KING] & ab_col))
	*bval -= 30;
      pieces &= ~piece;
    }
  }
}

/*------------------------
 | Evaluate the bishops. |
 ------------------------*/
void eval_bishops(struct board *board, int *wval, int *bval) {
  bitboard pieces;
  int sq;

  /*-----------------------------------
   | Iterate through white's bishops. |
   -----------------------------------*/
  pieces = board->piece[WHITE][BISHOP];
  while (pieces) {
    sq = get_first_bitpos(pieces);
    pieces &= ~(square[sq]);

    /* Check bishop's placement. */
    *wval += bishop_posval[sq];

    /*-----------------------------------------------------------
     | Check for a trapped bishop at a7, b8, h7 or g8 for white |
     -----------------------------------------------------------*/
    if (sq == 8 && board->piece[BLACK][PAWN] & square[17])
      *wval -= 174;
    else if (sq == 1 && board->piece[BLACK][PAWN] & square[10])
      *wval -= 174;
    if (sq == 15 && board->piece[BLACK][PAWN] & square[22])
      *wval -= 174;
    else if (sq == 6 && board->piece[BLACK][PAWN] & square[13])
      *wval -= 174;

    /*----------------------------------------------------
     | Check for bad bishops (far back in the corner and |
     | attacking own pawns from behind).                 |
     ----------------------------------------------------*/
    if (((sq >= 40 && sq <= 42)
	 || (sq >= 48 && sq <= 50)
	 || (sq >= 56 && sq <= 58))
	&& ((board->piece[WHITE][PAWN] & square[sq-7])
	    || (board->piece[WHITE][PAWN]
		& square[sq-14])))
      *wval -= 10;
    else if (((sq >= 45 && sq <= 47)
	      || (sq >= 53 && sq <= 55)
	      || (sq >= 61 && sq <= 63))
	     && ((board->piece[WHITE][PAWN] & square[sq-9])
		 || (board->piece[WHITE][PAWN]
		     & square[sq-18])))
      *wval -= 10;
  }

  /*-----------------------------------
   | Iterate through black's bishops. |
   -----------------------------------*/
  pieces = board->piece[BLACK][BISHOP];
  while (pieces) {
    sq = get_first_bitpos(pieces);
    pieces &= ~(square[sq]);

    /* Check bishop's placement. */
    *bval += bishop_posval[sq];

    /*-------------------------------------------------------------
      | Check for a trapped bishop at a2, b1, h2 or g1 for black. |
      ------------------------------------------------------------*/
    if (sq == 48 && board->piece[WHITE][PAWN] & square[41])
      *bval -= 174;
    else if (sq == 57 && board->piece[WHITE][PAWN] & square[50])
      *bval -= 174;
    if (sq == 55 && board->piece[WHITE][PAWN] & square[46])
      *bval -= 174;
    else if (sq == 62 && board->piece[WHITE][PAWN] & square[53])
      *bval -= 174;

    /*----------------------------------------------------
     | Check for bad bishops (far back in the corner and |
     | attacking own pawns from behind).                 |
     ----------------------------------------------------*/
    if (((sq >= 0 && sq <= 2)
	 || (sq >= 8 && sq <= 10)
	 || (sq >= 16 && sq <= 18))
	&& ((board->piece[BLACK][PAWN] & square[sq+9])
	    || (board->piece[BLACK][PAWN]
		& square[sq+18])))
      *bval -= 10;
    else if (((sq >= 5 && sq <= 7)
	      || (sq >= 13 && sq <= 15)
	      || (sq >= 21 && sq <= 23))
	     && ((board->piece[BLACK][PAWN] & square[sq+7])
		 || (board->piece[BLACK][PAWN]
		     & square[sq+14])))
      *bval -= 10;
  }

  /*------------------------------------------------------------
   | Check if bishops are placed in "holes" in the pawn chain. |
   ------------------------------------------------------------*/
  *wval += 8*bitcount(pawn_struct.pawn_hole[BLACK]
		      & board->piece[WHITE][BISHOP]);
  *bval += 8*bitcount(pawn_struct.pawn_hole[WHITE]
		      & board->piece[BLACK][BISHOP]);

  /*--------------------------------------------
   | Add points if a bishop is blocking one of |
   | the 2 center pawns.                       |
   --------------------------------------------*/
  if ((board->piece[WHITE][BISHOP] & square[19])
      && (board->piece[BLACK][PAWN] & square[11]))
    *wval += 12;
  if ((board->piece[WHITE][BISHOP] & square[20])
      && (board->piece[BLACK][PAWN] & square[12]))
    *wval += 12;
  if ((board->piece[BLACK][BISHOP] & square[43])
      && (board->piece[WHITE][PAWN] & square[51]))
    *bval += 12;
  if ((board->piece[BLACK][BISHOP] & square[44])
      && (board->piece[WHITE][PAWN] & square[52]))
    *bval += 12;

  /*-------------------------------------------------------------
   | If we are in the endgame and there are pawns on both sides |
   | of the board, then it's good to have a bishop.             |
   -------------------------------------------------------------*/
  if (endgame) {
    if ((abc_col
	 & (board->piece[WHITE][PAWN] | board->piece[BLACK][PAWN])) &&
	(fgh_col
	 & (board->piece[WHITE][PAWN] | board->piece[BLACK][PAWN]))) {
      if (board->piece[WHITE][BISHOP]
	  && board->piece[BLACK][BISHOP] == 0)
	*wval += 36;
      else if (board->piece[BLACK][BISHOP]
	  && board->piece[WHITE][BISHOP] == 0)
	*bval += 36;
    }
  }

  /*-----------------------------------------------------------------
   | Give bonus for having two bishops if the center isn't blocked. |
   -----------------------------------------------------------------*/
  if (bitcount(board->piece[WHITE][BISHOP]) >= 2) {
    if (pawn_struct.center == 1)
      *wval += 30;
    else if (pawn_struct.center == 2)
      *wval += 60;
  }
  if (bitcount(board->piece[BLACK][BISHOP]) >= 2) {
    if (pawn_struct.center == 1)
      *bval += 30;
    else if (pawn_struct.center == 2)
      *bval += 60;
  }
}


/*------------------------
 | Evaluate the knights. |
 ------------------------*/
void eval_knights(struct board *board, int *wval, int *bval) {
  bitboard pieces;
  int sq;

  /*-----------------------------------
   | Iterate through white's knights. |
   -----------------------------------*/
  pieces = board->piece[WHITE][KNIGHT];
  while (pieces) {
    sq = get_first_bitpos(pieces);
    pieces &= ~(square[sq]);

    /* Knights should be standing close to the middle. */
    *wval += knight_posval[sq];

    /*---------------------------------------------------------------
     | Check for pawn outposts (central pawn that can't be attacked |
     | by an enemy pawn and that is supported by a friendly pawn).  |
     ---------------------------------------------------------------*/
    if (white_outpost[sq] && !(possible_pawn_attack[BLACK][sq]
			       & board->piece[BLACK][PAWN])
	&& (attack.pawn[BLACK][sq] & board->piece[WHITE][PAWN]))
      *wval += white_outpost[sq];
  }

  /*-----------------------------------
   | Iterate through black's knights. |
   -----------------------------------*/
  pieces = board->piece[BLACK][KNIGHT];
  while (pieces) {
    sq = get_first_bitpos(pieces);
    pieces &= ~(square[sq]);

    /* Knights should be standing close to the middle. */
    *bval += knight_posval[sq];

    /*---------------------------------------------------------------
     | Check for pawn outposts (central pawn that can't be attacked |
     | by an enemy pawn and that is supported by a friendly pawn).  |
     ---------------------------------------------------------------*/
    if (black_outpost[sq] && !(possible_pawn_attack[WHITE][sq]
			       & board->piece[WHITE][PAWN])
	&& (attack.pawn[WHITE][sq] & board->piece[BLACK][PAWN]))
      *bval += black_outpost[sq];
  }

  /*------------------------------------------------------------
   | Check if knights are placed in "holes" in the pawn chain. |
   ------------------------------------------------------------*/
  *wval += 8*bitcount(pawn_struct.pawn_hole[BLACK]
		      & board->piece[WHITE][KNIGHT]);
  *bval += 8*bitcount(pawn_struct.pawn_hole[WHITE]
		      & board->piece[BLACK][KNIGHT]);

  /*--------------------------------------------
   | Add points if a knight is blocking one of |
   | the 2 center pawns.                       |
   --------------------------------------------*/
  if ((board->piece[WHITE][KNIGHT] & square[19])
      && (board->piece[BLACK][PAWN] & square[11]))
    *wval += 12;
  if ((board->piece[WHITE][KNIGHT] & square[20])
      && (board->piece[BLACK][PAWN] & square[12]))
    *wval += 12;
  if ((board->piece[BLACK][KNIGHT] & square[43])
      && (board->piece[WHITE][PAWN] & square[51]))
    *bval += 12;
  if ((board->piece[BLACK][KNIGHT] & square[44])
      && (board->piece[WHITE][PAWN] & square[52]))
    *bval += 12;
}

/*----------------------
 | Evaluate the kings. |
 ----------------------*/
void eval_kings(struct board *board, int *wval, int *bval) {
  bitboard all_pawns;
  int w_pos, b_pos;

  w_pos = get_first_bitpos(board->piece[WHITE][KING]);
  b_pos = get_first_bitpos(board->piece[BLACK][KING]);

  /* In endgames the king should be in the center if there are pawns
     on both wings, or otherwise on the wing where the pawns are. */
  if (endgame) {
    all_pawns = board->piece[WHITE][PAWN] | board->piece[BLACK][PAWN];
    if ((abcd_col & all_pawns) && (efgh_col & all_pawns)) {
      *wval += w_king_reach_endgame_normal[w_pos];
      *bval += b_king_reach_endgame_normal[b_pos];
    } else if (abcd_col & all_pawns) {
      *wval += w_king_reach_endgame_qside[w_pos];
      *bval += b_king_reach_endgame_qside[b_pos];
    } else if (all_pawns) {
      *wval += w_king_reach_endgame_kside[w_pos];
      *bval += b_king_reach_endgame_kside[b_pos];
    }
  } else {
    if (board->material_pieces[BLACK] >= VAL_KING + VAL_QUEEN + VAL_ROOK*2)
      *wval += king_reach_early[w_pos];
    else
      *wval += king_reach_late[w_pos];
    if (board->material_pieces[WHITE] >= VAL_KING + VAL_QUEEN + VAL_ROOK*2)
      *bval += king_reach_early[b_pos];
    else
      *bval += king_reach_late[b_pos];

    /* Add incentive to castle. */
    if (board->castling_status[WHITE] & CASTLED)
      *wval += 50;
    else if (board->castling_status[WHITE]
	     & (LONG_CASTLING_OK | SHORT_CASTLING_OK))
      *wval += 10;
    else
      *wval -= 50;
    if (board->castling_status[BLACK] & CASTLED)
      *bval += 50;
    else if (board->castling_status[BLACK]
	     & (LONG_CASTLING_OK | SHORT_CASTLING_OK))
      *bval += 10;
    else
      *bval -= 50;
  }


}

/*-------------------------------------------------------------------
 | This function returns a value for how good a position is. A high |
 | value for the player at move means he is well off in the game.   |
 -------------------------------------------------------------------*/
int eval(struct board *board, int alpha, int beta) {
  int wvalue = 0, bvalue = 0;
  bitboard pawns, pawn;
  int full_eval = 1;
  int temp_score;

  /* Check the material balance. */
  wvalue += board->material_pieces[WHITE] + board->material_pawns[WHITE];
  bvalue += board->material_pieces[BLACK] + board->material_pawns[BLACK];

  /*-------------------------------------------------------------------------
   | Add incentive to trade pieces when ahead, and trade pawns when behind. |
   -------------------------------------------------------------------------*/
  if (board->material_pieces[WHITE] > board->material_pieces[BLACK]) {
    if (board->material_pieces[BLACK] < presearch_pieceval[BLACK])
      wvalue += (presearch_pieceval[BLACK] - board->material_pieces[BLACK]) / 10;
    if (board->material_pawns[WHITE] < presearch_pawnval[WHITE])
      bvalue += 1;
  } else if (board->material_pieces[BLACK] > board->material_pieces[WHITE]) {
    if (board->material_pieces[WHITE] < presearch_pieceval[WHITE])
      bvalue += (presearch_pieceval[WHITE] - board->material_pieces[WHITE]) / 10;
    if (board->material_pawns[BLACK] < presearch_pawnval[BLACK])
      wvalue += 1;
  }

  /* Add the capture-values to make shallower captures (or promotions)
     to be worth a little bit more than deeper captures/promotions. This
     can be good if for example the engine detects that the loss of a pawn
     is inevitable to the maximum search depth. However beyond the horizon
     of the search it might turn out that it's indeed possible to save the
     pawn, and therefore we should try to keep it for as long as possible.
     Another use of this is if for example the engine has the possibility
     to promote a pawn to a queen. Then it needs some encouragement to do
     it soon, rather than waiting. */
  wvalue += board->captures[WHITE];
  bvalue += board->captures[BLACK];

  eval_pawns(board,&wvalue,&bvalue);

  if (endgame) {
    int wsquare, bsquare;
    wsquare = get_first_bitpos(board->piece[WHITE][KING]);
    bsquare = get_first_bitpos(board->piece[BLACK][KING]);

    if (endgame == KRK || endgame == KQK) {
      /* In KRK and KQK the color who is having the advantage should try
	 to force the enemy king to the side, and to come close with his king. */

      if (bitcount(board->all_pieces[WHITE]) > 1) {    //white is ahead
	wvalue -= dist_to_side[bsquare]*10;
	wvalue -= 2*(abs(wsquare%8-bsquare%8) + abs(wsquare/8-bsquare/8));
	wvalue -= dist_to_corn[bsquare];
	wvalue += dist_to_side[wsquare];
      } else {   //black is ahead
	bvalue -= dist_to_side[wsquare]*10;
	bvalue -= 2*(abs(wsquare%8-bsquare%8) + abs(wsquare/8-bsquare/8));
	bvalue -= dist_to_corn[wsquare];
	bvalue += dist_to_side[bsquare];
      }
    } else if (endgame == UNKNOWN_ENDGAME) {
      /* Make sure the opponent doesn't get an unstoppable passed pawn. */
      if (board->material_pieces[WHITE] == VAL_KING
	  && board->material_pawns[WHITE] == 0
	  && pawn_struct.passed_pawn[BLACK]) {
        pawns = pawn_struct.passed_pawn[BLACK] & board->piece[BLACK][PAWN];
	while (pawns != 0) {
	  pawn = getlsb(pawns);
	  if (dist_to_square[wsquare]
	      [get_first_bitpos(col_bitboard[get_first_bitpos(pawn)%8]
				& pawn_lastrow[BLACK])]
	      > dist_to_square[get_first_bitpos(pawn)]
	      [get_first_bitpos(col_bitboard[get_first_bitpos(pawn)%8]
				& pawn_lastrow[BLACK])]) {
	    wvalue -= 600;
	    pawns = 0;
	  }
	  pawns &= ~pawn;
	}
      } else if (board->material_pieces[BLACK] == VAL_KING
		 && board->material_pawns[BLACK] == 0
		 && pawn_struct.passed_pawn[WHITE]) {
        pawns = pawn_struct.passed_pawn[WHITE] & board->piece[WHITE][PAWN];
	while (pawns != 0) {
	  pawn = getlsb(pawns);
	  if (dist_to_square[bsquare]
	      [get_first_bitpos(col_bitboard[get_first_bitpos(pawn)%8]
				& pawn_lastrow[WHITE])]
	      > dist_to_square[get_first_bitpos(pawn)]
	      [get_first_bitpos(col_bitboard[get_first_bitpos(pawn)%8]
				& pawn_lastrow[WHITE])]) {
	    bvalue -= 600;
	    pawns = 0;
	  }
	  pawns &= ~pawn;
	}
      }
      /* If the king is losing, then force him to the edge of the board. */
      if (board->material_pieces[BLACK] <= VAL_KING + VAL_BISHOP
	  && board->material_pawns[BLACK] <= VAL_PAWN*2
	  && pawn_struct.passed_pawn[BLACK] == 0) {
	wvalue -= dist_to_side[bsquare]*10;
	wvalue -= 2*(abs(wsquare%8-bsquare%8) + abs(wsquare/8-bsquare/8));
	wvalue -= dist_to_corn[bsquare];
	wvalue += dist_to_side[wsquare];
      }
      if (board->material_pieces[WHITE] <= VAL_KING + VAL_BISHOP
	  && board->material_pawns[WHITE] <= VAL_PAWN*2
	  && pawn_struct.passed_pawn[WHITE] == 0) {
	bvalue -= dist_to_side[wsquare]*10;
	bvalue -= 2*(abs(wsquare%8-bsquare%8) + abs(wsquare/8-bsquare/8));
	bvalue -= dist_to_corn[wsquare];
	bvalue += dist_to_side[bsquare];
      }

      /*--------------------------------------------------------------------
	| Give a slightly higher value if the pawns are on opposite colored |
	| squares of the opponents bishop.                                  |
	--------------------------------------------------------------------*/
      if (bitcount(board->piece[BLACK][BISHOP]) == 1) {
	if (board->piece[BLACK][BISHOP] & white_squares)
	  pawn_struct.white_value += 2*bitcount(board->piece[WHITE][PAWN]
						& black_squares);
	else
	  pawn_struct.white_value += 2*bitcount(board->piece[WHITE][PAWN]
						& white_squares);
      }
      if (bitcount(board->piece[WHITE][BISHOP]) == 1) {
	if (board->piece[WHITE][BISHOP] & white_squares)
	  pawn_struct.black_value += 2*bitcount(board->piece[BLACK][PAWN]
						& black_squares);
	else
	  pawn_struct.black_value += 2*bitcount(board->piece[BLACK][PAWN]
						& white_squares);
      }
    }
  }

  /*----------------------------------------------------------------
   | Lazy evaluation:                                              |
   | If the current evaluation is so far outside of the alpha/beta |
   | bounds that the piece evaluation cannot bring the score back  |
   | inside the bounds, then skip the piece evaluation.            |
   ----------------------------------------------------------------*/
  temp_score = (Color == WHITE ? wvalue - bvalue : bvalue - wvalue);
  if (temp_score - 350 >= beta || temp_score + 350 <= alpha)
    full_eval = 0;
  if (full_eval) {
    eval_bishops(board,&wvalue,&bvalue);
    eval_knights(board,&wvalue,&bvalue);
    eval_kings(board,&wvalue,&bvalue);
    eval_queens(board,&wvalue,&bvalue);
    eval_rooks(board,&wvalue,&bvalue);
  }

  /* If the score is equal to draw_score(), then give an extra point to
     white. The reason for this is that draw_score's aren't stored in
     the hashtable. This way we make sure that we get as many
     hashtable hits as possible. (Also it shouldn't hurt anything to do this,
     since in practice white is ahead by being the first party to move).
     TODO: This could probably be removed if we make sure that in alphabeta()
     we check for draw by 50 move rule before probing the hashtable. */
  if (Color == WHITE) {
    if (wvalue - bvalue == draw_score())
      return (wvalue - bvalue) + 1;
    else
      return (wvalue - bvalue);
  } else {   //black's turn, invert the value
    if (bvalue - wvalue == draw_score())
      return (bvalue - wvalue) - 1;
    else
      return bvalue - wvalue;
  }
}
