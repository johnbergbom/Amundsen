#ifndef _THREADS_
#define _THREADS_

extern int start_input_thread();
void stop_input_thread();

#endif       //_THREADS_
